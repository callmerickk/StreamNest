package com.example.streamnest

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import java.util.concurrent.ConcurrentHashMap

/**
 * Addon stream requests, shared: while one request for a title is on its way, everyone else (title page, player,
 * upgrade search, Sources) waits for that same answer instead of sending their own; a good answer is reused for 45 s.
 * Fewer requests = the addon's server doesn't start refusing us ("too many requests").
 * The quick-play addon gets one more try after a short pause when it answers nothing or refuses (a busy moment).
 */
object AddonCalls {
    private val inFlight = ConcurrentHashMap<String, CompletableDeferred<List<StreamInfo>>>()
    private val recent = ConcurrentHashMap<String, Pair<Long, List<StreamInfo>>>()

    suspend fun streams(url: String, retry: Boolean): List<StreamInfo> {
        recent[url]?.let { (at, l) -> if (System.currentTimeMillis() - at < 45_000 && l.isNotEmpty()) return l }
        val mine = CompletableDeferred<List<StreamInfo>>()
        val other = inFlight.putIfAbsent(url, mine)
        if (other != null) return other.await()
        try {
            val l = fetch(url, retry)
            if (l.isNotEmpty()) recent[url] = System.currentTimeMillis() to l
            mine.complete(l)
            return l
        } catch (e: Throwable) {
            mine.completeExceptionally(e)
            throw e
        } finally {
            inFlight.remove(url, mine)
        }
    }

    private suspend fun fetch(url: String, retry: Boolean): List<StreamInfo> {
        val first = runCatching { Api.fetch<StreamResponse>(url).streams }
        val l = first.getOrNull()
        if (!retry || (l != null && l.isNotEmpty())) return l ?: throw first.exceptionOrNull()!!
        // Busy (429) → wait a little longer; empty / other error → a short pause. Then once more.
        val busy = first.exceptionOrNull()?.message?.contains("429") == true
        delay(if (busy) 2_500 else 1_200)
        return runCatching { Api.fetch<StreamResponse>(url).streams }.getOrNull() ?: l ?: throw first.exceptionOrNull()!!
    }

    /** A title's links failed / were refused: the next request asks the server again. */
    fun forgetTitle(id: String) { val k = id.substringBefore(':'); recent.keys.removeIf { it.contains(k) } }
}

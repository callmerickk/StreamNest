StreamX TV 0.9.7 (the phone app stays on 0.9.67)

• Next episode: the TV's refresh-rate change happens behind the loading screen; a pause caused by it plays on by itself.

StreamX TV 0.9.6 (the phone app stays on 0.9.67)

• Live / Curve: the frame sits on the picture again; lighter, smoother sliding (every 6.5 s); Glass follows the card you stop on.
• The update window works with the remote (▲ ▼ scroll the notes, Back = Later).
• Quality sheet: Other streams grouped by quality with names; streaming qualities read in the background; Auto keeps the stream.
• MovieBox shows named with their season ("New Girl S7") are found.
• Solid floating side bar; profile page posters first; activity log newest first.

StreamX TV 0.9.5 (the phone app stays on 0.9.67)

• Updates download fast on every network: through StreamX's own fast server first, GitHub as the backup.

StreamX TV 0.9.4 (the phone app stays on 0.9.67)

• Smarter search: shows listed with a later year are checked by their page (years and cast) — New Girl on MovieBox; series first, page 2 too; found pages remembered.
• Quality sheet exactly like Xstream (frame = chosen, coloured tick = playing), streaming levels listed, Auto drops on slow internet and climbs back.
• Loading screen with poster and heartbeat back; just a ring on stream change; Back / Sources reachable.
• Picture size button (Original, Crop, Fit); ▲ hides the options; faster Audio & Subtitles; steady Upgrade countdown.
• Live / Curve: endless side cards, 4 s glide, faces not cut, ★ rating. Profile page: bigger stack with details, new remote moves. Smooth Glass blur, round capsule.

StreamX TV 0.9.3 (the phone app stays on 0.9.67)

• Finds more: same-name titles from another year no longer block the right show (New Girl), season-named shows are found, slow sites are asked again, the working DNS is asked first.
• Live and Curve as big full cards; side bars open in their own style (or another one); Orbit = Xstream Live's bar; new Glass colours; Look inside Settings › Layout.
• Profile page: ▲ then ◀ ▶ through Continue watching. Sign out reachable; phone sign-in from the email page. Search Back → Discover, recent searches on the search page.
• Player: phone-style quality list, small Next episode card, plain loading ring.

StreamX TV 0.9.2 (the phone app stays on 0.9.67)

• Settings › Look: Home style (Sliding, Live, Curve), side bar (Slim, Glass, Orbit glow, Solid, Floating glass, Hidden) and colours (Midnight, Crimson, Elegant, Ocean) — any mix.
• Remote: ◀ ▶ on the big card only slide it; ▼ Play, then ◀ opens the side bar.
• New profile page: landscape cards of your last titles with Resume; Add first, main profile last; "Opening…" in a small note.
• Steadier DNS (MovieBox), less memory used by broken pages, a note for scenes after the credits.

StreamX TV 0.8.8 and StreamX 0.9.67

• TV: the sign-in QR code shows again; one OK opens the keyboard; voice works in the email box.
• TV: no more closing while scrolling Home fast; search fixed for repeat searches, spelling slips and lost connections.
• TV: refreshes itself after updates (voice search without clearing data); phone-style options on Pick up cards (no accidental play).
• TV: cleaner exit pop-up; film info no longer covers Quality; code names everywhere; faster starts and no loading screen when switching.
• Phone: Link a TV scanner opens upright; scanning the TV's QR and tapping Approve signs the TV in.

StreamX TV 0.8.7 and StreamX 0.9.66

TV 0.8.7
• Search asks one place only (TMDB): right order, whole film series together; Discover wall with posters of different sizes.
• Home like the phone: tall Trending posters, fresh shuffle, no cinema-only films (search still finds them).
• Films out at home play a web / Blu-ray copy, not a cinema recording (a cinema copy only as the last resort, with a note).
• Each source asked only for what it carries; 4K HDHUB starts ahead; less memory while a film starts.
• Bin reachable with ▲; rating pop-up keeps the remote inside; highlights match each button; notice once per TV and account.

Phone 0.9.66
• Settings › Account › Link a TV: scan the TV's QR code (or type the code) and approve.

StreamX TV 0.8.6 (the phone app stays on 0.9.65)

• Sign in with your phone: scan the QR code or type the 6-digit code in StreamX on your phone (Settings › Account › Link a TV) and approve. Email sign-in is still there.
• Sound formats (Dolby, DTS, TrueHD…) now use StreamX's own FFmpeg audio build.

StreamX TV 0.8.5 (the phone app stays on 0.9.65)

• Better quality is always reachable from the player bar (▲); its countdown waits while it is selected.
• Waits up to a minute for VegaMovies / RogMovies HD, then other sources; 4K TVs get "Upgrade to 4K".
• Seeking with the menu hidden: just the bar and a preview, 10 s steps that speed up when held, one jump on release.
• Quality list like the phone: Auto, 4K, 1080p 60fps, 1080p, 720p, 480p, Other streams.
• Search uses the TV's own keyboard and voice, plus a mic button; phone-style posters.
• Home like the phone: Pick up where you left off, numbered Trending, AIDEN picked for you; faster pictures and profiles.
• NOW PLAYING on Continue Watching when a title plays on another device; progress syncs within seconds.
• Audio & Subtitles: wider, every option reachable with the remote.
• A new row starts at its first card; hold OK on a card for its options.
• The bin next to Pick up where you left off: mark titles, Delete removes them and their cache.
• Turbo + Elite on from the start; Exit asks and can clear the cache.

StreamX TV 0.8.4 (the phone app stays on 0.9.65)

• Opens faster and lighter on Fire TV sticks.
• Smooth loading screen; streaming playlists climb to their best quality without pausing.
• Continue Watching works after an update (a fresh link from the same source, no error screen).
• Next Episode shows the episode's picture with the countdown.
• 1 GB sticks: fewer pictures in memory, no 60fps copies, no trailers.

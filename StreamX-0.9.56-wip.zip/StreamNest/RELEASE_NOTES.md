StreamX 0.9.54

• Meet AIDEN, your movie friend: he opens in a bubble from the AI button.
• AIDEN's words light up exactly as he says them.
• AIDEN says hello when the app opens, then waits for you.
• Most of the top cards on Home are AIDEN's picks for you.
• A new AI logo reaches every phone without restarting.

---

StreamX TV 0.8.1

• Home rows show the names set for everyone.

---

StreamX 0.9.53

• Play manually: Quick Play first (ready stream, then backups in order), then Turbo and Extensions.
• A stream you pick yourself is never swapped; no freezes when a stream fails.
• Download-only files hidden; Play manually shows Full HD and up.
• Faster posters, whole-video seek previews, notifications in a bubble.
• Profile capsule: water ripple and Add profile; hold and drag to reorder.
• Faster updates that keep going in the background.

---

StreamX TV 0.8.0

• Works with touch too: use StreamX TV on a tablet or a touch display.
• No freezes when a stream fails; download-only files hidden.
• Faster posters, whole-video seek previews, more Turbo sources.

---

StreamX 0.9.52

• Streams start faster: the quickest copy of each server is used.
• More shows found (an exact title match is no longer missed).
• "Not available" shows as soon as no server has the title.
• VPN: switched off stays off (it came back on by itself).

---

StreamX TV 0.7.7 beta

• Turbo streams start faster and more shows are found.
• "Not available" shows as soon as no server has the title.

---

StreamX 0.9.51

• Opening a plugin's settings (the gear) no longer closes the app on Android 12 and newer.
• Profile picker: the highlight is a round ring around the photo.

---

StreamX TV 0.7.6 beta

• Turbo comes to the TV: streams from big streaming catalogues start almost instantly (Settings › Sources & Extensions).
• The same official sources as the phone, kept warm while the app is open.
• If the instant backup started first, the better stream takes over at the same frame.
• Seek previews are made ahead while you watch.

---

StreamX 0.9.50

• Updates keep downloading when you minimise StreamX (with a notification), plus a Download in background button.
• New bottom bar: Home, Search, Library and Profile — hold Profile and slide up to switch profiles.
• A bell at the top of Home for notifications; the TV / Movies / Live switch is gone.
• Hold any poster for its trailer and ratings.
• Turbo is the default way to watch (recommended): streams start almost instantly; Classic is one tap away.
• Settings › Sources & Extensions, Extensions and Filters with your own rules.
• Netflix-style subtitles, smarter auto sync and Follow the speaker (beta).
• Faster seek previews; Continue Watching and episodes start faster.
• Fixes: plugin settings no longer close the app, Proton VPN sign-in, GIF search.

---

StreamX TV 0.7.5 beta

• Trailers on the home screen are switched off for now, so moving around is smooth again.
• Loading screen: a calm dark background, with the moment playing inside the card and the progress around its edge.

---

StreamX TV 0.7.4 beta

• Search waits for you: type, then press Search. It no longer crashes the Fire TV Stick.
• New loading screen: a large card with the progress around its edge and the heartbeat line under it, over a blurred picture.
• The loading screen goes away as soon as the video plays.
• The Next episode pop-up shows near the end of every episode.
• Trailers are back in the big Home card, playing as real video.

---

StreamX 0.9.47 · StreamX TV 0.7.3 beta

Phone
• Watch together is a full page: watch friends, introductions (everyone decides who can see them), shared lists with plans, chats and privacy.
• Watchlist calendar: new episodes, release days and your plans; everyone in a plan is reminded at the same time and can join the room.
• Chats: one-to-one with view-once photos (screenshots blocked) and a 24 h – 7 day keep time; groups are text only and clear after 24 hours.
• My Space: your own dashboard, Library and Watch together, Watchlist, Notifications, Clear Continue Watching.
• Upgrade quality pops up again when a sharper file is ready.
• GIF profile pictures without any key, or paste any GIF link.

TV
• Upgrade quality ring fits and the pill goes away when its time ends; movies keep Next inside More.
• Lighter loading screen; Choose manually, pop-ups, Settings and Search work properly with the remote; bigger search keys and Fire TV voice typing.

---

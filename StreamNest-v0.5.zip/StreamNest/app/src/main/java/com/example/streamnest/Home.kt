package com.example.streamnest

import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

@Composable
private fun SectionTitle(text: String) =
    Text(text, fontSize = 21.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFE6E9F2),
        maxLines = 1, overflow = TextOverflow.Ellipsis,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 26.dp, bottom = 12.dp))

/** The app's logo: the uploaded one from Developer's Corner, or the built-in red mark. */
@Composable
fun AppLogo(vm: AppViewModel, size: Dp, modifier: Modifier = Modifier) {
    val ver by vm.imgVersion.collectAsStateWithLifecycle()
    val custom = remember(ver) { vm.logoFile().takeIf { it.exists() } }
    if (custom != null) AsyncImage(custom, null, modifier.size(size).clip(RoundedCornerShape(size * 0.22f)), contentScale = ContentScale.Crop)
    else Image(painterResource(R.drawable.logo_mark), null, modifier.size(size))
}

private data class DeckItem(val meta: Meta, val catalog: String)

@Composable
fun HomeScreen(
    vm: AppViewModel,
    listState: LazyListState,
    chromeVisible: Boolean,
    onOpen: (Meta) -> Unit,
    onPlay: (Screen.Player) -> Unit,
    onLive: () -> Unit,
    onAi: () -> Unit,
) {
    val allShelves by vm.shelves.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val myList by vm.myList.collectAsStateWithLifecycle()
    val profile by vm.current.collectAsStateWithLifecycle()
    var filter by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current

    val hasSports = remember(allShelves) { allShelves.any { it.title.contains("sport", ignoreCase = true) } }
    val rowsOrder = t("rowsOrder")
    val rowsHidden = t("rowsHidden")
    val arranged = remember(allShelves, rowsOrder, rowsHidden) {
        val hidden = rowsHidden.split("|").toSet()
        arrangeShelves(allShelves, rowsOrder).filter { it.title !in hidden }
    }
    val shelves = remember(arranged, filter) {
        arranged.filter { s ->
            when (filter) {
                null -> true
                "sports" -> s.title.contains("sport", ignoreCase = true)
                else -> s.items.firstOrNull()?.type == filter
            }
        }
    }
    // Top cards: mix the first two rows (e.g. popular movies + popular series).
    val deck = remember(shelves) {
        val a = shelves.getOrNull(0)?.let { s -> s.items.map { DeckItem(it, s.title) } }.orEmpty()
        val b = shelves.getOrNull(1)?.let { s -> s.items.map { DeckItem(it, s.title) } }.orEmpty()
        (0 until maxOf(a.size, b.size)).flatMap { listOfNotNull(a.getOrNull(it), b.getOrNull(it)) }
            .filter { it.meta.poster != null }.distinctBy { it.meta.id }.take(10)
    }

    val autoSlide = t("autoSlide").trim().lowercase() != "no"
    val slideSecs = t("slideSeconds").trim().toIntOrNull()?.coerceIn(2, 20) ?: 5
    val showBrand = t("showBrand").trim().lowercase() == "yes"
    val appName = t("appName")
    val cwStyle = t("cwStyle")
    val showHero = isOn(t("showHero"))
    val cwShow = isOn(t("cwShow"))
    val continueTitle = t("continueWatching").replace("{name}", profile?.name ?: "")
    val newOn = t("newOn").replace("{app}", appName)
    val pillLabels = buildList {
        add(t("pillLeft") to "series")
        add(t("pillRight") to "movie")
        if (hasSports) add(t("pillSports") to "sports")
        add(t("pillLive") to "live")
    }

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxWidth().height(600.dp).background(Brush.verticalGradient(listOf(Palette.tint, Bg))))

        LazyColumn(Modifier.fillMaxSize(), state = listState) {
            item {
                Row(Modifier.statusBarsPadding().padding(start = 16.dp, end = 16.dp, top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    val pill = RoundedCornerShape(50)
                    Row(
                        Modifier.clip(pill).background(Color(0x99101420))
                            .border(1.dp, Brush.horizontalGradient(listOf(Accent, Accent.copy(alpha = 0.25f))), pill)
                            .padding(start = 6.dp, end = if (showBrand) 16.dp else 6.dp, top = 6.dp, bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        AppLogo(vm, 28.dp)
                        if (showBrand) {
                            Spacer(Modifier.width(8.dp))
                            Text(appName, fontFamily = BrandFont, fontWeight = FontWeight.Bold, fontSize = 18.sp, letterSpacing = (-0.5).sp)
                        }
                    }
                }
            }
            item {
                Text(t("forYou"), fontSize = 26.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFEDEFF7),
                    modifier = Modifier.padding(start = 16.dp, top = 18.dp, bottom = 16.dp))
            }
            if (shelves.isEmpty()) {
                item {
                    Box(Modifier.fillMaxWidth().height(420.dp), Alignment.Center) {
                        if (loading) CircularProgressIndicator(color = Accent) else Text(t("emptyMsg"), Modifier.padding(32.dp))
                    }
                }
            } else {
                if (showHero) item { Deck(deck, myList, autoSlide, slideSecs, onOpen) { vm.toggleList(it) } }
            }
            if (progress.isNotEmpty() && filter == null && cwShow) {
                item { SectionTitle(continueTitle) }
                item {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(progress, key = { it.key }) { p ->
                            ContinueCard(p, cwStyle, onClick = { onPlay(Screen.Player(p.title, p.url, p.subs, p.key, p.image, p.positionMs)) }, onRemove = { vm.removeProgress(p.key) })
                        }
                    }
                }
            }
            items(shelves) { shelf ->
                SectionTitle(if (shelf.title.startsWith("New")) "$newOn · ${shelf.title.removePrefix("New ").trim()}" else shelf.title)
                ShelfRow(shelf.items, onOpen)
            }
            item { Spacer(Modifier.navigationBarsPadding().height(180.dp)) }
        }

        AnimatedVisibility(
            visible = chromeVisible,
            enter = slideInVertically(tween(250)) { it * 2 } + fadeIn(),
            exit = slideOutVertically(tween(250)) { it * 2 } + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 70.dp),
        ) {
            FloatingFilters(
                filter = filter,
                labels = pillLabels,
                onFilter = { type -> if (type == "live") onLive() else filter = if (filter == type) null else type },
                onTop = { scope.launch { listState.animateScrollToItem(0) } },
                onAi = onAi,
            )
        }
    }
}

// Poster Card Style (Help & Settings > Layout > Poster Card Style)
val PosterWidths = linkedMapOf("Compact" to 100, "Dense" to 112, "Standard" to 120, "Balanced" to 126, "Comfort" to 140, "Large" to 156)
val PosterCorners = linkedMapOf("Sharp" to 0, "Subtle" to 4, "Classic" to 8, "Rounded" to 12, "Pill" to 22)

@Composable fun posterWidth(): Dp = (PosterWidths[t("posterWidth")] ?: 126).dp
@Composable fun posterCorner(): Dp = (PosterCorners[t("posterCorner")] ?: 12).dp

/** Applies the row order chosen in Home Layout; rows not in the list keep their original order at the end. */
fun arrangeShelves(all: List<Shelf>, order: String): List<Shelf> {
    val wanted = order.split("|").filter { it.isNotBlank() }
    return all.withIndex().sortedBy { (i, s) -> wanted.indexOf(s.title).let { if (it < 0) 10_000 + i else it } }.map { it.value }
}

/** A home row: wide landscape cards (Hotstar style) or tall posters, depending on settings. */
@Composable
fun ShelfRow(items: List<Meta>, onOpen: (Meta) -> Unit) {
    val landscape = isOn(t("landscapePosters"))
    val w = posterWidth()
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(items, key = { it.type + it.id }) { m ->
            if (landscape) LandscapeCard(m, w * 1.87f) { onOpen(m) } else Poster(m, Modifier.width(w), onOpen)
        }
    }
}

@Composable
fun LandscapeRow(items: List<Meta>, onOpen: (Meta) -> Unit) =
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(items, key = { it.type + it.id }) { m -> LandscapeCard(m) { onOpen(m) } }
    }

/** Wide 16:9 card: backdrop artwork with the title logo on top (Hotstar style). */
@Composable
fun LandscapeCard(m: Meta, width: Dp = 236.dp, onClick: () -> Unit) {
    var logoFailed by remember(m.id) { mutableStateOf(false) }
    val hideLabels = isOn(t("hideLabels"))
    Box(Modifier.width(width).aspectRatio(16f / 9f).clip(RoundedCornerShape(posterCorner())).background(Surface1).clickable(onClick = onClick)) {
        AsyncImage(backdropOf(m), m.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0f to Color(0xCC000000), 0.65f to Color.Transparent)))
        val logo = logoOf(m)
        if (!hideLabels) Box(Modifier.align(Alignment.BottomStart).padding(10.dp).fillMaxWidth(0.55f)) {
            if (logo != null && !logoFailed) {
                AsyncImage(logo, m.name, Modifier.fillMaxWidth().height(42.dp), contentScale = ContentScale.Fit,
                    alignment = Alignment.BottomStart, onError = { logoFailed = true })
            } else {
                Text(m.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun Deck(items: List<DeckItem>, myList: List<Meta>, auto: Boolean, secs: Int, onOpen: (Meta) -> Unit, onToggle: (Meta) -> Unit) {
    if (items.isEmpty()) return
    val cardW = (LocalConfiguration.current.screenWidthDp * 0.83f).dp
    val pager = rememberPagerState { items.size }
    val dragged by pager.interactionSource.collectIsDraggedAsState()

    // Auto-slide every few seconds; pauses while a finger is on the cards.
    LaunchedEffect(auto, secs, dragged, items.size) {
        if (!auto || dragged || items.size < 2) return@LaunchedEffect
        while (true) {
            delay(secs * 1000L)
            pager.animateScrollToPage((pager.currentPage + 1) % items.size, animationSpec = tween(700))
        }
    }

    HorizontalPager(
        state = pager,
        pageSize = PageSize.Fixed(cardW),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp),
        beyondViewportPageCount = 3,
        modifier = Modifier.fillMaxWidth(),
    ) { page ->
        val d = items[page]
        DeckCard(
            d.meta, rank = page + 1, catalog = d.catalog, saved = myList.any { it.id == d.meta.id },
            onOpen = { onOpen(d.meta) }, onToggle = { onToggle(d.meta) },
            modifier = Modifier
                .zIndex(-abs(page - pager.currentPage).toFloat())
                .graphicsLayer {
                    val r = page - pager.currentPage - pager.currentPageOffsetFraction
                    val s = 1f - 0.06f * minOf(abs(r), 2.5f)
                    scaleX = s; scaleY = s
                    if (r > 0f) translationX = -minOf(r, 3f) * size.width * 0.88f
                    alpha = if (r > 2.6f) 0f else 1f - 0.18f * minOf(abs(r), 2f)
                },
        )
    }
}

@Composable
private fun DeckCard(m: Meta, rank: Int, catalog: String, saved: Boolean, onOpen: () -> Unit, onToggle: () -> Unit, modifier: Modifier) {
    val shape = RoundedCornerShape(Palette.corner.dp)
    val rating = m.imdbRating?.toDoubleOrNull()
    val rankText = t("badge").replace("{rank}", rank.toString()).replace("{catalog}", catalog)
    var logoFailed by remember(m.id) { mutableStateOf(false) }
    Box(modifier.fillMaxWidth().aspectRatio(0.76f).clip(shape).background(Color(0xFF05070C)).clickable(onClick = onOpen)) {
        AsyncImage(m.poster ?: backdropOf(m), m.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.42f to Color.Transparent, 0.82f to Color(0xEE000000), 1f to Color.Black)))

        // Badge: IMDb score for highly rated titles, otherwise the rank in its row.
        val badgeShape = RoundedCornerShape(14.dp)
        if (rating != null && rating >= 7.5) {
            Row(Modifier.padding(16.dp).clip(badgeShape).background(Color(0x99000000)).border(1.dp, Color(0x33FFFFFF), badgeShape)
                .padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clip(RoundedCornerShape(4.dp)).background(Color(0xFFF5C518)).padding(horizontal = 5.dp, vertical = 2.dp)) {
                    Icon(Icons.Default.Star, null, Modifier.size(14.dp), tint = Color.Black)
                }
                Spacer(Modifier.width(8.dp))
                Text("IMDb ${m.imdbRating}", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
        } else if (rankText.isNotBlank()) {
            Row(Modifier.padding(16.dp).clip(badgeShape).background(Color(0x99000000)).border(1.dp, Color(0x33FFFFFF), badgeShape)
                .padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.WorkspacePremium, null, Modifier.size(20.dp), tint = Color(0xFFFFB13B))
                Spacer(Modifier.width(8.dp))
                Text(rankText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
            val logo = logoOf(m)
            if (logo != null && !logoFailed) {
                AsyncImage(logo, m.name, Modifier.fillMaxWidth(0.85f).height(84.dp), contentScale = ContentScale.Fit,
                    alignment = Alignment.BottomStart, onError = { logoFailed = true })
            } else {
                Text(m.name, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(10.dp))
            Text(
                (listOfNotNull(m.releaseInfo?.take(4)) + m.genres.orEmpty().take(2)).joinToString("  •  "),
                fontSize = 15.sp, color = Color(0xFFC9CEDB), maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassButton(Modifier.weight(1f).height(52.dp), onOpen) {
                    Icon(Icons.Default.PlayArrow, null, Modifier.size(28.dp)); Spacer(Modifier.width(6.dp))
                    Text(t("watchNow"), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                }
                GlassButton(Modifier.size(52.dp), onToggle) {
                    Icon(if (saved) Icons.Default.Check else Icons.Default.Add, if (saved) "In Watchlist" else "Add to Watchlist")
                }
            }
        }
    }
}

@Composable
private fun GlassButton(modifier: Modifier, onClick: () -> Unit, content: @Composable RowScope.() -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(modifier.clip(shape).background(Color(0x3DFFFFFF)).border(1.dp, Color(0x26FFFFFF), shape).clickable(onClick = onClick),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically, content = content)
}

/** Continue Watching card. style: "card" (TV-style), "wide" (info on the artwork) or "poster" (tall). */
@Composable
fun ContinueCard(p: Progress, style: String = "card", onClick: () -> Unit, onRemove: () -> Unit) {
    val frac = if (p.durationMs > 0) (p.positionMs.toFloat() / p.durationMs).coerceIn(0f, 1f) else 0f
    val leftMin = if (p.durationMs > 0) ((p.durationMs - p.positionMs) / 60000).toInt() else 0
    val left = if (p.durationMs <= 0) "Resume" else if (leftMin >= 60) "${leftMin / 60}h ${leftMin % 60}m left" else "${maxOf(leftMin, 1)}m left"
    var menu by remember { mutableStateOf(false) }
    val corner = posterCorner()
    val more: @Composable () -> Unit = {
        Box {
            Icon(Icons.Default.MoreVert, "More", Modifier.clip(CircleShape).clickable { menu = true }.padding(2.dp).size(22.dp), tint = Color(0xFFB6BDCC))
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Remove from Continue Watching") }, onClick = { menu = false; onRemove() })
            }
        }
    }
    val bar: @Composable () -> Unit = {
        Box(Modifier.fillMaxWidth().height(3.dp).background(Color(0x33FFFFFF))) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(Accent))
        }
    }
    when (style) {
        "wide" -> Box(Modifier.width(300.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(corner)).background(Surface1).clickable(onClick = onClick)) {
            AsyncImage(p.image, p.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.35f to Color.Transparent, 1f to Color(0xE6000000))))
            Row(Modifier.align(Alignment.BottomStart).padding(start = 12.dp, end = 6.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PlayCircle, null, Modifier.size(34.dp))
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(p.title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(left, fontSize = 12.sp, color = Color(0xFFC9CEDB))
                }
                more()
            }
            Box(Modifier.align(Alignment.BottomCenter)) { bar() }
        }
        "poster" -> Column(Modifier.width(posterWidth())) {
            Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(RoundedCornerShape(corner)).background(Surface1).clickable(onClick = onClick)) {
                AsyncImage(p.image, p.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Icon(Icons.Default.PlayCircle, null, Modifier.align(Alignment.Center).size(40.dp))
                Box(Modifier.align(Alignment.BottomCenter)) { bar() }
            }
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(left, Modifier.weight(1f), fontSize = 12.sp, color = Color(0xFF8A94A8), maxLines = 1)
                more()
            }
        }
        else -> Column(Modifier.width(236.dp)) {
            Column(Modifier.clip(RoundedCornerShape(corner)).clickable(onClick = onClick)) {
                Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Surface1)) {
                    AsyncImage(p.image, p.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.6f to Color.Transparent, 1f to Color(0x99000000))))
                    Icon(Icons.Default.PlayArrow, null, Modifier.align(Alignment.BottomStart).padding(8.dp).size(30.dp))
                }
                bar()
            }
            Row(Modifier.padding(top = 8.dp, start = 4.dp), verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text(p.title, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(left, fontSize = 13.sp, color = Color(0xFF8A94A8))
                }
                more()
            }
        }
    }
}

/** Hotstar-style capsule (centred) with the AI voice button on the right. */
@Composable
private fun FloatingFilters(
    filter: String?,
    labels: List<Pair<String, String>>,
    onFilter: (String) -> Unit,
    onTop: () -> Unit,
    onAi: () -> Unit,
) {
    val pill = RoundedCornerShape(50)
    val maxCapsule = (LocalConfiguration.current.screenWidthDp - 2 * (12 + 52 + 8)).dp
    Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
        Row(
            Modifier.align(Alignment.Center).widthIn(max = maxCapsule)
                .shadow(14.dp, pill)
                .clip(pill)
                .background(Brush.horizontalGradient(listOf(Color(0xF2263070), Color(0xF24A2468))))
                .border(1.dp, Color(0x33FFFFFF), pill).padding(horizontal = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            labels.forEach { (label, type) ->
                Text(label, Modifier.clip(pill).clickable { onFilter(type) }.padding(horizontal = 11.dp, vertical = 12.dp),
                    fontSize = 15.sp, fontWeight = if (filter == type) FontWeight.Bold else FontWeight.Medium, maxLines = 1,
                    color = if (filter == type) Color.White else Color(0xC8FFFFFF))
                Box(Modifier.width(1.dp).height(18.dp).background(Color(0x44FFFFFF)))
            }
            Icon(Icons.Default.KeyboardArrowUp, "Back to top", Modifier.clip(CircleShape).clickable(onClick = onTop).padding(horizontal = 8.dp, vertical = 10.dp).size(24.dp))
        }
        Box(Modifier.align(Alignment.CenterEnd).shadow(14.dp, CircleShape)) { AiOrbButton(52.dp, onAi) }
    }
}

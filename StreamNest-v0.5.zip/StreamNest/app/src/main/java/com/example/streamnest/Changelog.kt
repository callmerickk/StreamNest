package com.example.streamnest

/** Release notes shown in Help & Settings > Update Log. Newest first. Add a new entry with every version. */
data class Release(val version: String, val date: String, val title: String, val changes: List<String>)

val Changelog = listOf(
    Release(
        "0.5", "10 Oct 2026", "The new player",
        listOf(
            "Brand-new full-screen player: big centre controls, ±10 s skip, thick seek bar and time display",
            "Content advisory box (Violence, Profanity, Nudity…) at the top-left when a title starts",
            "Choose subtitles and audio tracks inside the player",
            "Subtitle style: size, bold, text colour, background and outline (Playback settings)",
            "Switch source while watching, keeping your position",
            "Next Episode button and optional auto-play of the next episode",
            "Skip Intro / Skip Recap using the free IntroDB database",
            "Info screen appears when you pause (title, year, rating, genres, story)",
            "Playback speed, aspect ratio (Fit, Crop, Stretch), screen lock, double-tap to skip",
            "Open any stream in VLC, MX Player or another app, or make an external player the default",
            "Auto Stream Selection: play the first source or the first one matching your pattern",
            "Playback settings page is now live",
            "Update Log (this page) replaces Check for updates",
            "Fixed: the AI voice button could close the app when used a second time",
        ),
    ),
    Release(
        "0.4", "10 Oct 2026", "AI voice & new settings",
        listOf(
            "AI voice button next to the capsule: tell it your mood or say what to play",
            "Capsule centred and smaller; bottom bar glow polished",
            "Help & Settings redesigned in sections: Account, General, About, Advanced",
            "Themes: 7 classic, 5 gradient and Custom; AMOLED black; navigation bar styles",
            "Home Layout: hero on/off, slide speed, hide and reorder rows",
            "Continue Watching styles: Card, Wide, Poster",
            "Poster Card Style with live preview",
            "Addons page: stats, on/off switch, reorder, refresh",
            "Remember last profile; Developer's Corner moved into Advanced",
        ),
    ),
    Release(
        "0.3", "10 Oct 2026", "Hotstar-style redesign",
        listOf(
            "New red logo and app icon",
            "\"Who's watching?\" profiles with a Kids profile",
            "Profile pictures can be photos, GIFs or short looping videos",
            "Home redesigned: For You cards, wide rows with title logos",
            "Bottom bar with Home, Search and My Space and a glowing curved edge",
            "Capsule and bar hide/shrink while scrolling",
            "My Space with Help & Settings, profiles, watchlist and Continue Watching",
            "Permanent signing key: updates now install over the old app",
        ),
    ),
    Release(
        "0.2", "10 Oct 2026", "Deck home & customisation",
        listOf(
            "Disney+/Hotstar-style stacked card deck that slides automatically",
            "Continue Watching and My List",
            "Settings and My Profile pages with stats",
            "Developer's Corner with password, app name and logo editing",
            "Live TV from M3U playlists",
        ),
    ),
    Release(
        "0.1", "9 Oct 2026", "First version",
        listOf(
            "Browse Cinemeta movie and series catalogs",
            "Install Stremio-style addons by link",
            "Search, detail pages with seasons and episodes",
            "Built-in player with subtitles and resume",
        ),
    ),
)

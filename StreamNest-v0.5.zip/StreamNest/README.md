# StreamNest
Disney+/Hotstar-inspired Android app (Kotlin, Compose, Media3 ExoPlayer).

- Start: "Who's watching?" profile picker (per-profile history & watchlist; Kids profile shows animated/family titles)
- Navigation: Home / Search / My Space. All settings live behind My Space -> Help & Settings
- Customize: Help & Settings -> Advanced -> Developer's Corner (password protected)
- Icon: res/drawable/ic_launcher_*.xml + res/mipmap-*; name under the icon: res/values/strings.xml
- Signing: app/streamnest.keystore is used for every build so updates install over the old app. Never delete it.
- Metadata: Cinemeta (built-in, default addon)
- Addons: Stremio addon protocol (catalog / meta / stream / subtitles)
- Player: Media3 ExoPlayer (Apache-2.0), CC button for subtitle tracks
- Only direct-URL streams (HTTP/HLS/DASH) play. Torrent/infoHash streams are not supported.

## Build
1. Open this folder in Android Studio (Koala or newer). It generates the Gradle wrapper.
2. Sync, then Run on a device/emulator (minSdk 24).

- Voice assistant: AI button next to the capsule. Mood -> genre rules live in Voice.kt (offline, no API key)
- Changelog: Changelog.kt (shown in Help & Settings > Update Log). Add an entry every version.
- Version: v0.5 (versionCode 5). Every build: versionCode +1, versionName 0.<code>

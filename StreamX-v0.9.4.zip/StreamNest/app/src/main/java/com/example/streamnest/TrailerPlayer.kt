package com.example.streamnest

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color as AColor
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlinx.coroutines.delay

/*
 * Full-screen, landscape trailer player: YouTube's IFrame player without its own controls (controls:0),
 * with StreamX controls drawn on top. Plays the list in order, then offers "Play the movie".
 */

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private fun fmtClock(sec: Double): String {
    val s = sec.toInt().coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

/** The red Play pill (same look as the title page's Play button). */
@Composable
fun RedPill(text: String, modifier: Modifier = Modifier, height: Int = 60, fontSize: Int = 22, onClick: () -> Unit, onLongClick: (() -> Unit)? = null, content: @Composable BoxScope.() -> Unit = {}) {
    val shape = RoundedCornerShape((height / 2).dp)
    val click by rememberUpdatedState(onClick)
    val longClick by rememberUpdatedState(onLongClick)
    val hasLong = onLongClick != null
    val tap = Modifier.pointerInput(hasLong) {
        detectTapGestures(onTap = { click() }, onLongPress = if (hasLong) { _: Offset -> longClick?.invoke() } else null)
    }
    Box(
        modifier.height(height.dp)
            .shadow(10.dp, shape, ambientColor = Color.Black, spotColor = Color.Black)
            .border(1.dp, Color(0x59E50914), shape)
            .padding(1.dp)
            .clip(shape)
            .background(Brush.verticalGradient(0f to Color(0xFFF0242E), 0.55f to Color(0xFFD10A14), 1f to Color(0xFFA8060E)))
            .drawBehind {
                // thin top highlight
                val y = 3.dp.toPx()
                val inset = size.height * 0.45f
                drawLine(Color(0x59FFFFFF), Offset(inset, y), Offset(size.width - inset, y), strokeWidth = 1.dp.toPx())
            }
            .border(2.dp, Color.Black, shape)
            .then(tap),
        Alignment.Center,
    ) {
        Text(
            text, Modifier.padding(horizontal = 14.dp), maxLines = 1, overflow = TextOverflow.Ellipsis,
            style = TextStyle(
                fontFamily = BrandFont, fontWeight = FontWeight.Bold, fontSize = fontSize.sp, letterSpacing = (-0.2).sp, color = Color.White,
                shadow = Shadow(Color(0x73000000), Offset(0f, 2f), 4f),
            ),
        )
        content()
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun TrailerScreen(p: Screen.Trailer, onBack: () -> Unit, onPlayMovie: () -> Unit) {
    val ctx = LocalContext.current
    val main = remember { Handler(Looper.getMainLooper()) }
    var index by remember { mutableIntStateOf(p.start.coerceIn(0, (p.videos.size - 1).coerceAtLeast(0))) }
    var web by remember { mutableStateOf<WebView?>(null) }
    var ready by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var muted by remember { mutableStateOf(false) }
    var pos by remember { mutableDoubleStateOf(0.0) }
    var dur by remember { mutableDoubleStateOf(0.0) }
    var controls by remember { mutableStateOf(true) }
    var finished by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    var loadedIndex by remember { mutableIntStateOf(index) }
    var touch by remember { mutableIntStateOf(0) } // bumps on every interaction to restart the auto-hide timer

    val key = p.videos.getOrNull(index)
    val name = p.titles.getOrNull(index) ?: "Trailer"
    val hasNext = index < p.videos.lastIndex

    fun js(code: String) { runCatching { web?.evaluateJavascript(code, null) } }
    fun next() {
        if (hasNext) { index++; finished = false; failed = false; pos = 0.0; dur = 0.0 } else { finished = true; controls = true; playing = false }
    }
    val goNext by rememberUpdatedState({ next() })

    // Landscape + no system bars while the trailer is open.
    DisposableEffect(Unit) {
        val activity = ctx.findActivity()
        val ctrl = activity?.let { WindowCompat.getInsetsController(it.window, it.window.decorView) }
        val before = activity?.requestedOrientation ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        ctrl?.hide(WindowInsetsCompat.Type.systemBars())
        ctrl?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        onDispose {
            runCatching { web?.stopLoading(); web?.loadUrl("about:blank"); web?.removeJavascriptInterface("Android"); web?.destroy() }
            web = null
            ctrl?.show(WindowInsetsCompat.Type.systemBars())
            activity?.requestedOrientation = if (before == ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE) ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED else before
        }
    }

    // Next video in the list: load it into the same player.
    LaunchedEffect(index, ready) {
        if (!ready || key == null || index == loadedIndex) return@LaunchedEffect
        loadedIndex = index
        js("loadVid('$key')")
    }
    LaunchedEffect(muted, ready) { if (ready) js("setMuted(${if (muted) "true" else "false"})") }
    // Auto-hide the controls while playing.
    LaunchedEffect(controls, playing, touch, finished) {
        if (controls && playing && !finished) { delay(3500); controls = false }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (p.videos.isEmpty()) {
            Text("No trailer to play.", Modifier.align(Alignment.Center), fontSize = 16.sp, color = Color(0xFF9AA3B5))
        } else {
            AndroidView(
                factory = { c ->
                    WebView(c).apply {
                        setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
                        setBackgroundColor(AColor.BLACK)
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        isVerticalScrollBarEnabled = false
                        isHorizontalScrollBarEnabled = false
                        webChromeClient = WebChromeClient()
                        webViewClient = object : WebViewClient() {
                            override fun onPageFinished(view: WebView?, url: String?) {
                                main.postDelayed({ runCatching { view?.evaluateJavascript("tryPlay()", null) } }, 1200)
                                main.postDelayed({ runCatching { view?.evaluateJavascript("tryPlay()", null) } }, 3000)
                            }
                        }
                        addJavascriptInterface(object {
                            @JavascriptInterface fun ready() { main.post { ready = true } }
                            @JavascriptInterface fun playing() { main.post { playing = true; failed = false } }
                            @JavascriptInterface fun paused() { main.post { playing = false } }
                            @JavascriptInterface fun ended() { main.post { playing = false; goNext() } }
                            @JavascriptInterface fun error(code: Int) { main.post { playing = false; failed = true; controls = true } }
                            @JavascriptInterface fun time(cur: Double, total: Double) { main.post { pos = cur; if (total > 0) dur = total } }
                        }, "Android")
                        val origin = "https://${c.packageName}"
                        loadDataWithBaseURL("$origin/", trailerPlayerHtml(p.videos[index], origin, muted), "text/html", "utf-8", null)
                        web = this
                    }
                },
                modifier = Modifier.fillMaxSize(),
            )
        }

        // Tap anywhere: show / hide the controls (no ripple).
        Box(Modifier.fillMaxSize().pointerInput(Unit) {
            detectTapGestures(onTap = { controls = !controls; touch++ }, onDoubleTap = { o ->
                if (o.x < size.width / 2f) js("seekBy(-10)") else js("seekBy(10)"); touch++
            })
        })

        AnimatedVisibility(controls || finished || failed, Modifier.fillMaxSize(), enter = fadeIn(tween(180)), exit = fadeOut(tween(220))) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to Color(0x8C000000), 0.3f to Color(0x1A000000), 0.6f to Color(0x26000000), 1f to Color(0xD9000000)))) {
                // ── Top: back, title, mute ──
                Row(Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(CircleShape).background(Color(0xFF15161C)).quietClick(onBack), Alignment.Center) {
                        Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, "Back", Modifier.size(26.dp), tint = Color.White)
                    }
                    Column(Modifier.weight(1f).padding(start = 14.dp)) {
                        Text(p.title, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(if (dur > 0) "$name · ${fmtClock(dur)}" else name, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color(0xFFC9CED9),
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Box(Modifier.size(42.dp).clip(CircleShape).background(Color(0xFF15161C)).quietClick { muted = !muted; touch++ }, Alignment.Center) {
                        Icon(if (muted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp, if (muted) "Unmute" else "Mute", Modifier.size(22.dp), tint = Color.White)
                    }
                }

                // ── Centre: -10s, play/pause, +10s ──
                if (finished) {
                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (p.videos.size > 1) "That's all the trailers" else "Trailer finished", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFC9CED9))
                        if (p.meta != null) RedPill("Play the movie", Modifier.padding(top = 16.dp).widthIn(min = 240.dp), onClick = onPlayMovie)
                        Text("Watch again", Modifier.padding(top = 14.dp).clip(RoundedCornerShape(18.dp)).background(Color(0x2EFFFFFF))
                            .quietClick { finished = false; js("seekTo(0);playV()") }.padding(horizontal = 16.dp, vertical = 8.dp),
                            fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                } else if (failed) {
                    Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("This video can't be played inside the app.", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("Open in YouTube", Modifier.clip(RoundedCornerShape(18.dp)).background(Color(0x2EFFFFFF)).quietClick {
                                runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=$key"))) }
                            }.padding(horizontal = 16.dp, vertical = 8.dp), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            if (hasNext) Text("Next video", Modifier.clip(RoundedCornerShape(18.dp)).background(Color(0x2EFFFFFF)).quietClick { next() }
                                .padding(horizontal = 16.dp, vertical = 8.dp), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                } else {
                    Row(Modifier.align(Alignment.Center), horizontalArrangement = Arrangement.spacedBy(70.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Replay10, "Back 10 seconds", Modifier.size(52.dp).clip(CircleShape).quietClick { js("seekBy(-10)"); touch++ }.padding(8.dp), tint = Color.White)
                        Box(
                            Modifier.size(74.dp).clip(CircleShape).background(Color(0x59000000)).border(1.5.dp, Color(0x59FFFFFF), CircleShape)
                                .quietClick { js(if (playing) "pauseV()" else "playV()"); touch++ },
                            Alignment.Center,
                        ) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "Pause" else "Play", Modifier.size(38.dp), tint = Color.White) }
                        Icon(Icons.Default.Forward10, "Forward 10 seconds", Modifier.size(52.dp).clip(CircleShape).quietClick { js("seekBy(10)"); touch++ }.padding(8.dp), tint = Color.White)
                    }
                }

                // ── Bottom: seek bar, time, next, play the movie ──
                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 40.dp, vertical = 20.dp)) {
                    val frac = if (dur > 0) (pos / dur).toFloat().coerceIn(0f, 1f) else 0f
                    Box(
                        Modifier.fillMaxWidth().height(22.dp).pointerInput(Unit) {
                            detectTapGestures { o -> if (dur > 0) { js("seekTo(${(o.x / size.width).coerceIn(0f, 1f) * dur})"); touch++ } }
                        },
                        Alignment.CenterStart,
                    ) {
                        Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x4DFFFFFF))) {
                            Box(Modifier.fillMaxHeight().fillMaxWidth(frac).clip(RoundedCornerShape(3.dp)).background(Color(0xFFE50914)))
                        }
                        BoxWithConstraints(Modifier.fillMaxWidth()) {
                            Box(Modifier.offset(x = maxWidth * frac - 8.dp).size(16.dp).clip(CircleShape).background(Color.White))
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${fmtClock(pos)} / ${fmtClock(dur)}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.weight(1f))
                        if (hasNext) Text("Next: ${p.titles.getOrNull(index + 1) ?: "Video"} ▸",
                            Modifier.padding(end = 16.dp).widthIn(max = 260.dp).quietClick { next() }, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                            color = Color(0xFFC9CED9), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (p.meta != null && !finished) RedPill("Play the movie", Modifier.widthIn(min = 150.dp), height = 40, fontSize = 14, onClick = onPlayMovie)
                    }
                }
            }
        }
    }
}

private fun trailerPlayerHtml(id: String, origin: String, muted: Boolean) = """
<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<style>html,body{margin:0;padding:0;background:#000;height:100%;overflow:hidden}#p{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none}</style>
</head><body><div id="p"></div>
<script src="https://www.youtube.com/iframe_api"></script>
<script>
var player=null,ready=false,tries=0,timer=null,poll=null,wantMuted=${if (muted) "true" else "false"},started=false;
function tryPlay(){try{if(player&&ready&&!started){player.mute();if(player.getPlayerState()!=1)player.playVideo();}}catch(e){}}
function report(){try{if(player&&ready)Android.time(player.getCurrentTime()||0,player.getDuration()||0);}catch(e){}}
function onYouTubeIframeAPIReady(){
  player=new YT.Player('p',{videoId:'$id',
    playerVars:{autoplay:1,mute:1,controls:0,rel:0,playsinline:1,modestbranding:1,iv_load_policy:3,fs:0,disablekb:1,cc_load_policy:0,origin:'$origin'},
    events:{
      onReady:function(e){ready=true;Android.ready();e.target.mute();e.target.playVideo();
        poll=setInterval(report,500);
        timer=setInterval(function(){tries++;tryPlay();if(tries>24||started){clearInterval(timer);}},400);},
      onStateChange:function(e){
        if(e.data==1){started=true;if(!wantMuted)player.unMute();Android.playing();}
        if(e.data==2)Android.paused();
        if(e.data==0){report();Android.ended();}
      },
      onError:function(e){Android.error(e.data);}
    }});
}
function setMuted(m){wantMuted=m;if(player&&player.mute){if(m)player.mute();else player.unMute();}}
function playV(){try{player.playVideo();}catch(e){}}
function pauseV(){try{player.pauseVideo();}catch(e){}}
function seekTo(s){try{player.seekTo(Math.max(0,s),true);report();}catch(e){}}
function seekBy(d){try{seekTo((player.getCurrentTime()||0)+d);}catch(e){}}
function loadVid(v){try{player.loadVideoById(v);if(!wantMuted)player.unMute();}catch(e){}}
</script></body></html>
""".trimIndent()

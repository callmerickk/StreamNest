package com.example.streamnest

import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Typeface
import android.media.AudioManager
import android.net.Uri
import android.util.TypedValue
import android.view.View
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack

import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.animation.core.animateDp
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.text.Cue
import androidx.media3.common.text.CueGroup
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.media3.ui.SubtitleView
import coil.compose.AsyncImage
import kotlinx.coroutines.async
import kotlinx.coroutines.Job
import android.os.SystemClock
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import kotlin.math.abs
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** Inter: the clean geometric sans used by the player (bundled, SIL Open Font License). */
val InterFont = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold),
)

private fun subMime(url: String) = when {
    url.contains(".vtt", true) -> MimeTypes.TEXT_VTT
    url.contains(".ass", true) || url.contains(".ssa", true) -> MimeTypes.TEXT_SSA
    else -> MimeTypes.APPLICATION_SUBRIP
}

/** Opens a stream in another installed player (VLC, MX Player…) through Android's app chooser. */
fun openExternal(ctx: android.content.Context, url: String, title: String) {
    try {
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(url), "video/*").putExtra("title", title)
        ctx.startActivity(Intent.createChooser(i, "Open with"))
    } catch (e: Exception) {
        Snack.show("No other video player found")
    }
}

const val PlayerUserAgent = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"

/** Builds the video player: fast-start buffering, the app's HTTP client (DNS setting), FFmpeg audio, remembered languages. */
@OptIn(UnstableApi::class)
fun buildPlayer(ctx: android.content.Context, vm: AppViewModel, fast: Boolean): ExoPlayer {
    val load = DefaultLoadControl.Builder()
        .setBufferDurationsMs(15_000, 50_000, if (fast) 1_000 else 2_500, if (fast) 2_000 else 5_000)
        .setPrioritizeTimeOverSizeThresholds(true)
        .build()
    // Streams go through the app's HTTP client, so the DNS chosen in Settings applies to video too.
    val http = OkHttpDataSource.Factory(Api.http).setUserAgent(PlayerUserAgent)
    val dataSource = DefaultDataSource.Factory(ctx, withStreamHeaders(http))
    // FFmpeg first for audio, so Dolby Digital / DD+ / DTS / TrueHD play even when the phone has no decoder for them.
    val renderers = DefaultRenderersFactory(ctx)
        .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
        .setEnableDecoderFallback(true)
    return ExoPlayer.Builder(ctx, renderers).setLoadControl(load).setMediaSourceFactory(DefaultMediaSourceFactory(dataSource)).build().apply {
        val aLang = vm.playerPref("audio")
        val sLang = vm.playerPref("subs")
        trackSelectionParameters = trackSelectionParameters.buildUpon().apply {
            if (aLang.isNotEmpty()) setPreferredAudioLanguage(aLang)
            when {
                sLang == "off" -> setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                sLang.isNotEmpty() -> setPreferredTextLanguage(sLang)
            }
        }.build()
    }
}

fun subtitleConfigs(subs: List<Subtitle>) = subs.filter { it.url.isNotBlank() }.map {
    MediaItem.SubtitleConfiguration.Builder(Uri.parse(it.url)).setMimeType(subMime(it.url)).setLanguage(it.lang).setLabel(it.lang).build()
}

/** A video prepared in the background on the title page, handed to the player when you press Play. */
class Preloaded(val key: String, val url: String, val subs: List<Subtitle>, val source: String?, val addon: String?, val quick: List<StreamItem>, val player: ExoPlayer)

object Preloader {
    private var cur: Preloaded? = null
    fun set(p: Preloaded) { cur?.let { if (it !== p) runCatching { it.player.release() } }; cur = p }
    fun has(key: String) = cur?.key == key
    fun take(key: String): Preloaded? = cur?.takeIf { it.key == key }?.also { cur = null }
    fun release(key: String? = null) { cur?.let { if (key == null || it.key == key) { runCatching { it.player.release() }; cur = null } } }
}

/** One way of playing a link. */
data class Way(val vlc: Boolean, val hw: Boolean, val relay: Boolean) {
    fun label() = if (!vlc) "ExoPlayer" else "VLC " + (if (hw) "HW" else "SW") + (if (relay) " + relay" else "")
}

/** The order in which a link is tried. Links that need more headers than VLC can send go through the relay straight away. */
fun waysFor(url: String, engine: String): List<Way> {
    val h = StreamHeaders.forUrl(url)
    val needsRelay = h.keys.any { !it.equals("User-Agent", true) && !it.equals("Referer", true) }
    val vlcWays = when {
        needsRelay -> listOf(Way(true, true, true), Way(true, false, true))
        h.isNotEmpty() -> listOf(Way(true, true, false), Way(true, false, false), Way(true, true, true))
        else -> listOf(Way(true, true, false), Way(true, false, false))
    }
    val exo = Way(false, true, false)
    return if (engine == "exo") listOf(exo) + vlcWays else vlcWays + exo
}

/** Copies the frame on screen (VLC or ExoPlayer surface) so it can stay visible while another link loads. */
fun captureFrame(root: View, onDone: (android.graphics.Bitmap?) -> Unit) {
    fun find(v: View, pick: (View) -> Boolean): View? {
        if (pick(v)) return v
        if (v is android.view.ViewGroup) for (i in 0 until v.childCount) find(v.getChildAt(i), pick)?.let { return it }
        return null
    }
    try {
        (find(root) { it is android.view.TextureView && it.isAvailable } as? android.view.TextureView)?.let { tv ->
            onDone(tv.getBitmap(tv.width / 2, tv.height / 2)); return
        }
        val sv = find(root) { it is android.view.SurfaceView && it.width > 0 && it.visibility == View.VISIBLE } as? android.view.SurfaceView
        if (sv == null || !sv.holder.surface.isValid || android.os.Build.VERSION.SDK_INT < 24) { onDone(null); return }
        val bmp = android.graphics.Bitmap.createBitmap((sv.width / 2).coerceAtLeast(1), (sv.height / 2).coerceAtLeast(1), android.graphics.Bitmap.Config.ARGB_8888)
        android.view.PixelCopy.request(sv, bmp, { r -> onDone(if (r == android.view.PixelCopy.SUCCESS) bmp else null) }, android.os.Handler(android.os.Looper.getMainLooper()))
    } catch (e: Throwable) { onDone(null) }
}

private data class TrackOpt(val label: String, val group: Tracks.Group, val index: Int, val selected: Boolean)

/** What is actually playing (the link can change: finding, fallbacks, switching source). */
private data class Now(val url: String, val subs: List<Subtitle>, val source: String?, val addon: String?)

private val noRipple = MutableInteractionSource()

@OptIn(UnstableApi::class)
@kotlin.OptIn(androidx.compose.animation.ExperimentalAnimationApi::class)
@Composable
fun PlayerScreen(
    vm: AppViewModel,
    p: Screen.Player,
    onBack: () -> Unit,
    onReplace: (Screen.Player) -> Unit,
    onProgress: (pos: Long, dur: Long, url: String, subs: List<Subtitle>) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val texts by vm.texts.collectAsStateWithLifecycle()
    fun opt(k: String) = texts[k] ?: Defaults[k] ?: ""

    val type = p.type.ifBlank { if (p.key.contains(":")) "series" else "movie" }
    var meta by remember { mutableStateOf(p.meta) }
    // A video already prepared on the title page starts instantly.
    val pre = remember { Preloader.take(p.key) }
    var now by remember {
        mutableStateOf(
            pre?.let { Now(it.url, it.subs, it.source, it.addon) } ?: if (p.url.isNotBlank()) Now(p.url, p.subs, p.source, p.addon) else null,
        )
    }
    var quickList by remember { mutableStateOf(pre?.quick ?: emptyList()) }
    var quality by remember { mutableStateOf(vm.playerPref("quality").ifEmpty { vm.texts.value["qsQuality"] ?: "auto" }) }
    var qualityMenu by remember { mutableStateOf(false) }
    var candidates by remember { mutableStateOf(p.candidates) }
    // Every stream we know for this title (for language versions in the Audio panel).
    var known by remember { mutableStateOf(p.candidates) }
    var otherLangsOpen by remember { mutableStateOf(false) }
    var tracks by remember { mutableStateOf(Tracks.EMPTY) }
    var playing by remember { mutableStateOf(true) }
    var pos by remember { mutableLongStateOf(p.resumeMs) }
    var dur by remember { mutableLongStateOf(0L) }
    var buffered by remember { mutableLongStateOf(0L) }
    var buffering by remember { mutableStateOf(true) }
    var firstFrame by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf(if (p.url.isBlank() && pre == null) "Finding stream source" else "Buffering…") }
    var failure by remember { mutableStateOf<String?>(null) }
    var findRequest by remember { mutableIntStateOf(if (p.url.isBlank() && pre == null) 1 else 0) }
    var controls by remember { mutableStateOf(false) }
    var poke by remember { mutableIntStateOf(0) }
    var locked by remember { mutableStateOf(false) }
    var more by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf<String?>(null) }
    var lastPanel by remember { mutableStateOf("sources") }
    var showEpisodes by remember { mutableStateOf(false) }
    // Remembered per profile: aspect ratio, audio language, subtitle language (Help: auto-applied next time).
    var aspectIdx by remember { mutableIntStateOf(vm.playerPref("aspect").toIntOrNull()?.coerceIn(0, AspectModes.lastIndex) ?: 0) }
    var resize by remember { mutableIntStateOf(AspectModes[aspectIdx].second) }
    var holdSpeed by remember { mutableStateOf<Float?>(null) }
    var tapJob by remember { mutableStateOf<Job?>(null) }
    val haptics = LocalHapticFeedback.current
    var speed by remember { mutableFloatStateOf(1f) }
    var advisory by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var showAdvisory by remember { mutableStateOf(false) }
    var segs by remember { mutableStateOf<Segments?>(null) }
    var showInfo by remember { mutableStateOf(false) }
    var seekHint by remember { mutableStateOf<String?>(null) }
    var cues by remember { mutableStateOf<List<Cue>>(emptyList()) }
    var aspectLabel by remember { mutableStateOf<String?>(null) }
    var hud by remember { mutableStateOf<Pair<String, Float>?>(null) }
    val audio = remember { ctx.getSystemService(android.content.Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var autoNextDone by remember { mutableStateOf(false) }
    var linkSaved by remember { mutableStateOf(false) }
    // Loading scenes: how many addons answered the search, the best quality seen, and the "serving" progress.
    var answered by remember { mutableIntStateOf(0) }
    var sourceTotal by remember { mutableIntStateOf(0) }
    var bestRes by remember { mutableIntStateOf(0) }
    var bufProgress by remember { mutableFloatStateOf(0f) }
    var brightApplied by remember { mutableStateOf(false) }
    fun streamAddonCount(only: Set<String>? = null): Int =
        vm.addons.value.count { vm.isAddonOn(it) && it.supports("stream", type, p.key) && (only == null || it.manifest.name in only) }
    fun noteAnswer(list: List<StreamItem>, done: Boolean) {
        answered = if (done) sourceTotal else (answered + 1).coerceAtMost(sourceTotal)
        val r = list.maxOfOrNull { it.resolution() } ?: 0
        if (r > bestRes) bestRes = r
    }

    // Faster start: begin playing after ~1 s of video instead of the default 2.5 s (Playback > Fast start).
    val player = remember { pre?.player ?: buildPlayer(ctx, vm, isOn(texts["fastStart"] ?: Defaults["fastStart"] ?: "yes")) }

    // ───── Engines: VLC (default) and ExoPlayer (Playback > Player engine). Same controls for both. ─────
    // Every link is tried several ways before giving up on it:
    //   VLC hardware decoding → VLC software decoding → VLC through the header relay → ExoPlayer
    // ("exo" setting: ExoPlayer first). Only then the next source is tried.
    val engine = opt("playerEngine").let { if (it == "exo") "exo" else "vlc" }
    var vlc by remember { mutableStateOf<VlcEngine?>(null) }
    var usingVlc by remember { mutableStateOf(false) }
    var vlcTick by remember { mutableIntStateOf(0) } // bumps when VLC tracks may have changed
    var ways by remember { mutableStateOf<List<Way>>(emptyList()) }
    var wayIdx by remember { mutableIntStateOf(0) }
    var loadTick by remember { mutableIntStateOf(0) }
    var midRetries by remember { mutableIntStateOf(0) }
    // Where the video should start / continue (kept while a new link loads, so a switch never restarts at 0:00).
    var resumeAt by remember { mutableLongStateOf(p.resumeMs) }
    // Switching while playing: keep the last frame on screen (blurred) instead of the loading screen.
    var switching by remember { mutableStateOf(false) }
    var switchLabel by remember { mutableStateOf<String?>(null) }
    var frozen by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var videoView by remember { mutableStateOf<View?>(null) }

    fun curPos(): Long = if (usingVlc) vlc?.time ?: 0L else player.currentPosition
    fun curDur(): Long = if (usingVlc) vlc?.length ?: 0L else player.duration.coerceAtLeast(0L)
    fun curBuffered(): Long = if (usingVlc) curPos() else player.bufferedPosition
    fun isPlayingNow(): Boolean = if (usingVlc) vlc?.isPlaying == true else player.isPlaying
    fun seekAbs(ms: Long) { if (usingVlc) vlc?.seek(ms) else player.seekTo(ms) }
    fun setRate(f: Float) { if (usingVlc) vlc?.rate = f else player.setPlaybackSpeed(f) }
    fun rateNow(): Float = if (usingVlc) vlc?.rate ?: 1f else player.playbackParameters.speed
    fun pauseNow() { if (usingVlc) vlc?.pause() else player.pause() }
    fun togglePlay() { if (isPlayingNow()) pauseNow() else { if (usingVlc) vlc?.play() else player.play() } }
    /** Position to keep when the link changes. */
    fun keepPos(): Long = if (firstFrame) curPos().takeIf { it > 0 } ?: resumeAt else resumeAt

    var onEngineError: (String) -> Unit = {}

    fun startVlc(n: Now, startMs: Long, w: Way) {
        runCatching { player.stop() }
        usingVlc = true
        firstFrame = false; failure = null; status = "Buffering…"; linkSaved = false
        val v = vlc ?: VlcEngine(ctx, object : VlcListener {
            override fun onPlaying(p0: Boolean) { playing = p0; if (p0) vlcTick++ }
            override fun onBuffering(b: Boolean) { buffering = b }
            override fun onFirstFrame() {
                firstFrame = true; buffering = false; vlcTick++
                if (!linkSaved) { linkSaved = true; now?.let { nn -> if (nn.url.startsWith("http")) vm.rememberLink(p.key, nn.url, nn.source, nn.addon) } }
            }
            override fun onError() { onEngineError("VLC_ERROR") }
            override fun onEnded() { playing = false }
        }).also { vlc = it }
        v.preferAudio = vm.qsLangs().filter { it != "original" } + listOfNotNull(vm.playerPref("audio").takeIf { it.isNotBlank() && it != "off" }?.let { runCatching { java.util.Locale(it).displayLanguage.lowercase() }.getOrNull() })
        val url = if (w.relay) Relay.wrap(n.url) else n.url
        v.load(url, if (w.relay) emptyMap() else StreamHeaders.forUrl(n.url), n.subs, startMs, hw = w.hw)
        now = n
    }

    fun startExo(n: Now, startMs: Long) {
        if (usingVlc) { vlc?.stop(); usingVlc = false }
        val subs = subtitleConfigs(n.subs)
        firstFrame = false; failure = null; status = "Buffering…"; linkSaved = false
        player.setMediaItem(MediaItem.Builder().setUri(n.url).setSubtitleConfigurations(subs).build(), startMs)
        player.prepare(); player.playWhenReady = true
        now = n
    }

    fun startWay(n: Now, startMs: Long) {
        loadTick++
        val w = ways.getOrNull(wayIdx) ?: Way(vlc = engine == "vlc", hw = true, relay = false)
        if (w.vlc) startVlc(n, startMs, w) else startExo(n, startMs)
    }

    fun load(n: Now, startMs: Long, label: String? = null) {
        // Mid-playback switch (audio language / source / quality): freeze the last frame and continue from the same second.
        if (firstFrame) {
            switching = true
            switchLabel = label
            videoView?.let { vv -> captureFrame(vv) { bmp -> if (switching) frozen = bmp } }
        }
        StreamHeaders.active = StreamHeaders.forUrl(n.url)
        resumeAt = startMs
        ways = waysFor(n.url, engine)
        wayIdx = 0
        midRetries = 0
        startWay(n, startMs)
    }

    /** A link failed: try the same link another way, then the next source, else show the error. */
    onEngineError = { code ->
        val n = now
        val start = keepPos()
        if (n != null) {
            val w = ways.getOrNull(wayIdx)
            val title = p.title
            scope.launch { PlaybackLog.add(ctx, "$title · ${n.addon ?: "?"} · ${w?.label() ?: "?"} · $code · ${PlaybackLog.probe(n.url)}") }
        }
        if (n != null && vm.lastLink(p.key)?.url == n.url) vm.forgetLink(p.key)
        val next = candidates.firstOrNull()
        when {
            // Broke while playing (network blip): reload the same link at the same second, twice at most.
            firstFrame && n != null && midRetries < 2 -> {
                midRetries++
                resumeAt = start
                startWay(n, start)
            }
            // Same link, another way (software decoding, header relay, other engine) — quietly.
            n != null && wayIdx + 1 < ways.size -> {
                wayIdx++
                if (wayIdx == 1) Snack.show("Trying another way to play this file…")
                resumeAt = start
                startWay(n, start)
            }
            next != null -> {
                candidates = candidates.drop(1)
                Snack.show("That source didn't play — trying the next one")
                load(Now(next.stream.url!!, next.stream.subtitles.orEmpty() + (n?.subs.orEmpty().filter { s -> next.stream.subtitles.orEmpty().none { it.url == s.url } }),
                    next.stream.name ?: next.addonName, next.addonName), start)
            }
            else -> { forgetStreams(p.key); switching = false; frozen = null; failure = "This file couldn't be played, even after trying every way ($code). Try another source." }
        }
        Unit
    }

    // A link that never starts (no error, no picture) counts as failed after 30 s.
    LaunchedEffect(loadTick) {
        if (loadTick == 0) return@LaunchedEffect
        delay(30_000)
        if (!firstFrame && failure == null && now != null) onEngineError("TIMEOUT")
    }
    // Back on screen after a switch: say where we continued, with a quick way to start over.
    LaunchedEffect(firstFrame) {
        if (firstFrame && switching) {
            switching = false
            frozen = null
            val at = resumeAt
            if (at > 5_000) Snack.show("${switchLabel?.let { "$it · " } ?: ""}Resumed at ${fmtTime(at)}", "Start from beginning", 5000) { seekAbs(0L) }
            else switchLabel?.let { Snack.show(it) }
            switchLabel = null
        }
    }

    // Start straight away when a link was given; the player is preparing while the loading screen shows.
    LaunchedEffect(player) {
        if (pre != null) {
            ways = waysFor(pre.url, "exo"); wayIdx = 0
            buffering = player.playbackState == Player.STATE_BUFFERING
            player.playWhenReady = true
        } else now?.let { load(it, p.resumeMs) }
    }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                if (usingVlc) return
                onEngineError(error.errorCodeName.removePrefix("ERROR_CODE_"))
            }
            override fun onTracksChanged(t: Tracks) { tracks = t }
            override fun onCues(cueGroup: CueGroup) { cues = cueGroup.cues }
            override fun onIsPlayingChanged(isPlaying: Boolean) { if (!usingVlc) playing = isPlaying }
            override fun onRenderedFirstFrame() { if (!usingVlc) firstFrame = true }
            override fun onPlaybackStateChanged(state: Int) {
                if (usingVlc) return
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY && !linkSaved) {
                    linkSaved = true
                    now?.let { n -> if (n.url.startsWith("http")) vm.rememberLink(p.key, n.url, n.source, n.addon) }
                    // Audio-only or no video track: there is no "first frame", so don't wait for it.
                    if (player.videoSize.width == 0) scope.launch { delay(800); firstFrame = true }
                }
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l) }
    }

    // "Finding stream source": Auto Stream Selection inside the player (and for the next episode).
    LaunchedEffect(findRequest) {
        if (findRequest == 0) return@LaunchedEffect
        failure = null; firstFrame = false; status = "Finding stream source"
        answered = 0; bestRes = 0; bufProgress = 0f; sourceTotal = streamAddonCount()
        val subsJob = async { runCatching { vm.subtitles(type, p.key) }.getOrDefault(emptyList()) }
        val forced = findRequest > 1 // asked again after a failure: never reuse the old link
        val last = if (!forced && !p.quick && isOn(opt("reuseLastLink"))) vm.lastLink(p.key) else null
        if (last != null) {
            load(Now(last.url, withTimeoutOrNull(1200) { subsJob.await() }.orEmpty(), last.source, last.addon), resumeAt)
            // Also look up other sources in the background, in case the saved link has expired.
            scope.launch { vm.streamsFlow(type, p.key).first { it.second }.let { (l, _) -> val fl = vm.filtered(l).list; known = fl; candidates = fl.filter { it.stream.url != last.url } } }
            return@LaunchedEffect
        }
        // Quick Start: fast addons, chosen quality and your language order.
        // The first file in your top language (e.g. Hindi) starts at once; the other addons keep loading
        // in the background and fill the Audio panel / quality menu as they arrive.
        if (p.quick) {
            var started = false
            suspend fun startWith(list: List<StreamItem>, q: StreamItem) {
                started = true
                candidates = list.filter { it !== q && vm.isQuick(it) }.sortedBy { vm.langRank(it) }
                val extra = withTimeoutOrNull(800) { subsJob.await() }.orEmpty()
                load(Now(q.stream.url!!, q.stream.subtitles.orEmpty() + extra, q.stream.name ?: q.addonName, q.addonName), resumeAt)
            }
            val cached = if (forced) null else cachedQuick(p.key)
            if (cached != null) {
                sourceTotal = streamAddonCount(vm.qsAddons()); noteAnswer(cached, true)
                quickList = cached; known = (known + cached).distinctBy { it.stream.url }
                val q = vm.pickQuick(cached, quality) ?: vm.pickQuick(cached, "auto")
                if (q != null) { startWith(cached, q); return@LaunchedEffect }
            } else {
                val topLang = vm.qsLangs().firstOrNull()
                var last: List<StreamItem> = emptyList()
                sourceTotal = streamAddonCount(vm.qsAddons())
                vm.streamsFlow(type, p.key, only = vm.qsAddons()).collect { (l, done) ->
                    val list = vm.filtered(l).list
                    if (!started) noteAnswer(list, done)
                    last = list
                    quickList = list
                    known = (known + list).distinctBy { it.stream.url }
                    if (started) {
                        candidates = (candidates + list.filter { it.stream.url != now?.url && vm.isQuick(it) }).distinctBy { it.stream.url }.sortedBy { vm.langRank(it) }
                    } else {
                        val q = vm.pickQuick(list, quality) ?: vm.pickQuick(list, "auto")
                        val inTopLang = q != null && topLang != null && topLang in q.languages()
                        if (q != null && (inTopLang || done)) startWith(list, q)
                    }
                }
                putQuick(p.key, last)
                if (started) return@LaunchedEffect
            }
        }
        val mode = opt("autoPlayMode").let { if (it == "manual") "first" else it }
        val patterns = regexList(opt("autoRegex"))
        val prefer = p.source
        var picked: StreamItem? = null
        var pool: List<StreamItem> = emptyList()
        var hiddenAll = false
        val cachedList = if (forced) null else cachedAll(p.key)
        val flow = if (cachedList != null) kotlinx.coroutines.flow.flowOf(cachedList to true) else vm.streamsFlow(type, p.key)
        answered = 0; sourceTotal = streamAddonCount()
        flow.first { (l, done) ->
            val f = vm.filtered(l)
            noteAnswer(f.list, done)
            pool = f.list
            hiddenAll = f.forcedEmpty
            picked = when {
                pool.isEmpty() -> null
                prefer != null && !done -> pool.firstOrNull { it.stream.name == prefer } // same source as the last episode
                mode == "regex" && patterns.isNotEmpty() -> matchChain(pool, patterns.take(1))?.first ?: if (done) vm.autoPick(pool, "regex", opt("autoRegex")) else null
                else -> if (done || prefer == null) vm.autoPick(pool, "first", "", prefer) else null
            }
            picked != null || done
        }
        val s0 = picked ?: (if (pool.isNotEmpty()) vm.autoPick(pool, mode, opt("autoRegex"), prefer) else null)
        // Prefer your audio language (Hindi → Original…) among versions of the same file from the same addon.
        val s = s0?.let { a -> pool.filter { it.addonName == a.addonName && it.resolution() == a.resolution() }.minByOrNull { vm.langRank(it) }
            ?.takeIf { vm.langRank(it) < vm.langRank(a) } ?: a }
        if (s == null) {
            failure = if (hiddenAll) "No streams match your forced stream filters." else "No stream found for this title."
            return@LaunchedEffect
        }
        known = pool
        candidates = pool.filter { it !== s }
        val extra = withTimeoutOrNull(1500) { subsJob.await() }.orEmpty()
        load(Now(s.stream.url!!, s.stream.subtitles.orEmpty() + extra, s.stream.name ?: s.addonName, s.addonName), resumeAt)
    }
    LaunchedEffect(firstFrame, buffering) { if (!firstFrame && now != null && failure == null) status = "Buffering…" }
    // "Serving" progress on the loading screen: eases to 90% over ~4 s (faster when ExoPlayer reports a real buffer),
    // creeps on slowly after that and jumps to 100% with the first frame. It never goes backwards.
    LaunchedEffect(status, loadTick, firstFrame) {
        if (firstFrame) { bufProgress = 1f; return@LaunchedEffect }
        if (!status.startsWith("Buffering")) return@LaunchedEffect
        val t0 = SystemClock.uptimeMillis()
        while (true) {
            val t = (SystemClock.uptimeMillis() - t0) / 4000f
            val eased = if (t < 1f) { val u = 1f - t; 0.9f * (1f - u * u * u) } else 0.9f + 0.08f * (1f - kotlin.math.exp(-(t - 1f)))
            val real = if (!usingVlc) ((player.bufferedPosition - resumeAt).toFloat() / 2500f).coerceIn(0f, 0.95f) else 0f
            bufProgress = maxOf(bufProgress, eased, real)
            delay(50)
        }
    }
    // Starting brightness (Playback > Brightness): applied once, when the video is first on screen.
    LaunchedEffect(firstFrame) {
        if (!firstFrame || brightApplied) return@LaunchedEffect
        brightApplied = true
        if (!isOn(opt("startBright"))) return@LaunchedEffect
        val act = ctx as? Activity ?: return@LaunchedEffect
        val saved = if (opt("startBrightMode") == "last") vm.playerPref("bright").toFloatOrNull() else null
        val level = (saved ?: ((opt("startBrightLevel").toFloatOrNull() ?: 50f) / 100f)).coerceIn(0.1f, 1f)
        act.window.attributes = act.window.attributes.apply { screenBrightness = level }
        hud = "brightness" to level
        delay(2000)
        if (hud?.first == "brightness") hud = null
    }
    // The Full HD / Mid HD / Low menu is always there when Quick Start is on — also when playing from
    // Continue Watching, the sources list or a saved link: its streams are looked up in the background.
    LaunchedEffect(p.key) {
        if (!vm.qsActive()) return@LaunchedEffect
        delay(1500)
        if (quickList.isNotEmpty()) return@LaunchedEffect
        val l = cachedQuick(p.key) ?: runCatching { vm.quickStreams(type, p.key) }.getOrDefault(emptyList())
        if (quickList.isEmpty() && l.isNotEmpty()) {
            quickList = l
            known = (known + l).distinctBy { it.stream.url }
            // Show the level that matches what's playing.
            now?.url?.let { u -> vm.qualityMap(l).firstOrNull { it.first.id != "auto" && it.second?.stream?.url == u }?.let { quality = it.first.id } }
        }
    }

    // Episodes in order, for "Next episode".
    val episodes = remember(meta) {
        meta?.videos.orEmpty().filter { (it.season ?: 0) > 0 && it.episode != null }.sortedWith(compareBy({ it.season }, { it.episode }))
    }
    val nextEp = remember(episodes, p.key) { episodes.indexOfFirst { it.id == p.key }.let { i -> if (i >= 0) episodes.getOrNull(i + 1) else null } }

    LaunchedEffect(p.key) {
        if (meta == null || meta?.videos == null && type == "series") {
            vm.fullMeta(Meta(id = p.key.substringBefore(":"), type = type))?.let { meta = it }
        }
    }
    // Content advisory once the video is on screen.
    LaunchedEffect(p.key, firstFrame) {
        if (firstFrame && advisory.isEmpty() && isOn(opt("showAdvisory")) && p.key.startsWith("tt")) {
            val g = vm.parentalGuide(p.key.substringBefore(":"))
            if (g.isNotEmpty()) { advisory = g; showAdvisory = true; delay(9_000); showAdvisory = false }
        }
    }
    LaunchedEffect(p.key) { if (isOn(opt("skipIntro"))) segs = vm.segments(p.key) }

    LaunchedEffect(player) {
        while (true) {
            pos = if (firstFrame) curPos() else resumeAt
            dur = curDur()
            buffered = curBuffered()
            delay(500)
        }
    }
    LaunchedEffect(controls, poke, playing, panel, qualityMenu) {
        if (controls && playing && panel == null && !qualityMenu) { delay(4000); controls = false; more = false }
    }
    LaunchedEffect(playing, firstFrame) {
        if (firstFrame && !playing && !buffering && isOn(opt("pauseInfo"))) { delay(5000); if (!isPlayingNow()) { showInfo = true; controls = false } }
        else showInfo = false
    }

    fun seekBy(ms: Long) { seekAbs((curPos() + ms).coerceIn(0L, maxOf(0L, curDur()))); poke++ }

    fun playEpisode(ep: Video) {
        val m = meta ?: return
        onReplace(
            Screen.Player(
                "${m.name}  S${ep.season}E${ep.episode}", "", emptyList(), key = ep.id,
                image = ep.thumbnail ?: m.background ?: m.poster, type = type, meta = m,
                source = if (p.quick) null else now?.source, addon = now?.addon, find = true, quick = p.quick,
            )
        )
    }
    fun playNext() { nextEp?.let { playEpisode(it) } }
    /** Play another Quick Start file (quality or language change) from the same second. */
    fun switchTo(st: StreamItem, label: String? = null) {
        val keep = keepPos()
        val addonSubs = now?.subs.orEmpty().filter { sub -> st.stream.subtitles.orEmpty().none { it.url == sub.url } }
        load(Now(st.stream.url!!, st.stream.subtitles.orEmpty() + addonSubs, st.stream.name ?: st.addonName, st.addonName), keep, label)
    }
    fun setQuality(id: String) {
        quality = id; qualityMenu = false; poke++
        vm.setPlayerPref("quality", id)
        val st = vm.pickQuick(quickList, id) ?: return
        if (st.stream.url != now?.url) switchTo(st, QualityLevels.firstOrNull { it.id == id }?.label)
    }
    fun setAspect(i: Int, label: String = AspectModes[i].first) {
        aspectIdx = i; resize = AspectModes[i].second; aspectLabel = label
        vlc?.setAspect(i)
        vm.setPlayerPref("aspect", i.toString())
    }

    // Last few minutes of an episode: look up the next one's streams, so it starts at once.
    var nextPrefetched by remember { mutableStateOf(false) }
    LaunchedEffect(pos >= dur - 300_000 && dur > 600_000) {
        val ep = nextEp
        if (!nextPrefetched && ep != null && dur > 600_000 && pos >= dur - 300_000) {
            nextPrefetched = true
            if (p.quick) runCatching { vm.quickStreams(type, ep.id) } else runCatching { vm.allStreams(type, ep.id) }
        }
    }
    val threshold = (opt("nextThreshold").toIntOrNull() ?: 95).coerceIn(50, 100) / 100f
    LaunchedEffect(pos, dur) {
        if (!autoNextDone && isOn(opt("autoNext")) && nextEp != null && dur > 60_000 && pos >= dur * threshold) {
            autoNextDone = true
            playNext()
        }
    }

    DisposableEffect(Unit) {
        val activity = ctx as Activity
        val ctrl = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        ctrl.hide(WindowInsetsCompat.Type.systemBars())
        ctrl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        onDispose {
            val d = curDur()
            now?.let { n -> if (firstFrame) onProgress(curPos(), if (d > 0) d else 0L, n.url, n.subs) }
            player.release()
            vlc?.release()
            activity.window.attributes = activity.window.attributes.apply { screenBrightness = -1f }
            ctrl.show(WindowInsetsCompat.Type.systemBars())
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    BackHandler {
        when {
            panel != null -> panel = null
            showEpisodes -> showEpisodes = false
            showInfo -> showInfo = false
            locked && firstFrame -> { controls = true; poke++ }
            else -> onBack()
        }
    }

    val subSize = opt("subSize").toFloatOrNull() ?: 20f
    val subStyle = CaptionStyleCompat(
        (parseColor(opt("subColor")) ?: Color.White).toArgb(),
        (parseColor(opt("subBg")) ?: Color.Transparent).toArgb(),
        Color.Transparent.toArgb(),
        if (isOn(opt("subOutline"))) CaptionStyleCompat.EDGE_TYPE_OUTLINE else CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW,
        (parseColor(opt("subOutlineColor")) ?: Color.Black).toArgb(),
        if (isOn(opt("subBold"))) Typeface.DEFAULT_BOLD else Typeface.DEFAULT,
    )

    // Loading screen fades out, then the video fades in from black.
    val loadingAlpha by animateFloatAsState(if ((firstFrame || switching) && failure == null) 0f else 1f, tween(420), label = "loading")
    val videoAlpha by animateFloatAsState(if (firstFrame) 1f else 0f, tween(650, delayMillis = 180), label = "video")

    ProvideTextStyle(TextStyle(fontFamily = InterFont, color = Color.White)) {
        BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
            // Measured from the reference player: wide side margins, scaled to this screen.
            val side = (maxWidth * 0.11f).coerceIn(28.dp, 110.dp)
            val topEnd = (maxWidth * 0.12f).coerceIn(28.dp, 120.dp)
            val topY = (maxHeight * 0.12f).coerceIn(16.dp, 64.dp)
            val bottomY = (maxHeight * 0.06f).coerceIn(12.dp, 36.dp)

            Box(Modifier.fillMaxSize()) {
                if (usingVlc) {
                    val v = vlc
                    if (v != null) AndroidView(
                        factory = { c -> org.videolan.libvlc.util.VLCVideoLayout(c).apply { keepScreenOn = true; videoView = this } },
                        update = { layout -> v.attach(layout); v.setAspect(aspectIdx) },
                        modifier = Modifier.fillMaxSize(),
                    )
                } else AndroidView(
                    factory = { c -> PlayerView(c).apply { useController = false; this.player = player; keepScreenOn = true; videoView = this } },
                    update = { v -> v.resizeMode = resize; v.subtitleView?.visibility = View.GONE },
                    modifier = Modifier.fillMaxSize(),
                )
                // Subtitles live outside the video frame, so zoom / crop never moves or enlarges them.
                if (!usingVlc) AndroidView(
                    factory = { c -> SubtitleView(c).apply { setBottomPaddingFraction(0.07f) } },
                    update = { sv ->
                        sv.setApplyEmbeddedStyles(false); sv.setApplyEmbeddedFontSizes(false)
                        sv.setStyle(subStyle); sv.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, subSize); sv.setCues(cues)
                    },
                    modifier = Modifier.fillMaxSize(),
                )
                // The video surface can't fade itself, so a black layer on top fades away instead.
                Box(Modifier.fillMaxSize().graphicsLayer { alpha = 1f - videoAlpha }.background(Color.Black))
                // Switching link mid-playback: the last frame stays, softly blurred, until the new one is on screen.
                androidx.compose.animation.AnimatedVisibility(switching && failure == null, Modifier.fillMaxSize(), enter = fadeIn(tween(120)), exit = fadeOut(tween(450))) {
                    Box(Modifier.fillMaxSize().background(Color.Black)) {
                        frozen?.let { bmp ->
                            androidx.compose.foundation.Image(bmp.asImageBitmap(), null, Modifier.fillMaxSize().blur(18.dp), contentScale = if (aspectIdx == 1) ContentScale.Crop else ContentScale.Fit)
                        }
                        Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0x33000000), Color(0x99000000)))))
                        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(Modifier.size(38.dp), color = Color.White, strokeWidth = 2.5.dp)
                            Text(
                                (switchLabel?.let { "$it · " } ?: "") + "Continuing at ${fmtTime(resumeAt)}",
                                Modifier.padding(top = 14.dp).clip(RoundedCornerShape(20.dp)).background(Color(0x66000000)).padding(horizontal = 14.dp, vertical = 7.dp),
                                fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFE6E8EE),
                            )
                        }
                    }
                }
            }

            // Gestures:
            //  tap = controls · double-tap left/right = ∓10 s · double-tap middle = play/pause
            //  swipe up/down left = brightness, right = volume · pinch = zoom to fill / original
            //  press & hold = 2x, keep holding and slide right/left = faster/slower (0.5x – 4x)
            Box(
                Modifier.fillMaxSize().pointerInput(locked, firstFrame) {
                    if (!firstFrame) return@pointerInput
                    if (locked) { detectTapGestures(onTap = { controls = !controls; poke++ }); return@pointerInput }
                    val slop = viewConfiguration.touchSlop
                    val longMs = viewConfiguration.longPressTimeoutMillis
                    val stepPx = 36.dp.toPx()
                    var lastTapAt = 0L
                    var lastTapX = 0f
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val start = down.position
                        val downAt = SystemClock.uptimeMillis()
                        var mode = 0 // 0 = undecided, 1 = brightness/volume, 2 = hold speed, 3 = pinch, 4 = ignore
                        val left = start.x < size.width / 2f
                        var level = 0f
                        var pinchStart = 0f
                        var pinchRatio = 1f
                        var baseSpeed = 1f
                        var lastStep = 0
                        while (true) {
                            val wait = if (mode == 0) (longMs - (SystemClock.uptimeMillis() - downAt)).coerceAtLeast(1L) else Long.MAX_VALUE
                            val ev = this.withTimeoutOrNull(wait) { awaitPointerEvent() }
                            if (ev == null) {
                                // Held still long enough: 2x while holding.
                                if (mode == 0) {
                                    mode = 2
                                    baseSpeed = rateNow()
                                    setRate(2f); holdSpeed = 2f
                                    controls = false
                                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                }
                                continue
                            }
                            val pressed = ev.changes.filter { it.pressed }
                            if (pressed.isEmpty()) break
                            if (pressed.size >= 2 && (mode == 0 || mode == 3)) {
                                val d = (pressed[0].position - pressed[1].position).getDistance()
                                if (mode == 0) { mode = 3; pinchStart = d.coerceAtLeast(1f) } else pinchRatio = d / pinchStart
                                ev.changes.forEach { it.consume() }
                                continue
                            }
                            val c = ev.changes.firstOrNull { it.id == down.id } ?: pressed.first()
                            val delta = c.position - start
                            when (mode) {
                                0 -> if (abs(delta.y) > slop && abs(delta.y) > abs(delta.x)) {
                                    mode = 1
                                    val act = ctx as Activity
                                    level = if (left) act.window.attributes.screenBrightness.let { if (it < 0f) 0.5f else it }
                                    else audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol
                                } else if (abs(delta.x) > slop * 2) mode = 4
                                1 -> {
                                    val dy = c.position.y - c.previousPosition.y
                                    level = (level - dy / (size.height * 0.8f)).coerceIn(0f, 1f)
                                    if (left) {
                                        val act = ctx as Activity
                                        act.window.attributes = act.window.attributes.apply { screenBrightness = level.coerceAtLeast(0.01f) }
                                        hud = "brightness" to level
                                    } else {
                                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (level * maxVol).toInt(), 0)
                                        hud = "volume" to level
                                    }
                                    c.consume()
                                }
                                2 -> {
                                    val step = (delta.x / stepPx).toInt()
                                    if (step != lastStep) {
                                        lastStep = step
                                        val sp = (2f + 0.25f * step).coerceIn(0.5f, 4f)
                                        if (sp != holdSpeed) {
                                            setRate(sp); holdSpeed = sp
                                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        }
                                    }
                                    c.consume()
                                }
                            }
                        }
                        when (mode) {
                            0 -> {
                                // A tap. Two quick taps = double-tap.
                                val t = SystemClock.uptimeMillis()
                                if (t - lastTapAt < 300 && abs(start.x - lastTapX) < 120.dp.toPx()) {
                                    tapJob?.cancel(); lastTapAt = 0L
                                    val third = size.width / 3f
                                    when {
                                        start.x < third -> { seekBy(-10_000); seekHint = "-10s" }
                                        start.x > third * 2 -> { seekBy(10_000); seekHint = "+10s" }
                                        else -> { val was = isPlayingNow(); togglePlay(); seekHint = if (was) "❚❚" else "▶" }
                                    }
                                } else {
                                    lastTapAt = t; lastTapX = start.x
                                    tapJob?.cancel()
                                    tapJob = scope.launch {
                                        delay(260)
                                        if (showInfo) showInfo = false else { controls = !controls; poke++ }
                                    }
                                }
                            }
                            1 -> {
                                // Remember the brightness you swiped to (used by "Remember my last").
                                if (left) {
                                    val b = (ctx as Activity).window.attributes.screenBrightness
                                    if (b > 0f) vm.setPlayerPref("bright", b.toString())
                                }
                                hud = null
                            }
                            2 -> { setRate(baseSpeed); holdSpeed = null }
                            3 -> when {
                                pinchRatio > 1.12f && aspectIdx != 1 -> setAspect(1, "Zoomed to fill")
                                pinchRatio < 0.9f && aspectIdx != 0 -> setAspect(0, "Original")
                            }
                        }
                    }
                },
            )

            // Hold-for-speed pill.
            AnimatedVisibility(holdSpeed != null, Modifier.align(Alignment.TopCenter).padding(top = 28.dp), enter = fadeIn(tween(150)), exit = fadeOut(tween(200))) {
                Row(
                    Modifier.clip(RoundedCornerShape(22.dp)).background(Color(0xB3000000)).padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("${(holdSpeed ?: 2f).let { if (it % 1f == 0f) it.toInt().toString() else it.toString() }}x", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(6.dp))
                    Icon(Icons.Default.FastForward, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("Slide ◀ ▶ to change", fontSize = 11.sp, color = Color(0xFFB6BDCC))
                }
            }

            LaunchedEffect(seekHint) { if (seekHint != null) { delay(700); seekHint = null } }
            seekHint?.let {
                Text(it, Modifier.align(when { it.startsWith("-") -> Alignment.CenterStart; it.startsWith("+") -> Alignment.CenterEnd; else -> Alignment.Center }).padding(horizontal = side)
                    .clip(RoundedCornerShape(30.dp)).background(Color(0x88000000)).padding(horizontal = 18.dp, vertical = 10.dp),
                    fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            }
            // Mid-playback buffering: a thin spinner only.
            if (firstFrame && buffering && failure == null) CircularProgressIndicator(Modifier.align(Alignment.Center).size(40.dp), color = Color.White, strokeWidth = 3.dp)
            hud?.let { (kind, lvl) ->
                Row(
                    Modifier.align(Alignment.TopCenter).padding(top = 32.dp).clip(RoundedCornerShape(24.dp)).background(Color(0xB3000000))
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(if (kind == "brightness") Icons.Default.LightMode else if (lvl == 0f) Icons.Default.VolumeOff else Icons.Default.VolumeUp, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Box(Modifier.width(140.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x55FFFFFF))) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth(lvl).background(Color.White))
                    }
                    Spacer(Modifier.width(10.dp))
                    Text("${(lvl * 100).toInt()}%", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            LaunchedEffect(aspectLabel) { if (aspectLabel != null) { delay(1500); aspectLabel = null } }
            aspectLabel?.let {
                Text(it, Modifier.align(Alignment.Center).padding(top = 110.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xB3000000))
                    .padding(horizontal = 16.dp, vertical = 8.dp), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }

            // Content advisory, top-left: white bar + "Category · Level" lines, 12sp.
            AnimatedVisibility(showAdvisory && advisory.isNotEmpty() && !controls, Modifier.align(Alignment.TopStart).padding(start = side, top = 20.dp),
                enter = fadeIn(tween(500)), exit = fadeOut(tween(500))) {
                Row(Modifier.height(IntrinsicSize.Min)) {
                    Box(Modifier.width(3.dp).fillMaxHeight().background(Color.White))
                    Column(Modifier.padding(start = 12.dp)) {
                        advisory.forEach { (cat, level) ->
                            Row(Modifier.padding(vertical = 4.dp)) {
                                Text(cat, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text("  ·  $level", fontSize = 12.sp, color = Color(0xFFB6BDCC))
                            }
                        }
                    }
                }
            }

            // Skip intro / recap, and Next episode near the end.
            val s = segs
            val inIntro = s?.intro?.let { pos >= it.start_ms && pos < it.end_ms - 1500 } == true
            val inRecap = s?.recap?.let { pos >= it.start_ms && pos < it.end_ms - 1500 } == true
            val nearEnd = nextEp != null && dur > 0 && (s?.outro?.let { pos >= it.start_ms } ?: (pos >= dur - 120_000))
            if (firstFrame) Column(Modifier.align(Alignment.BottomEnd).padding(end = side, bottom = if (controls) 128.dp else 32.dp), horizontalAlignment = Alignment.End) {
                if (inIntro || inRecap) PillButton(if (inIntro) "Skip Intro" else "Skip Recap", Icons.Default.FastForward) {
                    seekAbs(if (inIntro) s!!.intro!!.end_ms else s!!.recap!!.end_ms)
                }
                if (nearEnd && !locked) PillButton("Next Episode", Icons.Default.SkipNext) { playNext() }
            }

            // ───── Controls (fade in / out) ─────
            AnimatedVisibility(controls && !locked && !showInfo && firstFrame, Modifier.fillMaxSize(), enter = fadeIn(tween(220)), exit = fadeOut(tween(260))) {
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to Color(0x8C000000), 0.28f to Color(0x26000000), 0.6f to Color(0x33000000), 1f to Color(0xD9000000)))) {
                    Row(Modifier.align(Alignment.TopEnd).padding(top = topY, end = topEnd), horizontalArrangement = Arrangement.spacedBy(33.dp), verticalAlignment = Alignment.CenterVertically) {
                        CtlIcon(Icons.Default.LockOpen, "Lock", 22) { locked = true; controls = true; poke++ }
                        if (quickList.isNotEmpty()) {
                            Row(
                                Modifier.clip(RoundedCornerShape(18.dp)).background(Color(0x33FFFFFF)).border(1.dp, Color(0x26FFFFFF), RoundedCornerShape(18.dp))
                                    .clickable { qualityMenu = !qualityMenu; poke++ }.padding(start = 14.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(QualityLevels.firstOrNull { it.id == quality }?.label ?: "Auto", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Icon(if (qualityMenu) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, null, Modifier.size(18.dp))
                            }
                        }
                        CtlIcon(Icons.AutoMirrored.Filled.ArrowBack, "Back", 22) { onBack() }
                    }
                    // Centre: replay 10 · play/pause · forward 10, 160dp apart (centre to centre).
                    Box(Modifier.align(Alignment.Center).width(380.dp).height(72.dp)) {
                        CtlIcon(Icons.Default.Replay10, "Back 10 seconds", 30, Modifier.align(Alignment.Center).offset(x = (-160).dp)) { seekBy(-10_000) }
                        CtlIcon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "Pause" else "Play", 40, Modifier.align(Alignment.Center)) {
                            togglePlay(); poke++
                        }
                        CtlIcon(Icons.Default.Forward10, "Forward 10 seconds", 30, Modifier.align(Alignment.Center).offset(x = 160.dp)) { seekBy(10_000) }
                    }
                    Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(start = side, end = side, bottom = bottomY)) {
                        Text(meta?.name?.takeIf { type == "movie" } ?: p.title, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        now?.source?.let { Text("Via ${it.replace("\n", " | ")}", Modifier.padding(top = 2.dp), fontSize = 13.sp, color = Color(0xFFA9AFBC), fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        Spacer(Modifier.height(10.dp))
                        SeekBar(pos, buffered, dur) { seekAbs(it); poke++ }
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(29.dp)) {
                            if (nextEp != null) CtlIcon(Icons.Default.SkipNext, "Next episode", 26, pad = 0) { playNext() }
                            CtlIcon(Icons.Default.ClosedCaption, "Subtitles", 26, pad = 0) { panel = "subs" }
                            CtlIcon(Icons.Default.Audiotrack, "Audio", 24, pad = 0) { panel = "audio" }
                            CtlIcon(Icons.Default.CloudQueue, "Sources", 26, pad = 0) { panel = "sources" }
                            CtlIcon(Icons.Default.AspectRatio, "Aspect ratio", 26, pad = 0) {
                                setAspect((aspectIdx + 1) % AspectModes.size); poke++
                            }
                            if (type == "series" && episodes.isNotEmpty()) CtlIcon(Icons.Default.VideoLibrary, "Episodes", 25, pad = 0) { showEpisodes = true; controls = false }
                            if (more) {
                                CtlIcon(Icons.Default.Speed, "Speed", 26, pad = 0) { panel = "speed" }
                                CtlIcon(Icons.Default.OpenInNew, "Open in another player", 24, pad = 0) { pauseNow(); now?.let { openExternal(ctx, it.url, p.title) } }
                                CtlIcon(Icons.Outlined.Info, "Info", 25, pad = 0) { showInfo = true; controls = false }
                            }
                            Box(Modifier.size(30.dp).clip(CircleShape).background(Color(0x40FFFFFF)).clickable { more = !more; poke++ }, Alignment.Center) {
                                Icon(if (more) Icons.Default.ChevronLeft else Icons.Default.ChevronRight, if (more) "Less" else "More", Modifier.size(20.dp))
                            }
                            Spacer(Modifier.weight(1f))
                            Text("${fmtTime(pos)} / ${fmtTime(dur)}", fontSize = 15.sp)
                        }
                    }
                }
            }

            if (locked && controls) {
                Box(Modifier.align(Alignment.TopEnd).padding(top = topY, end = topEnd).size(44.dp).clip(CircleShape).background(Color(0x99000000))
                    .clickable { locked = false; poke++ }, Alignment.Center) { Icon(Icons.Default.Lock, "Unlock", Modifier.size(22.dp)) }
                LaunchedEffect(poke) { delay(2500); if (locked) controls = false }
            }

            // Info screen while paused.
            AnimatedVisibility(
                showInfo, Modifier.fillMaxSize(),
                enter = fadeIn(tween(450)) + androidx.compose.animation.scaleIn(tween(450), initialScale = 1.03f),
                exit = fadeOut(tween(380)) + androidx.compose.animation.scaleOut(tween(380), targetScale = 1.06f),
            ) {
                val m = meta
                // Tap anywhere: the info softly blurs, grows and fades away (no click ripple).
                val infoBlur by transition.animateDp(transitionSpec = { tween(380) }, label = "infoBlur") {
                    if (it == androidx.compose.animation.EnterExitState.Visible) 0.dp else 14.dp
                }
                Box(Modifier.fillMaxSize().blur(infoBlur).background(Brush.horizontalGradient(0f to Color(0xF2000000), 0.6f to Color(0xAA000000), 1f to Color(0x22000000)))
                    .pointerInput(Unit) { detectTapGestures { showInfo = false } }) {
                    Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(0.55f).padding(start = side)) {
                        Text("You're watching", fontSize = 15.sp, color = Color(0xFFB6BDCC))
                        if (m != null && logoOf(m) != null) AsyncImage(logoOf(m), m.name, Modifier.padding(vertical = 10.dp).height(70.dp), contentScale = ContentScale.Fit, alignment = Alignment.CenterStart)
                        else Text(m?.name ?: p.title, fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
                        if (type == "series") Text(p.title.removePrefix(m?.name ?: "").trim(), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                        m?.let { mm ->
                            Text(listOfNotNull(mm.releaseInfo, mm.runtime, mm.imdbRating?.let { "IMDb $it" }).joinToString("  •  "), fontSize = 14.sp, color = Color(0xFFC9CEDB), modifier = Modifier.padding(top = 6.dp))
                            mm.genres?.takeIf { it.isNotEmpty() }?.let { Text(it.take(3).joinToString(" · "), fontSize = 14.sp, color = Accent, modifier = Modifier.padding(top = 4.dp)) }
                            val epDesc = mm.videos?.firstOrNull { it.id == p.key }?.let { it.title ?: it.name }
                            Text(mm.description ?: epDesc ?: "", fontSize = 15.sp, lineHeight = 22.sp, color = Color(0xFFE2E5EC), maxLines = 5, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 12.dp))
                        }
                        Text("Tap anywhere to continue", fontSize = 13.sp, color = Color(0xFF8A94A8), modifier = Modifier.padding(top = 16.dp))
                    }
                }
            }

            // ───── Loading screen: dimmed artwork, "Finding stream source" → "Buffering…" ─────
            if (loadingAlpha > 0.01f) {
                Box(Modifier.fillMaxSize().graphicsLayer { alpha = loadingAlpha }.clickable(interactionSource = noRipple, indication = null) {}) {
                    AsyncImage(p.image ?: meta?.background ?: meta?.poster, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Color(0xA6000000)))
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to Color(0x66000000), 0.5f to Color.Transparent, 1f to Color(0x99000000))))
                    val f = failure
                    if (f == null) {
                        // Finding a source → the cat inspects the poster; buffering → the movie is served under a cloche.
                        val scenePoster = meta?.poster ?: p.image
                        val sceneQuality = when {
                            bestRes >= 2160 -> "4K · SHARP"
                            bestRes >= 1440 -> "1440p · SHARP"
                            bestRes >= 1080 -> "1080p · SHARP"
                            bestRes >= 720 -> "720p · CLEAR"
                            else -> null
                        }
                        Crossfade(status.startsWith("Finding"), Modifier.fillMaxSize(), animationSpec = tween(600), label = "scene") { finding ->
                            if (finding) FindingScene(scenePoster, meta?.name ?: p.title, answered, sourceTotal, sceneQuality, Modifier.fillMaxSize())
                            else ServingScene(scenePoster, bufProgress, Modifier.fillMaxSize())
                        }
                    } else {
                        Column(Modifier.align(Alignment.Center).padding(horizontal = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(f, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                            Row(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                LoadBtn("Find another source", true) { findRequest = if (findRequest < 1) 2 else findRequest + 1 }
                                LoadBtn("Choose source", false) { failure = null; panel = "sources"; status = "Buffering…" }
                            }
                        }
                    }
                    Box(
                        Modifier.align(Alignment.TopEnd).padding(top = 20.dp, end = topEnd - 14.dp).size(50.dp).clip(CircleShape).background(Color(0x80000000)).clickable { onBack() },
                        Alignment.Center,
                    ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", Modifier.size(22.dp)) }
                    // Sources: top-left, a little down from the edge so the thumb reaches it.
                    Box(
                        Modifier.align(Alignment.TopStart).padding(start = 30.dp, top = 74.dp).size(44.dp)
                            .shadow(10.dp, CircleShape, ambientColor = Color.Black, spotColor = Color.Black)
                            .background(Color(0x8C101014), CircleShape).border(1.dp, Color(0x24FFFFFF), CircleShape)
                            .clickable(interactionSource = noRipple, indication = null) { panel = "sources" },
                        Alignment.Center,
                    ) { Icon(Icons.Default.KeyboardArrowDown, "Sources", Modifier.size(20.dp), tint = Color.White) }
                }
            }

            // ───── Quality menu (Auto / Full HD / Mid HD / Low) ─────
            LaunchedEffect(controls) { if (!controls) qualityMenu = false }
            AnimatedVisibility(
                qualityMenu && controls, Modifier.align(Alignment.TopEnd).padding(top = topY + 40.dp, end = topEnd + 40.dp),
                enter = fadeIn(tween(160)) + androidx.compose.animation.scaleIn(spring(dampingRatio = 0.75f, stiffness = 500f), initialScale = 0.9f,
                    transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 0f)),
                exit = fadeOut(tween(140)) + androidx.compose.animation.scaleOut(tween(140), targetScale = 0.95f),
            ) {
                val map = remember(quickList) { vm.qualityMap(quickList) }
                val hideDupes = isOn(opt("qsHideDupes"))
                val shape = RoundedCornerShape(20.dp)
                Column(
                    Modifier.width(230.dp).clip(shape).background(Color(0xF0141418)).border(1.dp, Color(0x1FFFFFFF), shape).padding(vertical = 6.dp),
                ) {
                    map.forEachIndexed { i, (lvl, st) ->
                        val dupOf = if (lvl.id == "auto" || st == null) null else map.subList(1, i).firstOrNull { it.second?.stream?.url == st.stream.url }?.first
                        if (!(dupOf != null && hideDupes)) {
                        val on = lvl.id == quality
                        // Show "1080p" only when this level really has that quality; otherwise nothing.
                        val res = st?.resolution() ?: 0
                        val sub = when {
                            st == null || dupOf != null -> ""
                            lvl.id == "auto" -> if (res > 0) "${res}p" else ""
                            res == lvl.res -> "${res}p"
                            else -> ""
                        }
                        Row(
                            Modifier.fillMaxWidth().clickable(enabled = st != null) { setQuality(lvl.id) }.graphicsLayer { alpha = if (st == null) 0.4f else 1f }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(lvl.label, fontSize = 15.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium)
                                if (sub.isNotEmpty()) Text(sub, fontSize = 12.sp, color = Color(0xFF9AA3B5))
                            }
                            if (on) Icon(Icons.Default.Check, null, Modifier.size(18.dp), tint = Accent)
                        }
                        }
                    }
                }
            }

            // ───── Episodes (series): premium pop-up grouped by season ─────
            EpisodesPopup(
                visible = showEpisodes, episodes = episodes, currentId = p.key, showName = meta?.name ?: "",
                maxW = maxWidth, maxH = maxHeight, onClose = { showEpisodes = false },
            ) { ep -> showEpisodes = false; if (ep.id != p.key) playEpisode(ep) }

            // ───── Side panels slide in from the right ─────
            LaunchedEffect(panel) { panel?.let { lastPanel = it } }
            AnimatedVisibility(panel != null, Modifier.fillMaxSize(), enter = fadeIn(tween(200)), exit = fadeOut(tween(200))) {
                Box(Modifier.fillMaxSize().background(Color(0x66000000)).clickable(interactionSource = noRipple, indication = null) { panel = null })
            }
            AnimatedVisibility(
                panel != null, Modifier.align(Alignment.CenterEnd).fillMaxHeight(),
                enter = slideInHorizontally(spring(dampingRatio = 0.86f, stiffness = 420f)) { it } + fadeIn(tween(160)),
                exit = slideOutHorizontally(tween(220)) { it } + fadeOut(tween(200)),
            ) {
                val which = panel ?: lastPanel
                Column(
                    Modifier.fillMaxHeight().width(400.dp).clip(RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp))
                        .background(Color(0xF5111216)).border(1.dp, Color(0x14FFFFFF), RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp))
                        .clickable(interactionSource = noRipple, indication = null) {}
                        .padding(horizontal = 20.dp, vertical = 20.dp),
                ) {
                    Text(
                        when (which) { "subs" -> "Subtitles"; "audio" -> "Audio"; "speed" -> "Playback speed"; else -> if (vm.qsActive()) "All sources" else "Sources" },
                        fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp),
                    )
                    when (which) {
                        "subs" -> if (usingVlc) vlc?.let { v -> VlcTrackList(v, audio = false, tick = vlcTick) } else TrackList(tracks, C.TRACK_TYPE_TEXT, player, allowOff = true) { lang -> vm.setPlayerPref("subs", lang) }
                        "audio" -> {
                            val versions = remember(known, quickList, now) { vm.languageVersions((known + quickList).distinctBy { it.stream.url }, now?.url) }
                            val main = versions.filter { it.preferred || it.current }
                            val others = versions.filter { !it.preferred && !it.current }
                            val versionRow: @Composable (LangVersion) -> Unit = { v -> Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(enabled = !v.current) { panel = null; switchTo(v.stream, langLabel(v.lang)) }
                                    .padding(vertical = 11.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Text(langLabel(v.lang), Modifier.weight(1f), fontSize = 16.sp, fontWeight = if (v.current) FontWeight.Bold else FontWeight.Normal)
                                v.stream.resolution().takeIf { it > 0 }?.let { Text("${it}p", fontSize = 12.sp, color = Color(0xFF8A94A8)) }
                                if (v.current) Icon(Icons.Default.Check, null, Modifier.padding(start = 8.dp).size(18.dp), tint = Accent)
                            } }
                            if (versions.size > 1) {
                                Column(Modifier.weight(1f, fill = false).verticalScroll(androidx.compose.foundation.rememberScrollState())) {
                                    main.forEach { versionRow(it) }
                                    if (others.isNotEmpty()) {
                                        Row(
                                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { otherLangsOpen = !otherLangsOpen }.padding(vertical = 11.dp, horizontal = 8.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                        ) {
                                            Text("Other languages (${others.size})", Modifier.weight(1f), fontSize = 15.sp, color = Color(0xFFB6BDCC), fontWeight = FontWeight.SemiBold)
                                            Icon(if (otherLangsOpen) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, null, tint = Color(0xFFB6BDCC))
                                        }
                                        AnimatedVisibility(otherLangsOpen) { Column { others.forEach { versionRow(it) } } }
                                    }
                                    Text("Tracks in this file", Modifier.padding(top = 12.dp, bottom = 2.dp), fontSize = 13.sp, color = Color(0xFF8A94A8))
                                    Column(Modifier.heightIn(max = 220.dp)) {
                                        if (usingVlc) vlc?.let { v -> VlcTrackList(v, audio = true, tick = vlcTick) }
                                        else TrackList(tracks, C.TRACK_TYPE_AUDIO, player, allowOff = false) { lang -> vm.setPlayerPref("audio", lang) }
                                    }
                                }
                            } else {
                                if (usingVlc) vlc?.let { v -> VlcTrackList(v, audio = true, tick = vlcTick) }
                                else TrackList(tracks, C.TRACK_TYPE_AUDIO, player, allowOff = false) { lang -> vm.setPlayerPref("audio", lang) }
                            }
                        }
                        "speed" -> OptionList(listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).map { "${it}x" to (speed == it) }) { i ->
                            speed = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)[i]; setRate(speed); panel = null
                        }
                        else -> SourcesPanel(vm, type, p.key, now?.url, except = if (vm.qsActive()) vm.qsAddons() else null) { st, all ->
                            panel = null
                            known = all
                            candidates = all.filter { it !== st }
                            val keep = keepPos()
                            scope.launch {
                                val extra = withTimeoutOrNull(1500) { runCatching { vm.subtitles(type, p.key) }.getOrDefault(emptyList()) }.orEmpty()
                                load(Now(st.stream.url!!, st.stream.subtitles.orEmpty() + extra, st.stream.name ?: st.addonName, st.addonName), keep, "Source changed")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CtlIcon(icon: ImageVector, desc: String, size: Int, modifier: Modifier = Modifier, pad: Int = 8, onClick: () -> Unit) =
    Icon(icon, desc, modifier.clip(CircleShape).clickable(onClick = onClick).padding(pad.dp).size(size.dp), tint = Color.White)

@Composable
private fun LoadBtn(text: String, primary: Boolean, onClick: () -> Unit) =
    Text(text, Modifier.clip(RoundedCornerShape(22.dp)).background(if (primary) Color.White else Color(0x33FFFFFF)).clickable(onClick = onClick)
        .padding(horizontal = 18.dp, vertical = 10.dp), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (primary) Color.Black else Color.White)

@OptIn(UnstableApi::class)
private val AspectModes = listOf(
    "Fit" to AspectRatioFrameLayout.RESIZE_MODE_FIT,
    "Crop" to AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
    "Stretch" to AspectRatioFrameLayout.RESIZE_MODE_FILL,
)

@Composable
private fun PillButton(text: String, icon: ImageVector, onClick: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        Modifier.padding(top = 10.dp).clip(shape).background(Color(0xE6FFFFFF)).border(1.dp, Color(0x33000000), shape)
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, Modifier.size(18.dp), tint = Color.Black)
        Spacer(Modifier.width(6.dp))
        Text(text, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Black)
    }
}

/** 6dp rounded seek bar: white = watched, grey = buffered. Tap or drag to seek. */
@Composable
private fun SeekBar(pos: Long, buffered: Long, dur: Long, onSeek: (Long) -> Unit) {
    var dragFrac by remember { mutableStateOf<Float?>(null) }
    val frac = dragFrac ?: if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
    val bFrac = if (dur > 0) (buffered.toFloat() / dur).coerceIn(0f, 1f) else 0f
    Canvas(
        Modifier.fillMaxWidth().height(22.dp)
            .pointerInput(dur) { detectTapGestures { o -> if (dur > 0) onSeek((o.x / size.width * dur).toLong()) } }
            .pointerInput(dur) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> dragFrac = (o.x / size.width).coerceIn(0f, 1f) },
                    onDragEnd = { dragFrac?.let { if (dur > 0) onSeek((it * dur).toLong()) }; dragFrac = null },
                    onDragCancel = { dragFrac = null },
                ) { change, _ -> dragFrac = (change.position.x / size.width).coerceIn(0f, 1f) }
            },
    ) {
        val h = 6.dp.toPx(); val y = (size.height - h) / 2f; val r = CornerRadius(h / 2f)
        drawRoundRect(Color(0x4DFFFFFF), Offset(0f, y), Size(size.width, h), r)
        drawRoundRect(Color(0x80FFFFFF), Offset(0f, y), Size(size.width * bFrac, h), r)
        drawRoundRect(Color.White, Offset(0f, y), Size(size.width * frac, h), r)
        if (dragFrac != null) drawCircle(Color.White, 8.dp.toPx(), Offset(size.width * frac, size.height / 2f))
    }
}

@Composable
private fun OptionList(options: List<Pair<String, Boolean>>, enabled: List<Boolean> = emptyList(), onPick: (Int) -> Unit) {
    LazyColumn {
        items(options.size) { i ->
            val (label, on) = options[i]
            val en = enabled.getOrElse(i) { true }
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(enabled = en) { onPick(i) }.graphicsLayer { alpha = if (en) 1f else 0.4f }.padding(vertical = 13.dp, horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text(label, Modifier.weight(1f), fontSize = 16.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal)
                if (on) Icon(Icons.Default.Check, null, tint = Accent)
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun TrackList(tracks: Tracks, trackType: Int, player: ExoPlayer, allowOff: Boolean, onRemember: (String) -> Unit) {
    // Every track is listed; ones this phone can't decode are shown greyed out instead of hidden.
    val opts = tracks.groups.filter { it.type == trackType }.flatMap { g ->
        (0 until g.length).map { i ->
            val f = g.getTrackFormat(i)
            val name = listOfNotNull(f.label, f.language?.let { java.util.Locale(it).displayLanguage.takeIf { d -> d.isNotBlank() } ?: it })
                .distinct().joinToString(" · ").ifBlank { "Track ${i + 1}" }
            val codec = if (trackType == C.TRACK_TYPE_AUDIO) audioCodecName(f.sampleMimeType) else null
            val extra = buildString {
                if (trackType == C.TRACK_TYPE_AUDIO && f.channelCount > 0) append("  ").append(channelsLabel(f.channelCount))
                if (codec != null) append("  ").append(codec)
                if (!g.isTrackSupported(i)) append("  · Not supported on this device")
            }
            TrackOpt(name + extra, g, i, g.isTrackSelected(i)) to (g.isTrackSupported(i) to f.language)
        }
    }
    val off = player.trackSelectionParameters.disabledTrackTypes.contains(trackType)
    if (opts.isEmpty()) {
        Text(if (trackType == C.TRACK_TYPE_TEXT) "No subtitles in this stream. Install a subtitles addon to get more." else "Only one audio track.", color = Color(0xFF9AA3B5))
        return
    }
    Text("Your choice is remembered for the next videos.", fontSize = 12.sp, color = Color(0xFF8A94A8), modifier = Modifier.padding(bottom = 6.dp))
    val rows = (if (allowOff) listOf("Off" to off) else emptyList()) + opts.map { it.first.label to (it.first.selected && !off) }
    val enabled = (if (allowOff) listOf(true) else emptyList()) + opts.map { it.second.first }
    OptionList(rows, enabled) { i ->
        val params = player.trackSelectionParameters.buildUpon()
        if (allowOff && i == 0) {
            params.setTrackTypeDisabled(trackType, true)
            onRemember("off")
        } else {
            val (o, info) = opts[if (allowOff) i - 1 else i]
            params.setTrackTypeDisabled(trackType, false).setOverrideForType(TrackSelectionOverride(o.group.mediaTrackGroup, o.index))
            val lang = info.second.orEmpty()
            if (trackType == C.TRACK_TYPE_AUDIO) params.setPreferredAudioLanguage(lang.ifEmpty { null }) else params.setPreferredTextLanguage(lang.ifEmpty { null })
            onRemember(lang)
        }
        player.trackSelectionParameters = params.build()
    }
}

private fun channelsLabel(n: Int) = when (n) { 1 -> "Mono"; 2 -> "Stereo"; 6 -> "5.1"; 8 -> "7.1"; else -> "${n}ch" }

@OptIn(UnstableApi::class)
private fun audioCodecName(mime: String?): String? = when (mime) {
    MimeTypes.AUDIO_AAC -> "AAC"
    MimeTypes.AUDIO_AC3 -> "Dolby Digital"
    MimeTypes.AUDIO_E_AC3, MimeTypes.AUDIO_E_AC3_JOC -> "Dolby Digital+"
    MimeTypes.AUDIO_AC4 -> "AC-4"
    MimeTypes.AUDIO_DTS, MimeTypes.AUDIO_DTS_HD, MimeTypes.AUDIO_DTS_EXPRESS -> "DTS"
    MimeTypes.AUDIO_TRUEHD -> "TrueHD"
    MimeTypes.AUDIO_OPUS -> "Opus"
    MimeTypes.AUDIO_FLAC -> "FLAC"
    MimeTypes.AUDIO_MPEG -> "MP3"
    MimeTypes.AUDIO_VORBIS -> "Vorbis"
    else -> null
}

/** Sources inside the player: same filtered list and badges as the sources page. */
@Composable
private fun SourcesPanel(vm: AppViewModel, type: String, key: String, playingUrl: String?, except: Set<String>? = null, onSwitch: (StreamItem, List<StreamItem>) -> Unit) {
    val texts by vm.texts.collectAsStateWithLifecycle()
    val pack by vm.badgePack.collectAsStateWithLifecycle()
    var all by remember { mutableStateOf<List<StreamItem>>(emptyList()) }
    var done by remember { mutableStateOf(false) }
    var showAll by remember { mutableStateOf(false) }
    LaunchedEffect(key) { vm.streamsFlow(type, key, except = except).collect { (l, d) -> all = l; done = d } }
    val f = remember(all, texts["tagRules"], showAll) { if (showAll) Filtered(all, 0, false, emptyList()) else vm.filtered(all) }
    val fusion = isOn(texts["fusionBadges"] ?: Defaults["fusionBadges"] ?: "yes")
    val showAddon = isOn(texts["showAddonName"] ?: "yes")
    when {
        f.forcedEmpty -> Column {
            Text("No ${f.forcedLabels.joinToString(" / ")} streams for this title.", color = Color(0xFF9AA3B5))
            LoadBtn("Show all streams", true) { showAll = true }
        }
        f.list.isEmpty() && done -> Text("No sources found.", color = Color(0xFF9AA3B5))
        f.list.isEmpty() -> Box(Modifier.fillMaxWidth().padding(30.dp), Alignment.Center) { CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp) }
        else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(f.list) { s ->
                StreamCard(s, fusion, showAddon, pack, playing = s.stream.url == playingUrl, compact = true) { onSwitch(s, f.list) }
            }
            if (!done) item { Box(Modifier.fillMaxWidth().padding(12.dp), Alignment.Center) { CircularProgressIndicator(Modifier.size(24.dp), color = Color.White, strokeWidth = 2.dp) } }
        }
    }
}

/** Episodes pop-up: scales in with a spring, season chips on top, "Now playing" on the current episode. */
@Composable
private fun EpisodesPopup(
    visible: Boolean, episodes: List<Video>, currentId: String, showName: String,
    maxW: androidx.compose.ui.unit.Dp, maxH: androidx.compose.ui.unit.Dp,
    onClose: () -> Unit, onPick: (Video) -> Unit,
) {
    val prog = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(visible) {
        if (visible) prog.animateTo(1f, spring(dampingRatio = 0.8f, stiffness = 380f)) else prog.animateTo(0f, tween(200))
    }
    if (!visible && prog.value <= 0.01f) return
    val seasons = remember(episodes) { episodes.mapNotNull { it.season }.distinct().sorted() }
    val currentSeason = episodes.firstOrNull { it.id == currentId }?.season ?: seasons.firstOrNull() ?: 1
    var season by remember(currentSeason) { mutableIntStateOf(currentSeason) }
    val list = remember(episodes, season) { episodes.filter { it.season == season } }
    val listState = rememberLazyListState()
    LaunchedEffect(season, visible) {
        val i = list.indexOfFirst { it.id == currentId }
        if (visible && i > 0) listState.scrollToItem((i - 1).coerceAtLeast(0))
    }
    val shape = RoundedCornerShape(28.dp)
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().graphicsLayer { alpha = prog.value.coerceIn(0f, 1f) }.background(Color(0xA6000000))
            .clickable(interactionSource = noRipple, indication = null) { onClose() })
        Column(
            Modifier.align(Alignment.Center)
                .width((maxW * 0.86f).coerceAtMost(820.dp)).height((maxH * 0.84f))
                .graphicsLayer {
                    val v = prog.value
                    alpha = v.coerceIn(0f, 1f); scaleX = 0.9f + 0.1f * v; scaleY = scaleX
                }
                .clip(shape)
                .background(Brush.verticalGradient(listOf(Color(0xF21C1C22), Color(0xF5121216))))
                .border(1.dp, Brush.linearGradient(listOf(Color(0x33FFFFFF), Color(0x0AFFFFFF))), shape)
                .clickable(interactionSource = noRipple, indication = null) {}
                .padding(top = 18.dp, bottom = 10.dp),
        ) {
            Row(Modifier.padding(horizontal = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Episodes", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    if (showName.isNotBlank()) Text(showName, fontSize = 13.sp, color = Color(0xFF9AA3B5), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Box(Modifier.size(36.dp).clip(CircleShape).background(Color(0x1FFFFFFF)).clickable { onClose() }, Alignment.Center) {
                    Icon(Icons.Default.Close, "Close", Modifier.size(20.dp))
                }
            }
            LazyRow(contentPadding = PaddingValues(horizontal = 22.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(seasons) { sn ->
                    val on = sn == season
                    Text(
                        "Season $sn" + if (sn == currentSeason) " •" else "",
                        Modifier.clip(RoundedCornerShape(20.dp)).background(if (on) Color.White else Color(0x1AFFFFFF)).clickable { season = sn }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (on) Color.Black else Color.White,
                    )
                }
            }
            LazyColumn(state = listState, contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(list, key = { _, e -> e.id }) { _, ep ->
                    val now = ep.id == currentId
                    val rs = RoundedCornerShape(18.dp)
                    Row(
                        Modifier.fillMaxWidth().clip(rs).background(if (now) Accent.copy(alpha = 0.14f) else Color(0x0DFFFFFF))
                            .border(1.dp, if (now) Accent.copy(alpha = 0.7f) else Color.Transparent, rs)
                            .clickable { onPick(ep) }.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(Modifier.width(150.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(12.dp)).background(Color(0xFF22222A))) {
                            AsyncImage(ep.thumbnail, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            if (now) Box(Modifier.fillMaxSize().background(Color(0x66000000)), Alignment.Center) {
                                Icon(Icons.Default.GraphicEq, null, Modifier.size(28.dp), tint = Color.White)
                            }
                        }
                        Column(Modifier.weight(1f).padding(start = 14.dp, end = 6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("E${ep.episode}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF9AA3B5))
                                if (now) Text("NOW PLAYING", Modifier.padding(start = 8.dp).clip(RoundedCornerShape(6.dp)).background(Accent)
                                    .padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = OnAccent, letterSpacing = 0.5.sp)
                            }
                            Text(ep.title ?: ep.name ?: "Episode ${ep.episode}", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(top = 2.dp))
                            (ep.overview ?: ep.description)?.takeIf { it.isNotBlank() }?.let {
                                Text(it, fontSize = 12.sp, color = Color(0xFFB6BDCC), maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 16.sp, modifier = Modifier.padding(top = 2.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Audio / subtitle lists when the VLC engine is playing. */
@Composable
private fun VlcTrackList(v: VlcEngine, audio: Boolean, tick: Int) {
    var refresh by remember { mutableIntStateOf(0) }
    val list = remember(tick, refresh) { if (audio) v.audioTracks() else v.subTracks() }
    val cur = remember(tick, refresh) { if (audio) v.audioTrack else v.subTrack }
    if (list.isEmpty()) {
        Text(if (audio) "Only one audio track." else "No subtitles in this stream.", color = Color(0xFF9AA3B5))
        return
    }
    val rows = (if (!audio) listOf("Off" to (cur < 0)) else emptyList()) + list.map { it.second to (it.first == cur) }
    OptionList(rows) { i ->
        if (!audio && i == 0) v.selectSub(-1)
        else { val id = list[if (audio) i else i - 1].first; if (audio) v.selectAudio(id) else v.selectSub(id) }
        refresh++
    }
}

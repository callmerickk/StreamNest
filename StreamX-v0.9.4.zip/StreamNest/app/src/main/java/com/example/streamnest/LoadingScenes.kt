package com.example.streamnest

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.FloatState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter
import coil.request.ImageRequest
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/** Inter Display: the airy headline face of the loading scenes (bundled, SIL Open Font License). */
val DisplayFont = FontFamily(
    Font(R.font.inter_display_light, FontWeight.Light),
    Font(R.font.inter_display_semibold, FontWeight.SemiBold),
)

// ───────────── Shared bits ─────────────

private val Gold = Color(0xFFE2B968)
private val GoldDark = Color(0xFFB47A26)
private val GoldLight = Color(0xFFF6DC9C)
private val Ink = Color(0xFFF3EFE8)

/** Seconds since this scene appeared, updated every frame (read it only in draw / placement lambdas). */
@Composable
private fun rememberSceneClock(): FloatState {
    val t = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (true) withFrameNanos { n -> t.floatValue = (n - start) / 1_000_000_000f }
    }
    return t
}

/** The poster as a Painter, loaded big enough to be magnified by the lens. */
@Composable
private fun rememberPosterPainter(poster: String?): Painter {
    val ctx = LocalContext.current
    val req = remember(poster) { ImageRequest.Builder(ctx).data(poster).size(480, 720).build() }
    return rememberAsyncImagePainter(req)
}

/** Draws [painter] like CSS background-size: cover into (0,0)-(w,h). */
private fun DrawScope.drawCover(painter: Painter, w: Float, h: Float) {
    val isz = painter.intrinsicSize
    clipRect(0f, 0f, w, h) {
        if (isz == Size.Unspecified || !(isz.width > 0f) || !(isz.height > 0f)) {
            with(painter) { draw(Size(w, h)) }
        } else {
            val k = max(w / isz.width, h / isz.height)
            val dw = isz.width * k
            val dh = isz.height * k
            translate((w - dw) / 2f, (h - dh) / 2f) { with(painter) { draw(Size(dw, dh)) } }
        }
    }
}

/** Soft dark ellipse under a figure (the "gshadow" of the design). */
private fun DrawScope.groundShadow(left: Float, top: Float, w: Float, h: Float, alpha: Float) {
    val c = Offset(left + w / 2f, top + h / 2f)
    withTransform({ scale(1f, h / w, pivot = c) }) {
        drawCircle(
            Brush.radialGradient(0f to Color.Black.copy(alpha = 0.65f), 1f to Color.Transparent, center = c, radius = w / 2f),
            radius = w / 2f, center = c, alpha = alpha,
        )
    }
}

private fun warmTone(scope: DrawScope) = with(scope) {
    drawRect(
        Brush.radialGradient(
            0f to Color(0x40461610), 1f to Color(0x66000000),
            center = Offset(size.width * 0.52f, size.height * 0.46f), radius = size.maxDimension * 0.6f,
        )
    )
}

/** The poster card: 12dp corners, faint gold rim, deep shadow, darker bottom. */
@Composable
private fun PosterCard(painter: Painter, title: String, s: Float, modifier: Modifier) {
    val shape = RoundedCornerShape((12f * s).dp)
    Box(
        modifier.shadow((18f * s).dp, shape, ambientColor = Color.Black, spotColor = Color.Black)
            .background(Brush.verticalGradient(listOf(Color(0xFF2A2630), Color(0xFF15141A))))
            .border(1.dp, Color(0x52F2D394), shape),
    ) {
        if (title.isNotBlank()) Text(
            title, Modifier.align(Alignment.Center).padding((10f * s).dp), color = Color(0x99FFFFFF),
            textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis,
            fontSize = with(LocalDensity.current) { (12f * s).dp.toSp() }, fontFamily = InterFont, fontWeight = FontWeight.SemiBold,
        )
        Image(painter, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to Color.Transparent, 0.55f to Color.Transparent, 1f to Color(0x80000000))))
    }
}

/** One word in gold, with a sheen sliding across it (like the CSS background-clip:text). */
@Composable
private fun GoldWord(text: String, fontSize: TextUnit, time: FloatState, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier.graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }.drawWithContent {
            drawContent()
            val w = size.width
            val u = (time.floatValue % 3.2f) / 3.2f
            val left = -1.44f * w + u * 2.88f * w
            drawRect(
                Brush.linearGradient(
                    0f to Color(0xFFF7E1A8), 0.45f to Color(0xFFD9A441), 0.55f to Color(0xFFFFF2C9), 1f to Color(0xFFC98A2E),
                    start = Offset(left, 0f), end = Offset(left + 2.2f * w, size.height * 0.18f),
                ),
                blendMode = BlendMode.SrcIn,
            )
        },
        color = Color.White, fontSize = fontSize, fontFamily = DisplayFont, fontWeight = FontWeight.SemiBold,
        letterSpacing = with(LocalDensity.current) { (-0.4).dp.toSp() }, maxLines = 1,
    )
}

/** Kicker, headline with a gold word, and a status line under the stage. */
@Composable
private fun SceneText(kicker: String, pre: String, gold: String, post: String, s: Float, time: FloatState, line: @Composable () -> Unit) {
    val d = LocalDensity.current
    fun tsp(v: Float) = with(d) { (v * s).dp.toSp() }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            kicker, Modifier.padding(top = (6f * s).dp), color = Color(0xD9E8C480), fontSize = tsp(10.5f),
            fontFamily = InterFont, fontWeight = FontWeight.SemiBold, letterSpacing = tsp(3.2f), maxLines = 1,
        )
        val headSize = tsp(25f)
        val spacing = tsp(-0.4f)
        Row(Modifier.padding(top = (6f * s).dp)) {
            Text(pre, Modifier.alignByBaseline(), color = Ink, fontSize = headSize, fontFamily = DisplayFont, fontWeight = FontWeight.Light, letterSpacing = spacing, maxLines = 1)
            Spacer(Modifier.width((6.5f * s).dp))
            GoldWord(gold, headSize, time, Modifier.alignByBaseline())
            Spacer(Modifier.width((6.5f * s).dp))
            Text(post, Modifier.alignByBaseline(), color = Ink, fontSize = headSize, fontFamily = DisplayFont, fontWeight = FontWeight.Light, letterSpacing = spacing, maxLines = 1)
        }
        Box(Modifier.padding(top = (6f * s).dp).height((20f * s).dp), Alignment.Center) { line() }
    }
}

@Composable
private fun SceneLine(text: String, s: Float) {
    Text(
        text, color = Color(0x9EECE8E1), fontSize = with(LocalDensity.current) { (13f * s).dp.toSp() },
        fontFamily = InterFont, fontWeight = FontWeight.Normal, maxLines = 1,
    )
}

/** Stage scale: the 560 × 262 design (plus text) shrinks on small screens, never grows. */
private fun stageScale(maxW: Dp, maxH: Dp): Float = minOf(1f, maxW / 600.dp, maxH / 360.dp).coerceAtLeast(0.3f)

// ───────────── Finding: the cat inspects the poster with a magnifier ─────────────

private const val FPX = 322f
private const val FPY = 24f
private const val FPW = 136f
private const val FPH = 204f
private const val LENS_ZOOM = 2.3f
private const val CAT1_W = 175f
private const val CAT1_H = 230f
// The front paw that holds the magnifier, as a fraction of the cat_inspect image.
private const val PAW1_X = 166f / 175f
private const val PAW1_Y = 116f / 230f

private class FindPose(val catX: Float, val catY: Float, val rot: Float, val sc: Float, val pawX: Float, val pawY: Float, val cx: Float, val cy: Float, val dirX: Float, val dirY: Float)

private fun findPose(t: Float): FindPose {
    val sway = sin(t * 0.8f)
    val lean = max(0f, sin(t * 0.5f))
    val x = 128f + sway * 14f + lean * 10f
    val y = 14f - abs(sin(t * 1.6f)) * 3f
    val rot = sway * 3f + lean * 4f
    val sc = 1f + sin(t * 2.4f) * 0.006f
    val ox = CAT1_W * 0.3f
    val oy = CAT1_H
    val dx = (PAW1_X * CAT1_W - ox) * sc
    val dy = (PAW1_Y * CAT1_H - oy) * sc
    val r = Math.toRadians(rot.toDouble())
    val cr = cos(r).toFloat()
    val sr = sin(r).toFloat()
    val px = x + ox + dx * cr - dy * sr
    val py = y + oy + dx * sr + dy * cr
    val a = Math.toRadians((-28f + sin(t * 1.3f) * 22f).toDouble())
    val ux = cos(a).toFloat()
    val uy = sin(a).toFloat()
    return FindPose(x, y, rot, sc, px, py, px + ux * 44f, py + uy * 44f, ux, uy)
}

/**
 * "Finding the finest copy": a cat stands next to the poster and studies it through a gold magnifier
 * (the poster really is magnified inside the lens). [checked] of [total] sources have answered so far.
 */
@Composable
fun FindingScene(poster: String?, title: String, checked: Int, total: Int, bestQuality: String?, modifier: Modifier = Modifier) {
    val time = rememberSceneClock()
    val posterPainter = rememberPosterPainter(poster)
    val cat = painterResource(R.drawable.cat_inspect)
    var hint by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(1500); hint = (hint + 1) % 3 } }

    BoxWithConstraints(modifier.fillMaxSize().drawBehind { warmTone(this) }) {
        val s = stageScale(maxWidth, maxHeight)
        fun u(v: Float) = (v * s).dp
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(u(560f), u(262f))) {
                PosterCard(posterPainter, title, s, Modifier.offset(u(FPX), u(FPY)).size(u(FPW), u(FPH)))
                Canvas(Modifier.matchParentSize()) {
                    val k = size.width / 560f
                    val p = findPose(time.floatValue)
                    withTransform({ scale(k, k, pivot = Offset.Zero) }) {
                        groundShadow(p.catX + 10f, 240f, 130f, 12f, 1f)
                        // The cat: sways, leans in (rotation around its feet) and breathes.
                        withTransform({
                            translate(p.catX, p.catY)
                            rotate(p.rot, pivot = Offset(CAT1_W * 0.3f, CAT1_H))
                            scale(p.sc, p.sc, pivot = Offset(CAT1_W * 0.3f, CAT1_H))
                        }) { with(cat) { draw(Size(CAT1_W, CAT1_H)) } }

                        // The lens.
                        val c = Offset(p.cx, p.cy)
                        val outer = Path().apply { addOval(Rect(c, 32f)) }
                        clipPath(outer, ClipOp.Difference) {
                            drawCircle(
                                Brush.radialGradient(0f to Color(0x99000000), 0.62f to Color(0x80000000), 1f to Color.Transparent, center = c + Offset(0f, 8f), radius = 50f),
                                radius = 50f, center = c + Offset(0f, 8f),
                            )
                            drawCircle(
                                Brush.radialGradient(0f to Color(0x59E8C27A), 0.64f to Color(0x59E8C27A), 1f to Color.Transparent, center = c, radius = 50f),
                                radius = 50f, center = c,
                            )
                        }
                        val inner = Path().apply { addOval(Rect(c, 29f)) }
                        val lx = p.cx - FPX
                        val ly = p.cy - FPY
                        val inside = lx > 8f && lx < FPW - 8f && ly > 8f && ly < FPH - 8f
                        clipPath(inner) {
                            if (inside) {
                                withTransform({ scale(LENS_ZOOM, LENS_ZOOM, pivot = c) }) {
                                    translate(FPX, FPY) { drawCover(posterPainter, FPW, FPH) }
                                }
                            } else drawCircle(Color(0x1AA0C8FF), 29f, c)
                            drawCircle(Brush.radialGradient(0.62f to Color.Transparent, 1f to Color(0x4D000000), center = c, radius = 29f), 29f, c)
                        }
                        drawCircle(Gold, 30.5f, c, style = Stroke(3f))
                        // Glass highlight (top-left).
                        val hc = c + Offset(-9f, -14.5f)
                        withTransform({ rotate(-30f, pivot = hc) }) {
                            drawArc(Color(0xBFFFFFFF), 200f, 140f, false, topLeft = hc - Offset(10f, 5.5f), size = Size(20f, 11f), style = Stroke(2f, cap = StrokeCap.Round))
                        }
                        // Handle: from the paw to the ring.
                        val paw = Offset(p.pawX, p.pawY)
                        val end = Offset(p.cx - p.dirX * 30f, p.cy - p.dirY * 30f)
                        drawLine(Brush.linearGradient(listOf(Color(0xFFA86E1F), GoldLight), start = paw, end = end), paw, end, strokeWidth = 6f, cap = StrokeCap.Round)
                    }
                }
                if (bestQuality != null) {
                    val shape = RoundedCornerShape(u(8f))
                    Text(
                        bestQuality,
                        Modifier
                            .offset {
                                val p = findPose(time.floatValue)
                                IntOffset(((p.cx + 20f) * s).dp.roundToPx(), ((p.cy - 48f) * s).dp.roundToPx())
                            }
                            .graphicsLayer {
                                val ph = time.floatValue % 4.4f
                                alpha = when {
                                    ph < 2.8f -> 0f
                                    ph < 3.9f -> ((ph - 2.8f) / 0.3f).coerceIn(0f, 1f)
                                    else -> (1f - (ph - 3.9f) / 0.3f).coerceIn(0f, 1f)
                                }
                                shadowElevation = (6f * s).dp.toPx()
                                this.shape = shape
                                clip = true
                            }
                            .background(Brush.horizontalGradient(listOf(GoldLight, Color(0xFFD9A441))))
                            .padding(horizontal = u(7f), vertical = u(3f)),
                        color = Color(0xFF1A1206), fontFamily = InterFont, fontWeight = FontWeight.Bold, maxLines = 1,
                        fontSize = with(LocalDensity.current) { (10f * s).dp.toSp() }, letterSpacing = with(LocalDensity.current) { (0.6f * s).dp.toSp() },
                    )
                }
            }
            SceneText("STREAMX CONCIERGE", "Finding the", "finest", "copy for you", s, time) {
                Crossfade(hint, animationSpec = tween(400), label = "findHint") { i ->
                    val text = when (i) {
                        0 -> if (total > 0) "Checking ${checked.coerceIn(1, total)} of $total sources" else "Looking through your sources"
                        1 -> "Inspecting the picture quality"
                        else -> "Hindi audio first — worth the wait"
                    }
                    Box(Modifier.fillMaxWidth(), Alignment.Center) { SceneLine(text, s) }
                }
            }
        }
    }
}

// ───────────── Serving: the cloche is lifted off the poster ─────────────

private const val SPX = 368f
private const val SPY = 64f
private const val SPW = 104f
private const val SPH = 156f
private const val LID_X = 332f
private const val LID_Y = 52f
private const val LID_OX = 88f
private const val LID_OY = 158.4f
private const val CAT2_W = 221f
private const val CAT2_H = 215f
private const val CAT2_OX = CAT2_W * 0.95f
private const val CAT2_OY = CAT2_H * 0.02f
// The raised paw (lands on the knob) and the nose, in cat_leap image units (221 × 215).
private const val PAW2_X = 209f
private const val PAW2_Y = 5f
private const val NOSE2_X = 153f
private const val NOSE2_Y = 52f

private class ServePose(
    val lidTx: Float, val lidTy: Float, val lidRot: Float, val lidSc: Float,
    val catX: Float, val catY: Float, val catRot: Float, val shX: Float, val shA: Float,
    val sniff: Float, val noseX: Float, val noseY: Float,
)

private fun servePose(b: Float): ServePose {
    val lift = ((b - 1.0f) / 1.3f).coerceIn(0f, 1f)
    val e = 1f - (1f - lift) * (1f - lift) * (1f - lift)
    val bob = sin(b * 2.2f) * 4f * e
    val tx = -118f * e
    val ty = -66f * e + bob
    val rot = -18f * e
    val sc = 1f - 0.32f * e
    // Knob (88, 15) in lid units, through the lid's transform.
    val r = Math.toRadians(rot.toDouble())
    val cr = cos(r).toFloat()
    val sr = sin(r).toFloat()
    val kdx = 0f
    val kdy = (15f - LID_OY) * sc
    val kx = LID_X + tx + LID_OX + kdx * cr - kdy * sr
    val ky = LID_Y + ty + LID_OY + kdx * sr + kdy * cr
    // The cat flies in during the first second; its paw lands on the knob and then follows it.
    val fly = b.coerceIn(0f, 1f)
    val f = 1f - (1f - fly) * (1f - fly) * (1f - fly)
    val ctx = kx - PAW2_X
    val cty = ky - PAW2_Y
    val catX = ctx - (1f - f) * 170f
    val catY = cty + (1f - f) * 80f
    val catRot = (1f - f) * -14f + sin(b * 2.2f) * 2f * e
    val sniff = ((b - 2.4f) / 0.8f).coerceIn(0f, 1f)
    val cr2 = cos(Math.toRadians(catRot.toDouble())).toFloat()
    val sr2 = sin(Math.toRadians(catRot.toDouble())).toFloat()
    val ndx = NOSE2_X - CAT2_OX
    val ndy = NOSE2_Y - CAT2_OY
    val nx = catX + CAT2_OX + ndx * cr2 - ndy * sr2
    val ny = catY + CAT2_OY + ndx * sr2 + ndy * cr2
    return ServePose(tx, ty, rot, sc, catX, catY, catRot, ctx + 40f - (1f - f) * 170f, 0.5f + 0.5f * f, sniff, nx, ny)
}

private val goldH = listOf(GoldDark, GoldLight, GoldDark)

private fun DrawScope.drawPlate() {
    translate(300f, 196f) {
        drawOval(Color.Black.copy(alpha = 0.55f), topLeft = Offset(16f, 32f), size = Size(208f, 16f))
        drawOval(Brush.horizontalGradient(goldH, startX = 10f, endX = 230f), topLeft = Offset(10f, 10f), size = Size(220f, 32f))
        val pc = Offset(120f, 24f)
        withTransform({ scale(1f, 12f / 100f, pivot = pc) }) {
            drawCircle(Brush.radialGradient(listOf(Color(0xFFF4F2EE), Color(0xFF9C9993)), center = Offset(120f, 4f), radius = 120f), radius = 100f, center = pc)
        }
        drawOval(Color(0xFFD9D6CF), topLeft = Offset(46f, 16f), size = Size(148f, 16f))
    }
}

private val lidDome = Path().apply {
    moveTo(8f, 170f)
    cubicTo(8f, 70f, 44f, 22f, 88f, 22f)
    cubicTo(132f, 22f, 168f, 70f, 168f, 170f)
    close()
}
private val lidShine = Path().apply {
    moveTo(40f, 60f)
    cubicTo(52f, 40f, 70f, 32f, 84f, 30f)
}

private fun DrawScope.drawLid() {
    drawPath(
        lidDome,
        Brush.linearGradient(
            0f to Color(0xFFF4F1EA), 0.4f to Color(0xFFAEABA5), 0.72f to Color(0xFF5D5B58), 1f to Color(0xFFC9C5BD),
            start = Offset(8f, 22f), end = Offset(168f, 170f),
        ),
    )
    drawPath(lidShine, Color.White.copy(alpha = 0.55f), style = Stroke(5f, cap = StrokeCap.Round))
    drawRoundRect(Brush.horizontalGradient(goldH, startX = 2f, endX = 174f), topLeft = Offset(2f, 166f), size = Size(172f, 7f), cornerRadius = CornerRadius(3.5f))
    drawCircle(Brush.horizontalGradient(goldH, startX = 80f, endX = 96f), radius = 8f, center = Offset(88f, 15f))
}

/** Rounded-rect outline around the small poster, starting at the top-left corner, clockwise. */
private val progressPath = Path().apply {
    val l = SPX + 1.5f
    val t = SPY + 1.5f
    val r = l + 101f
    val b = t + 153f
    val rad = 11f
    moveTo(l + rad, t)
    lineTo(r - rad, t)
    arcTo(Rect(r - 2 * rad, t, r, t + 2 * rad), -90f, 90f, false)
    lineTo(r, b - rad)
    arcTo(Rect(r - 2 * rad, b - 2 * rad, r, b), 0f, 90f, false)
    lineTo(l + rad, b)
    arcTo(Rect(l, b - 2 * rad, l + 2 * rad, b), 90f, 90f, false)
    lineTo(l, t + rad)
    arcTo(Rect(l, t, l + 2 * rad, t + 2 * rad), 180f, 90f, false)
    close()
}

private fun easeOut(x: Float) = 1f - (1f - x) * (1f - x)

/**
 * "Serving it fresh": the poster stands on a gold plate under a silver cloche; a cat leaps in, lifts the lid
 * by its knob and sniffs the steam. A gold outline around the poster shows [progress] (0..1).
 */
@Composable
fun ServingScene(poster: String?, progress: Float, modifier: Modifier = Modifier) {
    val time = rememberSceneClock()
    val posterPainter = rememberPosterPainter(poster)
    val cat = painterResource(R.drawable.cat_leap)
    val prog by animateFloatAsState(progress.coerceIn(0f, 1f), tween(300), label = "serveProgress")
    val measure = remember { PathMeasure().apply { setPath(progressPath, false) } }
    val segment = remember { Path() }

    BoxWithConstraints(modifier.fillMaxSize().drawBehind { warmTone(this) }) {
        val s = stageScale(maxWidth, maxHeight)
        fun u(v: Float) = (v * s).dp
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(u(560f), u(262f))) {
                // Plate and the cat's shadow (below the poster).
                Canvas(Modifier.matchParentSize()) {
                    val k = size.width / 560f
                    val p = servePose(time.floatValue)
                    withTransform({ scale(k, k, pivot = Offset.Zero) }) {
                        drawPlate()
                        groundShadow(p.shX, 238f, 120f, 12f, p.shA)
                    }
                }
                PosterCard(posterPainter, "", s, Modifier.offset(u(SPX), u(SPY)).size(u(SPW), u(SPH)))
                // Progress outline, lid, steam, the cat and the scent trails.
                Canvas(Modifier.matchParentSize()) {
                    val k = size.width / 560f
                    val b = time.floatValue
                    val p = servePose(b)
                    withTransform({ scale(k, k, pivot = Offset.Zero) }) {
                        if (prog > 0.002f) {
                            segment.reset()
                            measure.getSegment(0f, measure.length * prog, segment, true)
                            drawPath(segment, Gold.copy(alpha = 0.22f), style = Stroke(9f, cap = StrokeCap.Round))
                            drawPath(segment, Gold.copy(alpha = 0.4f), style = Stroke(5.5f, cap = StrokeCap.Round))
                            drawPath(segment, Gold, style = Stroke(3f, cap = StrokeCap.Round))
                        }
                        withTransform({
                            translate(LID_X + p.lidTx, LID_Y + p.lidTy)
                            rotate(p.lidRot, pivot = Offset(LID_OX, LID_OY))
                            scale(p.lidSc, p.lidSc, pivot = Offset(LID_OX, LID_OY))
                        }) { drawLid() }
                        // Wisps of steam.
                        val wisps = floatArrayOf(392f, 44f, 418f, 38f, 444f, 44f)
                        for (i in 0 until 3) {
                            val delayS = 0.8f * i
                            if (b < delayS) continue
                            val q = ((b - delayS) % 2.4f) / 2.4f
                            val a = if (q < 0.4f) 0.85f * (q / 0.4f) else 0.85f * (1f - (q - 0.4f) / 0.6f)
                            val e = q * q
                            val x = wisps[i * 2] - 8f * e
                            val y = wisps[i * 2 + 1] + 8f - 42f * e
                            drawRoundRect(
                                Brush.verticalGradient(listOf(Color.Transparent, Color(0x99FFF0DC), Color.Transparent), startY = y, endY = y + 30f),
                                topLeft = Offset(x - 0.5f, y), size = Size(3.5f, 30f), cornerRadius = CornerRadius(2f), alpha = a.coerceIn(0f, 1f),
                            )
                        }
                        // Soft smoke puffs.
                        val puffs = floatArrayOf(372f, 40f, 46f, 402f, 28f, 56f, 432f, 40f, 42f, 392f, 50f, 38f, 422f, 34f, 50f)
                        for (i in 0 until 5) {
                            val delayS = 0.6f * i
                            if (b < delayS) continue
                            val q = ((b - delayS) % 3.2f) / 3.2f
                            val a = if (q < 0.3f) 0.9f * easeOut(q / 0.3f) else 0.9f * (1f - easeOut((q - 0.3f) / 0.7f))
                            val e = easeOut(q)
                            val w = puffs[i * 3 + 2]
                            val c = Offset(puffs[i * 3] + w / 2f - 14f * e, puffs[i * 3 + 1] + w / 2f + 10f - 70f * e)
                            val rad = (w / 2f) * (0.5f + 1.1f * e) + 4f
                            drawCircle(
                                Brush.radialGradient(0f to Color(0x57FFF4E6), 0.45f to Color(0x2EFFF4E6), 1f to Color.Transparent, center = c, radius = rad),
                                radius = rad, center = c, alpha = a.coerceIn(0f, 1f),
                            )
                        }
                        // The cat.
                        withTransform({
                            translate(p.catX, p.catY)
                            rotate(p.catRot, pivot = Offset(CAT2_OX, CAT2_OY))
                        }) { with(cat) { draw(Size(CAT2_W, CAT2_H)) } }
                        // Scent trails from the poster to the nose, once the lid is up.
                        if (p.sniff > 0f) {
                            val nx = p.noseX
                            val ny = p.noseY
                            val sc1 = Path().apply { moveTo(432f, 70f); quadraticBezierTo((432f + nx) / 2f + 20f, ny - 34f, nx + 6f, ny) }
                            val sc2 = Path().apply { moveTo(410f, 78f); quadraticBezierTo((410f + nx) / 2f + 10f, ny - 10f, nx + 6f, ny + 6f) }
                            val ph1 = ((-b * 20f) % 10f + 10f) % 10f
                            val ph2 = ((-b * 16f) % 10f + 10f) % 10f
                            drawPath(sc1, Color(0x99FFECC8), alpha = p.sniff,
                                style = Stroke(2f, cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 6f), ph1)))
                            drawPath(sc2, Color(0x6BFFECC8), alpha = p.sniff,
                                style = Stroke(2f, cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(3f, 7f), ph2)))
                        }
                    }
                }
            }
            val pct = (prog * 100f).roundToInt().coerceIn(0, 100)
            val phase = when {
                prog < 0.45f -> "Plating your movie"
                prog < 0.8f -> "Smells perfect"
                else -> "Your table is ready"
            }
            SceneText("STREAMX KITCHEN", "Serving it", "fresh", "for you", s, time) { SceneLine("$phase · $pct%", s) }
        }
    }
}

package com.example.streamnest

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.graphics.vector.ImageVector
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

sealed interface Screen {
    data class Detail(val meta: Meta) : Screen
    data class Player(val title: String, val url: String, val subs: List<Subtitle>, val key: String = "", val image: String? = null, val resumeMs: Long = 0L) : Screen
    data object Settings : Screen
    data object Live : Screen
}

@Composable
fun App(vm: AppViewModel = viewModel()) {
    val stack = remember { mutableStateListOf<Screen>() }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var voiceOpen by rememberSaveable { mutableStateOf(false) }
    val pop = { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex); Unit }
    val profile by vm.current.collectAsStateWithLifecycle()
    val texts by vm.texts.collectAsStateWithLifecycle()

    // Hotstar-style: scrolling down hides the filter pill and shrinks the bar, scrolling up restores both.
    var scrolledDown by remember { mutableStateOf(false) }
    // Navigation bar style (Help & Settings > Layout): adaptive hides/shrinks while scrolling.
    val navStyle = texts["navStyle"] ?: "adaptive"
    val chrome = when (navStyle) { "expanded" -> true; "compact" -> !scrolledDown; else -> !scrolledDown }
    val compactBar = when (navStyle) { "expanded" -> false; "compact" -> true; else -> scrolledDown }
    val scrollWatcher = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < -6f) scrolledDown = true else if (available.y > 6f) scrolledDown = false
                return Offset.Zero
            }
        }
    }
    val homeList = rememberLazyListState()
    val scope = rememberCoroutineScope()

    BackHandler(stack.isNotEmpty() || (profile != null && tab != 0)) { if (stack.isNotEmpty()) pop() else tab = 0 }

    CompositionLocalProvider(LocalTexts provides texts) {
        LaunchedEffect(profile == null) { if (profile == null) stack.clear() }
        val open: (Meta) -> Unit = { stack.add(Screen.Detail(it)) }
        if (profile == null) WhoIsWatchingScreen(vm) { tab = 0; scrolledDown = false }
        else when (val top = stack.lastOrNull()) {
            is Screen.Player -> PlayerScreen(top, onBack = pop, onProgress = { pos, dur ->
                if (top.key.isNotEmpty()) vm.saveProgress(Progress(top.key, top.title, top.image, top.url, top.subs, pos, dur, System.currentTimeMillis()))
            })
            is Screen.Detail -> DetailScreen(vm, top.meta, onBack = pop, onPlay = { stack.add(it) })
            Screen.Settings -> Box(Modifier.fillMaxSize().background(Bg)) { SettingsHost(vm, onClose = pop) }
            Screen.Live -> Box(Modifier.fillMaxSize().background(Bg)) { LiveTvScreen(vm, onBack = pop) { stack.add(it) } }
            null -> Box(Modifier.fillMaxSize().background(Bg).nestedScroll(scrollWatcher)) {
                when (tab) {
                    0 -> HomeScreen(
                        vm, homeList, chrome, open, { stack.add(it) },
                        onLive = { stack.add(Screen.Live) },
                        onAi = { voiceOpen = true },
                    )
                    1 -> SearchScreen(vm, "", open)
                    else -> MySpaceScreen(
                        vm,
                        onSettings = { stack.add(Screen.Settings) },
                        onSwitchProfile = { vm.leaveProfile() },
                        onOpen = open,
                        onPlay = { stack.add(it) },
                    )
                }
                BottomNav(
                    tab, vm, compact = compactBar,
                    onTab = {
                        scrolledDown = false
                        if (it == 0 && tab == 0) { scope.launch { homeList.animateScrollToItem(0) }; vm.refresh() } else tab = it
                    },
                    modifier = Modifier.align(Alignment.BottomCenter),
                )
                if (voiceOpen) VoiceAssistant(vm, onClose = { voiceOpen = false }) { voiceOpen = false; open(it) }
            }
        }
    }
}

/** Hotstar-style bottom bar: 3 items, dark base with a glowing curved top edge. Shrinks while scrolling down. */
@Composable
fun BottomNav(tab: Int, vm: AppViewModel, compact: Boolean, onTab: (Int) -> Unit, modifier: Modifier = Modifier) {
    val barH by animateDpAsState(if (compact) 50.dp else 66.dp, label = "barH")
    val glow = Accent
    val glow2 = Palette.accent2
    Box(modifier.fillMaxWidth()) {
        Canvas(Modifier.matchParentSize()) {
            // A planet-like horizon: rises from the left, peaks a little right of centre, falls gently on the right.
            val yl = 26.dp.toPx(); val yr = 18.dp.toPx(); val peak = (-6).dp.toPx()
            val surface = Path().apply {
                moveTo(0f, yl); quadraticBezierTo(size.width * 0.5f, peak, size.width, yr)
                lineTo(size.width, size.height); lineTo(0f, size.height); close()
            }
            drawPath(surface, Brush.verticalGradient(listOf(Color(0xFA120E18), Color(0xFF07080C))))
            val edge = Path().apply { moveTo(0f, yl); quadraticBezierTo(size.width * 0.5f, peak, size.width, yr) }
            // Light is strongest on the left and fades towards the right, like sunrise on a horizon.
            val light = Brush.horizontalGradient(listOf(glow2, glow, glow.copy(alpha = 0.35f), glow.copy(alpha = 0.08f)))
            drawPath(edge, light, style = Stroke(width = 14.dp.toPx()), alpha = 0.10f)
            drawPath(edge, light, style = Stroke(width = 7.dp.toPx()), alpha = 0.22f)
            drawPath(edge, light, style = Stroke(width = 2.2.dp.toPx()))
        }
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(top = 14.dp).height(barH),
            horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically,
        ) {
            NavItem(tab == 0, t("navHome"), compact, { onTab(0) }) { c -> Icon(Icons.Default.AutoAwesome, t("navHome"), Modifier.size(if (compact) 24.dp else 28.dp), tint = c) }
            NavItem(tab == 1, t("navSearch"), compact, { onTab(1) }) { c -> Icon(Icons.Default.Search, t("navSearch"), Modifier.size(if (compact) 24.dp else 28.dp), tint = c) }
            NavItem(tab == 2, t("navMySpace"), compact, { onTab(2) }) { _ ->
                Avatar(vm, if (compact) 26.dp else 30.dp, if (tab == 2) Modifier.border(2.dp, Color.White, CircleShape) else Modifier)
            }
        }
    }
}

@Composable
private fun NavItem(selected: Boolean, label: String, compact: Boolean, onClick: () -> Unit, icon: @Composable (Color) -> Unit) {
    val c = if (selected) Color.White else Color(0xFF8A94A8)
    Box(
        Modifier.width(96.dp).fillMaxHeight().clip(RoundedCornerShape(22.dp)).clickable(onClick = onClick)
            .then(if (selected) Modifier.background(Brush.radialGradient(listOf(Accent.copy(alpha = 0.42f), Accent.copy(alpha = 0.10f), Color.Transparent))) else Modifier),
        Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            icon(c)
            if (selected && !compact) Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = c, maxLines = 1)
        }
    }
}

@Composable
fun Poster(m: Meta, modifier: Modifier = Modifier, onClick: (Meta) -> Unit) {
    AsyncImage(
        model = m.poster, contentDescription = m.name, contentScale = ContentScale.Crop,
        modifier = modifier.aspectRatio(2f / 3f).clip(RoundedCornerShape(posterCorner())).background(Surface1).clickable { onClick(m) },
    )
}

// ───────────── Search ─────────────
@Composable
fun SearchScreen(vm: AppViewModel, initial: String, onOpen: (Meta) -> Unit) {
    var q by rememberSaveable(initial) { mutableStateOf(initial) }
    val res by vm.searchResults.collectAsStateWithLifecycle()
    Column(Modifier.statusBarsPadding().padding(16.dp)) {
        OutlinedTextField(
            q, { q = it; vm.search(it) }, Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text(t("searchHint")) }, leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(14.dp),
        )
        LazyVerticalGrid(
            GridCells.Adaptive(105.dp), contentPadding = PaddingValues(top = 16.dp, bottom = 140.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp),
        ) { items(res, key = { it.type + it.id }) { m -> Poster(m, Modifier.fillMaxWidth(), onOpen) } }
    }
}

// ───────────── Detail ─────────────
@Composable
fun DetailScreen(vm: AppViewModel, meta0: Meta, onBack: () -> Unit, onPlay: (Screen.Player) -> Unit) {
    var meta by remember { mutableStateOf(meta0) }
    LaunchedEffect(meta0.id) { vm.fullMeta(meta0)?.let { meta = it } }
    val scope = rememberCoroutineScope()
    var pick by remember { mutableStateOf<Pair<String, String>?>(null) } // videoId to title
    var streams by remember { mutableStateOf<List<StreamItem>?>(null) }
    LaunchedEffect(pick) { streams = null; pick?.let { streams = vm.streams(meta.type, it.first) } }

    val episodes = remember(meta) { meta.videos.orEmpty().filter { it.season != null && it.episode != null } }
    val seasons = remember(episodes) { episodes.mapNotNull { it.season }.distinct().sorted() }
    var season by remember(seasons) { mutableIntStateOf(seasons.firstOrNull { it > 0 } ?: seasons.firstOrNull() ?: 1) }
    val shown = remember(episodes, season) { episodes.filter { it.season == season }.sortedBy { it.episode } }

    Box(Modifier.fillMaxSize().background(Bg)) {
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Box(Modifier.fillMaxWidth().height(340.dp)) {
                    AsyncImage(meta.background ?: meta.poster, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x66000000), Color.Transparent, Bg))))
                }
            }
            item {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    Text(meta.name, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    val line = listOfNotNull(meta.releaseInfo, meta.runtime, meta.imdbRating?.let { "★ $it" }).joinToString("  •  ")
                    Text(line, color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                    meta.genres?.takeIf { it.isNotEmpty() }?.let { Text(it.joinToString(" • "), color = Accent, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)) }
                    if (episodes.isEmpty()) {
                        Button({ pick = meta.id to meta.name }, Modifier.fillMaxWidth().padding(top = 14.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent), shape = RoundedCornerShape(8.dp)) {
                            Icon(Icons.Default.PlayArrow, null); Text(t("playBtn"), fontWeight = FontWeight.Bold)
                        }
                    }
                    meta.description?.let { Text(it, color = Color(0xFFD0D4DC), fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 14.dp)) }
                    if (seasons.isNotEmpty()) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 14.dp)) {
                            items(seasons) { s -> FilterChip(season == s, { season = s }, { Text(if (s == 0) "Specials" else "Season $s") }) }
                        }
                    }
                }
            }
            items(shown, key = { it.id }) { ep ->
                Row(
                    Modifier.fillMaxWidth().clickable { pick = ep.id to "${meta.name}  S${ep.season}E${ep.episode}" }.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    AsyncImage(ep.thumbnail, null, Modifier.width(120.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(6.dp)).background(Surface1), contentScale = ContentScale.Crop)
                    Spacer(Modifier.width(12.dp))
                    Text("${ep.episode}. ${ep.title ?: ep.name ?: "Episode ${ep.episode}"}", maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.PlayCircle, null, tint = Accent)
                }
            }
            item { Spacer(Modifier.height(32.dp)) }
        }
        IconButton(onBack, Modifier.statusBarsPadding().padding(8.dp).background(Color(0x88000000), CircleShape)) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
    }

    pick?.let { (vid, title) ->
        AlertDialog(
            onDismissRequest = { pick = null },
            containerColor = Surface1,
            title = { Text(t("chooseSource")) },
            text = {
                val list = streams
                when {
                    list == null -> Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) { CircularProgressIndicator() }
                    list.isEmpty() -> Text(t("noStreams"))
                    else -> LazyColumn(Modifier.heightIn(max = 380.dp)) {
                        items(list) { s ->
                            Column(Modifier.fillMaxWidth().clickable {
                                scope.launch {
                                    val subs = s.stream.subtitles.orEmpty() + vm.subtitles(meta.type, vid)
                                    pick = null
                                    onPlay(Screen.Player(title, s.stream.url!!, subs, key = vid, image = meta.background ?: meta.poster))
                                }
                            }.padding(vertical = 10.dp)) {
                                Text(s.stream.name ?: s.addonName, fontWeight = FontWeight.SemiBold)
                                Text(s.stream.title ?: s.stream.description ?: "", color = Color.Gray, fontSize = 12.sp, maxLines = 3)
                                if (isOn(t("showAddonName"))) Text("via ${s.addonName}", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                            HorizontalDivider(color = Color(0x22FFFFFF))
                        }
                    }
                }
            },
            confirmButton = { TextButton({ pick = null }) { Text("Cancel") } },
        )
    }
}

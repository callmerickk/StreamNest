package com.example.streamnest

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

private const val REPO_URL = "https://github.com/callmerickk/StreamNest"

// ───────────── Help & Settings: page stack ─────────────

@Composable
fun SettingsHost(vm: AppViewModel, onClose: () -> Unit) {
    val pages = remember { mutableStateListOf("root") }
    var devUnlocked by remember { mutableStateOf(false) }
    val back: () -> Unit = {
        if (pages.size > 1) {
            if (pages.last() == "dev") devUnlocked = false
            pages.removeAt(pages.lastIndex)
        } else onClose()
    }
    val open: (String) -> Unit = { pages.add(it) }
    BackHandler(pages.size > 1) { back() }

    when (pages.last()) {
        "profile" -> ProfileScreen(vm, back)
        "account" -> AccountScreen(vm, back)
        "layout" -> LayoutPage(vm, back, open)
        "homeLayout" -> HomeLayoutPage(vm, back)
        "cw" -> ContinueWatchingPage(vm, back)
        "poster" -> PosterStylePage(vm, back)
        "streams" -> StreamsPage(vm, back)
        "content" -> ContentPage(back, open)
        "addons" -> AddonsPage(vm, back)
        "about" -> LicensesPage(back)
        "advanced" -> AdvancedPage(vm, back, open)
        "dev" -> if (devUnlocked) DevCorner(vm, back) else DevGate(vm, onUnlocked = { devUnlocked = true }, onBack = back)
        else -> SettingsRootPage(vm, onClose, open)
    }
}

@Composable
private fun Page(title: String, onBack: (() -> Unit)?, content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(bottom = 40.dp)) {
        PageHeader(title, onBack)
        content()
    }

@Composable
private fun SettingsRootPage(vm: AppViewModel, onClose: () -> Unit, open: (String) -> Unit) {
    val uri = LocalUriHandler.current
    Page("Settings", onClose) {
        Spacer(Modifier.height(8.dp))
        SettingsCard {
            SettingRow(Icons.Default.People, "My Profile", "Your viewing pulse, library signals, and profile actions.") { open("profile") }
            RowDivider()
            SettingRow(Icons.Default.AccountCircle, "Account", "Where your data lives and history controls.") { open("account") }
        }
        SectionLabel("General")
        SettingsCard {
            SettingRow(Icons.Default.Palette, "Layout", "Themes, home, posters and navigation bar.") { open("layout") }
            RowDivider()
            SettingRow(Icons.Default.Extension, "Content & Discovery", "Manage addons and discovery sources.") { open("content") }
            RowDivider()
            SettingRow(Icons.Default.PlayArrow, "Playback", "Player, subtitles, and auto-play.", enabled = false, badge = "v0.5") {}
            RowDivider()
            SettingRow(Icons.Default.Link, "Integrations", "Trakt, TMDB, ratings and AI assistant.", enabled = false, badge = "Soon") {}
            RowDivider()
            SettingRow(Icons.Default.Notifications, "Notifications", "Episode release alerts.", enabled = false, badge = "Soon") {}
        }
        SectionLabel("About")
        SettingsCard {
            SettingRow(Icons.Default.Info, "Licenses & Attribution", "Data sources, acknowledgements, and licenses.") { open("about") }
            RowDivider()
            SettingRow(Icons.Default.CloudDownload, "Check for updates", "Open the build page on GitHub.") { uri.openUri("$REPO_URL/actions") }
        }
        SectionLabel("Advanced")
        SettingsCard {
            SettingRow(Icons.Default.Tune, "Advanced", "Startup, cache and Developer's Corner.") { open("advanced") }
        }
        Column(Modifier.fillMaxWidth().padding(top = 36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppLogo(vm, 26.dp)
                Spacer(Modifier.width(8.dp))
                Text(t("appName"), fontFamily = BrandFont, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            Text("Version ${vm.appVersion}", Modifier.padding(top = 6.dp), fontSize = 14.sp, color = Muted)
        }
    }
}

// ───────────── Layout ─────────────

private data class ThemeOpt(val name: String, val c1: Long, val c2: Long, val enhanced: Boolean = false)

private val Themes = listOf(
    ThemeOpt("White", 0xFFF2F2F2, 0xFFFFFFFF), ThemeOpt("Crimson", 0xFFE8323C, 0xFFFF6A5C),
    ThemeOpt("Ocean", 0xFF2E86DE, 0xFF5AB0FF), ThemeOpt("Violet", 0xFF9B3FD1, 0xFFC27BFF),
    ThemeOpt("Emerald", 0xFF2EAD5B, 0xFF5CD98A), ThemeOpt("Amber", 0xFFF5A20A, 0xFFFFC857),
    ThemeOpt("Rose", 0xFFE3376F, 0xFFFF7AA6),
    ThemeOpt("Messenger", 0xFF0A84FF, 0xFF00C6FF, true), ThemeOpt("Amethyst", 0xFF8B4DFF, 0xFFD08CFF, true),
    ThemeOpt("Blossom", 0xFFE3376F, 0xFFFF9AC2, true), ThemeOpt("Lagoon", 0xFF1294C8, 0xFF3EE6C1, true),
    ThemeOpt("Sunset", 0xFFFF5E62, 0xFFFFB347, true),
)

private fun hex(c: Color) = String.format("#%06X", c.toArgb() and 0xFFFFFF)

private fun applyTheme(vm: AppViewModel, name: String, c1: Color, c2: Color) {
    vm.setText("theme", name)
    vm.setText("accent", hex(c1))
    vm.setText("accent2", hex(c2))
    vm.setText("deckTint", hex(lerp(Color(0xFF0B0F1A), c1, 0.22f)))
}

@Composable
private fun ThemeDot(name: String, c1: Color, c2: Color, enhanced: Boolean, custom: Boolean, selected: Boolean, onClick: () -> Unit) {
    Column(Modifier.width(96.dp).clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(74.dp).then(if (selected) Modifier.border(2.dp, Color.White, RoundedCornerShape(18.dp)) else Modifier).padding(6.dp),
            Alignment.Center,
        ) {
            val fill = when {
                custom -> Modifier.border(4.dp, Brush.sweepGradient(listOf(Color.Red, Color.Yellow, Color.Green, Color.Cyan, Color.Blue, Color.Magenta, Color.Red)), CircleShape).background(Color.Black, CircleShape)
                enhanced -> Modifier.background(Brush.sweepGradient(listOf(c2, c1, c2)), CircleShape)
                else -> Modifier.background(c1, CircleShape)
            }
            Box(Modifier.size(58.dp).clip(CircleShape).then(fill), Alignment.Center) {
                if (selected) Icon(Icons.Default.Check, null, tint = if (c1.red + c1.green + c1.blue > 2.2f) Color.Black else Color.White)
            }
        }
        Text(name, fontSize = 14.sp, letterSpacing = 1.sp, color = if (selected) Color.White else Muted, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
        Box(Modifier.padding(top = 6.dp).width(40.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Brush.horizontalGradient(listOf(c1, c2))))
    }
}

@Composable
private fun LayoutPage(vm: AppViewModel, onBack: () -> Unit, open: (String) -> Unit) {
    val texts by vm.texts.collectAsStateWithLifecycle()
    val cur = texts["theme"] ?: Defaults["theme"]!!
    var navDialog by remember { mutableStateOf(false) }
    var customDialog by remember { mutableStateOf(false) }
    val navStyle = texts["navStyle"] ?: "adaptive"
    val navNames = linkedMapOf("adaptive" to "Adaptive", "expanded" to "Always Expanded", "compact" to "Always Compact")

    Page("Layout", onBack) {
        SectionLabel("Theme")
        SettingsCard {
            Text("Classic themes", Modifier.padding(start = 20.dp, top = 18.dp, bottom = 4.dp), fontSize = 15.sp, color = Muted, letterSpacing = 1.sp)
            Themes.filter { !it.enhanced }.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    row.forEach { th -> ThemeDot(th.name, Color(th.c1), Color(th.c2), false, false, cur == th.name) { applyTheme(vm, th.name, Color(th.c1), Color(th.c2)) } }
                    repeat(3 - row.size) { Spacer(Modifier.width(96.dp)) }
                }
            }
            HorizontalDivider(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), color = Color(0x12FFFFFF))
            Text("Enhanced themes", Modifier.padding(start = 20.dp, top = 6.dp, bottom = 4.dp), fontSize = 15.sp, color = Muted, letterSpacing = 1.sp)
            val enhanced = Themes.filter { it.enhanced }
            (enhanced.map { it.name } + "Custom").chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    row.forEach { name ->
                        val th = enhanced.firstOrNull { it.name == name }
                        if (th != null) ThemeDot(th.name, Color(th.c1), Color(th.c2), true, false, cur == th.name) { applyTheme(vm, th.name, Color(th.c1), Color(th.c2)) }
                        else ThemeDot("Custom", Palette.accent, Palette.accent2, false, true, cur == "Custom") { customDialog = true }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.width(96.dp)) }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        SectionLabel("Display")
        SettingsCard {
            ToggleRow("AMOLED Black", "Use pure black backgrounds for OLED screens.", isOn(texts["amoled"] ?: "no")) { vm.setText("amoled", if (it) "yes" else "no") }
            RowDivider(20.dp)
            SettingRow(null, "Navigation Bar", navNames[navStyle] ?: "Adaptive") { navDialog = true }
        }
        SectionLabel("Home")
        SettingsCard {
            SettingRow(null, "Home Layout", "Hero cards, row order and visibility.") { open("homeLayout") }
            RowDivider(20.dp)
            SettingRow(null, "Continue Watching", "Settings for the Continue Watching section.") { open("cw") }
            RowDivider(20.dp)
            SettingRow(null, "Poster Card Style", "Tune card width and corner radius.") { open("poster") }
        }
        SectionLabel("Streams")
        SettingsCard { SettingRow(null, "Streams", "How stream sources are listed.") { open("streams") } }
        SectionLabel("Detail Page")
        SettingsCard { SettingRow(null, "Detail Page", "Settings for the detail and episode screens.", enabled = false, badge = "v0.6") {} }
    }

    if (navDialog) AlertDialog(
        onDismissRequest = { navDialog = false },
        containerColor = Surface1,
        title = { Text("Navigation Bar Style") },
        text = {
            Column {
                navNames.forEach { (key, label) ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { vm.setText("navStyle", key); navDialog = false }.padding(vertical = 14.dp, horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text(label, Modifier.weight(1f), fontSize = 18.sp, fontWeight = FontWeight.Medium)
                        if (navStyle == key) Icon(Icons.Default.Check, null)
                    }
                }
                Text("Adaptive: the capsule hides and the bar shrinks while you scroll down.", fontSize = 13.sp, color = Muted, modifier = Modifier.padding(top = 6.dp))
            }
        },
        confirmButton = {},
    )

    if (customDialog) {
        var a by remember { mutableStateOf(hex(Palette.accent)) }
        var b by remember { mutableStateOf(hex(Palette.accent2)) }
        AlertDialog(
            onDismissRequest = { customDialog = false },
            containerColor = Surface1,
            title = { Text("Custom theme") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(a, { a = it }, singleLine = true, label = { Text("Main colour (hex)") }, shape = RoundedCornerShape(12.dp))
                    OutlinedTextField(b, { b = it }, singleLine = true, label = { Text("Second colour (hex)") }, shape = RoundedCornerShape(12.dp))
                    val c1 = parseColor(a); val c2 = parseColor(b)
                    Box(Modifier.fillMaxWidth().height(36.dp).clip(RoundedCornerShape(18.dp))
                        .background(if (c1 != null && c2 != null) Brush.horizontalGradient(listOf(c1, c2)) else Brush.horizontalGradient(listOf(Color.DarkGray, Color.DarkGray))))
                }
            },
            confirmButton = {
                TextButton({
                    val c1 = parseColor(a); val c2 = parseColor(b)
                    if (c1 != null && c2 != null) { applyTheme(vm, "Custom", c1, c2); customDialog = false }
                }) { Text("Apply") }
            },
            dismissButton = { TextButton({ customDialog = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun HomeLayoutPage(vm: AppViewModel, onBack: () -> Unit) {
    val texts by vm.texts.collectAsStateWithLifecycle()
    val all by vm.shelves.collectAsStateWithLifecycle()
    fun v(k: String) = texts[k] ?: Defaults[k] ?: ""
    val hidden = v("rowsHidden").split("|").filter { it.isNotBlank() }.toSet()
    val rows = arrangeShelves(all, v("rowsOrder"))
    val visibleCount = rows.count { it.title !in hidden }

    Page("Home Layout", onBack) {
        Column(Modifier.padding(16.dp).fillMaxWidth().clip(CardShape).background(CardBg).border(1.dp, Color(0x12FFFFFF), CardShape).padding(20.dp)) {
            Text("Keep Home focused", fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            Text("$visibleCount of ${rows.size} rows visible • Hero ${if (isOn(v("showHero"))) "on" else "off"}", fontSize = 16.sp, color = Muted, modifier = Modifier.padding(top = 4.dp))
            Text("Hide rows you don't need and move your favourites up.", fontSize = 13.sp, color = Muted, modifier = Modifier.padding(top = 6.dp))
        }
        SectionLabel("Home layout")
        SettingsCard {
            ToggleRow("Show Hero Section", "Display the sliding cards at the top of Home.", isOn(v("showHero"))) { vm.setText("showHero", if (it) "yes" else "no") }
            RowDivider(20.dp)
            ToggleRow("Auto-slide", "Cards move on their own every few seconds.", v("autoSlide").trim().lowercase() != "no") { vm.setText("autoSlide", if (it) "yes" else "no") }
            Row(Modifier.padding(start = 20.dp, end = 20.dp, bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(3, 5, 8, 10).forEach { sec ->
                    FilterChip(v("slideSeconds").trim() == sec.toString(), { vm.setText("slideSeconds", sec.toString()) }, { Text("$sec sec") })
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { SectionLabel("Rows") }
            TextButton({ vm.setText("rowsHidden", ""); vm.setText("rowsOrder", "") }, Modifier.padding(top = 12.dp)) {
                Text("Reset to Default", color = Color.White, fontWeight = FontWeight.SemiBold)
            }
        }
        if (rows.isEmpty()) Text("Rows appear here once Home has loaded.", Modifier.padding(horizontal = 24.dp), color = Muted)
        else SettingsCard {
            rows.forEachIndexed { i, shelf ->
                if (i > 0) RowDivider(20.dp)
                val visible = shelf.title !in hidden
                Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 10.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(shelf.title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${shelf.items.size} titles · ${if (visible) "Visible" else "Hidden"}", fontSize = 13.sp, color = Muted)
                    }
                    Switch(visible, { on ->
                        val h = hidden.toMutableSet(); if (on) h.remove(shelf.title) else h.add(shelf.title)
                        vm.setText("rowsHidden", h.joinToString("|"))
                    })
                    IconButton({ move(vm, rows, i, -1) }, enabled = i > 0) { Icon(Icons.Default.KeyboardArrowUp, "Move up") }
                    IconButton({ move(vm, rows, i, 1) }, enabled = i < rows.lastIndex) { Icon(Icons.Default.KeyboardArrowDown, "Move down") }
                }
            }
        }
    }
}

private fun move(vm: AppViewModel, rows: List<Shelf>, i: Int, by: Int) {
    val list = rows.map { it.title }.toMutableList()
    val j = i + by
    if (j !in list.indices) return
    val x = list.removeAt(i); list.add(j, x)
    vm.setText("rowsOrder", list.joinToString("|"))
}

@Composable
private fun StyleTile(title: String, sub: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit, art: @Composable () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier.clip(shape).background(CardBg).border(if (selected) 2.dp else 1.dp, if (selected) Color.White else Color(0x12FFFFFF), shape)
            .clickable(onClick = onClick).padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.fillMaxWidth().height(70.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF26262C)), Alignment.Center) { art() }
        Text(title, Modifier.padding(top = 10.dp), fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text(sub, fontSize = 12.sp, color = Muted, textAlign = TextAlign.Center)
    }
}

@Composable
private fun ContinueWatchingPage(vm: AppViewModel, onBack: () -> Unit) {
    val texts by vm.texts.collectAsStateWithLifecycle()
    val style = texts["cwStyle"] ?: "card"
    var confirm by remember { mutableStateOf(false) }
    Page("Continue Watching", onBack) {
        SectionLabel("Visibility")
        SettingsCard {
            ToggleRow("Show Continue Watching", "Display the Continue Watching shelf on the Home screen.", isOn(texts["cwShow"] ?: "yes")) { vm.setText("cwShow", if (it) "yes" else "no") }
        }
        SectionLabel("Card style")
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StyleTile("Card", "TV-style landscape card", style == "card", Modifier.weight(1f), { vm.setText("cwStyle", "card") }) {
                Column(Modifier.width(70.dp)) {
                    Box(Modifier.fillMaxWidth().height(32.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF55555E)))
                    Box(Modifier.padding(top = 6.dp).width(46.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(Color(0xFF8A8A94)))
                }
            }
            StyleTile("Wide", "Info on the artwork", style == "wide", Modifier.weight(1f), { vm.setText("cwStyle", "wide") }) {
                Box(Modifier.width(78.dp).height(42.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF55555E))) {
                    Box(Modifier.align(Alignment.BottomStart).padding(5.dp).width(40.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(Color.White))
                }
            }
            StyleTile("Poster", "Artwork-first tall card", style == "poster", Modifier.weight(1f), { vm.setText("cwStyle", "poster") }) {
                Box(Modifier.width(34.dp).height(50.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF55555E))) {
                    Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(4.dp).background(Accent))
                }
            }
        }
        SectionLabel("Cache")
        SettingsCard { SettingRow(Icons.Default.DeleteSweep, "Clear Continue Watching", "Remove everything from this profile's Continue Watching.") { confirm = true } }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, containerColor = Surface1,
        title = { Text("Clear Continue Watching?") },
        text = { Text("Your watchlist stays. Only resume points for this profile are removed.") },
        confirmButton = { TextButton({ vm.progress.value.map { it.key }.forEach { vm.removeProgress(it) }; confirm = false }) { Text("Clear") } },
        dismissButton = { TextButton({ confirm = false }) { Text("Cancel") } },
    )
}

@Composable
private fun PosterStylePage(vm: AppViewModel, onBack: () -> Unit) {
    val texts by vm.texts.collectAsStateWithLifecycle()
    fun v(k: String) = texts[k] ?: Defaults[k] ?: ""
    val wName = v("posterWidth"); val cName = v("posterCorner")
    val w = PosterWidths[wName] ?: 126; val c = PosterCorners[cName] ?: 12
    val landscape = isOn(v("landscapePosters"))
    Page("Poster Card Style", onBack) {
        Row(Modifier.fillMaxWidth().padding(end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { SectionLabel("Poster card style") }
            TextButton({ listOf("posterWidth", "posterCorner", "landscapePosters", "hideLabels").forEach { vm.setText(it, Defaults[it]!!) } }, Modifier.padding(top = 12.dp)) {
                Text("Reset to Default", color = Color.White, fontWeight = FontWeight.SemiBold)
            }
        }
        SettingsCard {
            Column(Modifier.padding(20.dp)) {
                Text("Tune card width and corner radius.", color = Muted)
                Text("Live Preview", Modifier.padding(top = 12.dp, bottom = 10.dp), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.Top) {
                    val pw = if (landscape) (w * 1.87f).coerceAtMost(200f) else w.toFloat()
                    Box(
                        Modifier.width(pw.dp).aspectRatio(if (landscape) 16f / 9f else 2f / 3f).clip(RoundedCornerShape(c.dp))
                            .background(Brush.linearGradient(listOf(Palette.accent.copy(alpha = 0.55f), Color(0xFF1C1C22)))),
                    )
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text("Width: ${if (landscape) (w * 1.87f).toInt() else w}dp", fontSize = 16.sp)
                        Text("Corner radius: ${c}dp", fontSize = 16.sp)
                        Text("Height: ${if (landscape) (w * 1.87f * 9 / 16).toInt() else w * 3 / 2}dp", fontSize = 14.sp, color = Muted)
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 16.dp), color = Color(0x12FFFFFF))
                Text("Width ($wName)", fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                ChipGrid(PosterWidths.keys.toList(), wName) { vm.setText("posterWidth", it) }
                Text("Corner Radius ($cName)", Modifier.padding(top = 12.dp), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                ChipGrid(PosterCorners.keys.toList(), cName) { vm.setText("posterCorner", it) }
            }
            ToggleRow("Landscape Posters", "Wide Hotstar-style cards on Home.", landscape) { vm.setText("landscapePosters", if (it) "yes" else "no") }
            ToggleRow("Hide labels", "Hide title logos on wide cards.", isOn(v("hideLabels"))) { vm.setText("hideLabels", if (it) "yes" else "no") }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun ChipGrid(options: List<String>, selected: String, onPick: (String) -> Unit) {
    options.chunked(3).forEach { row ->
        Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            row.forEach { o ->
                val on = o == selected
                val shape = RoundedCornerShape(14.dp)
                Text(
                    o, Modifier.clip(shape).background(if (on) Color(0xFF2E2E36) else Color.Transparent)
                        .border(1.dp, if (on) Color.Transparent else Color(0x33FFFFFF), shape).clickable { onPick(o) }
                        .padding(horizontal = 18.dp, vertical = 10.dp),
                    fontSize = 16.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium, color = if (on) Color.White else Muted,
                )
            }
        }
    }
}

@Composable
private fun StreamsPage(vm: AppViewModel, onBack: () -> Unit) {
    val texts by vm.texts.collectAsStateWithLifecycle()
    Page("Streams", onBack) {
        SectionLabel("Display")
        SettingsCard {
            ToggleRow("Addon name", "Show which addon each stream source comes from.", isOn(texts["showAddonName"] ?: "yes")) { vm.setText("showAddonName", if (it) "yes" else "no") }
        }
    }
}

// ───────────── Content & Discovery ─────────────

@Composable
private fun ContentPage(onBack: () -> Unit, open: (String) -> Unit) {
    Page("Content & Discovery", onBack) {
        SectionLabel("Sources")
        SettingsCard {
            SettingRow(null, "Addons", "Install, remove, refresh, and sort your content sources.") { open("addons") }
        }
    }
}

@Composable
private fun AddonsPage(vm: AppViewModel, onBack: () -> Unit) {
    val addons by vm.addons.collectAsStateWithLifecycle()
    val texts by vm.texts.collectAsStateWithLifecycle()
    val error by vm.addError.collectAsStateWithLifecycle()
    var url by remember { mutableStateOf("") }
    val activeCount = remember(addons, texts) { addons.count { vm.isAddonOn(it) } }
    val catalogs = addons.sumOf { it.manifest.catalogs.size }

    Page(t("addonsTitle"), onBack) {
        SectionLabel("Overview")
        Row(Modifier.padding(horizontal = 16.dp).fillMaxWidth().clip(CardShape).background(CardBg).padding(vertical = 22.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf("${addons.size}" to "Addons", "$activeCount" to "Active", "$catalogs" to "Catalogs").forEachIndexed { i, (n, l) ->
                if (i > 0) Box(Modifier.width(1.dp).height(44.dp).background(Color(0x22FFFFFF)))
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(n, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text(l, fontSize = 16.sp, color = Muted)
                }
            }
        }
        SectionLabel("Add addon")
        Column(Modifier.padding(horizontal = 16.dp).fillMaxWidth().clip(CardShape).background(CardBg).padding(18.dp)) {
            Text(t("addonsHint"), fontSize = 13.sp, color = Muted, modifier = Modifier.padding(bottom = 10.dp))
            OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text(t("addonUrlHint")) }, shape = RoundedCornerShape(16.dp))
            Spacer(Modifier.height(12.dp))
            Button(
                { vm.addAddon(url); url = "" }, Modifier.fillMaxWidth().height(54.dp), enabled = url.isNotBlank(), shape = RoundedCornerShape(27.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF2F2F2), contentColor = Color.Black),
            ) { Text("Install Addon", fontSize = 17.sp, fontWeight = FontWeight.SemiBold) }
            error?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)) }
        }
        SectionLabel("Installed addons")
        addons.forEachIndexed { i, a ->
            val on = vm.isAddonOn(a)
            Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth().clip(CardShape).background(CardBg).padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(58.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF26262C)), Alignment.Center) {
                        Icon(Icons.Default.Extension, null, Modifier.size(32.dp), tint = Color(0xFF6FB6FF))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(a.manifest.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("Version ${a.manifest.version}", fontSize = 15.sp, color = Muted)
                    }
                    Switch(on, { vm.toggleAddon(a) })
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.End) {
                    IconButton({ vm.moveAddon(a, -1) }, enabled = i > 0) { Icon(Icons.Default.ArrowUpward, "Move up") }
                    IconButton({ vm.moveAddon(a, 1) }, enabled = i < addons.lastIndex) { Icon(Icons.Default.ArrowDownward, "Move down") }
                    IconButton({ vm.reloadAddon(a) }) { Icon(Icons.Default.Refresh, "Refresh") }
                    if (a.baseUrl != CINEMETA) IconButton({ vm.removeAddon(a) }) { Icon(Icons.Default.Delete, "Remove", tint = Color(0xFFE86F8A)) }
                }
                HorizontalDivider(Modifier.padding(vertical = 10.dp), color = Color(0x12FFFFFF))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(if (on) "Active" else "Off", "${vm.resourceCount(a)} resources", "${a.manifest.catalogs.size} catalogs").forEach {
                        Text(it, Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFF26262C)).padding(horizontal = 12.dp, vertical = 6.dp), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                a.manifest.description?.let { Text(it, Modifier.padding(top = 10.dp), fontSize = 15.sp, color = Color(0xFFC9CEDB), maxLines = 3, overflow = TextOverflow.Ellipsis) }
                if (a.manifest.types.isNotEmpty()) Text(a.manifest.types.joinToString(" / ") { it.replaceFirstChar { c -> c.uppercase() } }, Modifier.padding(top = 6.dp), fontSize = 13.sp, color = Muted)
            }
        }
    }
}

// ───────────── About & Advanced ─────────────

@Composable
private fun LicensesPage(onBack: () -> Unit) {
    val items = listOf(
        "Cinemeta" to "Movie and series metadata, provided by the Stremio Cinemeta addon.",
        "Stremio addon protocol" to "Catalogs, streams and subtitles come from the addons you install.",
        "AndroidX Media3 / ExoPlayer" to "Video playback. Apache License 2.0.",
        "Jetpack Compose & Material 3" to "User interface. Apache License 2.0.",
        "Coil" to "Image, GIF and video-frame loading. Apache License 2.0.",
        "OkHttp" to "Networking. Apache License 2.0.",
        "Kotlinx Serialization" to "JSON parsing. Apache License 2.0.",
        "Poppins" to "Wordmark font. SIL Open Font License 1.1.",
        "Android speech services" to "Voice assistant uses the speech recognition and text-to-speech built into your phone.",
    )
    Page("Licenses & Attribution", onBack) {
        Spacer(Modifier.height(8.dp))
        SettingsCard {
            items.forEachIndexed { i, (name, desc) ->
                if (i > 0) RowDivider(20.dp)
                Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
                    Text(name, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Text(desc, fontSize = 14.sp, color = Muted)
                }
            }
        }
        Text("This app does not host any content. Everything shown comes from the addons you add.", Modifier.padding(24.dp), fontSize = 13.sp, color = Muted)
    }
}

@Composable
private fun AdvancedPage(vm: AppViewModel, onBack: () -> Unit, open: (String) -> Unit) {
    val texts by vm.texts.collectAsStateWithLifecycle()
    var confirm by remember { mutableStateOf(false) }
    Page("Advanced", onBack) {
        SectionLabel("Startup")
        SettingsCard {
            ToggleRow("Remember Last Profile", "Skip \"Who's watching?\" and open the last profile at startup.", isOn(texts["rememberProfile"] ?: "no")) {
                vm.setText("rememberProfile", if (it) "yes" else "no")
            }
        }
        SectionLabel("Cache")
        SettingsCard {
            SettingRow(null, "Clear Continue Watching Cache", "Remove cached Continue Watching data and refresh watch progress.") { confirm = true }
        }
        SectionLabel("Developer")
        SettingsCard {
            SettingRow(Icons.Default.Code, "Developer's Corner", "App name, logo, password and UI editing.") { open("dev") }
        }
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, containerColor = Surface1,
        title = { Text("Clear Continue Watching?") },
        text = { Text("Resume points and watch stats for this profile will be reset. Your watchlist stays.") },
        confirmButton = { TextButton({ vm.clearHistory(); confirm = false }) { Text("Clear") } },
        dismissButton = { TextButton({ confirm = false }) { Text("Cancel") } },
    )
}

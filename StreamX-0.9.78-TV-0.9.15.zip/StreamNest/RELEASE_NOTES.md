StreamX 0.9.78

• Glass theme: one frosted picture behind the whole title page, it no longer turns off or goes black.
• Trailers play inside the title card (tap), hold for every trailer.
• Late sources (Nuvio, slow plugins) join the backups by themselves.
• Blocked file sites are reached through StreamX's relay.
• Jumping in a file that can't jump moves quietly to one that can.

---

StreamX TV 0.9.15 

• Back on Home no longer freezes or closes the app.
• The first open after an update stays open.
• Posters load once at start (no more reloading).
• Home appears at once and refreshes quietly.

StreamX 0.9.61

• MovieBox plays smoothly again.
• If the video keeps buffering, StreamX moves to a better copy by itself.
• Choosing a language in Audio now plays that language (some files were labelled wrongly inside).
• MovieBox's other languages are in Audio & Subtitles; picking one fades over to it.
• Trailers on the top cards stay inside their card.

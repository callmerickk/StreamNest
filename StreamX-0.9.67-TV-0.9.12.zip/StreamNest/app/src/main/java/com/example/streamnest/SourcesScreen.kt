package com.example.streamnest

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage

private val StreamCardBg = Color(0xFF121216)

/** One small Fusion-style badge. Uses the badge pack image when there is one. */
@Composable
fun BadgeChip(b: Badge) {
    if (b.image != null) {
        AsyncImage(b.image, b.text.ifBlank { null }, Modifier.height(20.dp).widthIn(max = 90.dp), contentScale = ContentScale.Fit)
        return
    }
    Text(
        b.text,
        Modifier.clip(RoundedCornerShape(6.dp)).background(b.kind.bg)
            .then(if (b.kind == BadgeKind.Dv) Modifier.border(1.dp, Color(0x55FFFFFF), RoundedCornerShape(6.dp)) else Modifier)
            .padding(horizontal = 7.dp, vertical = 3.dp),
        fontSize = 11.sp, fontWeight = FontWeight.Bold, color = b.kind.fg, maxLines = 1, letterSpacing = 0.2.sp,
    )
}

/** Stream card: badge row, stream name, then the addon's own description lines. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StreamCard(
    s: StreamItem, fusion: Boolean, showAddon: Boolean, pack: List<PackBadge>,
    playing: Boolean = false, compact: Boolean = false, onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(if (compact) 16.dp else 20.dp)
    // The built-in servers: no names, file names or descriptions for normal users — quality, language and tags only.
    val masked = !Public.dev && (Public.isDevChoice(s.addonName) || s.addonName.startsWith("CloudStream · ") || s.addonName.startsWith("Nuvio · "))
    Column(
        Modifier.fillMaxWidth().clip(shape).background(StreamCardBg)
            .border(1.dp, if (playing) Accent.copy(alpha = 0.8f) else Color(0x0FFFFFFF), shape)
            .clickable(enabled = !playing, onClick = onClick)
            .padding(horizontal = if (compact) 14.dp else 18.dp, vertical = if (compact) 12.dp else 16.dp),
    ) {
        if (fusion || masked) {
            val badges = remember(s, pack, masked) { s.badges(pack).filter { b -> !masked || !Public.realNames.containsMatchIn(b.text) } }
            if (badges.isNotEmpty()) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 10.dp)) {
                    badges.forEach { BadgeChip(it) }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (masked) listOfNotNull(if (s.addonName.startsWith("CloudStream · ") || s.addonName.startsWith("Nuvio · ")) Public.streamName(s) else Public.serverName(s.addonName), Prepare.qualityName(s.effectiveRes()), VisualTags.primary(s)).joinToString(" · ")
                else (s.stream.name ?: addonLabel(s.addonName)).replace("\n", " "), Modifier.weight(1f),
                fontSize = if (compact) 15.sp else 17.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
            if (playing) Text("Playing", Modifier.padding(start = 8.dp), color = Accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        if (masked) s.languages().takeIf { it.isNotEmpty() }?.let { l ->
            Text(l.joinToString(" + ") { it.replaceFirstChar { c -> c.uppercase() } }, fontSize = if (compact) 13.sp else 15.sp, color = Color(0xFFC9CDD6), modifier = Modifier.padding(top = 3.dp))
        }
        if (!masked) s.detailLines().forEach { line ->
            Text(line, fontSize = if (compact) 13.sp else 15.sp, color = Color(0xFFC9CDD6), lineHeight = if (compact) 18.sp else 21.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp))
        }
        if (showAddon && !masked) Text("via ${Public.streamName(s)}", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
    }
}

/** Grey shimmering placeholder while addons answer. */
@Composable
private fun SkeletonCard() {
    val a by animateFloatAsState(1f, tween(600), label = "sk")
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(StreamCardBg).padding(18.dp).graphicsLayer { alpha = a }) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { repeat(4) { Box(Modifier.size(46.dp, 18.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF1F1F25))) } }
        Box(Modifier.padding(top = 12.dp).fillMaxWidth(0.6f).height(16.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF1F1F25)))
        Box(Modifier.padding(top = 8.dp).fillMaxWidth(0.8f).height(12.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF1A1A1F)))
        Box(Modifier.padding(top = 6.dp).fillMaxWidth(0.5f).height(12.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF1A1A1F)))
    }
}

/** Data the sources page needs about what is being played. */
data class SourceTarget(val videoId: String, val title: String, val epLabel: String?, val epTitle: String?, val image: String?)

/**
 * Full-screen sources page (like the screenshot): backdrop header with ratings, episode label and title,
 * "Resume from" pill, addon filter chips, and stream cards with Fusion badges.
 */
@Composable
fun SourcesScreen(
    vm: AppViewModel,
    meta: Meta,
    target: SourceTarget,
    resumeMs: Long,
    onBack: () -> Unit,
    onPick: (picked: StreamItem, all: List<StreamItem>, resume: Long) -> Unit,
) {
    val texts by vm.texts.collectAsStateWithLifecycle()
    val pack by vm.badgePack.collectAsStateWithLifecycle()
    fun v(k: String) = texts[k] ?: Defaults[k] ?: ""
    LaunchedEffect(v("badgePack")) { vm.loadBadgePack(v("badgePack")) }

    var reload by remember { mutableIntStateOf(0) }
    var all by remember { mutableStateOf<List<StreamItem>>(emptyList()) }
    var done by remember { mutableStateOf(false) }
    LaunchedEffect(target.videoId, reload) {
        all = emptyList(); done = false
        vm.streamsFlow(meta.type, target.videoId).collect { (l, d) -> all = l; done = d }
    }
    // StreamX: plugin mode's links (CloudStream / Nuvio) come in the main list; they get their own chips. Addon mode: none.
    fun isPlugin(s: StreamItem) = s.addonName.startsWith("CloudStream · ") || s.addonName.startsWith("Nuvio · ")
    var showAll by remember(target.videoId) { mutableStateOf(false) }
    val rules = remember(texts["tagRules"]) { parseTagRules(v("tagRules")) }
    // Links a slow-server addon (CNCVerse) finds later appear here by themselves (asked again every 5 s).
    LaunchedEffect(target.videoId) { SlowAddons.watch(vm, meta.type, target.videoId) }
    val slow by SlowAddons.links.collectAsStateWithLifecycle()
    val merged = remember(all, slow[target.videoId]) { (all + slow[target.videoId].orEmpty()).distinctBy { it.stream.url } }
    // Download-only files and 480p / 720p are never offered here (auto-play may still use them as a last resort).
    val f = remember(merged, rules, showAll) { (if (showAll) Filtered(merged, 0, false, emptyList()) else applyTagRules(merged, rules)).let { r -> r.copy(list = r.list.filter { it.manualOk() }) } }
    // Three sections: Quick play (the built-in quick server), Backup play (the built-in HD servers, grouped by picture tag;
    // a group plays its best-ranked file) and Your addons (the ones you installed, with every detail).
    val own = remember(f.list) { f.list.filter { !Public.isDevChoice(it.addonName) && !isPlugin(it) } }
    val csItems = remember(f.list) { f.list.filter { it.addonName.startsWith("CloudStream · ") } }
    val nuItems = remember(f.list) { f.list.filter { it.addonName.startsWith("Nuvio · ") } }
    val quickItems = remember(f.list) {
        f.list.filter { Public.isDevChoice(it.addonName) && vm.isQuick(it) }.distinctBy { it.stream.url }
            .sortedWith(compareBy<StreamItem> { vm.langRank(it) }.thenByDescending { it.effectiveRes() })
    }
    val backupGroups = remember(f.list) {
        val l = f.list.filter { Public.isDevChoice(it.addonName) && !vm.isQuick(it) }.distinctBy { it.stream.url }
            .filter { !Ranker.isDead(it) && !Ranker.keepsFailing(it) && HostStats.penalty(it.stream.url.orEmpty()) == 0 && !it.unplayableHere() }
            .sortedWith(compareByDescending<StreamItem> { Ranker.score(it) }.thenByDescending { it.effectiveRes() })
        tagGroups(l, PicturePref.order(vm))
    }
    // Quick Play = the ONE stream that is ready (prepared on the title page, else the link that played last, else the
    // best quick one); every other source follows as a backup.
    val prep by Prepare.state.collectAsState()
    val quickOne = remember(f.list, prep) {
        prep?.takeIf { it.key == target.videoId }?.item?.let { pi -> f.list.firstOrNull { it.stream.url == pi.stream.url } ?: pi }
            ?: vm.lastLink(target.videoId)?.let { ll -> f.list.firstOrNull { it.stream.url == ll.url } }
            ?: quickItems.firstOrNull()
    }
    val addons = remember(own) { own.map { it.addonName }.distinct() }
    // Turbo (plugin mode): Quick Play is the first tab — the one ready stream, then the backups in the order they'd
    // play (MovieBox, VegaMovies 1080p…); Turbo holds every other plugin link, then Extensions.
    val plug = vm.pluginMode()
    var addon by remember(target.videoId) { mutableStateOf<String?>(if (plug) QP_TAB else null) }
    val csRanked = remember(f.list) { if (plug) vm.rankedCandidates(f.list.filter { it.addonName.startsWith("CloudStream · ") }, "auto", quickOnly = false) else emptyList() }
    val plugQuick = remember(csRanked, prep) {
        if (!plug) null else prep?.takeIf { it.key == target.videoId }?.item?.let { pi -> csRanked.firstOrNull { it.stream.url == pi.stream.url } ?: pi }
            ?: vm.lastLink(target.videoId)?.let { ll -> csRanked.firstOrNull { it.stream.url == ll.url } }
            ?: csRanked.firstOrNull()
    }
    val plugBackups = remember(csRanked, plugQuick) {
        csRanked.filter { it.stream.url != plugQuick?.stream?.url && it.ottTier() in setOf(0, 1, 2, 4) }.distinctBy { it.stream.url }.take(12)
    }
    val turboList = remember(csRanked, plugQuick, plugBackups) {
        val skip = (plugBackups.mapNotNull { it.stream.url } + listOfNotNull(plugQuick?.stream?.url)).toSet()
        csRanked.filter { it.stream.url !in skip }.distinctBy { it.stream.url }
    }
    // distinctBy: the list below uses this as its key, and LazyColumn crashes on duplicate keys.
    val shown = remember(own, addon) {
        (if (addon == null) own else own.filter { it.addonName == addon }).distinctBy { it.addonName + (it.stream.url ?: "") + (it.stream.name ?: "") }
    }
    // CloudStream and Nuvio get their own chips next to "All", like an addon.
    val csList = remember(csItems) { csItems.distinctBy { it.stream.url } }
    val nuList = remember(nuItems) { nuItems.distinctBy { it.stream.url } }
    val nothing = when (addon) {
        QP_TAB -> if (plug) plugQuick == null else quickOne == null
        CS_TAB -> (if (plug) turboList else csList).isEmpty()
        NU_TAB -> nuList.isEmpty()
        else -> shown.isEmpty() && (addon != null || (quickItems.isEmpty() && backupGroups.isEmpty() && csList.isEmpty() && nuList.isEmpty()))
    }
    LaunchedEffect(nothing && done, addon) {
        if (nothing && done && addon == null) {
            val parts = target.videoId.split(":")
            NoStream.report(target.title, NoStream.key(meta.name, parts.getOrNull(1)?.toIntOrNull(), parts.getOrNull(2)?.toIntOrNull()), "sources page: no streams")
        }
    }
    var resume by remember(resumeMs) { mutableStateOf(resumeMs > 0) }
    val fusion = isOn(v("fusionBadges"))
    val showAddon = isOn(v("showAddonName"))

    // TV: the remote starts on Resume (or "All"), so every chip and source can be reached with the arrows.
    val firstFr = remember { androidx.compose.ui.focus.FocusRequester() }
    LaunchedEffect(Unit) { if (BuildConfig.IS_TV) repeat(12) { kotlinx.coroutines.delay(80); if (firstFr.tryFocus()) return@LaunchedEffect } }
    Box(Modifier.fillMaxSize().background(Color(0xFF07070A))) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 40.dp)) {
            item {
                Box(Modifier.fillMaxWidth().height(330.dp)) {
                    AsyncImage(target.image ?: meta.background ?: meta.poster, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to Color(0x80000000), 0.35f to Color.Transparent, 1f to Color(0xFF07070A))))
                    Row(Modifier.statusBarsPadding().padding(top = 8.dp).align(Alignment.TopCenter), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        meta.imdbRating?.takeIf { it.isNotBlank() }?.let { RatingChip("IMDb", it, Color(0xFFF5C518)) }
                    }
                    Column(Modifier.align(Alignment.BottomStart).padding(horizontal = 20.dp, vertical = 6.dp)) {
                        target.epLabel?.let { Text(it, color = Accent, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
                        Text(target.epTitle ?: meta.name, fontSize = 27.sp, fontWeight = FontWeight.Bold, lineHeight = 31.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        if (target.epTitle != null) Text(meta.name.uppercase(), fontSize = 14.sp, color = Color(0xFFB6BDCC), letterSpacing = 1.sp, modifier = Modifier.padding(top = 2.dp))
                    }
                }
            }
            if (resumeMs > 0) item {
                Row(Modifier.padding(start = 18.dp, top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("Resume from ${fmtTime(resumeMs)}", resume, mod = Modifier.focusRequester(firstFr)) { resume = true }
                    Pill("Start over", !resume) { resume = false }
                }
            }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 18.dp, vertical = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Box(Modifier.size(46.dp).clip(CircleShape).background(Color(0xFF1A1A1F)).clickable { reload++ }, Alignment.Center) {
                            Icon(Icons.Default.Refresh, "Refresh", Modifier.size(22.dp))
                        }
                    }
                    if (plug) {
                        item { Pill("Quick Play", addon == QP_TAB, big = true, mod = if (resumeMs > 0) Modifier else Modifier.focusRequester(firstFr)) { addon = QP_TAB } }
                        if (turboList.isNotEmpty()) item { Pill("Turbo · ${turboList.size}", addon == CS_TAB, big = true) { addon = CS_TAB } }
                    } else {
                        item { Pill("All", addon == null, big = true, mod = if (resumeMs > 0) Modifier else Modifier.focusRequester(firstFr)) { addon = null } }
                        if (quickOne != null) item { Pill("Quick Play", addon == QP_TAB, big = true) { addon = QP_TAB } }
                        if (csList.isNotEmpty()) item { Pill("Turbo · ${csList.size}", addon == CS_TAB, big = true) { addon = CS_TAB } }
                    }
                    if (nuList.isNotEmpty()) item { Pill((if (Public.dev) "Nuvio" else "Extensions") + " · ${nuList.size}", addon == NU_TAB, big = true) { addon = NU_TAB } }
                    items(addons) { a -> Pill(Public.serverName(a), addon == a, big = true) { addon = a } }
                }
            }
            if (f.hidden > 0 && !f.forcedEmpty) item {
                Text("${f.hidden} hidden by your stream filters", Modifier.padding(horizontal = 20.dp).padding(bottom = 10.dp), fontSize = 13.sp, color = Color(0xFF8A94A8))
            }
            when {
                f.forcedEmpty -> item {
                    EmptyBox(Icons.Default.FilterAlt, "No ${f.forcedLabels.joinToString(" / ")} streams for this title.", "Show all streams") { showAll = true }
                }
                nothing && done -> item {
                    EmptyBox(Icons.Default.CloudOff, t("noStreams"), "Try again") { reload++ }
                }
                plug && addon == QP_TAB -> {
                    plugQuick?.let { s ->
                        item { SectionHead("Quick play", "ready to play") }
                        item(key = "pq1") { Box(Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) { StreamCard(s, true, false, pack) { onPick(s, f.list, if (resume) resumeMs else 0L) } } }
                    }
                    if (plugBackups.isNotEmpty()) {
                        item { SectionHead("Backup play", "best first") }
                        items(plugBackups, key = { "pb" + it.stream.url }) { s ->
                            Box(Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) { StreamCard(s, true, false, pack, compact = true) { onPick(s, f.list, if (resume) resumeMs else 0L) } }
                        }
                    }
                    if (!done) item { Box(Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) { SkeletonCard() } }
                }
                plug && addon == CS_TAB -> items(turboList, key = { "tb" + it.addonName + it.stream.url }) { s ->
                    Box(Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) { StreamCard(s, fusion, true, pack) { onPick(s, turboList, if (resume) resumeMs else 0L) } }
                }
                addon == QP_TAB -> quickOne?.let { s -> item(key = "qp1") {
                    Box(Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) { StreamCard(s, true, false, pack) { onPick(s, f.list, if (resume) resumeMs else 0L) } }
                } }
                addon == CS_TAB -> items(csList, key = { "cs" + it.addonName + it.stream.url }) { s ->
                    Box(Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) { StreamCard(s, fusion, true, pack) { onPick(s, csList, if (resume) resumeMs else 0L) } }
                }
                addon == NU_TAB -> items(nuList, key = { "nu" + it.addonName + it.stream.url }) { s ->
                    Box(Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) { StreamCard(s, fusion, true, pack) { onPick(s, nuList, if (resume) resumeMs else 0L) } }
                }
                else -> {
                    if (addon == null && quickOne != null) {
                        item { SectionHead("Quick play", "starts instantly") }
                        items(listOf(quickOne), key = { "q" + it.stream.url }) { s ->
                            Box(Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) {
                                StreamCard(s, true, false, pack, compact = true) { onPick(s, f.list, if (resume) resumeMs else 0L) }
                            }
                        }
                    }
                    if (addon == null && backupGroups.isNotEmpty()) {
                        item { SectionHead("Backup play", "the best file plays automatically") }
                        items(backupGroups, key = { "b" + it.first }) { (tag, l) ->
                            BackupGroupRow(tag, l) { onPick(l.first(), f.list, if (resume) resumeMs else 0L) }
                        }
                    }
                    // Plugins sit above your addons so they are easy to reach (each also has its own chip).
                    if (addon == null && csList.isNotEmpty()) {
                        item { SectionHead("Turbo", "more streams") }
                        items(csList.take(6), key = { "cs" + it.addonName + it.stream.url }) { s ->
                            Box(Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) { StreamCard(s, fusion, true, pack) { onPick(s, csList, if (resume) resumeMs else 0L) } }
                        }
                        if (csList.size > 6) item { MoreLink("All ${csList.size} Turbo links") { addon = CS_TAB } }
                    }
                    if (addon == null && nuList.isNotEmpty()) {
                        item { SectionHead(if (Public.dev) "Nuvio" else "Extensions", "more streams") }
                        items(nuList.take(6), key = { "nu" + it.addonName + it.stream.url }) { s ->
                            Box(Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) { StreamCard(s, fusion, true, pack) { onPick(s, nuList, if (resume) resumeMs else 0L) } }
                        }
                        if (nuList.size > 6) item { MoreLink("All ${nuList.size} links") { addon = NU_TAB } }
                    }
                    if (shown.isNotEmpty() && (quickItems.isNotEmpty() || backupGroups.isNotEmpty() || csList.isNotEmpty() || nuList.isNotEmpty()) && addon == null) item { SectionHead("Your addons", "every detail") }
                    items(shown, key = { it.addonName + (it.stream.url ?: "") + (it.stream.name ?: "") }) { s ->
                        Box(Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) {
                            StreamCard(s, fusion, showAddon, pack) { onPick(s, f.list, if (resume) resumeMs else 0L) }
                        }
                    }
                    if (!done) items(if (shown.isEmpty()) 3 else 1) { Box(Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) { SkeletonCard() } }
                }
            }
        }
        Box(
            Modifier.statusBarsPadding().padding(12.dp).size(46.dp).clip(CircleShape).background(Color(0x99000000)).clickable(onClick = onBack),
            Alignment.Center,
        ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", Modifier.size(24.dp)) }
    }
}

@Composable
private fun SectionHead(title: String, sub: String) {
    Row(Modifier.padding(start = 20.dp, end = 20.dp, top = 18.dp, bottom = 4.dp), verticalAlignment = Alignment.Bottom) {
        Text(title.uppercase(), fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Text("  ·  $sub", fontSize = 12.sp, color = Color(0xFF8A94A8))
    }
}

/** One picture-tag group of the built-in HD servers: tap plays its best-ranked file. */
@Composable
private fun BackupGroupRow(tag: String, list: List<StreamItem>, onClick: () -> Unit) {
    val best = list.first()
    val langs = list.flatMap { it.languagesOrOriginal() }.distinct().take(3).joinToString(" + ") { langLabel(it) }
    Row(
        Modifier.padding(horizontal = 18.dp, vertical = 6.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(StreamCardBg)
            .border(1.dp, Color(0x0FFFFFFF), RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(listOf(VisualTags.quality(best), tag).joinToString(" · "), fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(listOf("${list.size} file${if (list.size == 1) "" else "s"}", langs).filter { it.isNotBlank() }.joinToString(" · "),
                fontSize = 13.sp, color = Color(0xFFC9CDD6), modifier = Modifier.padding(top = 3.dp))
        }
        Box(Modifier.size(34.dp).clip(CircleShape).background(Accent), Alignment.Center) { Icon(Icons.Default.PlayArrow, "Play", Modifier.size(20.dp), tint = OnAccent) }
    }
}

@Composable
private fun RatingChip(label: String, value: String, c: Color) {
    Row(Modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xB3000000)).padding(horizontal = 10.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.clip(RoundedCornerShape(4.dp)).background(c).padding(horizontal = 4.dp, vertical = 1.dp), fontSize = 11.sp, fontWeight = FontWeight.Black, color = Color.Black)
        Spacer(Modifier.width(6.dp))
        Text(value, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun Pill(text: String, on: Boolean, big: Boolean = false, mod: Modifier = Modifier, onClick: () -> Unit) {
    Text(
        text,
        mod.clip(RoundedCornerShape(24.dp)).background(if (on) BtnColor else Color(0xFF1A1A1F)).clickable(onClick = onClick)
            .padding(horizontal = if (big) 20.dp else 18.dp, vertical = if (big) 12.dp else 11.dp),
        fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = if (on) OnBtn else Color.White, maxLines = 1,
    )
}

@Composable
private fun EmptyBox(icon: androidx.compose.ui.graphics.vector.ImageVector, msg: String, action: String, onAction: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 30.dp, vertical = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, Modifier.size(42.dp), tint = Color(0xFF8A94A8))
        Text(msg, Modifier.padding(top = 12.dp), fontSize = 15.sp, color = Color(0xFFC9CDD6), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        Text(action, Modifier.padding(top = 16.dp).clip(RoundedCornerShape(22.dp)).background(Accent).clickable(onClick = onAction)
            .padding(horizontal = 22.dp, vertical = 11.dp), color = OnAccent, fontWeight = FontWeight.SemiBold)
    }
}

fun fmtTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

private const val CS_TAB = "\u0001cloudstream"
private const val NU_TAB = "\u0001nuvio"
private const val QP_TAB = "\u0001quickplay"

@Composable
private fun MoreLink(label: String, onClick: () -> Unit) {
    Text(label, Modifier.padding(horizontal = 20.dp, vertical = 8.dp).clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 4.dp),
        color = Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
}

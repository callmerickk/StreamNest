StreamX TV 0.9.12 (the phone app stays on 0.9.67)

• No black screen on any profile (frame-rate matching off everywhere).
• Next episode ready sooner and opens behind a small ring.
• Episodes no longer resume from a few seconds in.
• Updates install on the first download.
• Lighter, faster start.

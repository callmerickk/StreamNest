StreamX TV 0.9.15 (the phone app stays on 0.9.67)

• Back on Home no longer freezes or closes the app.
• The first open after an update stays open.
• Posters load once at start (no more reloading).
• Home appears at once and refreshes quietly.

package com.example.streamnest

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.NewReleases
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VideoSettings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableIntState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private data class TvSetCat(val key: String, val title: String, val sub: String, val icon: ImageVector)

private val TvSetCats = listOf(
    TvSetCat("playback", "Playback", "Player engine, subtitles, audio languages, auto-play and the next episode.", Icons.Default.PlayArrow),
    TvSetCat("quickStart", "Quick Start", "Addons used to start playing straight away, quality and languages.", Icons.Default.Bolt),
    TvSetCat("streams", "Streams", "How stream links are listed, badges and sorting.", Icons.Default.VideoSettings),
    TvSetCat("streamFilters", "Stream Filters", "Hide links by size, quality or words.", Icons.Default.FilterAlt),
    TvSetCat("addons", "Addons", "Install, sort and remove addons.", Icons.Default.Extension),
    TvSetCat("collections", "Collections", "Import Nuvio-style collections and choose which ones show on Home.", Icons.Default.Collections),
    TvSetCat("integrations", "Integrations", "AI assistant, TMDB, MDBList ratings and Trakt.", Icons.Default.Link),
    TvSetCat("layout", "Layout", "Theme, Home rows and posters.", Icons.Default.Palette),
    TvSetCat("cw", "Continue Watching", "What shows in Continue Watching and how it resumes.", Icons.Default.History),
    TvSetCat("network", "Network & DNS", "DNS provider for addons and links.", Icons.Default.Dns),
    TvSetCat("account", "Account", "Where your data lives and history controls.", Icons.Default.AccountCircle),
    TvSetCat("advanced", "Advanced", "Startup, cache and Developer's Corner.", Icons.Default.Tune),
    TvSetCat("updates", "Update Log", "What's new in this version and earlier ones.", Icons.Default.NewReleases),
    TvSetCat("about", "Licenses & Attribution", "Data sources, acknowledgements and licenses.", Icons.Default.Info),
)

/**
 * StreamX TV settings: a remote-friendly list of sections on the left and what each one holds on the right.
 * OK opens the section's page full screen ([onOpen] with the page key); LEFT on the list opens the rail.
 * [lastIdx] remembers the focused row while a page is open, so focus comes back to it.
 */
@Composable
fun TvSettingsScreen(vm: AppViewModel, lastIdx: MutableIntState, onOpen: (String) -> Unit, onLeftEdge: (FocusRequester) -> Unit) {
    val frs = remember { List(TvSetCats.size) { FocusRequester() } }
    var focused by remember { mutableIntStateOf(lastIdx.intValue.coerceIn(0, TvSetCats.lastIndex)) }
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = (lastIdx.intValue - 3).coerceAtLeast(0))
    LaunchedEffect(Unit) {
        withFrameNanos { }
        repeat(4) { if (frs[lastIdx.intValue.coerceIn(0, TvSetCats.lastIndex)].tryFocus()) return@LaunchedEffect; delay(50) }
    }
    val cur = TvSetCats[focused]
    Row(Modifier.fillMaxSize().padding(start = TvEdge, top = 28.dp)) {
        Column(Modifier.width(330.dp).fillMaxHeight()) {
            Text("Settings", Modifier.padding(start = 14.dp, bottom = 12.dp), fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(bottom = 40.dp)) {
                itemsIndexed(TvSetCats, key = { _, c -> c.key }) { i, c ->
                    TvSetRow(c, frs[i], onFocused = { focused = i; lastIdx.intValue = i }, onLeft = { onLeftEdge(frs[i]) }) { onOpen(c.key) }
                }
            }
        }
        // What the focused section holds.
        Column(Modifier.padding(start = 48.dp, top = 70.dp, end = 48.dp).widthIn(max = 420.dp)) {
            Box(Modifier.size(64.dp).clip(RoundedCornerShape(18.dp)).background(Color(0xFF22232B)), Alignment.Center) {
                Icon(cur.icon, null, Modifier.size(32.dp), tint = Color.White)
            }
            Text(cur.title, Modifier.padding(top = 18.dp), fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(cur.sub, Modifier.padding(top = 8.dp), fontSize = 14.sp, lineHeight = 20.sp, color = TvSubText)
            Text("Press OK to open", Modifier.padding(top = 22.dp), fontSize = 12.sp, color = Color(0xFF6E7585))
            Spacer(Modifier.height(40.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppLogo(vm, 22.dp)
                Spacer(Modifier.width(8.dp))
                Wordmark(t("appName"), 15.sp)
            }
            Text("Version ${vm.appVersion}", Modifier.padding(top = 4.dp), fontSize = 11.sp, color = TvSubText)
        }
    }
}

@Composable
private fun TvSetRow(c: TvSetCat, fr: FocusRequester, onFocused: () -> Unit, onLeft: () -> Unit, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp).height(50.dp)
            .focusRequester(fr)
            .tvLeftEdge(onLeft)
            .onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocused() }
            .clip(shape)
            .background(if (focused) Color.White else Color.Transparent)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(c.icon, null, Modifier.size(20.dp), tint = if (focused) Color.Black else Color(0xFFC9CED9))
        Spacer(Modifier.width(14.dp))
        Text(c.title, fontSize = 15.sp, fontWeight = if (focused) FontWeight.Bold else FontWeight.Medium,
            color = if (focused) Color.Black else Color(0xFFE6E9F2), maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

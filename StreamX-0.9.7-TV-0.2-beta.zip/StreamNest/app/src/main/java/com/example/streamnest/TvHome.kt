package com.example.streamnest

import androidx.compose.foundation.background
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Icon
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.foundation.border
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableIntState
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Everything TV Home must remember while a title page / player is open on top of it (Home itself is not composed
 * then): scroll positions, the hero card and the item that had focus. Plain fields: writing them recomposes nothing.
 */
class TvHomeState {
    val list = LazyListState()
    private val rows = HashMap<String, LazyListState>()
    fun row(key: String): LazyListState = rows.getOrPut(key) { LazyListState() }
    val deckPage: MutableIntState = mutableIntStateOf(0)
    /** Key of the row that had focus ("deck" = the hero card), and the item index in it. */
    var focusRow: String? = null
    var focusIndex: Int = 0
    /** Bumped by TvApp when the sidebar closes without a known item to return to: Home puts focus back itself. */
    val refocus: MutableIntState = mutableIntStateOf(0)
}

private data class TvDeckEntry(val meta: Meta, val catalog: String)

private sealed class TvHomeSec(val key: String) {
    class Cw(val items: List<Progress>) : TvHomeSec("cw")
    class Col(val c: NCollection) : TvHomeSec("col:" + c.id) { val folders = c.folders.distinctBy { it.id } }
    class Metas(key: String, val title: String, val items: List<Meta>) : TvHomeSec(key)
}

private const val DeckRow = "deck"

@Composable
fun TvHomeScreen(
    vm: AppViewModel,
    onOpen: (Meta) -> Unit,
    onPlay: (Screen.Player) -> Unit,
    onPlayMeta: (Meta) -> Unit,
    onOpenCollection: (NCollection, NFolder) -> Unit,
    onLeftEdge: (FocusRequester) -> Unit,
    state: TvHomeState = remember { TvHomeState() },
) {
    val allShelves by vm.shelves.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val profile by vm.current.collectAsStateWithLifecycle()
    val recs by vm.recommended.collectAsStateWithLifecycle()
    val colFlow = remember(vm) { vm.collections() }
    val collections by colFlow.collectAsStateWithLifecycle()

    val rowsOrder = t("rowsOrder")
    val rowsHidden = t("rowsHidden")
    val shelves = remember(allShelves, rowsOrder, rowsHidden) {
        val hidden = rowsHidden.split("|").toSet()
        arrangeShelves(allShelves, rowsOrder).filter { it.title !in hidden && it.items.isNotEmpty() }
    }
    val showHero = isOn(t("showHero"))
    // Hero cards: the first two rows mixed (e.g. popular movies + popular series), like the phone app.
    val deck = remember(shelves, showHero) {
        if (!showHero) emptyList() else {
            val a = shelves.getOrNull(0)?.let { s -> s.items.map { TvDeckEntry(it, s.title) } }.orEmpty()
            val b = shelves.getOrNull(1)?.let { s -> s.items.map { TvDeckEntry(it, s.title) } }.orEmpty()
            (0 until maxOf(a.size, b.size)).flatMap { listOfNotNull(a.getOrNull(it), b.getOrNull(it)) }
                .filter { it.meta.poster != null || it.meta.background != null }.distinctBy { it.meta.id }.take(10)
        }
    }
    val cwShow = isOn(t("cwShow"))
    val showRecs = isOn(t("showRecs"))
    val continueTitle = t("continueWatching").replace("{name}", profile?.name ?: "").trim()
    val recTitle = t("recommendedFor").replace("{name}", profile?.name ?: "you")
    val newOn = t("newOn").replace("{app}", t("appName"))
    val sections = remember(progress, collections, shelves, recs, cwShow, showRecs, recTitle, newOn) {
        buildList<TvHomeSec> {
            if (cwShow && progress.isNotEmpty()) add(TvHomeSec.Cw(progress))
            collections.filter { it.folders.isNotEmpty() }.distinctBy { it.id }.forEach { add(TvHomeSec.Col(it)) }
            shelves.forEachIndexed { i, s ->
                val title = if (s.title.startsWith("New")) "$newOn · ${s.title.removePrefix("New ").trim()}" else s.title
                add(TvHomeSec.Metas("shelf:$i:${s.title}", title, s.items))
            }
            if (showRecs && recs.isNotEmpty()) add(TvHomeSec.Metas("recs", recTitle, recs))
        }
    }

    val scope = rememberCoroutineScope()
    val scrollJob = remember { arrayOfNulls<Job>(1) }
    val bgImage = remember { mutableStateOf<String?>(null) }
    val deckFr = remember { FocusRequester() }
    val restoreFr = remember { FocusRequester() }
    val homeFocused = remember { booleanArrayOf(false) }
    val ls = state.list

    // Row [ord] got focus: it moves to the top of the screen (the big hero card slides away, like Hotstar).
    // ord = -1: the hero card itself (list back at the very top).
    fun scrollToSection(ord: Int) {
        val target = if (ord < 0) 0 else ord + 1
        scrollJob[0]?.cancel()
        scrollJob[0] = scope.launch {
            if (ls.firstVisibleItemIndex != target || ls.firstVisibleItemScrollOffset != 0) ls.animateScrollToItem(target)
        }
    }

    // Focus: back to where it was (coming back from a title page), else the hero card (or the first row).
    val restoreRow = state.focusRow ?: if (deck.isEmpty()) sections.firstOrNull()?.key else null
    val restoreIdx = if (state.focusRow != null) state.focusIndex else 0
    val hasContent = deck.isNotEmpty() || sections.isNotEmpty()
    LaunchedEffect(hasContent) {
        if (!hasContent) return@LaunchedEffect
        withFrameNanos { }
        delay(30)
        if (homeFocused[0]) return@LaunchedEffect
        val ok = if (restoreRow != null && restoreRow != DeckRow) restoreFr.tryFocus() else false
        if (!ok && !deckFr.tryFocus()) restoreFr.tryFocus()
    }
    val refocusTick = state.refocus.intValue
    LaunchedEffect(refocusTick) {
        if (refocusTick == 0) return@LaunchedEffect
        withFrameNanos { }
        val ok = if (restoreRow != null && restoreRow != DeckRow) restoreFr.tryFocus() else false
        if (!ok && !deckFr.tryFocus()) restoreFr.tryFocus()
    }

    Box(Modifier.fillMaxSize().onFocusChanged { homeFocused[0] = it.hasFocus }.focusGroup()) {
        TvHomeBackdrop(bgImage)
        if (!hasContent) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                if (loading) CircularProgressIndicator(color = Accent)
                else Text(t("emptyMsg"), Modifier.padding(32.dp), fontSize = 13.sp, color = TvSubText)
            }
        } else TvManualScroll {
            LazyColumn(Modifier.fillMaxSize(), state = ls, contentPadding = PaddingValues(bottom = 90.dp)) {
                item(key = DeckRow, contentType = DeckRow) {
                    if (deck.isNotEmpty()) TvHeroDeck(
                        vm, deck, state.deckPage, deckFr, ls,
                        onLeftEdge = onLeftEdge,
                        onFocused = { state.focusRow = DeckRow; state.focusIndex = 0; bgImage.value = null; scrollToSection(-1) },
                        onPlay = onPlayMeta,
                    ) else Spacer(Modifier.height(54.dp))
                }
                itemsIndexed(sections, key = { _, s -> s.key }, contentType = { _, s ->
                    when (s) { is TvHomeSec.Cw -> "cw"; is TvHomeSec.Col -> "col"; is TvHomeSec.Metas -> "row" }
                }) { ord, s ->
                    val rIdx = if (s.key == restoreRow) restoreIdx else -1
                    val itemFocus: (Int) -> Unit = { i -> state.focusRow = s.key; state.focusIndex = i }
                    when (s) {
                        is TvHomeSec.Cw -> TvRow(
                            s.items, key = { it.key }, title = continueTitle, state = state.row(s.key),
                            restoreIndex = rIdx, restoreRequester = restoreFr, onLeftEdge = onLeftEdge,
                            onRowFocus = { bgImage.value = null; scrollToSection(ord) }, onItemFocus = itemFocus,
                        ) { _, p, mod ->
                            TvContinueCard(p, mod) { onPlay(Screen.Player(p.title, p.url, p.subs, p.key, p.image, p.positionMs)) }
                        }
                        is TvHomeSec.Col -> TvRow(
                            s.folders, key = { it.id }, title = s.c.title, state = state.row(s.key),
                            restoreIndex = rIdx, restoreRequester = restoreFr, onLeftEdge = onLeftEdge,
                            onRowFocus = { scrollToSection(ord) }, onItemFocus = itemFocus,
                        ) { _, f, mod ->
                            TvFolderTile(f, mod, onFocus = { if (it) bgImage.value = f.hero ?: f.cover ?: s.c.backdrop }) { onOpenCollection(s.c, f) }
                        }
                        is TvHomeSec.Metas -> TvMetaRow(
                            s.title, s.items, onOpen, state = state.row(s.key),
                            restoreIndex = rIdx, restoreRequester = restoreFr, onLeftEdge = onLeftEdge,
                            onRowFocus = { bgImage.value = null; scrollToSection(ord) }, onItemFocus = itemFocus,
                        )
                    }
                }
            }
        }
    }
}

/** Full-screen artwork behind the rows while a collection folder has focus (dimmed, faded into the background). */
@Composable
private fun TvHomeBackdrop(image: State<String?>) {
    val url = image.value ?: return
    val req = tvImage(url, 480.dp, 270.dp)
    val bg = Bg
    val side = remember(bg) { Brush.horizontalGradient(0.25f to bg, 0.6f to bg.copy(alpha = 0.6f), 1f to bg.copy(alpha = 0.1f)) }
    val bottom = remember(bg) { Brush.verticalGradient(0.35f to Color.Transparent, 0.85f to bg) }
    Box(Modifier.fillMaxSize()) {
        if (req != null) AsyncImage(req, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alpha = 0.55f)
        Box(Modifier.fillMaxSize().background(side))
        Box(Modifier.fillMaxSize().background(bottom))
    }
}

// ───────────── Hero cards (Hotstar style) ─────────────

private val DeckShape = RoundedCornerShape(18.dp)
private val DeckShade = Brush.horizontalGradient(0f to Color(0xE6000000), 0.34f to Color(0x99000000), 0.62f to Color.Transparent)
private val DeckShadeBottom = Brush.verticalGradient(0.5f to Color.Transparent, 1f to Color(0xB3000000))
private val DeckRim = Color(0x40FFFFFF)

/** Hero card size: almost the whole screen, with room on the right for the next two cards to peek out. */
private val DeckH = 404.dp
private val DeckPeek = 150.dp

/**
 * The big hero card (Hotstar TV): backdrop, badge, title logo, info line, two lines of story and the phone's red
 * Play pill + My List. The next two cards peek out on the right like a fanned deck. Focus lives on the two buttons:
 * LEFT on Play = previous card (rail on the first), RIGHT on My List = next card. Auto-advances every 8 s while untouched.
 */
@Composable
private fun TvHeroDeck(
    vm: AppViewModel,
    items: List<TvDeckEntry>,
    pageState: MutableIntState,
    requester: FocusRequester,
    listState: LazyListState,
    onLeftEdge: (FocusRequester) -> Unit,
    onFocused: () -> Unit,
    onPlay: (Meta) -> Unit,
) {
    var page by pageState
    val p = page.coerceIn(0, items.lastIndex)
    var focused by remember { mutableStateOf(false) }
    val lastKey = remember { longArrayOf(0L) }
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val myList by vm.myList.collectAsStateWithLifecycle()
    val addFr = remember { FocusRequester() }

    BoxWithConstraints(Modifier.fillMaxWidth().padding(start = TvEdge, top = 54.dp, end = 18.dp)) {
        val deckW = maxWidth - DeckPeek
        val wPx = with(density) { deckW.roundToPx() }
        val hPx = with(density) { DeckH.roundToPx() }

        // Auto-advance while the cards are on screen and nobody pressed a key on them for 8 s.
        LaunchedEffect(items.size) {
            if (items.size < 2) return@LaunchedEffect
            while (true) {
                delay(8000)
                val idle = System.currentTimeMillis() - lastKey[0] > 7500
                if (idle && listState.firstVisibleItemIndex == 0) page = (page.coerceIn(0, items.lastIndex) + 1) % items.size
            }
        }
        // Pre-load the neighbours at exactly the card's size, so changing cards is instant (memory-cache hit).
        LaunchedEffect(p, items, wPx) {
            listOf(items.getOrNull((p + 1) % items.size), items.getOrNull((p - 1 + items.size) % items.size)).forEach { e ->
                val m = e?.meta ?: return@forEach
                val url = backdropOf(m) ?: m.poster ?: return@forEach
                ctx.imageLoader.enqueue(tvRequest(ctx, url, wPx, hPx))
            }
        }

        val cur = items[p]
        val m = cur.meta
        Box(Modifier.fillMaxWidth().height(DeckH)) {
            // Peeking cards (behind): two shorter cards fanned out to the right.
            // (visible strips: next card deckW..+80dp, the one after +80..+140dp; the rest hides behind)
            if (items.size > 2) TvDeckPeek(items[(p + 2) % items.size].meta, deckW + 140.dp - 300.dp, 300.dp, 330.dp, 0.62f)
            if (items.size > 1) TvDeckPeek(items[(p + 1) % items.size].meta, deckW + 80.dp - 320.dp, 320.dp, 370.dp, 0.42f)

            Box(Modifier.size(deckW, DeckH).clip(DeckShape).background(Color(0xFF05070C))) {
                val url = backdropOf(m) ?: m.poster
                val art = remember(url, wPx) { url?.let { tvRequest(ctx, it, wPx, hPx) } }
                if (art != null) AsyncImage(art, m.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(DeckShade))
                Box(Modifier.fillMaxSize().background(DeckShadeBottom))

                // Badge, top-left.
                val rating = m.imdbRating?.toDoubleOrNull()
                val badge = if (rating != null && rating >= 7.5) "IMDb ${m.imdbRating}" else "#${p + 1} in ${cur.catalog}"
                Row(
                    Modifier.padding(start = 20.dp, top = 18.dp).clip(RoundedCornerShape(8.dp)).background(Color(0x8C000000))
                        .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(8.dp)).padding(horizontal = 9.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(if (rating != null && rating >= 7.5) Icons.Default.Star else Icons.Default.Whatshot, null,
                        Modifier.size(12.dp), tint = if (rating != null && rating >= 7.5) Color(0xFFF5C518) else Color(0xFFFF4D3D))
                    Spacer(Modifier.width(5.dp))
                    Text(badge, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }

                Column(Modifier.align(Alignment.BottomStart).padding(start = 30.dp, bottom = 26.dp).width(440.dp)) {
                    var logoFailed by remember(m.id) { mutableStateOf(false) }
                    val logoReq = tvImage(logoOf(m), 320.dp, 96.dp)
                    if (logoReq != null && !logoFailed) {
                        AsyncImage(
                            logoReq, m.name, Modifier.widthIn(max = 320.dp).height(88.dp).fillMaxWidth(),
                            contentScale = ContentScale.Fit, alignment = Alignment.BottomStart, onError = { logoFailed = true },
                        )
                    } else {
                        Text(m.name, fontSize = 34.sp, lineHeight = 36.sp, fontWeight = FontWeight.Black, letterSpacing = (-1).sp,
                            maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    val line = (listOfNotNull(
                        m.releaseInfo?.take(4)?.takeIf { it.isNotBlank() },
                        m.runtime?.takeIf { it.isNotBlank() },
                        if (m.type == "series") "Series" else null,
                    ) + m.genres.orEmpty().take(2)).joinToString("  •  ")
                    if (line.isNotBlank()) Text(line, Modifier.padding(top = 10.dp), fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFE6E8EE), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    m.description?.takeIf { it.isNotBlank() }?.let {
                        Text(it, Modifier.padding(top = 6.dp), fontSize = 11.5.sp, lineHeight = 16.sp, color = Color(0xFFD0D3DB),
                            maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                    Row(Modifier.padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        // Play: the phone's red pill (white text, red gradient, black rim, shadow).
                        TvPillFocus(
                            Modifier.focusRequester(requester).onPreviewKeyEvent { e ->
                                if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                                lastKey[0] = System.currentTimeMillis()
                                when (e.key) {
                                    Key.DirectionLeft -> { if (p > 0) page = p - 1 else onLeftEdge(requester); true }
                                    Key.DirectionRight -> { addFr.tryFocus(); true }
                                    else -> false
                                }
                            },
                            onFocus = { f -> focused = f; if (f) onFocused() },
                            onClick = { onPlay(m) },
                        ) {
                            RedPill("Play", Modifier.width(132.dp), height = 38, fontSize = 14, onClick = { onPlay(m) })
                        }
                        Spacer(Modifier.width(14.dp))
                        val saved = myList.any { it.id == m.id }
                        TvPillFocus(
                            Modifier.focusRequester(addFr).onPreviewKeyEvent { e ->
                                if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                                lastKey[0] = System.currentTimeMillis()
                                when (e.key) {
                                    Key.DirectionRight -> { if (items.size > 1) { page = (p + 1) % items.size; requester.tryFocus() }; true }
                                    Key.DirectionLeft -> { requester.tryFocus(); true }
                                    else -> false
                                }
                            },
                            onFocus = { f -> focused = f; if (f) onFocused() },
                            onClick = { vm.toggleList(m) },
                        ) {
                            Box(
                                Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x33FFFFFF))
                                    .border(1.dp, Color(0x4DFFFFFF), RoundedCornerShape(12.dp)),
                                Alignment.Center,
                            ) {
                                Icon(if (saved) Icons.Default.Check else Icons.Default.Add, if (saved) "In My List" else "Add to My List",
                                    Modifier.size(20.dp), tint = Color.White)
                            }
                        }
                    }
                }
            }
            // Rim: thin when idle, white when the card's buttons have focus (drawn, no layer / no scaling of the big card).
            Box(Modifier.size(deckW, DeckH).border(if (focused) 2.5.dp else 1.dp, if (focused) Color.White else DeckRim, DeckShape))
        }
        // Page dots, centred under the card.
        Row(
            Modifier.padding(top = DeckH + 12.dp).width(deckW),
            horizontalArrangement = Arrangement.spacedBy(5.dp, Alignment.CenterHorizontally),
        ) {
            items.indices.forEach { i ->
                Box(Modifier.size(width = if (i == p) 16.dp else 6.dp, height = 6.dp).clip(RoundedCornerShape(3.dp))
                    .background(if (i == p) Color.White else Color(0x59FFFFFF)))
            }
        }
    }
}

/** A card behind the hero card, vertically centred, dimmed. [x] is its left edge. */
@Composable
private fun TvDeckPeek(m: Meta, x: Dp, w: Dp, h: Dp, dim: Float) {
    val req = tvImage(backdropOf(m) ?: m.poster, w, h)
    Box(Modifier.offset(x, (DeckH - h) / 2).size(w, h).clip(DeckShape).background(Surface1)) {
        if (req != null) AsyncImage(req, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim)))
    }
}

/**
 * Focus look for the hero buttons: grows a little and gets a thin white ring outside its own rim (draw phase only).
 * The child keeps its exact look (the red Play pill is the phone's). OK on the remote runs [onClick].
 */
@Composable
private fun TvPillFocus(modifier: Modifier, onFocus: (Boolean) -> Unit, onClick: () -> Unit, content: @Composable () -> Unit) {
    var f by remember { mutableStateOf(false) }
    val a by animateFloatAsState(if (f) 1f else 0f, tween(140), label = "pill")
    val focusCb = rememberUpdatedState(onFocus)
    val clickCb = rememberUpdatedState(onClick)
    Box(
        modifier
            .graphicsLayer { val sc = 1f + 0.08f * a; scaleX = sc; scaleY = sc }
            .drawWithContent {
                drawContent()
                if (a > 0.01f) {
                    val o = 3.dp.toPx()
                    val r = size.height / 2f + o
                    drawRoundRect(Color.White, topLeft = Offset(-o, -o), size = Size(size.width + 2 * o, size.height + 2 * o),
                        cornerRadius = CornerRadius(if (size.width > size.height * 1.5f) r else 12.dp.toPx() + o), style = Stroke(2.dp.toPx()), alpha = a)
                }
            }
            .onFocusChanged { if (it.isFocused != f) { f = it.isFocused; focusCb.value(it.isFocused) } }
            .onKeyEvent { e ->
                val ok = e.key == Key.DirectionCenter || e.key == Key.Enter || e.key == Key.NumPadEnter
                if (ok && e.type == KeyEventType.KeyUp) clickCb.value()
                ok
            }
            .focusable(),
    ) { content() }
}

// ───────────── Cards ─────────────

private val CwShade = Brush.verticalGradient(0.5f to Color.Transparent, 1f to Color(0xCC000000))

/** Continue Watching card (landscape, red progress bar). */
@Composable
fun TvContinueCard(p: Progress, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = remember { RoundedCornerShape(10.dp) }
    val frac = if (p.durationMs > 0) (p.positionMs.toFloat() / p.durationMs).coerceIn(0f, 1f) else 0f
    val req = tvImage(p.image, 180.dp, 101.dp)
    Box(modifier.size(180.dp, 101.dp).tvCard(10.dp, onClick = onClick).clip(shape).background(Surface1)) {
        if (req != null) AsyncImage(req, p.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(CwShade))
        Text(p.title, Modifier.align(Alignment.BottomStart).padding(start = 8.dp, end = 8.dp, bottom = 9.dp), fontSize = 10.sp,
            fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(3.dp).background(Color(0x40FFFFFF))) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(BrandRed))
        }
    }
}

private val FolderShade = Brush.verticalGradient(0.4f to Color.Transparent, 1f to Color(0xB3000000))

/** A collection folder tile: cover art, optional logo, title (unless hidden). */
@Composable
fun TvFolderTile(f: NFolder, modifier: Modifier = Modifier, onFocus: ((Boolean) -> Unit)? = null, onClick: () -> Unit) {
    val (w, h) = when (f.tileShape.uppercase()) {
        "POSTER", "PORTRAIT" -> 90.dp to 135.dp
        "SQUARE" -> 100.dp to 100.dp
        else -> 150.dp to 85.dp
    }
    val shape = remember { RoundedCornerShape(12.dp) }
    val cover = f.cover ?: f.hero
    val req = tvImage(cover, w, h)
    val logoReq = tvImage(f.logo, w * 0.62f, h * 0.5f)
    var logoFailed by remember(f.id) { mutableStateOf(false) }
    Box(modifier.size(w, h).tvCard(12.dp, onFocus = onFocus, onClick = onClick).clip(shape).background(Color(0xFF15161C))) {
        if (req != null) AsyncImage(req, f.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        if (logoReq != null && !logoFailed) {
            AsyncImage(logoReq, f.title, Modifier.align(Alignment.Center).fillMaxWidth(0.62f).fillMaxHeight(0.5f),
                contentScale = ContentScale.Fit, onError = { logoFailed = true })
        } else if (!f.hideTitle || cover == null) {
            if (cover != null) Box(Modifier.fillMaxSize().background(FolderShade))
            Text(
                f.title,
                if (cover != null) Modifier.align(Alignment.BottomStart).padding(start = 9.dp, end = 9.dp, bottom = 7.dp)
                else Modifier.align(Alignment.Center).padding(8.dp),
                fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

// ───────────── Library (beta: Continue Watching + My List) ─────────────

@Composable
fun TvLibraryScreen(vm: AppViewModel, onOpen: (Meta) -> Unit, onPlay: (Screen.Player) -> Unit, onLeftEdge: (FocusRequester) -> Unit) {
    val progress by vm.progress.collectAsStateWithLifecycle()
    val myList by vm.myList.collectAsStateWithLifecycle()
    val first = remember { FocusRequester() }
    val cwState = rememberLazyListState()
    val listState = rememberLazyListState()
    val empty = progress.isEmpty() && myList.isEmpty()
    LaunchedEffect(empty) {
        if (empty) return@LaunchedEffect
        withFrameNanos { }
        first.tryFocus()
    }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(top = 30.dp, bottom = 60.dp)) {
            item(key = "title") {
                Text("Library", Modifier.padding(start = TvEdge, bottom = 4.dp), fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            }
            if (progress.isNotEmpty()) item(key = "cw") {
                TvRow(progress, key = { it.key }, title = t("continueWatching").replace("{name}", "").trim(), state = cwState,
                    restoreIndex = 0, restoreRequester = first, onLeftEdge = onLeftEdge) { _, p, mod ->
                    TvContinueCard(p, mod) { onPlay(Screen.Player(p.title, p.url, p.subs, p.key, p.image, p.positionMs)) }
                }
            }
            if (myList.isNotEmpty()) item(key = "list") {
                TvMetaRow("My List", myList, onOpen, restoreIndex = if (progress.isEmpty()) 0 else -1, restoreRequester = first, onLeftEdge = onLeftEdge)
            }
            if (empty) item(key = "empty") {
                Text("Titles you add to My List and shows you're watching appear here.", Modifier.padding(start = TvEdge, top = 24.dp),
                    fontSize = 12.sp, color = TvSubText)
            }
        }
    }
}

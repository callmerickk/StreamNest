package com.example.streamnest

import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LocalRippleConfiguration
import androidx.compose.foundation.IndicationNodeFactory
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.ui.Modifier
import androidx.compose.ui.node.DelegatableNode
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material3.Text
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp

val Bg: Color get() = Palette.bg
val Accent: Color get() = Palette.accent
/** Card / placeholder surface: a deep neutral graphite (no blue cast), so artwork colours look true. */
val Surface1 = Color(0xFF15161C)

// Rounded wordmark font used for the app name (Poppins, free Google font).
val BrandFont = FontFamily(
    Font(R.font.poppins_medium, FontWeight.Medium),
    Font(R.font.poppins_bold, FontWeight.Bold),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StreamNestTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, onPrimary = OnAccent,
            background = Bg, surface = Bg, surfaceVariant = Surface1,
            onBackground = Color.White, onSurface = Color.White, onSurfaceVariant = Color(0xFFB6BDCC),
        ),
    ) {
        // Every Text/Icon defaults to white, so nothing renders black on the dark background.
        // No tap ripples anywhere in the app (clean, premium feel).
        CompositionLocalProvider(
            LocalContentColor provides Color.White,
            LocalIndication provides NoIndication,
            LocalRippleConfiguration provides null,
        ) { Responsive(content) }
    }
}

/** An indication that draws nothing: taps don't flash a ripple. */
private object NoIndication : IndicationNodeFactory {
    override fun create(interactionSource: InteractionSource): DelegatableNode = object : Modifier.Node() {}
    override fun equals(other: Any?): Boolean = other === this
    override fun hashCode(): Int = 7
}

/** Brand red used for the "X" in the StreamX wordmark. */
val BrandRed = Color(0xFFE50914)

/** App name wordmark. "StreamX" is drawn as "Stream" + a red "X"; any custom name is drawn plainly. */
@Composable
fun Wordmark(name: String, fontSize: TextUnit = 18.sp) {
    val n = name.trim()
    if (n.length > 1 && n.endsWith("x", ignoreCase = true) && n.lowercase() == "streamx") {
        Text(
            buildAnnotatedString {
                append(n.dropLast(1))
                withStyle(SpanStyle(color = BrandRed)) { append(n.takeLast(1)) }
            },
            fontFamily = BrandFont, fontWeight = FontWeight.Bold, fontSize = fontSize, letterSpacing = (-0.5).sp, color = Color.White,
        )
    } else Text(n, fontFamily = BrandFont, fontWeight = FontWeight.Bold, fontSize = fontSize, letterSpacing = (-0.5).sp)
}

/**
 * Fits every screen: the whole UI is designed for a ~392dp-wide phone and scaled to the real screen
 * (smaller on compact phones, larger on big ones), so icons and text keep the same proportions.
 * The screen size seen by layouts is adjusted to match, so width-based layouts stay correct.
 */
@Composable
private fun Responsive(content: @Composable () -> Unit) {
    val cfg = androidx.compose.ui.platform.LocalConfiguration.current
    val density = androidx.compose.ui.platform.LocalDensity.current
    val shortSide = minOf(cfg.screenWidthDp, cfg.screenHeightDp).takeIf { it > 0 } ?: 392
    val scale = (shortSide / 392f).coerceIn(0.86f, 1.14f)
    // TV screens are designed directly for a 960×540dp (1080p) canvas: no extra scaling there.
    if (BuildConfig.IS_TV || kotlin.math.abs(scale - 1f) < 0.02f) { content(); return }
    val scaledCfg = androidx.compose.runtime.remember(cfg, scale) {
        android.content.res.Configuration(cfg).apply {
            screenWidthDp = (cfg.screenWidthDp / scale).toInt()
            screenHeightDp = (cfg.screenHeightDp / scale).toInt()
            smallestScreenWidthDp = (cfg.smallestScreenWidthDp / scale).toInt()
        }
    }
    CompositionLocalProvider(
        androidx.compose.ui.platform.LocalDensity provides androidx.compose.ui.unit.Density(density.density * scale, density.fontScale),
        androidx.compose.ui.platform.LocalConfiguration provides scaledCfg,
        content = content,
    )
}

StreamX 0.9.71

• Search finds more titles (other spellings, names with marks).
• Collections show only the real films and series, and open at once.
• Each profile has its own search; Back returns to where you were.
• Episode lists are saved: they show at once, even offline.

---

StreamX TV 0.9.15 

• Back on Home no longer freezes or closes the app.
• The first open after an update stays open.
• Posters load once at start (no more reloading).
• Home appears at once and refreshes quietly.

package com.example.streamnest

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.Base64
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.util.concurrent.Executors

/**
 * Preview frames for the seek bar (phone drag + TV remote seeking), read straight from the video file with
 * MediaMetadataRetriever on one background thread. Frames are cached per 10-second step; only the newest
 * requested position is worked on (older requests are dropped). If the first two tries fail (HLS / DASH,
 * a server that refuses, a format Android can't open) it gives up for good, so no bandwidth is wasted.
 */
class SeekThumbs(url: String, headers: Map<String, String>) {
    private val src: String = original(url)
    private val hdrs: Map<String, String> = run {
        val h = if (src != url || headers.isEmpty()) StreamHeaders.forUrl(src) else headers
        if (h.keys.any { it.equals("User-Agent", true) }) h else h + ("User-Agent" to PlayerUserAgent)
    }
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "seek-thumbs").apply { isDaemon = true; priority = Thread.MIN_PRIORITY } }
    private val scope = CoroutineScope(SupervisorJob() + executor.asCoroutineDispatcher())
    private val requests = Channel<Long>(Channel.CONFLATED)
    private val cache = LruCache<Long, ImageBitmap>(40)
    private val waiting = HashMap<Long, CompletableDeferred<ImageBitmap?>>()
    private val lock = Any()
    private var retriever: MediaMetadataRetriever? = null
    @Volatile private var latest = -1L
    private var failures = 0 // guarded by lock
    @Volatile private var succeeded = false
    private val failedSteps = HashSet<Long>()
    @Volatile private var dead = (!src.startsWith("http://", true) && !src.startsWith("https://", true)) ||
        Regex("\\.(m3u8|mpd)(\\?|$)", RegexOption.IGNORE_CASE).containsMatchIn(src)
    @Volatile private var closed = false

    init {
        if (!dead) scope.launch {
            for (b in requests) {
                if (closed || dead) break
                if (b != latest) { finish(b, null); continue }
                val img = runCatching { extract(b * STEP) }.getOrNull()
                if (img != null) { cache.put(b, img); succeeded = true } else if (!succeeded) fail(b)
                finish(b, img)
                // Requests for other positions that were overtaken meanwhile: answer them with nothing.
                synchronized(lock) { waiting.keys.filter { it != latest && cache.get(it) == null }.toList() }.forEach { if (it != b) finish(it, null) }
            }
        }
    }

    /** The frame closest to [ms] (10-second steps), or null when it can't be made (in time). Never blocks the caller's thread. */
    suspend fun frameAt(ms: Long): ImageBitmap? {
        if (dead || closed) return null
        val b = (ms.coerceAtLeast(0L) / STEP)
        cache.get(b)?.let { return it }
        val d = synchronized(lock) { waiting.getOrPut(b) { CompletableDeferred() } }
        latest = b
        requests.trySend(b)
        val r = withTimeoutOrNull(TIMEOUT_MS) { d.await() }
        if (r == null && !d.isCompleted && !succeeded && latest == b) fail(b)
        return r
    }

    /** False once it gave up (or was closed): the seek bar then shows the time only. */
    val available: Boolean get() = !dead && !closed

    /** A frame already made for [ms], without waiting. */
    fun cached(ms: Long): ImageBitmap? = if (dead) null else cache.get(ms.coerceAtLeast(0L) / STEP)

    fun close() {
        if (closed) return
        closed = true
        requests.close()
        synchronized(lock) { waiting.values.toList().also { waiting.clear() } }.forEach { it.complete(null) }
        scope.cancel()
        // Released on the worker thread, after any frame it is still reading (the native calls are serialized).
        runCatching {
            executor.execute { runCatching { retriever?.release() }; retriever = null }
            executor.shutdown()
        }
    }

    /** One failed try per position (a slow try that then also returns nothing counts once). */
    private fun fail(b: Long) {
        val n = synchronized(lock) { if (!failedSteps.add(b)) return; ++failures }
        if (n >= 2 && !succeeded) {
            dead = true
            synchronized(lock) { waiting.values.toList().also { waiting.clear() } }.forEach { it.complete(null) }
        }
    }

    private fun finish(b: Long, img: ImageBitmap?) {
        synchronized(lock) { waiting.remove(b) }?.complete(img)
    }

    /** Runs on the worker thread only. */
    private fun extract(ms: Long): ImageBitmap? {
        if (closed) return null
        val r = retriever ?: MediaMetadataRetriever().also { mr ->
            try { mr.setDataSource(src, hdrs) } catch (e: Throwable) {
                runCatching { mr.release() }
                dead = true
                return null
            }
            retriever = mr
        }
        val us = ms * 1000L
        val bmp: Bitmap = (if (Build.VERSION.SDK_INT >= 27) r.getScaledFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, W, H)
        else r.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)) ?: return null
        val out = if (bmp.width > W + 8) {
            val h = (bmp.height * (W.toFloat() / bmp.width)).toInt().coerceAtLeast(1)
            Bitmap.createScaledBitmap(bmp, W, h, true).also { if (it !== bmp) bmp.recycle() }
        } else bmp
        out.prepareToDraw()
        return out.asImageBitmap()
    }

    private companion object {
        const val STEP = 10_000L
        const val TIMEOUT_MS = 4_000L
        const val W = 320
        const val H = 180

        /** The real link behind an in-app relay link (http://127.0.0.1:port/r/<base64>/v.ext). */
        fun original(url: String): String {
            if (!Relay.isWrapped(url)) return url
            val token = url.substringAfter("/r/").substringBefore("/")
            return runCatching { String(Base64.decode(token, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)) }.getOrDefault(url)
        }
    }
}

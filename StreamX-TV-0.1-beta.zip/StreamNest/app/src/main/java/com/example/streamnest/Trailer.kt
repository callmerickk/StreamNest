package com.example.streamnest

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

/**
 * A muted, control-less YouTube trailer that covers its box (the page crops the 16:9 video), using YouTube's official IFrame player
 * inside a WebView. The page identifies the app as its origin/referrer, which YouTube now requires
 * (otherwise embeds fail with error 152/153). Some uploaders block embedding; then onError is called.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun TrailerVideo(
    videoId: String,
    muted: Boolean,
    modifier: Modifier = Modifier,
    onPlaying: () -> Unit,
    onEnded: () -> Unit,
    onError: () -> Unit,
) {
    var web by remember { mutableStateOf<WebView?>(null) }
    val cbPlaying by rememberUpdatedState(onPlaying)
    val cbEnded by rememberUpdatedState(onEnded)
    val cbFailed by rememberUpdatedState(onError)
    val main = remember { Handler(Looper.getMainLooper()) }

    // The WebView is exactly the size of [modifier]; the page itself crops the 16:9 video to cover it (CSS), so no
    // Compose clip / oversize is needed. Default layer type: a hardware layer (or any clip / alpha / transform on the
    // WebView's ancestors) can make the video draw black while its sound plays.
    AndroidView(
        factory = { c ->
            WebView(c).apply {
                setBackgroundColor(AColor.BLACK)
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                isVerticalScrollBarEnabled = false
                isHorizontalScrollBarEnabled = false
                isFocusable = false
                isFocusableInTouchMode = false
                webChromeClient = object : WebChromeClient() {
                    // No grey "play" poster before the first frame.
                    override fun getDefaultVideoPoster(): Bitmap? = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
                }
                webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        // Nudge playback from the app side too, in case the page's own autoplay was blocked.
                        main.postDelayed({ runCatching { view?.evaluateJavascript("tryPlay()", null) } }, 1200)
                        main.postDelayed({ runCatching { view?.evaluateJavascript("tryPlay()", null) } }, 3000)
                    }
                }
                addJavascriptInterface(object {
                    @JavascriptInterface fun playing() { main.post { cbPlaying() } }
                    @JavascriptInterface fun ended() { main.post { cbEnded() } }
                    @JavascriptInterface fun error(code: Int) { main.post { cbFailed() } }
                }, "Android")
                val origin = "https://${c.packageName}"
                loadDataWithBaseURL("$origin/", trailerHtml(videoId, origin), "text/html", "utf-8", null)
                web = this
            }
        },
        modifier = modifier,
    )
    LaunchedEffect(muted, web) { web?.evaluateJavascript("setMuted(${if (muted) "true" else "false"})", null) }
    DisposableEffect(Unit) {
        onDispose {
            runCatching { web?.stopLoading(); web?.loadUrl("about:blank"); web?.removeJavascriptInterface("Android"); web?.destroy() }
        }
    }
}

private fun trailerHtml(id: String, origin: String) = """
<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<style>html,body{margin:0;padding:0;background:#000;height:100%;overflow:hidden}#p{position:absolute;pointer-events:none;width:max(100vw,177.78vh);height:max(100vh,56.25vw);left:calc((100vw - max(100vw,177.78vh)) / 2);top:calc((100vh - max(100vh,56.25vw)) / 2)}</style>
</head><body><div id="p"></div>
<script src="https://www.youtube.com/iframe_api"></script>
<script>
var player=null,ready=false,tries=0,timer=null,wantMuted=true;
function tryPlay(){try{if(player&&ready){if(wantMuted)player.mute();if(player.getPlayerState()!=1)player.playVideo();}}catch(e){}}
function onYouTubeIframeAPIReady(){
  player=new YT.Player('p',{videoId:'$id',
    playerVars:{autoplay:1,mute:1,controls:0,rel:0,playsinline:1,modestbranding:1,iv_load_policy:3,fs:0,disablekb:1,cc_load_policy:0,origin:'$origin'},
    events:{
      onReady:function(e){ready=true;e.target.mute();e.target.playVideo();
        // Keep asking to play (muted) until it really plays — autoplay is sometimes blocked at first.
        timer=setInterval(function(){tries++;tryPlay();if(tries>24||(player&&player.getPlayerState&&player.getPlayerState()==1)){clearInterval(timer);}},400);},
      onStateChange:function(e){if(e.data==1){Android.playing();if(!wantMuted)player.unMute();}if(e.data==0)Android.ended();},
      onError:function(e){Android.error(e.data);}
    }});
}
function setMuted(m){wantMuted=m;if(player&&player.mute){if(m)player.mute();else player.unMute();}}
</script></body></html>
""".trimIndent()

package com.example.streamnest

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

/** Main sections of StreamX TV (picked in the sidebar). */
enum class TvTab { Search, Home, Library, MySpace, Settings }

private val SideBrush = Brush.verticalGradient(listOf(Color(0xF71C1D24), Color(0xF7101116)))
private val SideShape = RoundedCornerShape(17.dp)
private val ItemShape = RoundedCornerShape(11.dp)
private val ItemText = Color(0xFFC9CED9)

/**
 * The floating TV menu. Completely hidden when closed (no icon strip); slides in from the left over a dim scrim.
 * When it opens, focus goes to the current section. RIGHT closes it ([onClose]); BACK is handled by TvApp.
 * UP/DOWN stay inside the panel.
 */
@Composable
fun TvSidebar(
    open: Boolean,
    vm: AppViewModel,
    current: TvTab,
    onSelect: (TvTab) -> Unit,
    onClose: () -> Unit,
) {
    AnimatedVisibility(open, enter = fadeIn(tween(220)), exit = fadeOut(tween(220))) {
        Box(Modifier.fillMaxSize().background(Color(0x73000000)))
    }
    AnimatedVisibility(
        open,
        enter = slideInHorizontally(tween(220)) { -it } + fadeIn(tween(220)),
        exit = slideOutHorizontally(tween(220)) { -it } + fadeOut(tween(220)),
    ) {
        SidebarPanel(vm, current, onSelect, onClose)
    }
}

private data class SideItem(val tab: TvTab, val label: String, val icon: ImageVector)

@Composable
private fun SidebarPanel(vm: AppViewModel, current: TvTab, onSelect: (TvTab) -> Unit, onClose: () -> Unit) {
    val profile by vm.current.collectAsStateWithLifecycle()
    val close by rememberUpdatedState(onClose)
    val items = listOf(
        SideItem(TvTab.Search, t("navSearch"), Icons.Default.Search),
        SideItem(TvTab.Home, t("navHome"), Icons.Default.Home),
        SideItem(TvTab.Library, "Library", Icons.Default.VideoLibrary),
        SideItem(TvTab.MySpace, t("navMySpace"), Icons.Default.Person),
        SideItem(TvTab.Settings, "Settings", Icons.Default.Settings),
    )
    val requesters = remember { List(TvTab.entries.size) { FocusRequester() } }
    // 0 = profile row, 1..n = items. Plain holder: changes must not recompose anything.
    val focusedIdx = remember { intArrayOf(-1) }
    val last = items.size
    LaunchedEffect(Unit) {
        withFrameNanos { }
        val i = items.indexOfFirst { it.tab == current }.coerceAtLeast(0)
        requesters[i].tryFocus()
    }
    Column(
        Modifier.padding(14.dp).width(200.dp).fillMaxHeight()
            .clip(SideShape).background(SideBrush).border(1.dp, Color(0x1AFFFFFF), SideShape)
            .onPreviewKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                when (e.key) {
                    Key.DirectionRight -> { close(); true }
                    Key.DirectionLeft -> true
                    Key.DirectionUp -> focusedIdx[0] == 0
                    Key.DirectionDown -> focusedIdx[0] == last
                    else -> false
                }
            }
            .padding(horizontal = 14.dp, vertical = 20.dp),
    ) {
        // Profile + "Switch profile"
        var profFocused by remember { mutableStateOf(false) }
        Row(
            Modifier.fillMaxWidth().clip(ItemShape)
                .background(if (profFocused) Color(0x24FFFFFF) else Color.Transparent)
                .onFocusChanged { profFocused = it.isFocused; if (it.isFocused) focusedIdx[0] = 0 }
                .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.leaveProfile() }
                .padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            ProfileAvatar(vm, profile, 32.dp, Modifier.border(1.5.dp, BrandRed, CircleShape), animate = false)
            Spacer(Modifier.width(8.dp))
            Column {
                Text(profile?.name ?: "", fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("Switch profile", fontSize = 8.sp, fontWeight = FontWeight.Medium, color = TvSubText)
            }
        }
        Spacer(Modifier.height(20.dp))
        items.forEachIndexed { i, it ->
            SideRow(it, selected = it.tab == current, requester = requesters[i], onFocused = { focusedIdx[0] = i + 1 }) { onSelect(it.tab) }
            Spacer(Modifier.height(4.dp))
        }
        Spacer(Modifier.weight(1f))
        Box(Modifier.padding(start = 6.dp, bottom = 4.dp)) { Wordmark(t("appName"), 17.sp) }
    }
}

@Composable
private fun SideRow(item: SideItem, selected: Boolean, requester: FocusRequester, onFocused: () -> Unit, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val bg = when {
        focused -> Color.White
        selected -> Color(0x1FFFFFFF)
        else -> Color.Transparent
    }
    val fg = when {
        focused -> Color.Black
        selected -> Color.White
        else -> ItemText
    }
    Row(
        Modifier.fillMaxWidth().focusRequester(requester).clip(ItemShape).background(bg)
            .onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocused() }
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(item.icon, null, Modifier.size(15.dp), tint = fg)
        Spacer(Modifier.width(10.dp))
        Text(item.label, Modifier.weight(1f), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = fg, maxLines = 1)
        if (selected && !focused) Box(Modifier.size(5.dp).clip(CircleShape).background(BrandRed))
    }
}

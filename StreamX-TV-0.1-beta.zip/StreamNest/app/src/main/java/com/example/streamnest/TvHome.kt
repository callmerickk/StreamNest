package com.example.streamnest

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableIntState
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.imageLoader
import coil.request.ImageRequest
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Everything TV Home must remember while a title page / player is open on top of it (Home itself is not composed
 * then): scroll positions, the hero card and the item that had focus. Plain fields: writing them recomposes nothing.
 */
class TvHomeState {
    val list = LazyListState()
    private val rows = HashMap<String, LazyListState>()
    fun row(key: String): LazyListState = rows.getOrPut(key) { LazyListState() }
    val deckPage: MutableIntState = mutableIntStateOf(0)
    /** Key of the row that had focus ("deck" = the hero card), and the item index in it. */
    var focusRow: String? = null
    var focusIndex: Int = 0
    /** Bumped by TvApp when the sidebar closes without a known item to return to: Home puts focus back itself. */
    val refocus: MutableIntState = mutableIntStateOf(0)
}

private data class TvDeckEntry(val meta: Meta, val catalog: String)

private sealed class TvHomeSec(val key: String) {
    class Cw(val items: List<Progress>) : TvHomeSec("cw")
    class Col(val c: NCollection) : TvHomeSec("col:" + c.id) { val folders = c.folders.distinctBy { it.id } }
    class Metas(key: String, val title: String, val items: List<Meta>) : TvHomeSec(key)
}

private const val DeckRow = "deck"

@Composable
fun TvHomeScreen(
    vm: AppViewModel,
    onOpen: (Meta) -> Unit,
    onPlay: (Screen.Player) -> Unit,
    onOpenCollection: (NCollection, NFolder) -> Unit,
    onLeftEdge: (FocusRequester) -> Unit,
    state: TvHomeState = remember { TvHomeState() },
) {
    val allShelves by vm.shelves.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val profile by vm.current.collectAsStateWithLifecycle()
    val recs by vm.recommended.collectAsStateWithLifecycle()
    val colFlow = remember(vm) { vm.collections() }
    val collections by colFlow.collectAsStateWithLifecycle()

    val rowsOrder = t("rowsOrder")
    val rowsHidden = t("rowsHidden")
    val shelves = remember(allShelves, rowsOrder, rowsHidden) {
        val hidden = rowsHidden.split("|").toSet()
        arrangeShelves(allShelves, rowsOrder).filter { it.title !in hidden && it.items.isNotEmpty() }
    }
    val showHero = isOn(t("showHero"))
    // Hero cards: the first two rows mixed (e.g. popular movies + popular series), like the phone app.
    val deck = remember(shelves, showHero) {
        if (!showHero) emptyList() else {
            val a = shelves.getOrNull(0)?.let { s -> s.items.map { TvDeckEntry(it, s.title) } }.orEmpty()
            val b = shelves.getOrNull(1)?.let { s -> s.items.map { TvDeckEntry(it, s.title) } }.orEmpty()
            (0 until maxOf(a.size, b.size)).flatMap { listOfNotNull(a.getOrNull(it), b.getOrNull(it)) }
                .filter { it.meta.poster != null || it.meta.background != null }.distinctBy { it.meta.id }.take(10)
        }
    }
    val cwShow = isOn(t("cwShow"))
    val showRecs = isOn(t("showRecs"))
    val continueTitle = t("continueWatching").replace("{name}", profile?.name ?: "").trim()
    val recTitle = t("recommendedFor").replace("{name}", profile?.name ?: "you")
    val newOn = t("newOn").replace("{app}", t("appName"))
    val sections = remember(progress, collections, shelves, recs, cwShow, showRecs, recTitle, newOn) {
        buildList<TvHomeSec> {
            if (cwShow && progress.isNotEmpty()) add(TvHomeSec.Cw(progress))
            collections.filter { it.folders.isNotEmpty() }.distinctBy { it.id }.forEach { add(TvHomeSec.Col(it)) }
            shelves.forEachIndexed { i, s ->
                val title = if (s.title.startsWith("New")) "$newOn · ${s.title.removePrefix("New ").trim()}" else s.title
                add(TvHomeSec.Metas("shelf:$i:${s.title}", title, s.items))
            }
            if (showRecs && recs.isNotEmpty()) add(TvHomeSec.Metas("recs", recTitle, recs))
        }
    }

    val scope = rememberCoroutineScope()
    val scrollJob = remember { arrayOfNulls<Job>(1) }
    val bgImage = remember { mutableStateOf<String?>(null) }
    val deckFr = remember { FocusRequester() }
    val restoreFr = remember { FocusRequester() }
    val homeFocused = remember { booleanArrayOf(false) }
    val ls = state.list

    // Row [ord] got focus: the first row keeps the hero card visible above it, later rows go to the top.
    // ord = -1: the hero card itself (list back at the very top).
    fun scrollToSection(ord: Int) {
        val target = if (ord <= 0) 0 else ord + 1
        scrollJob[0]?.cancel()
        scrollJob[0] = scope.launch {
            if (ls.firstVisibleItemIndex != target || ls.firstVisibleItemScrollOffset != 0) ls.animateScrollToItem(target)
            if (ord == 0) {
                val info = ls.layoutInfo
                val first = info.visibleItemsInfo.firstOrNull { it.index == 1 }
                if (first != null) {
                    val over = first.offset + first.size - info.viewportSize.height
                    if (over > 0) ls.animateScrollBy(over.toFloat())
                }
            }
        }
    }

    // Focus: back to where it was (coming back from a title page), else the hero card (or the first row).
    val restoreRow = state.focusRow ?: if (deck.isEmpty()) sections.firstOrNull()?.key else null
    val restoreIdx = if (state.focusRow != null) state.focusIndex else 0
    val hasContent = deck.isNotEmpty() || sections.isNotEmpty()
    LaunchedEffect(hasContent) {
        if (!hasContent) return@LaunchedEffect
        withFrameNanos { }
        delay(30)
        if (homeFocused[0]) return@LaunchedEffect
        val ok = if (restoreRow != null && restoreRow != DeckRow) restoreFr.tryFocus() else false
        if (!ok && !deckFr.tryFocus()) restoreFr.tryFocus()
    }
    val refocusTick = state.refocus.intValue
    LaunchedEffect(refocusTick) {
        if (refocusTick == 0) return@LaunchedEffect
        withFrameNanos { }
        val ok = if (restoreRow != null && restoreRow != DeckRow) restoreFr.tryFocus() else false
        if (!ok && !deckFr.tryFocus()) restoreFr.tryFocus()
    }

    Box(Modifier.fillMaxSize().onFocusChanged { homeFocused[0] = it.hasFocus }.focusGroup()) {
        TvHomeBackdrop(bgImage)
        if (!hasContent) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                if (loading) CircularProgressIndicator(color = Accent)
                else Text(t("emptyMsg"), Modifier.padding(32.dp), fontSize = 13.sp, color = TvSubText)
            }
        } else TvManualScroll {
            LazyColumn(Modifier.fillMaxSize(), state = ls, contentPadding = PaddingValues(bottom = 90.dp)) {
                item(key = DeckRow, contentType = DeckRow) {
                    if (deck.isNotEmpty()) TvHeroDeck(
                        deck, state.deckPage, deckFr, ls,
                        onLeftEdge = onLeftEdge,
                        onFocused = { state.focusRow = DeckRow; state.focusIndex = 0; bgImage.value = null; scrollToSection(-1) },
                        onOpen = onOpen,
                    ) else Spacer(Modifier.height(20.dp))
                }
                itemsIndexed(sections, key = { _, s -> s.key }, contentType = { _, s ->
                    when (s) { is TvHomeSec.Cw -> "cw"; is TvHomeSec.Col -> "col"; is TvHomeSec.Metas -> "row" }
                }) { ord, s ->
                    val rIdx = if (s.key == restoreRow) restoreIdx else -1
                    val itemFocus: (Int) -> Unit = { i -> state.focusRow = s.key; state.focusIndex = i }
                    when (s) {
                        is TvHomeSec.Cw -> TvRow(
                            s.items, key = { it.key }, title = continueTitle, state = state.row(s.key),
                            restoreIndex = rIdx, restoreRequester = restoreFr, onLeftEdge = onLeftEdge,
                            onRowFocus = { bgImage.value = null; scrollToSection(ord) }, onItemFocus = itemFocus,
                        ) { _, p, mod ->
                            TvContinueCard(p, mod) { onPlay(Screen.Player(p.title, p.url, p.subs, p.key, p.image, p.positionMs)) }
                        }
                        is TvHomeSec.Col -> TvRow(
                            s.folders, key = { it.id }, title = s.c.title, state = state.row(s.key),
                            restoreIndex = rIdx, restoreRequester = restoreFr, onLeftEdge = onLeftEdge,
                            onRowFocus = { scrollToSection(ord) }, onItemFocus = itemFocus,
                        ) { _, f, mod ->
                            TvFolderTile(f, mod, onFocus = { if (it) bgImage.value = f.hero ?: f.cover ?: s.c.backdrop }) { onOpenCollection(s.c, f) }
                        }
                        is TvHomeSec.Metas -> TvMetaRow(
                            s.title, s.items, onOpen, state = state.row(s.key),
                            restoreIndex = rIdx, restoreRequester = restoreFr, onLeftEdge = onLeftEdge,
                            onRowFocus = { bgImage.value = null; scrollToSection(ord) }, onItemFocus = itemFocus,
                        )
                    }
                }
            }
        }
    }
}

/** Full-screen artwork behind the rows while a collection folder has focus (dimmed, faded into the background). */
@Composable
private fun TvHomeBackdrop(image: State<String?>) {
    val url = image.value ?: return
    val req = tvImage(url, 480.dp, 270.dp)
    val bg = Bg
    val side = remember(bg) { Brush.horizontalGradient(0.25f to bg, 0.6f to bg.copy(alpha = 0.6f), 1f to bg.copy(alpha = 0.1f)) }
    val bottom = remember(bg) { Brush.verticalGradient(0.35f to Color.Transparent, 0.85f to bg) }
    Box(Modifier.fillMaxSize()) {
        if (req != null) AsyncImage(req, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alpha = 0.55f)
        Box(Modifier.fillMaxSize().background(side))
        Box(Modifier.fillMaxSize().background(bottom))
    }
}

// ───────────── Hero cards (Hotstar style) ─────────────

private val DeckShape = RoundedCornerShape(14.dp)
private val DeckShade = Brush.horizontalGradient(0f to Color(0xD9000000), 0.38f to Color(0x8C000000), 0.65f to Color.Transparent)
private val DeckShadeBottom = Brush.verticalGradient(0.55f to Color.Transparent, 1f to Color(0x99000000))

@Composable
private fun TvHeroDeck(
    items: List<TvDeckEntry>,
    pageState: MutableIntState,
    requester: FocusRequester,
    listState: LazyListState,
    onLeftEdge: (FocusRequester) -> Unit,
    onFocused: () -> Unit,
    onOpen: (Meta) -> Unit,
) {
    var page by pageState
    val p = page.coerceIn(0, items.lastIndex)
    var focused by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val density = LocalDensity.current

    // Auto-advance every 7 s while the cards are on screen and not focused.
    LaunchedEffect(focused, items.size) {
        if (focused || items.size < 2) return@LaunchedEffect
        while (true) {
            delay(7000)
            if (listState.firstVisibleItemIndex == 0) page = (page.coerceIn(0, items.lastIndex) + 1) % items.size
        }
    }
    // Warm up the next card's artwork so RIGHT shows it straight away.
    LaunchedEffect(p, items) {
        val next = items.getOrNull((p + 1) % items.size)?.meta ?: return@LaunchedEffect
        val url = backdropOf(next) ?: next.poster ?: return@LaunchedEffect
        val w = with(density) { 650.dp.roundToPx() }
        val h = with(density) { 300.dp.roundToPx() }
        ctx.imageLoader.enqueue(ImageRequest.Builder(ctx).data(url).size(w, h).build())
    }

    val cur = items[p]
    val m = cur.meta
    Box(Modifier.padding(start = TvEdge, top = 35.dp).size(width = 780.dp, height = 300.dp)) {
        if (items.size > 2) TvDeckPeek(items[(p + 2) % items.size].meta, 670.dp, 35.dp, 80.dp, 230.dp, 0.7f)
        if (items.size > 1) TvDeckPeek(items[(p + 1) % items.size].meta, 605.dp, 20.dp, 100.dp, 260.dp, 0.55f)
        Box(
            Modifier.size(650.dp, 300.dp)
                .focusRequester(requester)
                .onPreviewKeyEvent { e ->
                    if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                    when (e.key) {
                        Key.DirectionLeft -> { if (p > 0) page = p - 1 else onLeftEdge(requester); true }
                        Key.DirectionRight -> { if (items.size > 1) page = (p + 1) % items.size; true }
                        else -> false
                    }
                }
                .tvCard(14.dp, scale = 1.02f, onFocus = { focused = it; if (it) onFocused() }) { onOpen(m) }
                .clip(DeckShape).background(Color(0xFF05070C)),
        ) {
            val art = tvImage(backdropOf(m) ?: m.poster, 650.dp, 300.dp)
            if (art != null) AsyncImage(art, m.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(DeckShade))
            Box(Modifier.fillMaxSize().background(DeckShadeBottom))
            Column(Modifier.align(Alignment.BottomStart).padding(start = 28.dp, bottom = 30.dp).width(430.dp)) {
                val rating = m.imdbRating?.toDoubleOrNull()
                val badge = if (rating != null && rating >= 7.5) "★  IMDb ${m.imdbRating}" else "#${p + 1} in ${cur.catalog}"
                val badgeShape = RoundedCornerShape(4.dp)
                Text(
                    badge.uppercase(),
                    Modifier.clip(badgeShape).background(Color(0x24FFFFFF)).border(1.dp, Color(0x40FFFFFF), badgeShape)
                        .padding(horizontal = 6.dp, vertical = 3.dp),
                    fontSize = 7.5.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.2.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(9.dp))
                var logoFailed by remember(m.id) { mutableStateOf(false) }
                val logo = logoOf(m)
                val logoReq = tvImage(logo, 300.dp, 70.dp)
                if (logoReq != null && !logoFailed) {
                    AsyncImage(
                        logoReq, m.name, Modifier.widthIn(max = 300.dp).heightIn(max = 70.dp).height(64.dp).fillMaxWidth(),
                        contentScale = ContentScale.Fit, alignment = Alignment.BottomStart, onError = { logoFailed = true },
                    )
                } else {
                    Text(m.name.uppercase(), fontSize = 32.sp, lineHeight = 34.sp, fontWeight = FontWeight.Black, letterSpacing = (-1).sp,
                        maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                val line = (listOfNotNull(m.releaseInfo?.take(4)?.takeIf { it.isNotBlank() }, m.runtime?.takeIf { it.isNotBlank() }) +
                    listOfNotNull(m.genres?.take(3)?.joinToString(" · ")?.takeIf { it.isNotBlank() })).joinToString("  •  ")
                if (line.isNotBlank()) Text(line, Modifier.padding(top = 8.dp), fontSize = 10.sp, fontWeight = FontWeight.SemiBold,
                    color = Color(0xFFE6E8EE), maxLines = 1, overflow = TextOverflow.Ellipsis)
                m.description?.takeIf { it.isNotBlank() }?.let {
                    Text(it, Modifier.padding(top = 7.dp), fontSize = 10.sp, lineHeight = 14.5.sp, color = Color(0xFFD6D9E1),
                        maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
            // Page dots
            Row(Modifier.align(Alignment.BottomStart).padding(start = 28.dp, bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                items.indices.forEach { i ->
                    Box(Modifier.size(width = if (i == p) 15.dp else 5.dp, height = 5.dp).clip(RoundedCornerShape(3.dp))
                        .background(if (i == p) Color.White else Color(0x59FFFFFF)))
                }
            }
        }
    }
}

@Composable
private fun TvDeckPeek(m: Meta, x: Dp, y: Dp, w: Dp, h: Dp, dim: Float) {
    val req = tvImage(m.poster ?: backdropOf(m), w, h)
    Box(Modifier.offset(x, y).size(w, h).clip(DeckShape).background(Surface1)) {
        if (req != null) AsyncImage(req, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = dim)))
    }
}

// ───────────── Cards ─────────────

private val CwShade = Brush.verticalGradient(0.5f to Color.Transparent, 1f to Color(0xCC000000))

/** Continue Watching card (landscape, red progress bar). */
@Composable
fun TvContinueCard(p: Progress, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = remember { RoundedCornerShape(10.dp) }
    val frac = if (p.durationMs > 0) (p.positionMs.toFloat() / p.durationMs).coerceIn(0f, 1f) else 0f
    val req = tvImage(p.image, 180.dp, 101.dp)
    Box(modifier.size(180.dp, 101.dp).tvCard(10.dp, onClick = onClick).clip(shape).background(Surface1)) {
        if (req != null) AsyncImage(req, p.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(CwShade))
        Text(p.title, Modifier.align(Alignment.BottomStart).padding(start = 8.dp, end = 8.dp, bottom = 9.dp), fontSize = 10.sp,
            fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(3.dp).background(Color(0x40FFFFFF))) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(BrandRed))
        }
    }
}

private val FolderShade = Brush.verticalGradient(0.4f to Color.Transparent, 1f to Color(0xB3000000))

/** A collection folder tile: cover art, optional logo, title (unless hidden). */
@Composable
fun TvFolderTile(f: NFolder, modifier: Modifier = Modifier, onFocus: ((Boolean) -> Unit)? = null, onClick: () -> Unit) {
    val (w, h) = when (f.tileShape.uppercase()) {
        "POSTER", "PORTRAIT" -> 90.dp to 135.dp
        "SQUARE" -> 100.dp to 100.dp
        else -> 150.dp to 85.dp
    }
    val shape = remember { RoundedCornerShape(12.dp) }
    val cover = f.cover ?: f.hero
    val req = tvImage(cover, w, h)
    val logoReq = tvImage(f.logo, w * 0.62f, h * 0.5f)
    var logoFailed by remember(f.id) { mutableStateOf(false) }
    Box(modifier.size(w, h).tvCard(12.dp, onFocus = onFocus, onClick = onClick).clip(shape).background(Color(0xFF15161C))) {
        if (req != null) AsyncImage(req, f.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        if (logoReq != null && !logoFailed) {
            AsyncImage(logoReq, f.title, Modifier.align(Alignment.Center).fillMaxWidth(0.62f).fillMaxHeight(0.5f),
                contentScale = ContentScale.Fit, onError = { logoFailed = true })
        } else if (!f.hideTitle || cover == null) {
            if (cover != null) Box(Modifier.fillMaxSize().background(FolderShade))
            Text(
                f.title,
                if (cover != null) Modifier.align(Alignment.BottomStart).padding(start = 9.dp, end = 9.dp, bottom = 7.dp)
                else Modifier.align(Alignment.Center).padding(8.dp),
                fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

// ───────────── Library (beta: Continue Watching + My List) ─────────────

@Composable
fun TvLibraryScreen(vm: AppViewModel, onOpen: (Meta) -> Unit, onPlay: (Screen.Player) -> Unit, onLeftEdge: (FocusRequester) -> Unit) {
    val progress by vm.progress.collectAsStateWithLifecycle()
    val myList by vm.myList.collectAsStateWithLifecycle()
    val first = remember { FocusRequester() }
    val cwState = rememberLazyListState()
    val listState = rememberLazyListState()
    val empty = progress.isEmpty() && myList.isEmpty()
    LaunchedEffect(empty) {
        if (empty) return@LaunchedEffect
        withFrameNanos { }
        first.tryFocus()
    }
    Box(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(top = 30.dp, bottom = 60.dp)) {
            item(key = "title") {
                Text("Library", Modifier.padding(start = TvEdge, bottom = 4.dp), fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            }
            if (progress.isNotEmpty()) item(key = "cw") {
                TvRow(progress, key = { it.key }, title = t("continueWatching").replace("{name}", "").trim(), state = cwState,
                    restoreIndex = 0, restoreRequester = first, onLeftEdge = onLeftEdge) { _, p, mod ->
                    TvContinueCard(p, mod) { onPlay(Screen.Player(p.title, p.url, p.subs, p.key, p.image, p.positionMs)) }
                }
            }
            if (myList.isNotEmpty()) item(key = "list") {
                TvMetaRow("My List", myList, onOpen, restoreIndex = if (progress.isEmpty()) 0 else -1, restoreRequester = first, onLeftEdge = onLeftEdge)
            }
            if (empty) item(key = "empty") {
                Text("Titles you add to My List and shows you're watching appear here.", Modifier.padding(start = TvEdge, top = 24.dp),
                    fontSize = 12.sp, color = TvSubText)
            }
        }
    }
}

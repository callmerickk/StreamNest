package com.example.streamnest

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.focusRestorer
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Screens pushed on top of the TV sections. */
sealed interface TvRoute {
    data class Detail(val meta: Meta) : TvRoute
    data class Person(val p: Screen.Person) : TvRoute
    data class Player(val p: Screen.Player) : TvRoute
    data class Collection(val c: NCollection, val f: NFolder) : TvRoute
    data class Settings(val start: String) : TvRoute
}

private tailrec fun Context.tvActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.tvActivity()
    else -> null
}

/**
 * StreamX TV shell: splash, "Who's watching?", then the sections (Home / Search / Library / My Space / Settings) with
 * a floating sidebar that is completely hidden until LEFT is pressed on the left-most item (or BACK on Home).
 * BACK: closes pushed screens → goes back to Home → opens the sidebar → (sidebar open on Home) exits the app.
 */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun TvApp(vm: AppViewModel = viewModel()) {
    val stack = remember { mutableStateListOf<TvRoute>() }
    var tab by rememberSaveable { mutableStateOf(TvTab.Home) }
    var sidebar by remember { mutableStateOf(false) }
    val returnFocus = remember { arrayOfNulls<FocusRequester>(1) }
    val contentFr = remember { FocusRequester() }
    val contentFocused = remember { booleanArrayOf(false) }
    val profile by vm.current.collectAsStateWithLifecycle()
    val texts by vm.texts.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val homeState = remember(profile?.id) { TvHomeState() }
    val searchQuery = remember(profile?.id) { mutableStateOf("") }
    val opening = remember { arrayOfNulls<Job>(1) }
    var voteFor by remember { mutableStateOf<Meta?>(null) }
    var showSplash by remember { mutableStateOf(!StartupState.splashShown && isOn(texts["splash"] ?: "yes")) }

    val push: (TvRoute) -> Unit = { stack.add(it) }
    val pop: () -> Unit = { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex); Unit }
    // Collection items can have TMDB ids: they are turned into IMDb ids first (normal addon titles return at once).
    val openMeta: (Meta) -> Unit = { m ->
        if (opening[0]?.isActive != true) opening[0] = scope.launch {
            val r = runCatching { vm.resolveForOpen(m) }.getOrNull()
            if (r != null) stack.add(TvRoute.Detail(r)) else Snack.show("Couldn't open ${m.name}")
        }
    }
    val play: (Screen.Player) -> Unit = { stack.add(TvRoute.Player(it)) }

    fun openSidebar(from: FocusRequester?) {
        returnFocus[0] = from
        sidebar = true
    }
    fun closeSidebar() {
        sidebar = false
        val fr = returnFocus[0]
        returnFocus[0] = null
        if (fr != null && fr.tryFocus()) return
        if (tab == TvTab.Home) homeState.refocus.intValue++ else contentFr.tryFocus()
    }

    BackHandler(enabled = profile != null && !showSplash) {
        when {
            stack.isNotEmpty() -> pop()
            sidebar -> if (tab == TvTab.Home) ctx.tvActivity()?.finish() else closeSidebar()
            tab != TvTab.Home -> tab = TvTab.Home
            else -> openSidebar(null)
        }
    }

    CompositionLocalProvider(LocalTexts provides texts) {
        LaunchedEffect(profile == null) { if (profile == null) { stack.clear(); sidebar = false } }
        // After switching sections, make sure something on the new screen has focus.
        LaunchedEffect(tab, stack.isEmpty(), profile?.id) {
            if (profile == null || stack.isNotEmpty()) return@LaunchedEffect
            delay(160)
            if (!sidebar && !contentFocused[0]) contentFr.tryFocus()
        }
        Box(Modifier.fillMaxSize().background(Bg)) {
            if (profile == null) TvProfileGate(vm, active = !showSplash) { tab = TvTab.Home }
            else when (val top = stack.lastOrNull()) {
                is TvRoute.Player -> key(top) {
                    val p = top.p
                    PlayerScreen(vm, p, onBack = pop, onReplace = { next -> if (stack.isNotEmpty()) stack[stack.lastIndex] = TvRoute.Player(next) }, onProgress = { pos, dur, url, subs ->
                        if (p.key.isNotEmpty() && url.isNotEmpty()) vm.saveProgress(Progress(p.key, p.title, p.image, url, subs, pos, dur, System.currentTimeMillis()))
                        // "How was it?" once you've really watched something (10 min or 30%).
                        val base = p.key.substringBefore(":")
                        val prev = vm.votes.value[base]
                        val watchedEnough = pos >= 10 * 60_000L || (dur > 0 && pos >= dur * 0.3)
                        val askAgain = prev == null || (prev.v == 0 && System.currentTimeMillis() - prev.at > 3L * 24 * 3600_000)
                        if (base.isNotEmpty() && watchedEnough && askAgain && isOn(texts["askVote"] ?: "yes")) {
                            voteFor = p.meta?.copy(id = base) ?: Meta(id = base, type = p.type.ifBlank { if (p.key.contains(":")) "series" else "movie" },
                                name = p.title.substringBefore("  S"), poster = p.image)
                        }
                    })
                }
                is TvRoute.Detail -> key(top) {
                    TvDetailScreen(vm, top.meta, onBack = pop, onOpen = openMeta, onPlay = play,
                        onPerson = { c -> push(TvRoute.Person(Screen.Person(c.id, c.name, c.photo))) })
                }
                is TvRoute.Person -> key(top) { Box(Modifier.fillMaxSize().background(Bg)) { PersonScreen(vm, top.p, onBack = pop, onOpen = openMeta) } }
                is TvRoute.Collection -> key(top) { TvCollectionScreen(vm, top.c, top.f, onBack = pop, onOpen = openMeta) }
                is TvRoute.Settings -> key(top) { Box(Modifier.fillMaxSize().background(Bg)) { SettingsHost(vm, top.start, onClose = pop) } }
                null -> {
                    val edge: (FocusRequester) -> Unit = { fr -> openSidebar(fr) }
                    Box(
                        Modifier.fillMaxSize()
                            .onFocusChanged { contentFocused[0] = it.hasFocus }
                            .focusRequester(contentFr)
                            .focusRestorer(),
                    ) {
                        when (tab) {
                            TvTab.Home -> TvHomeScreen(vm, onOpen = openMeta, onPlay = play,
                                onOpenCollection = { c, f -> push(TvRoute.Collection(c, f)) }, onLeftEdge = edge, state = homeState)
                            TvTab.Search -> TvSearchScreen(vm, searchQuery, onOpen = openMeta, onLeftEdge = edge)
                            TvTab.Library -> TvLibraryScreen(vm, onOpen = openMeta, onPlay = play, onLeftEdge = edge)
                            TvTab.MySpace -> MySpaceScreen(
                                vm,
                                onSettings = { tab = TvTab.Settings },
                                onProfile = { push(TvRoute.Settings("profile")) },
                                onSwitchProfile = { vm.leaveProfile() },
                                onOpen = openMeta,
                                onPlay = play,
                                onManual = { m, _ -> openMeta(m) },
                            )
                            TvTab.Settings -> SettingsHost(vm, "root", onClose = { tab = TvTab.Home })
                        }
                    }
                    TvSidebar(
                        open = sidebar, vm = vm, current = tab,
                        onSelect = { t ->
                            if (t == tab) closeSidebar()
                            else { returnFocus[0] = null; sidebar = false; tab = t }
                        },
                        onClose = { closeSidebar() },
                    )
                }
            }
        }
        if (profile != null && stack.lastOrNull() !is TvRoute.Player) voteFor?.let { m ->
            key(m.id) { VoteCapsule(m, onVote = { v -> vm.vote(m, v) }, onDismiss = { voteFor = null }) }
        }
        if (showSplash) StartupSplash { showSplash = false }
        SnackHost()
    }
}

// ───────────── "Who's watching?" for the remote ─────────────

/**
 * Remote-friendly profile picker: the last used profile has focus straight away; on the first start of the app it
 * opens by itself after a few seconds unless a button is pressed.
 */
@Composable
private fun TvProfileGate(vm: AppViewModel, active: Boolean, onPicked: () -> Unit) {
    val profiles by vm.profiles.collectAsStateWithLifecycle()
    val texts by vm.texts.collectAsStateWithLifecycle()
    val lastId = texts["lastProfile"] ?: ""
    val startIdx = profiles.indexOfFirst { it.id == lastId }.coerceAtLeast(0)
    val frs = remember(profiles.size) { List(profiles.size + 1) { FocusRequester() } }
    var focusedIdx by remember { mutableIntStateOf(-1) }
    var adding by remember { mutableStateOf(false) }
    var cancelled by remember { mutableStateOf(false) }
    val allowAuto = remember { !StartupState.autoPickDone }
    val secs = (texts["autoProfileSecs"] ?: Defaults["autoProfileSecs"] ?: "5").toIntOrNull() ?: 5
    var picked by remember { mutableStateOf(false) }

    fun pick(p: Profile) {
        if (picked) return
        picked = true
        cancelled = true
        vm.selectProfile(p)
        onPicked()
    }

    LaunchedEffect(Unit) { StartupState.autoPickDone = true }
    LaunchedEffect(active, profiles.size) {
        if (!active || profiles.isEmpty()) return@LaunchedEffect
        withFrameNanos { }
        frs.getOrNull(startIdx)?.tryFocus()
    }
    LaunchedEffect(active, cancelled, adding) {
        if (!allowAuto || !active || cancelled || adding || secs <= 0) return@LaunchedEffect
        delay(secs * 1000L + 600L)
        profiles.getOrNull(startIdx)?.let { pick(it) }
    }

    val bg = remember { Brush.verticalGradient(listOf(Color(0xFF15101E), Color(0xFF0B0B10), Color(0xFF07080C))) }
    Box(
        Modifier.fillMaxSize().background(bg).onPreviewKeyEvent { cancelled = true; false },
    ) {
        Column(Modifier.fillMaxWidth().padding(top = 110.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Wordmark(t("appName"), 20.sp)
            Text(t("whoWatching"), Modifier.padding(top = 22.dp), fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Row(Modifier.padding(top = 34.dp), horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                profiles.forEachIndexed { i, p ->
                    Column(Modifier.width(96.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        ProfileAvatar(
                            vm, p, 72.dp,
                            Modifier.focusRequester(frs[i]).tvCard(36.dp, scale = 1.12f, onFocus = { if (it) focusedIdx = i }) { pick(p) },
                        )
                        Text(
                            p.name, Modifier.padding(top = 12.dp), fontSize = 12.sp, textAlign = TextAlign.Center,
                            fontWeight = if (focusedIdx == i) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (focusedIdx == i) Color.White else Color(0xFFC9CDD6), maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                if (profiles.size < 5) Column(Modifier.width(96.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    val addIdx = profiles.size
                    Box(
                        Modifier.size(72.dp).focusRequester(frs[addIdx])
                            .tvCard(36.dp, scale = 1.12f, onFocus = { if (it) focusedIdx = addIdx }) { cancelled = true; adding = true }
                            .clip(CircleShape).background(Color(0x2EFFFFFF)),
                        Alignment.Center,
                    ) { Icon(Icons.Default.Add, "Add profile", Modifier.size(30.dp)) }
                    Text("Add", Modifier.padding(top = 12.dp), fontSize = 12.sp,
                        color = if (focusedIdx == addIdx) Color.White else Color(0xFFC9CDD6))
                }
            }
            Spacer(Modifier.height(30.dp))
            if (allowAuto && !cancelled && profiles.isNotEmpty()) {
                Text("Opening ${profiles.getOrNull(startIdx)?.name ?: ""} in a moment · press any button to choose",
                    fontSize = 11.sp, color = Color(0xFF7C8394))
            }
        }
    }
    if (adding) ProfileEditor(vm, null) { adding = false }
}

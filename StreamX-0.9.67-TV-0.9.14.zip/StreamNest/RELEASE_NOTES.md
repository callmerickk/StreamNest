StreamX TV 0.9.14 (the phone app stays on 0.9.67)

• No automatic stream switching while you watch — better copies come as Upgrade quality (now with 4K HDHUB, UHDMovies, HDHub4u).
• Upgrade, Quality, Sources and Watch next get ready in the background — no loading screen.
• Smoother: next episode prepared quietly, Skip intro fits your copy, faster Home.
• Smoother start and profile opening; Home cards never slide in empty.

StreamX TV 0.9.11 (the phone app stays on 0.9.67)

• Next episode starts at once (its link and first seconds are ready ahead).
• Hold OK on an episode: the menu stays open.
• Audio & Subtitles: every remote press works.
• Posters load faster: kept after updates, no more vanishing.

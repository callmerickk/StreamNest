StreamX 0.9.72

• New Home style: Live (Settings › Home Layout). StreamX's own cards stay the default.
• New colours: Midnight.
• Library › Watched: finished films and shows.
• Home opens with its pictures ready.

---

StreamX TV 0.9.15 

• Back on Home no longer freezes or closes the app.
• The first open after an update stays open.
• Posters load once at start (no more reloading).
• Home appears at once and refreshes quietly.

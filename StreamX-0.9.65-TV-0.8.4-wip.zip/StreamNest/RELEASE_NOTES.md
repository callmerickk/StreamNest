StreamX TV 0.8.4 (the phone app stays on 0.9.65)

• Opens faster and lighter on Fire TV sticks.
• Smooth loading screen; streaming playlists climb to their best quality without pausing.
• Continue Watching works after an update (a fresh link from the same source, no error screen).
• Next Episode shows the episode's picture with the countdown.
• 1 GB sticks: fewer pictures in memory, no 60fps copies, no trailers.

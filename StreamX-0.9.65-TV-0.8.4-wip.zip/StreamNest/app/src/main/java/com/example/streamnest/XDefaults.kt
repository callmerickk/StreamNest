package com.example.streamnest

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

/**
 * StreamX: defaults the developer publishes for everyone from Developer's Corner (shared/devDefaults in the cloud, readable
 * by signed-in users only): the API keys (AI, TMDB, MDBList, GIPHY, Trakt), the AI's logo and its voice. Every phone
 * applies them when a profile opens, so nobody has to get their own keys.
 */
object DevDefaults {
    private fun textKeys(): List<String> = listOf("aiOn", "aiProvider", "aiLogoUrl", "tmdbKey", "mdbKey", "giphyKey", "traktClientId", "codeNames", "homeRows", "tagRules", "rowNames", "rowStyles", "liveVoice_June", "liveVoice_Aiden", "liveModel", "aiName", "aiNameStyle", "appNameStyle", "dns", "autoPlayMode", "autoRegex") +
        AiProviders.flatMap { listOf("aiKey_${it.id}", "aiModel_${it.id}") }
    private val storeKeys = listOf("aiVoice", "aiVoiceEn", "aiVoiceHi", "aiVoiceRate", "aiVoiceOut")
    /**
     * Every setting of the app as the developer has it (look, Home, player, subtitles, Quick Play, sources, filters…),
     * published with "Publish everything" and put on every other account once per publish, replacing what they had.
     * Not included: personal things (18+, profile memory, likes, AI chats and faces, sign-in and first-run state).
     */
    private val settingKeys = listOf(
        "accent", "accent2", "addonPosters", "addonsOff", "addonsPinned", "amoled", "appName", "askVote", "autoOnlineSubs", "autoProfileSecs",
        "autoQuality", "autoSkipIntro", "autoSlide", "avLayout", "background", "badgePack", "btnColor", "btnText", "cardCorner", "cardTrailers",
        "colHidden", "colOrder", "customThemes", "cwShow", "cwStyle", "deckBorder", "deckTint", "detailCast", "detailMore", "detailRatings",
        "eliteWifiStrict", "extExclude", "extOn", "fastStart", "fusionBadges", "gestMidWidth", "hideDead", "hideLabels", "landscapePosters",
        "navBar", "navStyle", "nextThreshold", "notifyOn", "parallelDl", "pauseInfo", "picMatch", "picPref", "playerChoice", "playerEngine",
        "posterCorner", "posterPattern", "posterWidth", "qpUrl", "qsAddons", "qsHideDupes", "qsLangs", "qsOn", "qsPreload", "qsQuality",
        "qsUpgrade", "recsAfterCw", "reuseLastLink", "rowsHidden", "rowsOrder", "showAddonName", "showAdvisory", "showCollections", "showHero",
        "showRecs", "shuffleRows", "skipIntro", "slideSeconds", "splash", "srcAutoManage", "srcMode", "startBright", "startBrightLevel",
        "startBrightMode", "startVol", "startVolLevel", "startVolMode", "subAutoSync", "subBg", "subBold", "subColor", "subFollow", "subLangs",
        "subNetflix", "subOutline", "subOutlineColor", "subSize", "testedOnly", "theme", "userRegexIn", "userRegexOut",
    )

    /** Publishes what this phone has now (only the owner's account may write). Null = done. */
    suspend fun publish(vm: AppViewModel): String? = withContext(Dispatchers.IO) {
        val t = Cloud.token() ?: return@withContext "Sign in first."
        val texts = vm.texts.value
        val body = buildJsonObject {
            textKeys().forEach { k -> texts[k]?.let { put("t_$k", it) } }
            storeKeys.forEach { k -> vm.store(k)?.let { put("s_$k", it) } }
            settingKeys.forEach { k -> texts[k]?.let { put("a_$k", it) } }
            put("at", System.currentTimeMillis())
        }
        runCatching {
            Api.http.newCall(Request.Builder().url(XNs.url("devDefaults", t))
                .put(body.toString().toRequestBody("application/json".toMediaType())).build()).execute().use { r ->
                if (r.isSuccessful) null else if (r.code == 401 || r.code == 403) "Not allowed: add the Firebase rule for shared/devDefaults (write: owner only, read: signed-in)." else "HTTP ${r.code}"
            }
        }.getOrElse { "Couldn't reach the cloud." }
    }

    /** Applies the published defaults on this phone (keys that changed only). */
    suspend fun sync(vm: AppViewModel) {
        val t = Cloud.token() ?: return
        val o = withContext(Dispatchers.IO) {
            runCatching { Api.json.parseToJsonElement(XNs.read("devDefaults", t)!!) as? JsonObject }.getOrNull()
        } ?: return
        val changed = ArrayList<String>()
        // All settings: put on this profile once per publish, replacing its own (the developer's phone is left alone).
        val at = runCatching { o["at"]?.jsonPrimitive?.contentOrNull?.toLong() }.getOrNull() ?: 0L
        val allOnce = !Public.dev && o.keys.any { it.startsWith("a_") } && at > (vm.store("devSettingsAt")?.toLongOrNull() ?: 0L)
        withContext(Dispatchers.Main) {
            if (allOnce) {
                var n = 0
                o.forEach { (k, v) ->
                    if (!k.startsWith("a_")) return@forEach
                    val key = k.removePrefix("a_"); val value = runCatching { v.jsonPrimitive.contentOrNull }.getOrNull() ?: return@forEach
                    if (vm.texts.value[key] != value) { vm.setText(key, value); n++ }
                    vm.storePut("ownKey_$key", null)
                }
                vm.storePut("devSettingsAt", at.toString())
                ActLog.add("APP", "published settings applied: $n changed")
            }
            o.forEach { (k, v) ->
                val value = runCatching { v.jsonPrimitive.contentOrNull }.getOrNull() ?: return@forEach
                when {
                    // The developer's filters are the base; the user's own filter changes stay on top (never replaced).
                    k == "t_tagRules" -> if (vm.texts.value["devTagRules"] != value) { vm.setText("devTagRules", value); changed += "devTagRules" }
                    // The developer's DNS: for everyone who hasn't picked one themselves.
                    k == "t_dns" -> if (vm.store("ownKey_dns") != "1" && vm.texts.value["dns"] != value) { vm.setDns(value, byUser = false); changed += "dns" }
                    k.startsWith("t_") -> { val key = k.removePrefix("t_")
                        val own = vm.store("ownKey_$key") == "1" && !vm.texts.value[key].isNullOrBlank()
                        if (!own && vm.texts.value[key] != value) { vm.setText(key, value); changed += key } }
                    k.startsWith("a_") -> {}
                    k.startsWith("s_") -> { val key = k.removePrefix("s_"); if (vm.store(key) != value) { vm.storePut(key, value); changed += key } }
                }
            }
        }
        if (changed.isNotEmpty()) ActLog.add("APP", "published defaults applied: ${changed.size} setting(s)")
    }
}

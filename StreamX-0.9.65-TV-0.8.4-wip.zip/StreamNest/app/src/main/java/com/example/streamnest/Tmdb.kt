package com.example.streamnest

import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/* Rich title info from TMDB (Help & Settings > Integrations > TMDB key). Everything is optional. */

/** [id] = TMDB person id (empty when the cast comes from the addon instead of TMDB). */
data class TmCast(val name: String, val role: String, val photo: String?, val id: String = "")
data class TmCompany(val name: String, val logo: String?)
/** [official] = uploaded by the studio's official channel; [publishedAt] = ISO date-time ("2024-05-01T16:00:05.000Z"). */
data class TmVideo(val key: String, val name: String, val type: String, val year: String?, val official: Boolean = true, val publishedAt: String? = null, val lang: String? = null)
/** [score] = TMDB vote_average (0..10), [genreIds] = TMDB genre ids. */
data class TmRec(val tmdbId: String, val kind: String, val title: String, val year: String?, val poster: String?, val score: Double = 0.0, val genreIds: List<Int> = emptyList())
data class TmdbInfo(
    val tmdbId: String, val kind: String,
    val poster: String?, val backdrop: String?, val logo: String?,
    val certification: String?, val status: String?, val release: String?, val runtime: String?,
    val country: String?, val language: String?, val genres: List<String>, val overview: String?,
    val directors: List<String>, val writers: List<String>, val cast: List<TmCast>,
    val companies: List<TmCompany>, val videos: List<TmVideo>, val recs: List<TmRec>,
    val genreIds: List<Int> = emptyList(),
    /** TV loading screen: scene stills without text (best first), tagline and money. */
    val backdrops: List<String> = emptyList(), val tagline: String? = null, val budget: Long = 0, val revenue: Long = 0,
)

private val infoCache = HashMap<String, TmdbInfo>()
private const val IMG = "https://image.tmdb.org/t/p/"

private fun JsonObject.str(k: String) = (this[k] as? kotlinx.serialization.json.JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() }
private fun JsonObject.arr(k: String) = (this[k] as? JsonArray)?.mapNotNull { it as? JsonObject }.orEmpty()
private fun JsonObject.obj(k: String) = this[k] as? JsonObject

fun AppViewModel.tmdbKey(): String = (texts.value["tmdbKey"] ?: "").trim()

/**
 * TMDB sign-in for every request in the app: TMDB gives two kinds of key, the short "API key" (v3, sent as api_key=…)
 * and the long "API Read Access Token" (starts with eyJ…, must be sent as "Authorization: Bearer"). Pasting the long one
 * into the key field made every TMDB call fail with 401 (Source Test, plugin test, posters, search). Any request with a
 * long token in api_key is rewritten to the Bearer form here, so both kinds simply work.
 */
object TmdbAuth : okhttp3.Interceptor {
    fun isToken(k: String) = k.startsWith("eyJ") || k.length > 40
    override fun intercept(chain: okhttp3.Interceptor.Chain): okhttp3.Response {
        val req = chain.request()
        if (req.url.host != "api.themoviedb.org") return chain.proceed(req)
        val k = req.url.queryParameter("api_key")?.trim().orEmpty()
        if (k.isEmpty() || !isToken(k)) return chain.proceed(req)
        val url = req.url.newBuilder().removeAllQueryParameters("api_key").build()
        return chain.proceed(req.newBuilder().url(url).header("Authorization", "Bearer $k").header("accept", "application/json").build())
    }

    /** Last check of the key: "ok", "bad" (TMDB refused it: 401), "none" (no key), or "net: …" (couldn't reach TMDB). */
    val state = kotlinx.coroutines.flow.MutableStateFlow("")
    suspend fun check(key: String): String {
        val k = key.trim()
        val r = if (k.isEmpty()) "none" else runCatching { Api.get("https://api.themoviedb.org/3/configuration?api_key=$k"); "ok" }.getOrElse { e ->
            if ((e.message ?: "").contains("401")) "bad" else "net: " + (e.message ?: e.javaClass.simpleName).take(60)
        }
        state.value = r
        ActLog.add("NET", "TMDB key check: $r")
        return r
    }
    fun label(r: String) = when {
        r == "ok" -> "TMDB key works"
        r == "bad" -> "TMDB refused the key (401): paste the v3 API key or the Read Access Token from themoviedb.org › Settings › API"
        r == "none" -> "No TMDB key: add one in Integrations"
        r.startsWith("net") -> "Couldn't reach TMDB (${r.removePrefix("net: ")})"
        else -> "Checking TMDB key…"
    }
}

suspend fun AppViewModel.tmdbInfo(imdb: String, type: String): TmdbInfo? {
    val key = tmdbKey()
    if (key.isEmpty() || !imdb.startsWith("tt")) return null
    infoCache[imdb]?.let { return it }
    return runCatching {
        val find = Api.json.parseToJsonElement(Api.get("https://api.themoviedb.org/3/find/$imdb?api_key=$key&external_source=imdb_id")).jsonObject
        val tv = type == "series"
        val hit = find.arr(if (tv) "tv_results" else "movie_results").firstOrNull()
            ?: find.arr(if (tv) "movie_results" else "tv_results").firstOrNull() ?: return null
        val kind = if (find.arr("tv_results").firstOrNull() === hit) "tv" else "movie"
        val id = hit["id"]!!.jsonPrimitive.content
        val extra = if (kind == "tv") "credits,videos,content_ratings,recommendations,images" else "credits,videos,release_dates,recommendations,images"
        val d = Api.json.parseToJsonElement(Api.get("https://api.themoviedb.org/3/$kind/$id?api_key=$key&append_to_response=$extra&include_image_language=en,null&include_video_language=en,hi,ta,te,ml,kn,bn,mr,pa,es,fr,de,it,ja,ko,zh,pt,ru,null")).jsonObject

        val imgs = d.obj("images")
        fun bestImg(field: String, lang: String?) = imgs?.arr(field)?.filter { lang == null || it.str("iso_639_1") == lang }
            ?.maxByOrNull { (it["vote_average"] as? kotlinx.serialization.json.JsonPrimitive)?.contentOrNull?.toDoubleOrNull() ?: 0.0 }?.str("file_path")
        val logo = bestImg("logos", "en") ?: bestImg("logos", null)

        val cert = if (kind == "movie") {
            val res = d.obj("release_dates")?.arr("results").orEmpty()
            listOf("IN", "US", "GB").firstNotNullOfOrNull { c -> res.firstOrNull { it.str("iso_3166_1") == c }?.arr("release_dates")?.firstNotNullOfOrNull { it.str("certification") } }
        } else {
            val res = d.obj("content_ratings")?.arr("results").orEmpty()
            listOf("IN", "US", "GB").firstNotNullOfOrNull { c -> res.firstOrNull { it.str("iso_3166_1") == c }?.str("rating") }
        }
        val runtimeMin = if (kind == "movie") d["runtime"]?.jsonPrimitive?.intOrNull
        else (d["episode_run_time"] as? JsonArray)?.firstOrNull()?.jsonPrimitive?.intOrNull
        val credits = d.obj("credits")
        val crew = credits?.arr("crew").orEmpty()
        val directors = if (kind == "tv") d.arr("created_by").mapNotNull { it.str("name") } else crew.filter { it.str("job") == "Director" }.mapNotNull { it.str("name") }
        val writers = crew.filter { it.str("department") == "Writing" }.mapNotNull { it.str("name") }.distinct().take(3)
        // Actors only (credits.cast) — crew never appears in the cast row.
        val cast = credits?.arr("cast").orEmpty().take(60).mapNotNull { c ->
            TmCast(c.str("name") ?: return@mapNotNull null, c.str("character") ?: "", c.str("profile_path")?.let { "${IMG}w185$it" }, c.str("id") ?: "")
        }.distinctBy { it.id.ifEmpty { it.name } }
        val companies = (if (kind == "tv") d.arr("networks") + d.arr("production_companies") else d.arr("production_companies"))
            .mapNotNull { c -> TmCompany(c.str("name") ?: return@mapNotNull null, c.str("logo_path")?.let { "${IMG}w185$it" }) }.distinctBy { it.name }.take(6)
        val videos = d.obj("videos")?.arr("results").orEmpty().filter { it.str("site") == "YouTube" }.mapNotNull { v ->
            TmVideo(v.str("key") ?: return@mapNotNull null, v.str("name") ?: "Video", v.str("type") ?: "Video", v.str("published_at")?.take(4),
                official = (v["official"] as? JsonPrimitive)?.booleanOrNull ?: true, publishedAt = v.str("published_at"), lang = v.str("iso_639_1"))
        }.distinctBy { it.key }.sortedByDescending { it.publishedAt ?: "" } // newest first
        val recs = d.obj("recommendations")?.arr("results").orEmpty().take(20).mapNotNull { r -> parseRec(r, kind) }.distinctBy { it.kind + it.tmdbId }
        TmdbInfo(
            tmdbId = id, kind = kind,
            poster = d.str("poster_path")?.let { "${IMG}w780$it" },
            backdrop = d.str("backdrop_path")?.let { "${IMG}w1280$it" },
            logo = logo?.let { "${IMG}w500$it" },
            certification = cert, status = d.str("status"),
            release = (d.str("release_date") ?: d.str("first_air_date")),
            runtime = runtimeMin?.takeIf { it > 0 }?.let { if (it >= 60) "${it / 60}h ${it % 60}m" else "${it}m" },
            country = (d["origin_country"] as? JsonArray)?.firstOrNull()?.jsonPrimitive?.contentOrNull
                ?: d.arr("production_countries").firstOrNull()?.str("iso_3166_1"),
            language = d.str("original_language")?.uppercase(),
            genres = d.arr("genres").mapNotNull { it.str("name") },
            genreIds = d.arr("genres").mapNotNull { (it["id"] as? JsonPrimitive)?.intOrNull },
            overview = d.str("overview"),
            directors = directors, writers = writers, cast = cast, companies = companies, videos = videos, recs = recs,
            backdrops = imgs?.arr("backdrops").orEmpty().filter { it.str("iso_639_1") == null }
                .sortedByDescending { (it["vote_average"] as? JsonPrimitive)?.contentOrNull?.toDoubleOrNull() ?: 0.0 }
                .mapNotNull { it.str("file_path")?.let { p -> "${IMG}w1280$p" } }.take(6),
            tagline = d.str("tagline"),
            budget = (d["budget"] as? JsonPrimitive)?.longOrNull ?: 0L, revenue = (d["revenue"] as? JsonPrimitive)?.longOrNull ?: 0L,
        ).also { infoCache[imdb] = it }
    }.getOrNull()
}

/** IMDb id for a TMDB recommendation, so it can open in StreamX. */
private val imdbOfTmdb = java.util.concurrent.ConcurrentHashMap<String, String>()
suspend fun AppViewModel.tmdbToImdb(r: TmRec): String? = imdbOfTmdb[r.kind + r.tmdbId] ?: runCatching {
    val o = Api.json.parseToJsonElement(Api.get("https://api.themoviedb.org/3/${r.kind}/${r.tmdbId}/external_ids?api_key=${tmdbKey()}")).jsonObject
    o.str("imdb_id")
}.getOrNull()?.also { if (it.isNotBlank()) imdbOfTmdb[r.kind + r.tmdbId] = it }

private fun parseRec(r: JsonObject, kind: String): TmRec? {
    val id = r.str("id") ?: return null
    val title = r.str("title") ?: r.str("name") ?: return null
    return TmRec(
        id, r.str("media_type") ?: kind, title,
        (r.str("release_date") ?: r.str("first_air_date"))?.take(4), r.str("poster_path")?.let { "${IMG}w500$it" },
        score = (r["vote_average"] as? JsonPrimitive)?.doubleOrNull ?: 0.0,
        genreIds = (r["genre_ids"] as? JsonArray)?.mapNotNull { (it as? JsonPrimitive)?.intOrNull }.orEmpty(),
    )
}

private val similarCache = HashMap<String, List<TmRec>>()

/** TMDB "similar" titles (used to top up the recommendations). [kind] = "movie" or "tv". */
suspend fun AppViewModel.tmdbSimilar(kind: String, tmdbId: String): List<TmRec> {
    val key = tmdbKey()
    if (key.isEmpty()) return emptyList()
    similarCache[kind + tmdbId]?.let { return it }
    return runCatching {
        val o = Api.json.parseToJsonElement(Api.get("https://api.themoviedb.org/3/$kind/$tmdbId/similar?api_key=$key")).jsonObject
        o.arr("results").take(20).mapNotNull { parseRec(it, kind) }.distinctBy { it.kind + it.tmdbId }
    }.getOrDefault(emptyList()).also { if (it.isNotEmpty()) similarCache[kind + tmdbId] = it }
}

/**
 * Titles in the same language as a non-English title (Hindi → Hindi): same genres, popular, from nearby years.
 * TMDB's own recommendations are mostly English, so a Bollywood film used to get Hollywood picks.
 */
suspend fun AppViewModel.tmdbSameLanguage(kind: String, tmdbId: String, lang: String, genreIds: List<Int>, year: Int?): List<TmRec> {
    val key = tmdbKey(); if (key.isEmpty()) return emptyList()
    similarCache["lang:$kind$tmdbId"]?.let { return it }
    val dk = if (kind == "tv") "first_air_date" else "primary_release_date"
    val yr = year?.let { "&$dk.gte=${it - 8}-01-01&$dk.lte=${it + 6}-12-31" } ?: ""
    suspend fun q(genres: String) = runCatching {
        Api.json.parseToJsonElement(Api.get("https://api.themoviedb.org/3/discover/$kind?api_key=$key&with_original_language=${lang.lowercase()}" +
            "&sort_by=popularity.desc&vote_count.gte=15$genres$yr&page=1")).jsonObject.arr("results").take(20).mapNotNull { parseRec(it, kind) }
    }.getOrDefault(emptyList())
    val g = genreIds.take(2)
    // Sharing both genres first, then either one.
    val both = if (g.size == 2) q("&with_genres=${g.joinToString(",")}") else emptyList()
    val any = q(if (g.isNotEmpty()) "&with_genres=" + java.net.URLEncoder.encode(g.joinToString("|"), "UTF-8") else "")
    return (both + any).filter { it.tmdbId != tmdbId }.distinctBy { it.tmdbId }.take(20).also { if (it.isNotEmpty()) similarCache["lang:$kind$tmdbId"] = it }
}

/** TMDB genre ids (movies and TV) to names. */
val TmdbGenres: Map<Int, String> = mapOf(
    28 to "Action", 12 to "Adventure", 16 to "Animation", 35 to "Comedy", 80 to "Crime", 99 to "Documentary", 18 to "Drama",
    10751 to "Family", 14 to "Fantasy", 36 to "History", 27 to "Horror", 10402 to "Music", 9648 to "Mystery", 10749 to "Romance",
    878 to "Sci-Fi", 10770 to "TV Movie", 53 to "Thriller", 10752 to "War", 37 to "Western",
    10759 to "Action", 10762 to "Kids", 10763 to "News", 10764 to "Reality", 10765 to "Sci-Fi", 10766 to "Soap", 10767 to "Talk", 10768 to "War",
)

/**
 * Tall posters for the numbered (Top 10) rows: TMDB's own full-size portrait poster, found by IMDb id (or by name and
 * year for titles without one). Catalogs that only have a wide design are never cropped into a tall card any more.
 * Remembered for the whole session; the answer for each title is asked once.
 */
object TmdbPosters {
    private val cache = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val none = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    private val running = java.util.concurrent.ConcurrentHashMap<String, kotlinx.coroutines.Deferred<String?>>()
    private val scope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + kotlinx.coroutines.Dispatchers.IO)

    fun cached(m: Meta): String? = cache[m.id]
    fun remember(m: Meta, url: String) { cache[m.id] = url }

    /** A tall poster that never needs TMDB: Cinemeta's large poster by IMDb id, or the title's own when it is tall. */
    fun fallback(m: Meta): String? = hdPoster(m) ?: m.poster?.takeIf { !m.posterShape.equals("landscape", true) && !m.posterShape.equals("square", true) }?.let { hiResArt(it) }

    suspend fun portrait(m: Meta): String? {
        cache[m.id]?.let { return it }
        if (m.id in none) return null
        val vm = Public.vm ?: return null
        val key = vm.tmdbKey()
        if (key.isEmpty()) return null
        val d = running.getOrPut(m.id) { scope.async { runCatching { look(m, key) }.getOrNull() } }
        val r = d.await()
        running.remove(m.id)
        if (r != null) cache[m.id] = r else none += m.id
        return r
    }

    private suspend fun look(m: Meta, key: String): String? {
        val imdb = m.id.substringBefore(":").takeIf { it.startsWith("tt") }
        val path: String? = if (imdb != null) {
            val f = Api.json.parseToJsonElement(Api.get("https://api.themoviedb.org/3/find/$imdb?api_key=$key&external_source=imdb_id")).jsonObject
            val first = if (m.type == "series") listOf("tv_results", "movie_results") else listOf("movie_results", "tv_results")
            first.firstNotNullOfOrNull { k -> f.arr(k).firstOrNull()?.str("poster_path") }
        } else {
            val kind = if (m.type == "series") "tv" else "movie"
            val year = m.releaseInfo?.take(4)?.toIntOrNull()
            val yp = if (year == null) "" else if (kind == "tv") "&first_air_date_year=$year" else "&year=$year"
            val o = Api.json.parseToJsonElement(Api.get("https://api.themoviedb.org/3/search/$kind?api_key=$key&query=${java.net.URLEncoder.encode(m.name, "UTF-8")}$yp&page=1")).jsonObject
            o.arr("results").firstOrNull()?.str("poster_path")
        }
        return path?.let { "${IMG}w780$it" }
    }
}

/**
 * Bollywood in the Top rows: the most popular new Hindi films / series (TMDB, Hindi original language), with their
 * IMDb ids so they open and play like every other title. Fetched once per app start.
 */
/**
 * "Top on Netflix / Prime Video / JioHotstar" rows from TMDB (India's streaming lists), English and Hindi mixed — titles
 * carry IMDb ids and TMDB's tall posters, so they look and play like every other card. Fetched once per app start.
 */
object ServiceRows {
    private data class Svc(val name: String, val ids: String)
    private val services = listOf(Svc("Netflix", "8"), Svc("Prime Video", "119"), Svc("JioHotstar", "122|2336"))
    @Volatile private var cache: List<Shelf>? = null
    private val lock = kotlinx.coroutines.sync.Mutex()

    suspend fun rows(): List<Shelf> = cache ?: lock.withLock { cache ?: fetchAll().also { if (it.isNotEmpty()) cache = it } }

    private suspend fun fetchAll(): List<Shelf> = kotlinx.coroutines.coroutineScope {
        val vm = Public.vm ?: return@coroutineScope emptyList()
        val key = vm.tmdbKey().ifEmpty { return@coroutineScope emptyList() }
        services.flatMap { sv -> listOf(sv to "movie", sv to "series") }.map { (sv, kind) ->
            async { runCatching { row(key, sv, kind) }.getOrNull() }
        }.awaitAll().filterNotNull().filter { it.items.size >= 6 }
    }

    private suspend fun row(key: String, sv: Svc, kind: String): Shelf = kotlinx.coroutines.coroutineScope {
        val tv = kind == "series"
        val since = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(System.currentTimeMillis() - 3L * 365 * 86_400_000L))
        fun url(lang: String) = "https://api.themoviedb.org/3/discover/${if (tv) "tv" else "movie"}?api_key=$key&watch_region=IN&with_watch_providers=${java.net.URLEncoder.encode(sv.ids, "UTF-8")}" +
            "&with_watch_monetization_types=flatrate&with_original_language=$lang&sort_by=popularity.desc&vote_count.gte=5&page=1" +
            (if (tv) "&first_air_date.gte=$since" else "&primary_release_date.gte=$since")
        val en = async { runCatching { Api.json.parseToJsonElement(Api.get(url("en"))).jsonObject.arr("results").take(12) }.getOrDefault(emptyList()) }
        val hi = async { runCatching { Api.json.parseToJsonElement(Api.get(url("hi"))).jsonObject.arr("results").take(8) }.getOrDefault(emptyList()) }
        // English and Hindi woven together (3 English : 2 Hindi), most popular first.
        val e = en.await(); val h = hi.await()
        val mixed = ArrayList<JsonObject>()
        var i = 0; var j = 0
        while (mixed.size < 20 && (i < e.size || j < h.size)) {
            repeat(3) { if (i < e.size) mixed += e[i++].jsonObject }
            repeat(2) { if (j < h.size) mixed += h[j++].jsonObject }
        }
        val items = mixed.map { o ->
            async {
                runCatching {
                    val id = o["id"]?.jsonPrimitive?.content ?: return@runCatching null
                    val imdb = Api.json.parseToJsonElement(Api.get("https://api.themoviedb.org/3/${if (tv) "tv" else "movie"}/$id/external_ids?api_key=$key")).jsonObject
                        .str("imdb_id")?.takeIf { it.startsWith("tt") } ?: return@runCatching null
                    val poster = o.str("poster_path")?.let { "${IMG}w500$it" }
                    Meta(id = imdb, type = kind, name = o.str("title") ?: o.str("name") ?: return@runCatching null, poster = poster,
                        background = o.str("backdrop_path")?.let { "${IMG}w1280$it" },
                        releaseInfo = (o.str("release_date") ?: o.str("first_air_date"))?.take(4)).also { m -> if (poster != null) TmdbPosters.remember(m, poster) }
                }.getOrNull()
            }
        }.awaitAll().filterNotNull().distinctBy { it.id }
        Shelf("Top ${if (tv) "Series" else "Movies"} on ${sv.name}", items, src = "tmdb-svc:${sv.name}:$kind")
    }
}

object HindiTrending {
    private val cache = java.util.concurrent.ConcurrentHashMap<String, List<Meta>>()
    private val lock = kotlinx.coroutines.sync.Mutex()

    fun cachedOrNull(kind: String): List<Meta>? = cache[kind] ?: if (empty.contains(kind)) emptyList() else null
    private val empty = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    suspend fun list(kind: String): List<Meta> {
        cache[kind]?.let { return it }
        return lock.withLock {
            cache[kind]?.let { return@withLock it }
            val r = runCatching { fetch(kind) }.getOrDefault(emptyList())
            if (r.isNotEmpty()) cache[kind] = r else empty += kind
            r
        }
    }

    private suspend fun fetch(kind: String): List<Meta> = kotlinx.coroutines.coroutineScope {
        val vm = Public.vm ?: return@coroutineScope emptyList()
        val key = vm.tmdbKey().ifEmpty { return@coroutineScope emptyList() }
        val tv = kind == "series"
        val since = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(System.currentTimeMillis() - (if (tv) 365L else 150L) * 86_400_000L))
        val url = if (tv) "https://api.themoviedb.org/3/discover/tv?api_key=$key&with_original_language=hi&sort_by=popularity.desc&first_air_date.gte=$since&vote_count.gte=3&page=1"
            else "https://api.themoviedb.org/3/discover/movie?api_key=$key&with_original_language=hi&sort_by=popularity.desc&primary_release_date.gte=$since&vote_count.gte=3&page=1"
        val res = Api.json.parseToJsonElement(Api.get(url)).jsonObject.arr("results").take(6)
        res.map { o ->
            async {
                runCatching {
                    val id = o["id"]?.jsonPrimitive?.content ?: return@runCatching null
                    val imdb = Api.json.parseToJsonElement(Api.get("https://api.themoviedb.org/3/${if (tv) "tv" else "movie"}/$id/external_ids?api_key=$key")).jsonObject
                        .str("imdb_id")?.takeIf { it.startsWith("tt") } ?: return@runCatching null
                    val poster = o.str("poster_path")?.let { "${IMG}w780$it" }
                    Meta(id = imdb, type = kind, name = o.str("title") ?: o.str("name") ?: return@runCatching null, poster = poster,
                        background = o.str("backdrop_path")?.let { "${IMG}w1280$it" },
                        releaseInfo = (o.str("release_date") ?: o.str("first_air_date"))?.take(4)).also { m -> if (poster != null) TmdbPosters.remember(m, poster) }
                }.getOrNull()
            }
        }.awaitAll().filterNotNull()
    }

    /** Hindi titles woven into a Top row: one at every third place (2, 5, 8 …), never the same title twice. */
    fun mix(items: List<Meta>, hindi: List<Meta>): List<Meta> {
        if (hindi.isEmpty()) return items
        fun k(m: Meta) = m.name.lowercase().replace(Regex("[^\\p{L}\\p{N}]"), "")
        val have = items.flatMap { listOf(it.id.substringBefore(":"), k(it)) }.toSet()
        val add = hindi.filter { it.id !in have && k(it) !in have }.iterator()
        val out = ArrayList<Meta>()
        items.forEachIndexed { i, m -> if (i % 3 == 1 && add.hasNext()) out += add.next(); out += m }
        return out
    }
}

/**
 * Films still only in cinemas (no official web, Blu-ray or TV release anywhere yet) stay off Home; search still finds
 * them. Checked on TMDB's release dates, newest films only, remembered on the phone (a film that is out stays known;
 * one still in cinemas is checked again after 2 days).
 */
object CinemaOnly {
    val hidden = kotlinx.coroutines.flow.MutableStateFlow<Set<String>>(emptySet())
    /** Adult-only films (TMDB's adult flag, or rated NC-17 / X in the US): kept off Home unless 18+ is switched on. */
    val adult = kotlinx.coroutines.flow.MutableStateFlow<Set<String>>(emptySet())
    private var prefs: android.content.SharedPreferences? = null
    private val running = java.util.concurrent.atomic.AtomicBoolean(false)

    private fun p(ctx: android.content.Context) = prefs ?: ctx.getSharedPreferences("cinema_only", android.content.Context.MODE_PRIVATE).also { prefs = it }

    fun load(ctx: android.content.Context) {
        val now = System.currentTimeMillis()
        // Every film last seen as not out stays hidden from the start (a re-check shows it once it is out).
        hidden.value = p(ctx).all.mapNotNull { (k, v) -> (v as? String)?.takeIf { it.startsWith("cinema:") }?.let { k } }.toSet()
    }

    /** Titles asked for while a check was already running: checked right after it (they used to be skipped). */
    private val queued = java.util.Collections.synchronizedList(ArrayList<Meta>())
    suspend fun check(vm: AppViewModel, metas: List<Meta>) {
        val key = vm.tmdbKey(); if (key.isEmpty()) return
        if (!running.compareAndSet(false, true)) { queued += metas; return }
        try {
            checkNow(vm, key, metas)
            while (true) {
                val more = synchronized(queued) { queued.toList().also { queued.clear() } }
                if (more.isEmpty()) break
                checkNow(vm, key, more)
            }
        } finally { running.set(false) }
    }
    private suspend fun checkNow(vm: AppViewModel, key: String, metas: List<Meta>) {
        // Adult check (once per film, kept for good): every film on Home, at most 80 new ones per run.
        runCatching {
            val pr = p(vm.appContext)
            adult.value = adult.value + pr.all.filter { (k, v) -> k.startsWith("ad_") && v == true }.keys.map { it.removePrefix("ad_") }
            val todo = metas.asSequence().filter { it.type == "movie" && it.id.startsWith("tt") }.map { it.id.substringBefore(":") }.distinct()
                .filter { !pr.contains("ad_$it") }.take(80).toList()
            val sem = kotlinx.coroutines.sync.Semaphore(4)
            kotlinx.coroutines.coroutineScope {
                todo.forEach { id -> launch(kotlinx.coroutines.Dispatchers.IO) { sem.acquire(); try {
                    val a = runCatching { isAdult(key, id) }.getOrNull()
                    if (a != null) { pr.edit().putBoolean("ad_$id", a).apply(); if (a) adult.value = adult.value + id }
                } finally { sem.release() } } }
            }
        }
        run {
            val pr = p(vm.appContext)
            val year = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
            val now = System.currentTimeMillis()
            metas.filter { it.type == "movie" && (it.releaseInfo?.take(4)?.toIntOrNull() ?: 0) > year }.map { it.id.substringBefore(":") }
                .takeIf { it.isNotEmpty() }?.let { f -> hidden.value = hidden.value + f }
            val todo = metas.asSequence().filter { it.type == "movie" && it.id.startsWith("tt") }
                .filter { m -> (m.releaseInfo?.take(4)?.toIntOrNull() ?: year) >= year - 1 }
                .map { it.id.substringBefore(":") }.distinct()
                // Checked again every 2 days while recent (a film's online date can move; "web" answers used to stick forever).
                .filter { id -> val v = pr.getString(id, null); v == null || v == "web" ||
                    (v.contains(":") && now - (v.substringAfter(":").toLongOrNull() ?: 0) > 2 * 86_400_000L) }
                .take(120).toList()
            val sem = kotlinx.coroutines.sync.Semaphore(5)
            kotlinx.coroutines.coroutineScope {
                val yearOf = metas.associate { it.id.substringBefore(":") to (it.releaseInfo?.take(4)?.toIntOrNull() ?: year) }
                todo.forEach { id -> launch(kotlinx.coroutines.Dispatchers.IO) { sem.acquire(); try {
                    // No answer about its dates and it's from this year: not shown until it is known to be out.
                    val v = runCatching { verdict(key, id) }.getOrNull() ?: if ((yearOf[id] ?: year) >= year) false else null
                    if (v != null) {
                        pr.edit().putString(id, if (v) "web:$now" else "cinema:$now").apply()
                        hidden.value = if (v) hidden.value - id else hidden.value + id
                    }
                } finally { sem.release() } } }
            }
        }
    }

    private suspend fun isAdult(key: String, imdb: String): Boolean? {
        val f = Api.json.parseToJsonElement(Api.get("https://api.themoviedb.org/3/find/$imdb?api_key=$key&external_source=imdb_id")).jsonObject
        val m = f.arr("movie_results").firstOrNull() ?: return false
        if ((m["adult"] as? JsonPrimitive)?.booleanOrNull == true) return true
        val id = m.str("id") ?: return false
        val rd = Api.json.parseToJsonElement(Api.get("https://api.themoviedb.org/3/movie/$id/release_dates?api_key=$key")).jsonObject
        return rd.arr("results").filter { it.str("iso_3166_1") == "US" }.flatMap { it.arr("release_dates") }
            .any { (it.str("certification") ?: "").uppercase() in setOf("NC-17", "X") }
    }

    /** For "Available now": is this film out for people at home yet? null = can't tell. */
    suspend fun isOut(key: String, imdb: String): Boolean? = runCatching { verdict(key, imdb) }.getOrNull()

    /** true = out on web / disc / TV somewhere (or not a cinema release at all); false = only in cinemas so far. */
    private suspend fun verdict(key: String, imdb: String): Boolean? {
        val f = Api.json.parseToJsonElement(Api.get("https://api.themoviedb.org/3/find/$imdb?api_key=$key&external_source=imdb_id")).jsonObject
        val id = f.arr("movie_results").firstOrNull()?.str("id") ?: return null
        val rd = Api.json.parseToJsonElement(Api.get("https://api.themoviedb.org/3/movie/$id/release_dates?api_key=$key")).jsonObject
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        val dates = rd.arr("results").flatMap { it.arr("release_dates") }.mapNotNull { d ->
            val t = (d["type"] as? JsonPrimitive)?.intOrNull ?: return@mapNotNull null
            t to (d.str("release_date")?.take(10) ?: return@mapNotNull null)
        }
        // Not released anywhere yet (every date is in the future): not on Home.
        if (dates.isNotEmpty() && dates.none { it.second <= today }) return false
        val past = dates.filter { it.second <= today }
        if (past.isEmpty()) return null
        return checkPast(past)
    }
    /**
     * Out for people at home: a digital (4), Blu-ray / DVD (5) or TV (6) release that has happened somewhere, or a cinema
     * release more than 8 weeks ago (by then it's online almost everywhere). A premiere or festival only = not out.
     */
    private fun checkPast(dates: List<Pair<Int, String>>): Boolean {
        if (dates.any { it.first >= 4 }) return true
        val cut = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(System.currentTimeMillis() - 56L * 86_400_000L))
        return dates.any { (it.first == 2 || it.first == 3) && it.second <= cut }
    }
}

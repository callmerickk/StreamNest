StreamX 0.9.10 · StreamX TV 0.4.1 beta

• Instant play: the title page saves the first minute of the best link to storage; Play starts straight from it.
• Status line under Play shows what was prepared (or why not).
• Quality choice plays that quality first; the button shows what is really playing.
• Developer's Corner › Source Test with downloadable log and a shared provider ranking.
• TV: heavy background players switched off (fewer crashes on Fire TV sticks).

package com.example.streamnest

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/** One provider group in one quality group and language, as measured by the Source Test. */
@Serializable
data class RankEntry(
    val key: String, val addon: String = "", val label: String = "", val host: String = "",
    val bucket: String = "", val lang: String = "", val tests: Int = 0, val ok: Int = 0, val medianMs: Long = 0,
    val seekable: Boolean = true, val score: Double = 0.0,
)

@Serializable data class RankFile(val at: Long = 0, val author: String = "", val entries: List<RankEntry> = emptyList())

/** A provider group that failed twice in normal use (shown in Developer's Corner, re-tested by the next Source Test). */
@Serializable data class FailReport(val key: String, val label: String = "", val count: Int = 0, val reason: String = "", val at: Long = 0, val device: String = "")

/**
 * Which provider groups play fastest and most reliably, from the Source Test (shared with every StreamX user through the
 * cloud), plus what this phone learns while you watch: a group that fails twice goes "under observation" (tried last).
 */
object Ranker {
    @Volatile var file = RankFile()
        private set
    private val scores = ConcurrentHashMap<String, Double>()      // key|bucket|lang -> score
    private val anyScores = ConcurrentHashMap<String, Double>()   // key -> best score in any bucket
    private val unseekable = ConcurrentHashMap.newKeySet<String>()
    private val fails = ConcurrentHashMap<String, Int>()
    val observed: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private var prefs: android.content.SharedPreferences? = null
    private var dir: File? = null

    fun init(ctx: Context) {
        if (prefs != null) return
        prefs = ctx.getSharedPreferences("ranker", Context.MODE_PRIVATE)
        dir = ctx.filesDir
        observed += prefs?.getStringSet("observed", emptySet()).orEmpty()
        runCatching { use(Api.json.decodeFromString<RankFile>(File(ctx.filesDir, "ranking.json").readText())) }
    }

    private fun use(f: RankFile) {
        file = f
        scores.clear(); anyScores.clear(); unseekable.clear()
        f.entries.forEach { e ->
            scores["${e.key}|${e.bucket}|${e.lang}"] = e.score
            anyScores[e.key] = maxOf(anyScores[e.key] ?: Double.NEGATIVE_INFINITY, e.score)
            if (!e.seekable) unseekable += e.key
        }
    }

    /** Uses a new ranking (from a test or the cloud) and keeps it on the phone. A new test also clears "under observation". */
    fun apply(f: RankFile, fromTest: Boolean) {
        use(f)
        dir?.let { d -> runCatching { File(d, "ranking.json").writeText(Api.json.encodeToString(f)) } }
        if (fromTest) {
            val tested = f.entries.map { it.key }.toSet()
            observed.removeAll(tested); tested.forEach { fails.remove(it) }
            prefs?.edit()?.putStringSet("observed", observed.toSet())?.apply()
        }
    }

    // ───── Groups ─────

    private val noise = Regex(
        "\\b(2160p|1440p|1080p|720p|480p|360p|4k|uhd|fhd|hd|sd|hdr10\\+?|hdr|dv|dovi|sdr|x26[45]|h\\.?26[45]|hevc|avc|10bit|8bit|web-?dl|webrip|web|bluray|brrip|remux|hindi|english|dual|multi|audio|org|esub|esubs|aac|ddp?5\\.?1|atmos)\\b",
    )

    /** "addon|provider label|server" — the same for every title the provider serves. */
    fun groupKey(s: StreamItem): String {
        val host = runCatching { Uri.parse(s.stream.url.orEmpty()).host }.getOrNull().orEmpty().split('.').takeLast(2).joinToString(".")
        val base = (s.stream.behaviorHints?.bingeGroup?.takeIf { it.isNotBlank() } ?: s.stream.name ?: "").lowercase()
        val label = noise.replace(base, " ").replace(Regex("[^a-z0-9]+"), " ").trim()
            .split(" ").filter { it.isNotBlank() && it.length > 1 && !it.all(Char::isDigit) }.take(4).joinToString(" ")
        return "${s.addonName}|$label|$host"
    }

    fun labelOf(key: String): String = key.split('|').filter { it.isNotBlank() }.joinToString(" · ")

    /** 4k / fhd / mhd / low — the player's four quality groups. */
    fun bucket(res: Int): String = when { res >= 1440 -> "4k"; res >= 1080 -> "fhd"; res >= 720 -> "mhd"; else -> "low" }
    fun tier(res: Int): Int = when { res >= 1440 -> 4; res >= 1080 -> 3; res >= 720 -> 2; else -> 1 }

    fun lang(s: StreamItem): String { val l = s.languages(); return when { "hindi" in l -> "hindi"; "english" in l -> "english"; else -> "other" } }

    /** Reliability score: higher = more reliable and faster. Unknown = 0; under observation = far below everything. */
    fun score(s: StreamItem): Double {
        val k = groupKey(s)
        if (k in observed) return -1000.0
        return scores["$k|${bucket(s.resolution())}|${lang(s)}"] ?: anyScores[k] ?: 0.0
    }

    fun knownUnseekable(s: StreamItem): Boolean = groupKey(s) in unseekable

    /** Score of a measured group: success rate first, then speed; files you can't jump inside are pushed down. */
    fun scoreOf(ok: Int, tests: Int, medianMs: Long, seekable: Boolean): Double {
        if (tests == 0) return 0.0
        val rate = ok.toDouble() / tests
        val secs = (medianMs / 1000.0).coerceAtMost(20.0)
        return rate * 100 - secs * 4 - (if (seekable) 0 else 60)
    }

    // ───── Learning while you watch ─────

    fun recordOk(s: StreamItem?) {
        val k = s?.let { groupKey(it) } ?: return
        fails.remove(k)
    }

    /** A link failed to play. The second failure in a row puts its group under observation and reports it. */
    suspend fun recordFail(s: StreamItem?, reason: String) {
        val item = s ?: return
        val k = groupKey(item)
        val n = (fails[k] ?: 0) + 1
        fails[k] = n
        if (n >= 2 && k !in observed) {
            observed += k
            prefs?.edit()?.putStringSet("observed", observed.toSet())?.apply()
            report(FailReport(k, labelOf(k), n, reason.take(160), System.currentTimeMillis(), android.os.Build.MODEL ?: ""))
        }
    }

    // ───── Cloud (shared/sourceRanks: everyone reads, only the owner writes; shared/reports: failure reports) ─────

    private val jsonType = "application/json".toMediaType()

    /** Downloads the shared ranking (no sign-in needed). */
    suspend fun fetchShared(): Boolean = withContext(Dispatchers.IO) {
        val f = runCatching { Api.json.decodeFromString<RankFile>(Api.get("${CloudConfig.DB_URL}/shared/sourceRanks.json")) }.getOrNull()
            ?: return@withContext false
        if (f.entries.isNotEmpty() && f.at > file.at) apply(f, fromTest = false)
        true
    }

    /** Uploads this phone's ranking for everyone. Only works from the owner's account (Firebase rules). Null = done, else why not. */
    suspend fun upload(): String? = withContext(Dispatchers.IO) {
        if (file.entries.isEmpty()) return@withContext "No ranking yet — run the Source Test first."
        val t = Cloud.token() ?: return@withContext "Sign in first (Settings › Account & Cloud Sync)."
        runCatching {
            val req = Request.Builder().url("${CloudConfig.DB_URL}/shared/sourceRanks.json?auth=$t")
                .put(Api.json.encodeToString(file).toRequestBody(jsonType)).build()
            Api.http.newCall(req).execute().use { r -> if (r.isSuccessful) null else if (r.code == 401 || r.code == 403) "Not allowed: only the owner's account can upload." else "HTTP ${r.code}" }
        }.getOrElse { "Couldn't reach the cloud: ${it.javaClass.simpleName}" }
    }

    private suspend fun report(r: FailReport) = withContext(Dispatchers.IO) {
        val uid = Cloud.user.value?.uid ?: return@withContext
        val t = Cloud.token() ?: return@withContext
        val id = Integer.toHexString(r.key.hashCode())
        runCatching {
            val req = Request.Builder().url("${CloudConfig.DB_URL}/shared/reports/$uid/$id.json?auth=$t")
                .put(Api.json.encodeToString(r).toRequestBody(jsonType)).build()
            Api.http.newCall(req).execute().close()
        }
    }

    /** Every user's failure reports (owner only). */
    suspend fun allReports(): Pair<List<FailReport>, String?> = withContext(Dispatchers.IO) {
        val t = Cloud.token() ?: return@withContext emptyList<FailReport>() to "Sign in first."
        runCatching {
            val body = Api.get("${CloudConfig.DB_URL}/shared/reports.json?auth=$t")
            if (body.trim() == "null") return@runCatching emptyList<FailReport>() to null
            val byUser = Api.json.decodeFromString<Map<String, Map<String, FailReport>>>(body)
            byUser.values.flatMap { it.values }.groupBy { it.key }.map { (k, l) ->
                FailReport(k, l.first().label, l.sumOf { it.count }, l.maxByOrNull { it.at }?.reason.orEmpty(), l.maxOf { it.at }, "${l.size} phone(s)")
            }.sortedByDescending { it.count } to null
        }.getOrElse { emptyList<FailReport>() to "Couldn't read reports (${it.message?.take(60)})" }
    }
}

/**
 * Candidates for a quality level, best first: the right quality group first (4K / Full HD / Mid HD / Low — falling back
 * to the next lower one), then your language (Hindi → English…), then the measured reliability, then resolution.
 * Groups under observation and files you can't jump inside go last.
 */
fun AppViewModel.rankedCandidates(list: List<StreamItem>, level: String, quickOnly: Boolean): List<StreamItem> {
    val pool = list.filter { it.stream.url != null && (!quickOnly || isQuick(it)) }.distinctBy { it.stream.url }
    val target = AllQualityLevels.firstOrNull { it.id == level }?.res ?: 0
    // Auto: Full HD (TV and phone start fast), else the best below, else anything.
    val targetTier = if (target == 0) 3 else Ranker.tier(target)
    fun tierCost(s: StreamItem): Int { val t = Ranker.tier(s.resolution()); return if (t == targetTier) 0 else if (t < targetTier) targetTier - t else 10 + t }
    return pool.sortedWith(
        compareBy<StreamItem>({ if (Ranker.score(it) <= -1000.0) 1 else 0 }, { if (Ranker.knownUnseekable(it)) 1 else 0 }, { tierCost(it) }, { langRank(it) })
            .thenByDescending { Ranker.score(it) }.thenByDescending { it.resolution() },
    )
}

package com.example.streamnest

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.SurfaceTexture
import android.os.Build
import android.os.SystemClock
import android.provider.MediaStore
import android.view.Surface
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** One tested link. */
data class LinkResult(
    val title: String, val addon: String, val key: String, val bucket: String, val lang: String, val res: Int,
    val ok: Boolean, val firstFrameMs: Long?, val seekable: Boolean, val reason: String?,
)

/** A title picked for the test. */
private data class TestTitle(val imdb: String, val type: String, val name: String, val year: String?, val videoId: String, val label: String)

/**
 * Source Test (Developer's Corner): picks 2 random movies and 2 random series (Hindi / English, any year), asks the
 * chosen addons for every link, and plays each link until its first picture (20 s at most), measuring every step.
 * Then it ranks the provider groups per quality group (4K / Full HD / Mid HD / Low) and language, uses that ranking,
 * and writes a full log to download.
 */
@OptIn(UnstableApi::class)
object SourceTester {
    val running = MutableStateFlow(false)
    val line = MutableStateFlow("")
    val step = MutableStateFlow("")
    val done = MutableStateFlow(0)
    val total = MutableStateFlow(0)
    val results = MutableStateFlow<List<LinkResult>>(emptyList())
    /** true = the test player is shown on screen; false = it plays off-screen (same hardware decoder). */
    val showPlayer = MutableStateFlow(false)
    val player = MutableStateFlow<ExoPlayer?>(null)
    val logFile = MutableStateFlow<File?>(null)
    private var job: Job? = null
    private val log = StringBuilder()
    private var offTexture: SurfaceTexture? = null
    private var offSurface: Surface? = null

    private fun stamp() = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
    private fun w(s: String) { synchronized(log) { log.append(s).append('\n') } }

    fun stop() { job?.cancel(); job = null }

    fun start(vm: AppViewModel, ctx: Context, addons: Set<String>) {
        if (running.value) return
        job = vm.viewModelScope.launch {
            running.value = true
            results.value = emptyList(); done.value = 0; total.value = 0; logFile.value = null
            synchronized(log) { log.setLength(0) }
            if (offSurface == null) {
                val tex = SurfaceTexture(0).apply { setDefaultBufferSize(640, 360) }
                offTexture = tex
                offSurface = Surface(tex)
            }
            try {
                runTest(vm, ctx, addons)
            } finally {
                player.value?.let { runCatching { it.release() } }
                player.value = null
                running.value = false
                step.value = if (results.value.isEmpty()) "Stopped" else "Finished · ${results.value.count { it.ok }}/${results.value.size} links played"
                logFile.value = writeLog(ctx)
            }
        }
    }

    private suspend fun runTest(vm: AppViewModel, ctx: Context, addons: Set<String>) {
        val net = if (isOnWifi(ctx)) "Wi-Fi" else "mobile data"
        w("StreamX Source Test log")
        w("Started: ${SimpleDateFormat("dd MMM yyyy HH:mm", Locale.US).format(Date())}")
        w("App: ${vm.appVersion} · Device: ${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}) · Network: $net")
        w("Addons tested: ${addons.joinToString(", ")}")
        w("Your languages: ${vm.qsLangs().joinToString(" → ")}")
        w("Each link: 1) one-byte request (server answer, speed, size, seekable)  2) player opens it until the first picture (max 20 s)")
        w("")
        step.value = "Picking 2 movies and 2 series…"
        val titles = pickTitles(vm)
        if (titles.isEmpty()) { w("Couldn't pick titles (TMDB key missing in Integrations, or no internet)."); step.value = "Couldn't pick titles"; return }
        titles.forEach { w("Picked: ${it.label}") }
        w("")
        // Ask every addon for every title first (so the total is known).
        val perTitle = mutableListOf<Pair<TestTitle, List<StreamItem>>>()
        for ((ti, t) in titles.withIndex()) {
            step.value = "Title ${ti + 1}/${titles.size} · asking addons · ${t.label}"
            w("== ${t.label} ==")
            val all = mutableListOf<StreamItem>()
            for (a in addons) {
                val t0 = SystemClock.elapsedRealtime()
                val l = withTimeoutOrNull(35_000) {
                    runCatching { vm.streamsFlow(t.type, t.videoId, only = setOf(a)).first { it.second }.first }.getOrDefault(emptyList())
                }
                val ms = SystemClock.elapsedRealtime() - t0
                if (l == null) w("  Addon $a: no answer in 35 s")
                else w("  Addon $a: ${"%.1f".format(ms / 1000f)} s · ${l.size} links")
                l.orEmpty().forEach { s -> if (s.stream.url != null && all.none { it.stream.url == s.stream.url }) all += s }
            }
            perTitle += t to all
            w("")
        }
        total.value = perTitle.sumOf { it.second.size }
        for ((ti, pair) in perTitle.withIndex()) {
            val (t, links) = pair
            w("== Testing ${t.label} · ${links.size} links ==")
            for (s in links) {
                if (!kotlin.coroutines.coroutineContext.isActive) return
                val r = testLink(vm, ctx, t, s, ti, perTitle.size)
                results.value = results.value + r
                done.value = done.value + 1
            }
            w("")
        }
        val ranking = buildRanking(vm)
        Ranker.apply(ranking, fromTest = true)
        w("== Ranking (used on this phone now; upload it to share with everyone) ==")
        listOf("4k" to "4K", "fhd" to "Full HD", "mhd" to "Mid HD", "low" to "Low").forEach { (b, name) ->
            listOf("hindi", "english", "other").forEach { lang ->
                val rows = ranking.entries.filter { it.bucket == b && it.lang == lang }.sortedByDescending { it.score }
                if (rows.isNotEmpty()) {
                    w("-- $name · $lang --")
                    rows.forEachIndexed { i, e ->
                        w("  ${i + 1}. ${Ranker.labelOf(e.key)} · played ${e.ok}/${e.tests} · median ${"%.1f".format(e.medianMs / 1000f)} s · ${if (e.seekable) "seekable" else "NOT seekable"} · score ${"%.0f".format(e.score)}")
                    }
                }
            }
        }
    }

    // ───── Picking titles (TMDB discover: Hindi or English, random year) ─────

    private suspend fun pickTitles(vm: AppViewModel): List<TestTitle> {
        val key = vm.tmdbKey()
        val out = mutableListOf<TestTitle>()
        val rnd = java.util.Random()
        val nowYear = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
        suspend fun one(tv: Boolean): TestTitle? {
            repeat(8) {
                val lang = if (rnd.nextBoolean()) "hi" else "en"
                val year = 1995 + rnd.nextInt((nowYear - 1995).coerceAtLeast(1))
                val kind = if (tv) "tv" else "movie"
                val yearParam = if (tv) "first_air_date_year" else "primary_release_year"
                val list = if (key.isNotEmpty()) runCatching {
                    Api.json.parseToJsonElement(Api.get("https://api.themoviedb.org/3/discover/$kind?api_key=$key&with_original_language=$lang&$yearParam=$year&sort_by=popularity.desc&vote_count.gte=15&page=1"))
                        .jsonObject["results"]!!.jsonArray.map { it.jsonObject }
                }.getOrDefault(emptyList()) else emptyList()
                val hit: JsonObject = list.shuffled().firstOrNull() ?: return@repeat
                val tmdbId = hit["id"]?.jsonPrimitive?.content ?: return@repeat
                val name = (hit["title"] ?: hit["name"])?.jsonPrimitive?.content ?: return@repeat
                val imdb = runCatching {
                    Api.json.parseToJsonElement(Api.get("https://api.themoviedb.org/3/$kind/$tmdbId/external_ids?api_key=$key")).jsonObject["imdb_id"]?.jsonPrimitive?.content
                }.getOrNull()?.takeIf { it.startsWith("tt") } ?: return@repeat
                if (out.any { it.imdb == imdb }) return@repeat
                val langName = if (lang == "hi") "Hindi" else "English"
                if (!tv) return TestTitle(imdb, "movie", name, year.toString(), imdb, "$name ($year) · movie · $langName · $imdb")
                // Series: a random episode that has already aired.
                val meta = runCatching { vm.fullMeta(Meta(id = imdb, type = "series")) }.getOrNull() ?: return@repeat
                val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                val eps = meta.videos.orEmpty().filter { (it.season ?: 0) > 0 && it.episode != null && (it.released?.take(10)?.let { r -> r <= today } ?: true) }
                val ep = eps.shuffled().firstOrNull() ?: return@repeat
                return TestTitle(imdb, "series", name, year.toString(), ep.id, "$name ($year) S${ep.season} E${ep.episode} · series · $langName · ${ep.id}")
            }
            return null
        }
        repeat(2) { one(false)?.let { out += it } }
        repeat(2) { one(true)?.let { out += it } }
        // No TMDB key: use titles from the Home rows instead.
        if (out.isEmpty()) {
            vm.shelves.value.flatMap { it.items }.filter { it.type == "movie" && it.id.startsWith("tt") }.distinctBy { it.id }.shuffled().take(2).forEach {
                out += TestTitle(it.id, "movie", it.name, it.releaseInfo, it.id, "${it.name} · movie · ${it.id} (from Home)")
            }
        }
        return out
    }

    // ───── Testing one link ─────

    private suspend fun testLink(vm: AppViewModel, ctx: Context, t: TestTitle, s: StreamItem, ti: Int, tn: Int): LinkResult {
        val url = s.stream.url!!
        val key = Ranker.groupKey(s)
        val res = s.resolution()
        val bucket = Ranker.bucket(res)
        val lang = Ranker.lang(s)
        val name = (s.stream.name ?: "").replace("\n", " ").take(60)
        val file = (s.stream.behaviorHints?.filename ?: s.stream.title?.lineSequence()?.firstOrNull() ?: "").take(90)
        step.value = "Title ${ti + 1}/$tn · link ${done.value + 1}/${total.value}"
        line.value = "${Ranker.labelOf(key)} · ${Prepare.qualityName(res)} · $lang"
        w("#${done.value + 1} [${Ranker.labelOf(key)}] ${Prepare.qualityName(res)} · $lang · \"$name\" · $file")
        w("   link: ${url.take(140)}")
        // 1) one-byte request
        val pr = StreamCache.probe(url)
        val sizeTxt = if (pr.size > 0) "%.2f GB".format(pr.size / 1_073_741_824.0) else "size ?"
        w("   [${stamp()}] server: ${if (pr.ok) "HTTP ${pr.status}" else (pr.error ?: "failed")} in ${pr.ttfbMs} ms · $sizeTxt · ${if (pr.seekable) "seekable" else "NOT seekable"} · type ${pr.type ?: "?"} · host ${pr.host}${if (pr.finalHost != pr.host) " → ${pr.finalHost}" else ""}")
        if (!pr.ok && pr.status in 400..599) {
            w("   ✗ refused by the server — player not tried")
            return LinkResult(t.label, s.addonName, key, bucket, lang, res, false, null, pr.seekable, "HTTP ${pr.status}")
        }
        // 2) the player, until the first picture
        val fname = s.stream.behaviorHints?.filename
        val tm0 = SystemClock.elapsedRealtime()
        val mime = if (StreamType.needsProbe(url, fname)) withContext(Dispatchers.IO) { StreamType.probe(url) }.takeIf { it.isNotEmpty() } else StreamType.mimeFor(url, fname)
        val typeMs = SystemClock.elapsedRealtime() - tm0
        w("   [${stamp()}] type: ${mime ?: "plain file"} (${typeMs} ms)")
        val p = buildPlayer(ctx, vm, fast = true, cache = false)
        p.volume = 0f
        offSurface?.let { p.setVideoSurface(it) }
        player.value = p
        val t0 = SystemClock.elapsedRealtime()
        val result = CompletableDeferred<String?>()
        var readyAt = -1L
        var tracksTxt = ""
        val l = object : Player.Listener {
            override fun onRenderedFirstFrame() { result.complete(null) }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY && readyAt < 0) readyAt = SystemClock.elapsedRealtime() - t0
                if (state == Player.STATE_READY && p.videoSize.width == 0 && p.currentTracks.groups.none { it.type == C.TRACK_TYPE_VIDEO }) result.complete(null)
            }
            override fun onPlayerError(error: PlaybackException) {
                result.complete("${error.errorCodeName.removePrefix("ERROR_CODE_")}${error.cause?.message?.let { " · ${it.take(120)}" } ?: ""}")
            }
            override fun onTracksChanged(tracks: Tracks) {
                tracksTxt = tracks.groups.filter { it.type == C.TRACK_TYPE_VIDEO || it.type == C.TRACK_TYPE_AUDIO }.joinToString(" ; ") { g ->
                    (0 until g.length).joinToString(", ") { i ->
                        val f = g.getTrackFormat(i)
                        val kind = if (g.type == C.TRACK_TYPE_VIDEO) "video" else "audio"
                        val dims = if (f.width > 0) " ${f.width}x${f.height}" else ""
                        val ch = if (f.channelCount > 0) " ${f.channelCount}ch" else ""
                        "$kind ${f.sampleMimeType ?: f.codecs ?: "?"}$dims$ch ${if (g.isTrackSupported(i)) "ok" else "NOT SUPPORTED"}"
                    }
                }
            }
        }
        p.addListener(l)
        p.setMediaItem(MediaItem.Builder().setUri(url).apply { if (mime != null) setMimeType(mime) }.build())
        p.prepare(); p.playWhenReady = true
        val err = withTimeoutOrNull(20_000) { result.await() }
        val ff = SystemClock.elapsedRealtime() - t0
        val timedOut = err == null && !result.isCompleted
        p.removeListener(l)
        player.value = null
        runCatching { p.release() }
        val ok = !timedOut && err == null
        val reason = when {
            timedOut -> if (readyAt >= 0) "ready in ${readyAt} ms but no picture in 20 s (decoder?)" else "nothing after 20 s (server too slow or stuck)"
            else -> err
        }
        if (tracksTxt.isNotEmpty()) w("   tracks: $tracksTxt")
        if (ok) w("   [${stamp()}] ✓ first picture in ${ff} ms (player ready at ${if (readyAt >= 0) "$readyAt ms" else "?"})")
        else w("   [${stamp()}] ✗ $reason")
        line.value = (if (ok) "✓ ${"%.1f".format(ff / 1000f)} s · " else "✗ ") + "${Ranker.labelOf(key)} · ${Prepare.qualityName(res)}"
        return LinkResult(t.label, s.addonName, key, bucket, lang, res, ok, if (ok) ff else null, pr.seekable, reason)
    }

    // ───── Ranking ─────

    private fun buildRanking(vm: AppViewModel): RankFile {
        val by = results.value.groupBy { Triple(it.key, it.bucket, it.lang) }
        val entries = by.map { (k, l) ->
            val oks = l.filter { it.ok }.mapNotNull { it.firstFrameMs }.sorted()
            val median = if (oks.isEmpty()) 20_000L else oks[oks.size / 2]
            val seekable = l.count { it.seekable } * 2 >= l.size
            val parts = k.first.split('|')
            RankEntry(k.first, parts.getOrElse(0) { "" }, parts.getOrElse(1) { "" }, parts.getOrElse(2) { "" }, k.second, k.third,
                l.size, oks.size, median, seekable, Ranker.scoreOf(oks.size, l.size, median, seekable))
        }
        return RankFile(System.currentTimeMillis(), Cloud.user.value?.email ?: "", entries)
    }

    private fun writeLog(ctx: Context): File? = runCatching {
        val d = File(ctx.cacheDir, "logs").apply { mkdirs() }
        val f = File(d, "streamx-source-test-${SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())}.txt")
        f.writeText(synchronized(log) { log.toString() })
        f
    }.getOrNull()

    /** Opens the share sheet for the log (save to Files / Drive, or send it). */
    fun shareLog(ctx: Context, f: File) {
        runCatching {
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.updates", f)
            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_STREAM, uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Source Test log").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    /** Saves the log into Downloads (Android 10+). Null = saved, else why not. */
    fun saveToDownloads(ctx: Context, f: File): String? {
        if (Build.VERSION.SDK_INT < 29) return "Use Share on this Android version"
        return runCatching {
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, f.name)
                put(MediaStore.Downloads.MIME_TYPE, "text/plain")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return "Couldn't create the file"
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(f.readBytes()) }
            null
        }.getOrElse { it.message ?: "failed" }
    }
}

// ───────────── Screen ─────────────

@Composable
fun SourceTestScreen(vm: AppViewModel, onBack: () -> Unit) {
    BackHandler { onBack() }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val running by SourceTester.running.collectAsStateWithLifecycle()
    val step by SourceTester.step.collectAsStateWithLifecycle()
    val line by SourceTester.line.collectAsStateWithLifecycle()
    val done by SourceTester.done.collectAsStateWithLifecycle()
    val total by SourceTester.total.collectAsStateWithLifecycle()
    val results by SourceTester.results.collectAsStateWithLifecycle()
    val show by SourceTester.showPlayer.collectAsStateWithLifecycle()
    val testPlayer by SourceTester.player.collectAsStateWithLifecycle()
    val logFile by SourceTester.logFile.collectAsStateWithLifecycle()
    val addonsAll by vm.addons.collectAsStateWithLifecycle()
    val names = remember(addonsAll) {
        addonsAll.filter { vm.isAddonOn(it) && it.supports("stream", "movie", "tt0111161") }.map { it.manifest.name }.distinct()
    }
    var chosen by remember(names) {
        mutableStateOf(names.filter { n -> n in vm.qsAddons() && !n.contains("aio", ignoreCase = true) }.toSet().ifEmpty { names.filter { !it.contains("aio", true) }.toSet() })
    }
    var msg by remember { mutableStateOf<String?>(null) }
    var reports by remember { mutableStateOf<List<FailReport>?>(null) }
    // The screen stays on while testing.
    val view = LocalView.current
    DisposableEffect(running) { view.keepScreenOn = running; onDispose { view.keepScreenOn = false } }
    // Leaving this screen while the player is shown: keep testing off-screen.
    DisposableEffect(Unit) { onDispose { SourceTester.showPlayer.value = false } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 60.dp)) {
        PageHeader("Source Test", onBack)
        Text("Picks 2 random movies and 2 random series (Hindi / English, any year), plays every link of the chosen addons until its first picture (max 20 s each), ranks the providers per quality and language, and writes a full log.",
            Modifier.padding(horizontal = 20.dp), fontSize = 13.sp, color = Muted)

        SectionLabel("Addons to test")
        SettingsCard {
            Column(Modifier.padding(16.dp)) {
                names.chunked(2).forEach { row ->
                    Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { n ->
                            val on = n in chosen
                            Text(n, Modifier.clip(RoundedCornerShape(14.dp)).background(if (on) Color(0xFF2E2E36) else Color.Transparent)
                                .border(1.dp, if (on) Accent else Color(0x33FFFFFF), RoundedCornerShape(14.dp))
                                .clickable(enabled = !running) { chosen = if (on) chosen - n else chosen + n }.padding(horizontal = 14.dp, vertical = 9.dp),
                                fontSize = 14.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal, maxLines = 1)
                        }
                    }
                }
                if (names.isEmpty()) Text("No stream addons are on.", fontSize = 14.sp, color = Muted)
            }
        }

        SectionLabel("Run")
        SettingsCard {
            Column(Modifier.padding(16.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(false to "Run in background", true to "Show player").forEach { (v, label) ->
                        val on = show == v
                        Text(label, Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(if (on) Color(0xFF2E2E36) else Color.Transparent)
                            .border(1.dp, if (on) Accent else Color(0x33FFFFFF), RoundedCornerShape(14.dp))
                            .clickable { SourceTester.showPlayer.value = v }.padding(vertical = 11.dp),
                            fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
                Text("Both use the phone's real player and hardware decoder. Keep StreamX open while it runs (the screen stays on).",
                    Modifier.padding(top = 8.dp), fontSize = 12.sp, color = Muted)
                Spacer(Modifier.height(12.dp))
                Text(if (running) "Stop test" else "Start test",
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(if (running) Color(0xFF3A2228) else BrandRed)
                        .clickable(enabled = running || chosen.isNotEmpty()) { if (running) SourceTester.stop() else SourceTester.start(vm, ctx, chosen) }
                        .padding(vertical = 14.dp),
                    fontSize = 16.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                if (step.isNotEmpty()) {
                    Text(step, Modifier.padding(top = 12.dp), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    if (total > 0) LinearProgressIndicator(progress = { done.toFloat() / total }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), color = Accent)
                    if (line.isNotEmpty()) Text(line, Modifier.padding(top = 6.dp), fontSize = 12.sp, color = Color(0xFFC9CED9), maxLines = 2)
                }
            }
        }

        // The test player (shown mode): each link opens here, plays to its first picture, and closes.
        if (show && running) {
            Box(Modifier.padding(16.dp).fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(16.dp)).background(Color.Black)) {
                AndroidView(
                    factory = { c -> PlayerView(c).apply { useController = false } },
                    update = { v -> if (v.player !== testPlayer) v.player = testPlayer },
                    modifier = Modifier.fillMaxSize(),
                    onRelease = { v -> v.player = null },
                )
                Text(line, Modifier.align(Alignment.BottomStart).padding(10.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xB3000000))
                    .padding(horizontal = 8.dp, vertical = 4.dp), fontSize = 12.sp, color = Color.White, maxLines = 2)
            }
        }

        if (results.isNotEmpty()) {
            SectionLabel("Results so far")
            SettingsCard {
                Column(Modifier.padding(16.dp)) {
                    val ok = results.count { it.ok }
                    Text("$ok of ${results.size} links played", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    listOf("4k" to "4K", "fhd" to "Full HD", "mhd" to "Mid HD", "low" to "Low").forEach { (b, label) ->
                        val inB = results.filter { it.bucket == b }
                        if (inB.isNotEmpty()) {
                            Text("$label · ${inB.count { it.ok }}/${inB.size} played", Modifier.padding(top = 10.dp), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB6BDCC))
                            inB.groupBy { it.key }.map { (k, l) ->
                                val times = l.mapNotNull { it.firstFrameMs }.sorted()
                                Triple(k, l, if (times.isEmpty()) null else times[times.size / 2])
                            }.sortedWith(compareBy({ -(it.second.count { r -> r.ok }.toFloat() / it.second.size) }, { it.third ?: Long.MAX_VALUE })).take(8).forEach { (k, l, med) ->
                                Text("${Ranker.labelOf(k)} · ${l.count { it.ok }}/${l.size}" + (med?.let { " · ${"%.1f".format(it / 1000f)} s" } ?: "") +
                                    (if (l.any { !it.seekable }) " · not seekable" else ""), Modifier.padding(top = 3.dp), fontSize = 12.sp, color = Color(0xFFD5D8DF), fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }

        SectionLabel("Log & ranking")
        SettingsCard {
            Column(Modifier.padding(16.dp)) {
                val f = logFile
                Text(if (f != null) "Log: ${f.name}" else "The log is ready when a test finishes (or is stopped).", fontSize = 13.sp, color = Muted)
                if (f != null) Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallBtn("Save to Downloads") { msg = SourceTester.saveToDownloads(ctx, f) ?: "Saved to Downloads: ${f.name}" }
                    SmallBtn("Share log") { SourceTester.shareLog(ctx, f) }
                }
                val rf = Ranker.file
                Text(if (rf.entries.isEmpty()) "No ranking in use yet." else "Ranking in use: ${rf.entries.size} groups · ${SimpleDateFormat("dd MMM HH:mm", Locale.US).format(Date(rf.at))}" +
                    (if (rf.author.isNotBlank()) " · by ${rf.author}" else ""), Modifier.padding(top = 14.dp), fontSize = 13.sp)
                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallBtn("Upload ranking for everyone") { scope.launch { msg = Ranker.upload() ?: "Uploaded — every StreamX user gets this ranking." } }
                    SmallBtn("Reload shared") { scope.launch { msg = if (Ranker.fetchShared()) "Shared ranking checked." else "Couldn't read the shared ranking." } }
                }
                msg?.let { Text(it, Modifier.padding(top = 8.dp), fontSize = 13.sp, color = Color(0xFF7CD992)) }
            }
        }

        SectionLabel("Under observation")
        SettingsCard {
            Column(Modifier.padding(16.dp)) {
                Text("Provider groups that failed twice in a row while watching. They're tried last until the next Source Test re-tests them.",
                    fontSize = 13.sp, color = Muted)
                val local = Ranker.observed.toList()
                if (local.isEmpty()) Text("None on this phone.", Modifier.padding(top = 8.dp), fontSize = 13.sp)
                local.forEach { Text("• ${Ranker.labelOf(it)}", Modifier.padding(top = 4.dp), fontSize = 12.sp, fontFamily = FontFamily.Monospace) }
                Row(Modifier.padding(top = 10.dp)) {
                    SmallBtn("Load reports from all users") { scope.launch { val (l, e) = Ranker.allReports(); reports = l; if (e != null) msg = e } }
                }
                reports?.let { l ->
                    if (l.isEmpty()) Text("No reports.", Modifier.padding(top = 8.dp), fontSize = 13.sp)
                    l.take(30).forEach { r ->
                        Text("• ${r.label} · ${r.count} fails · ${r.device} · ${r.reason}", Modifier.padding(top = 4.dp), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

@Composable
private fun SmallBtn(text: String, onClick: () -> Unit) {
    Text(text, Modifier.clip(RoundedCornerShape(18.dp)).background(Color(0x1FFFFFFF)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 9.dp),
        fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
}

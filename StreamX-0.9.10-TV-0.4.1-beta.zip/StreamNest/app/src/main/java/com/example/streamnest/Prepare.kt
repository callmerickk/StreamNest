package com.example.streamnest

import android.content.Context
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/** What the title page has prepared for instant play. */
data class Prepared(
    val key: String,
    /** Short status shown under the Play button. */
    val status: String,
    val progress: Float = 0f,
    /** Saved enough: Play starts straight from storage. */
    val ready: Boolean = false,
    /** Nothing could be prepared: Play uses the normal search. */
    val failed: Boolean = false,
    val item: StreamItem? = null,
    val list: List<StreamItem> = emptyList(),
    val subs: List<Subtitle> = emptyList(),
    /** Bytes saved so far and the target. */
    val saved: Long = 0, val target: Long = 0,
)

/**
 * Instant play: as soon as a title page opens, the streams are found, the best link (your quality group → language →
 * Source Test ranking) is checked, and its first minute — or the minute from your resume point — is saved to storage.
 * Play then starts from storage like a file on a hard disk. If a link refuses, the next one is tried.
 */
object Prepare {
    val state = MutableStateFlow<Prepared?>(null)
    private var job: Job? = null
    private var saveJob: Job? = null
    private var lastResume = 0L
    private var preparedAt = 0L

    fun start(vm: AppViewModel, ctx: Context, type: String, id: String, resumeMs: Long, durMs: Long?, quick: Boolean, level: String) {
        val cur = state.value
        // Same title, same resume point (within 30 s), prepared or still preparing: keep it.
        val sameSpot = kotlin.math.abs(resumeMs - lastResume) < 30_000 && System.currentTimeMillis() - preparedAt < 15 * 60_000L
        if (cur != null && cur.key == id && sameSpot && !cur.failed && (job?.isActive == true || cur.ready)) return
        cancel()
        lastResume = resumeMs
        preparedAt = System.currentTimeMillis()
        state.value = Prepared(id, "Finding streams…")
        job = vm.viewModelScope.launch {
            val list = runCatching { if (quick) vm.quickStreams(type, id) else vm.allStreams(type, id) }.getOrDefault(emptyList())
            if (list.isEmpty()) { state.value = Prepared(id, "No streams found — Play will search again", failed = true); return@launch }
            val cands = vm.rankedCandidates(list, level, quickOnly = quick).take(5)
            if (cands.isEmpty()) { state.value = Prepared(id, "No Quick Start link in this quality", failed = true, list = list); return@launch }
            val subs = withTimeoutOrNull(2500) { runCatching { vm.subtitles(type, id) }.getOrDefault(emptyList()) }.orEmpty()
            var lastWhy = ""
            for ((i, s) in cands.withIndex()) {
                val url = s.stream.url ?: continue
                val label = "${Ranker.labelOf(Ranker.groupKey(s)).substringAfter(" · ", "")} · ${qualityName(s.resolution())}"
                state.value = Prepared(id, "Checking ${i + 1}/${cands.size} · $label", list = list, subs = subs)
                StreamCache.register(s)
                // Playlists (HLS / DASH) stream in small pieces: nothing to save, they start fast.
                val mime = if (StreamType.needsProbe(url, s.stream.behaviorHints?.filename))
                    withContext(Dispatchers.IO) { StreamType.probe(url) }.takeIf { it.isNotEmpty() } else StreamType.mimeFor(url, s.stream.behaviorHints?.filename)
                if (mime != null) {
                    state.value = Prepared(id, "Ready · streaming playlist · $label", 1f, ready = true, item = s, list = list, subs = subs)
                    return@launch
                }
                val pr = StreamCache.probe(url)
                if (!pr.ok) { lastWhy = pr.error ?: "HTTP ${pr.status}"; Ranker.recordFail(s, "prepare: $lastWhy"); continue }
                if (!pr.seekable) { lastWhy = "file can't be jumped inside (not seekable)"; continue }
                // One minute from the start (or from your resume point); very big files: ~15 seconds.
                val perMin = minuteBytes(s, pr.size, durMs)
                val big = perMin > 150L * 1024 * 1024
                val want = if (big) perMin / 4 else perMin
                val startByte = if (resumeMs > 5_000 && pr.size > 0 && durMs != null && durMs > 0)
                    ((pr.size.toDouble() * resumeMs / durMs).toLong() - 2L * 1024 * 1024).coerceAtLeast(0L) / (1024 * 1024) * (1024 * 1024)
                else 0L
                val len = if (pr.size > 0) minOf(want, pr.size - startByte) else want
                val minStart = if (big) want else want / 4 // enough to start without waiting
                state.value = Prepared(id, "Saving ${if (big) "15 s" else "1:00"} · $label", 0f, item = s, list = list, subs = subs, target = len)
                val err = run {
                    // Many files keep their index at the end (MP4 "moov", MKV "cues" for jumping to your resume point):
                    // save the end too, so the player never has to fetch it before starting.
                    if (pr.size > 40L * 1024 * 1024) {
                        val mp4 = url.contains(".mp4", true) || s.stream.behaviorHints?.filename?.endsWith(".mp4", true) == true
                        val tail = if (mp4) minOf(24L * 1024 * 1024, pr.size / 60) else minOf(8L * 1024 * 1024, pr.size / 200)
                        StreamCache.save(ctx, url, pr.size - tail, tail) { }
                    }
                    StreamCache.save(ctx, url, startByte, len) { f ->
                        val done = (len * f).toLong()
                        state.value = Prepared(id, if (done >= minStart) "Ready · saving more ${(f * 100).toInt()}% · $label" else "Saving ${(f * 100).toInt()}% · $label",
                            f, ready = done >= minStart, item = s, list = list, subs = subs, saved = done, target = len)
                    }
                }
                if (err == null) {
                    state.value = Prepared(id, "⚡ Ready to play instantly · ${if (big) "15 s" else "1:00"} saved · $label", 1f, ready = true,
                        item = s, list = list, subs = subs, saved = len, target = len)
                    return@launch
                }
                // Saving failed half-way: still fine to play if enough is saved.
                val now = state.value
                if (now != null && now.ready) { state.value = now.copy(status = "Ready · ${(now.progress * 100).toInt()}% saved · $label"); return@launch }
                lastWhy = err
            }
            state.value = Prepared(id, "Couldn't prepare (${lastWhy.ifBlank { "no link answered" }}) — Play will search again", failed = true, list = list, subs = subs)
        }
    }

    /** Stop downloading (Play was pressed — the player takes over; what was saved stays saved). */
    fun stopSaving() { job?.cancel(); job = null }

    fun cancel() { job?.cancel(); job = null; saveJob?.cancel(); saveJob = null }

    fun qualityName(res: Int): String = when { res >= 1440 -> "4K"; res >= 1080 -> "1080p"; res >= 720 -> "720p"; res > 0 -> "${res}p"; else -> "SD" }

    /**
     * While a video plays: save one minute (from the current point) of the top-ranked links in the other quality groups,
     * so switching quality starts almost at once. Runs one link at a time.
     */
    fun saveOthers(vm: AppViewModel, ctx: Context, list: List<StreamItem>, playingUrl: String, posMs: Long, durMs: Long) {
        saveJob?.cancel()
        saveJob = vm.viewModelScope.launch {
            val playing = list.firstOrNull { it.stream.url == playingUrl }
            val levels = listOf("4k", "fhd", "mhd").filter { lv -> playing == null || Ranker.tier(playing.resolution()) != Ranker.tier(AllQualityLevels.first { it.id == lv }.res) }
            for (lv in levels) {
                val s = vm.rankedCandidates(list, lv, quickOnly = true).firstOrNull { it.stream.url != playingUrl &&
                    Ranker.tier(it.resolution()) == Ranker.tier(AllQualityLevels.first { q -> q.id == lv }.res) } ?: continue
                val url = s.stream.url ?: continue
                if (isPlaylistLink(s, url)) continue
                StreamCache.register(s)
                val pr = StreamCache.probe(url)
                if (!pr.ok || !pr.seekable || pr.size <= 0) continue
                val perMin = minuteBytes(s, pr.size, durMs)
                val start = ((pr.size.toDouble() * posMs / durMs.coerceAtLeast(1)).toLong() - 1024 * 1024).coerceAtLeast(0L) / (1024 * 1024) * (1024 * 1024)
                StreamCache.save(ctx, url, start, minOf(perMin, pr.size - start)) { }
            }
        }
    }

    fun stopOthers() { saveJob?.cancel(); saveJob = null }
}

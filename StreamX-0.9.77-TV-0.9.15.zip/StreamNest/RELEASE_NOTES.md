StreamX 0.9.77

• No more crashes while browsing titles quickly (lighter title pages, fewer searches at once).
• Download pressed twice no longer starts twice.

---

StreamX TV 0.9.15 

• Back on Home no longer freezes or closes the app.
• The first open after an update stays open.
• Posters load once at start (no more reloading).
• Home appears at once and refreshes quietly.

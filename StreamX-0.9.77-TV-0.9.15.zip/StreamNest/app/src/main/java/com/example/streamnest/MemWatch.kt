package com.example.streamnest

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * 0.9.77: app-wide memory lines. For 60 s after every screen change, every 5 s:
 * "memory · <screen> · app X / Y MB · native · players · downloads · searches". When the app's own memory passes 75 %,
 * the extras are let go: the title page's paused player, the pictures kept in memory, and source answers for other
 * titles. Phones only.
 */
object MemWatch {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    @Volatile private var lastRelief = 0L
    @Volatile var currentId: String? = null

    fun onScreen(ctx: Context, screen: String) {
        if (BuildConfig.IS_TV) return
        val app = ctx.applicationContext
        job?.cancel()
        job = scope.launch {
            repeat(12) {
                delay(5_000)
                val rt = Runtime.getRuntime()
                val used = (rt.totalMemory() - rt.freeMemory()) / 1_048_576
                val max = rt.maxMemory() / 1_048_576
                val native = android.os.Debug.getNativeHeapAllocatedSize() / 1_048_576
                ActLog.add("APP", "memory · $screen · app $used / $max MB · native $native MB · players ${PlayerCount.alive()}" +
                    " · downloads ${runCatching { DlEngine.running() }.getOrDefault(0)} · searches ${PluginSources.running()}")
                if (used.toDouble() / max > 0.75) relieve(app, "$used / $max MB")
            }
        }
    }

    /** Over 75 %: free what can be made again later. At most every 10 s. */
    fun relieve(ctx: Context, why: String) {
        val now = System.currentTimeMillis()
        if (now - lastRelief < 10_000) return
        lastRelief = now
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            runCatching { Preloader.release() }
            runCatching { coil.Coil.imageLoader(ctx).memoryCache?.clear() }
            runCatching { PluginSources.trimExcept(currentId) }
            ActLog.add("APP", "memory high ($why) — let go of the paused player, pictures in memory and other titles' source answers")
        }
    }
}

StreamX 0.9.9 · StreamX TV 0.4 beta

• Choose your experience on first start: Elite (loads ahead, switches quality by itself) or Regular, plus a short guide.
• Settings › Playback › Streaming mode, with "Elite only on Wi-Fi".
• New Hotstar-style player: clock and "Ends at", Next Episode · Audio & Subtitles · Episodes · Watch Next · More.
• Audio & Subtitles in three columns; online subtitles in your languages (English by default).
• 4K quality option when a 2160p file exists; Elite auto quality switches at the same second.
• Elite: next episode found at 60% and pre-loaded at 75%; TV title page pre-loads the first minute.
• Continue Watching badges (time left / next episode / new episode in N days).
• Faster search with recent searches; new-episode notifications.
• Earbud play-pause, better seek previews, animated avatars sync from links.
• In-app updates.

StreamX 0.9.79

• Lighter, just as fast: nothing is downloaded ahead for Upgrade until you tap it.
• Quality sheet: your pick is ticked and shown on the button.
• Home looks up links only for what you're about to watch.
• Quieter start, fewer animations, lighter logs (Detailed logs in Developer's Corner).

---

StreamX TV 0.9.15 

• Back on Home no longer freezes or closes the app.
• The first open after an update stays open.
• Posters load once at start (no more reloading).
• Home appears at once and refreshes quietly.

package com.example.streamnest

import android.annotation.SuppressLint
import android.graphics.Color as AColor
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView

/**
 * A muted, control-less YouTube trailer that fills (crops into) its box, using YouTube's official IFrame player
 * inside a WebView. The page identifies the app as its origin/referrer, which YouTube now requires
 * (otherwise embeds fail with error 152/153). Some uploaders block embedding; then onError is called.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun TrailerVideo(
    videoId: String,
    muted: Boolean,
    modifier: Modifier = Modifier,
    onPlaying: () -> Unit,
    onEnded: () -> Unit,
    onError: () -> Unit,
) {
    var web by remember { mutableStateOf<WebView?>(null) }
    val cbPlaying by rememberUpdatedState(onPlaying)
    val cbEnded by rememberUpdatedState(onEnded)
    val cbFailed by rememberUpdatedState(onError)
    val main = remember { Handler(Looper.getMainLooper()) }

    BoxWithConstraints(modifier) {
        // 16:9 video scaled to cover the card (the card itself is taller than 16:9).
        val h = maxHeight
        val w = maxOf(maxWidth, h * 16f / 9f)
        AndroidView(
            factory = { c ->
                WebView(c).apply {
                    setBackgroundColor(AColor.BLACK)
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.mediaPlaybackRequiresUserGesture = false
                    isVerticalScrollBarEnabled = false
                    isHorizontalScrollBarEnabled = false
                    webChromeClient = WebChromeClient()
                    webViewClient = WebViewClient()
                    addJavascriptInterface(object {
                        @JavascriptInterface fun playing() { main.post { cbPlaying() } }
                        @JavascriptInterface fun ended() { main.post { cbEnded() } }
                        @JavascriptInterface fun error(code: Int) { main.post { cbFailed() } }
                    }, "Android")
                    val origin = "https://${c.packageName}"
                    loadDataWithBaseURL("$origin/", trailerHtml(videoId, origin), "text/html", "utf-8", null)
                    web = this
                }
            },
            modifier = Modifier.requiredSize(w, maxOf(h, w * 9f / 16f)).align(Alignment.Center),
        )
    }
    LaunchedEffect(muted, web) { web?.evaluateJavascript("setMuted(${if (muted) "true" else "false"})", null) }
    DisposableEffect(Unit) {
        onDispose {
            runCatching { web?.stopLoading(); web?.loadUrl("about:blank"); web?.removeJavascriptInterface("Android"); web?.destroy() }
        }
    }
}

private fun trailerHtml(id: String, origin: String) = """
<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<style>html,body{margin:0;padding:0;background:#000;height:100%;overflow:hidden}#p{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none}</style>
</head><body><div id="p"></div>
<script src="https://www.youtube.com/iframe_api"></script>
<script>
var player=null;
function onYouTubeIframeAPIReady(){
  player=new YT.Player('p',{videoId:'$id',
    playerVars:{autoplay:1,mute:1,controls:0,rel:0,playsinline:1,modestbranding:1,iv_load_policy:3,fs:0,disablekb:1,cc_load_policy:0,origin:'$origin'},
    events:{
      onReady:function(e){e.target.mute();e.target.playVideo();},
      onStateChange:function(e){if(e.data==1)Android.playing();if(e.data==0)Android.ended();},
      onError:function(e){Android.error(e.data);}
    }});
}
function setMuted(m){if(player&&player.mute){if(m)player.mute();else player.unMute();}}
</script></body></html>
""".trimIndent()

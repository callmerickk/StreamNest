plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
}

android {
    namespace = "com.example.streamnest"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.streamnest"
        minSdk = 24
        targetSdk = 34
        versionCode = 12
        versionName = "0.9.2"
        // 64-bit ARM phones only: every phone from the last ~6 years. Keeps the VLC engine small.
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    // One fixed key for every build, so new APKs install over the old app without uninstalling.
    signingConfigs {
        create("fixed") {
            storeFile = file("streamnest.keystore")
            storePassword = "streamnest"
            keyAlias = "streamnest"
            keyPassword = "streamnest"
        }
    }
    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fixed")
            // Remove unused code and resources (mostly unused icons) so the APK stays small.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android.txt"), "proguard-rules.pro")
        }
        release {
            signingConfig = signingConfigs.getByName("fixed")
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging {
        // Keep one copy of the C++ runtime, and store native libraries compressed (much smaller APK).
        jniLibs {
            pickFirsts += listOf("**/libc++_shared.so")
            useLegacyPackaging = true
        }
    }
}

dependencies {
    val bom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(bom)
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")

    implementation("androidx.media3:media3-exoplayer:1.5.0")
    implementation("androidx.media3:media3-exoplayer-hls:1.5.0")
    implementation("androidx.media3:media3-exoplayer-dash:1.5.0")
    implementation("androidx.media3:media3-ui:1.5.0")

    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("io.coil-kt:coil-gif:2.7.0")
    implementation("io.coil-kt:coil-video:2.7.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:okhttp-dnsoverhttps:4.12.0")
    implementation("androidx.media3:media3-datasource-okhttp:1.5.0")
    // VLC engine (default): plays every format (MKV, HEVC, DTS, Dolby…). ExoPlayer stays as a small backup.
    implementation("org.videolan.android:libvlc-all:3.6.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.2")
}

package com.example.streamnest

import android.content.Context
import android.net.Uri
import android.os.SystemClock
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.datasource.cache.CacheWriter
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import androidx.media3.datasource.okhttp.OkHttpDataSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/** What a quick look at a link (first byte only) tells us. */
data class LinkProbe(
    val ok: Boolean, val status: Int, val ttfbMs: Long, val size: Long, val seekable: Boolean,
    val type: String?, val host: String?, val finalHost: String?, val error: String?,
)

/**
 * Saved video on the phone's storage (like a file on a hard disk): the player reads from here first and only asks the
 * server for what isn't saved. The title page saves the first minute (or the minute from your resume point) before you
 * press Play. Up to 2 GB; the oldest is removed first.
 *
 * Files are saved under a key made from their file name + size (not the link), so a refreshed link for the same file
 * still finds what was saved.
 */
@OptIn(UnstableApi::class)
object StreamCache {
    private const val MAX_BYTES = 2L * 1024 * 1024 * 1024
    @Volatile private var cache: SimpleCache? = null
    private val keys = ConcurrentHashMap<String, String>()

    fun get(ctx: Context): SimpleCache = cache ?: synchronized(this) {
        cache ?: SimpleCache(File(ctx.applicationContext.cacheDir, "vcache"), LeastRecentlyUsedCacheEvictor(MAX_BYTES),
            StandaloneDatabaseProvider(ctx.applicationContext)).also { cache = it }
    }

    /** Remembers the stable key of a link (file name + size when the addon gives them). */
    fun register(item: StreamItem) {
        val url = item.stream.url ?: return
        val f = item.stream.behaviorHints?.filename?.trim()?.lowercase()
        val size = item.stream.behaviorHints?.videoSize
        if (!f.isNullOrEmpty() && size != null && size > 0) keys[url] = "f:$f:$size"
    }

    fun keyFor(uri: Uri): String = keys[uri.toString()] ?: uri.toString()

    /** Player data source: saved video first, then the network. */
    fun factory(ctx: Context, upstream: DataSource.Factory): DataSource.Factory =
        CacheDataSource.Factory()
            .setCache(get(ctx))
            .setUpstreamDataSourceFactory(upstream)
            .setCacheKeyFactory { spec -> keyFor(spec.uri) }
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)

    private fun writerSource(ctx: Context): CacheDataSource {
        val http = OkHttpDataSource.Factory(Api.http).setUserAgent(PlayerUserAgent)
        val up = DefaultDataSource.Factory(ctx, withStreamHeaders(http))
        return CacheDataSource.Factory().setCache(get(ctx)).setUpstreamDataSourceFactory(up)
            .setCacheKeyFactory { spec -> keyFor(spec.uri) }.createDataSource()
    }

    /** Bytes of this link already saved from [start] on (continuous). */
    fun savedBytes(ctx: Context, url: String, start: Long, length: Long): Long =
        runCatching { get(ctx).getCachedBytes(keyFor(Uri.parse(url)), start, length) }.getOrDefault(0L)

    /**
     * Saves [length] bytes of the link from byte [start]. [onProgress] gets 0..1. Returns null when it worked, else why not.
     * Cancelling the coroutine stops it (what was saved stays saved).
     */
    suspend fun save(ctx: Context, url: String, start: Long, length: Long, onProgress: (Float) -> Unit): String? = withContext(Dispatchers.IO) {
        val src = writerSource(ctx)
        val spec = DataSpec.Builder().setUri(Uri.parse(url)).setPosition(start).setLength(length).setKey(keyFor(Uri.parse(url))).build()
        val w = CacheWriter(src, spec, null) { req, cached, _ -> if (req > 0) onProgress((cached.toFloat() / req).coerceIn(0f, 1f)) }
        try {
            coroutineScope {
                val watcher = launch { try { awaitCancellation() } finally { w.cancel() } }
                try { runInterruptible { w.cache() } } finally { watcher.cancel() }
            }
            null
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Throwable) {
            e.javaClass.simpleName + (e.message?.let { ": " + it.take(120) } ?: "")
        }
    }

    /** One quick request for the first byte: is the server answering, how fast, how big, and can we jump inside the file? */
    suspend fun probe(url: String): LinkProbe = withContext(Dispatchers.IO) {
        val host = runCatching { Uri.parse(url).host }.getOrNull()
        if (!url.startsWith("http")) return@withContext LinkProbe(false, 0, 0, -1, false, null, host, host, "not a web link")
        val t0 = SystemClock.elapsedRealtime()
        try {
            val b = Request.Builder().url(url).header("Range", "bytes=0-0")
            val h = StreamHeaders.forUrl(url)
            h.forEach { (k, v) -> b.header(k, v) }
            if (h.keys.none { it.equals("User-Agent", true) }) b.header("User-Agent", PlayerUserAgent)
            Api.http.newCall(b.build()).execute().use { r ->
                val ms = SystemClock.elapsedRealtime() - t0
                val range = r.header("Content-Range")
                val size = range?.substringAfter('/')?.trim()?.toLongOrNull() ?: r.header("Content-Length")?.toLongOrNull()?.takeIf { r.code == 200 } ?: -1L
                val seekable = r.code == 206 || r.header("Accept-Ranges")?.contains("bytes", true) == true
                val ct = r.header("Content-Type")?.lowercase().orEmpty()
                // A web page instead of a video (link-page hosts): not playable.
                if (r.isSuccessful && ct.startsWith("text/html")) {
                    return@use LinkProbe(false, r.code, ms, size, false, ct, host, r.request.url.host, "web page, not a video")
                }
                // The server already says what the file is: the player needs no extra "what type is it?" request.
                if (r.isSuccessful) when {
                    "dash" in ct -> StreamType.remember(url, StreamType.DASH)
                    "mpegurl" in ct -> StreamType.remember(url, StreamType.HLS)
                    ct.startsWith("video/") || ct.startsWith("audio/") -> StreamType.remember(url, "")
                    ct.contains("octet-stream") && size > 20L * 1024 * 1024 -> StreamType.remember(url, "")
                }
                LinkProbe(r.isSuccessful, r.code, ms, size, seekable, r.header("Content-Type"), host, r.request.url.host,
                    if (r.isSuccessful) null else "HTTP ${r.code}")
            }
        } catch (e: Throwable) {
            LinkProbe(false, 0, SystemClock.elapsedRealtime() - t0, -1, false, null, host, host, e.javaClass.simpleName + (e.message?.let { ": " + it.take(100) } ?: ""))
        }
    }
}

/** "2h 10min" / "130 min" / "45m" → milliseconds (null when unknown). */
fun runtimeMs(runtime: String?): Long? {
    val t = runtime?.lowercase() ?: return null
    val h = Regex("(\\d+)\\s*h").find(t)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
    val m = Regex("(\\d+)\\s*m").find(t)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
    val total = h * 60 + m
    return if (total > 0) total * 60_000L else null
}

/**
 * How many bytes one minute of this file is, roughly: from its size and length when known, else from its quality.
 * [bigFile] = more than ~150 MB a minute (then only ~15 s are saved).
 */
fun minuteBytes(item: StreamItem?, size: Long, durMs: Long?): Long {
    if (size > 0 && durMs != null && durMs > 10 * 60_000L) return (size.toDouble() * 60_000.0 / durMs * 1.15).toLong()
    val res = item?.resolution() ?: 0
    val mbps = when { res >= 1440 -> 25.0; res >= 1080 -> 8.0; res >= 720 -> 4.0; else -> 5.0 }
    return (mbps * 1_000_000 / 8 * 60).toLong()
}

/** Is this link a playlist (HLS / DASH)? Those stream in small pieces and start fast; nothing to pre-save. */
fun isPlaylistLink(item: StreamItem?, url: String): Boolean =
    StreamType.mimeFor(url, item?.stream?.behaviorHints?.filename) != null

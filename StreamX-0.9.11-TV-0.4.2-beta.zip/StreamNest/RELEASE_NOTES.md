StreamX 0.9.11 · StreamX TV 0.4.2 beta

• Status light on the Play button (green = instant, amber = normal, red = no stream; long-press for details).
• Dead links (web pages, not found, expired signed links) hidden from Sources.
• Faster starts: no second "file type" request when the server already said it.
• Source Test: popular titles only, 429 retried and not counted, results add up across runs.
• Phone: home card trailers bigger/centred, sound on by default.
• TV: no automatic trailers; keyboard opens only on OK.
• Animated profile pictures stay animated on other devices.

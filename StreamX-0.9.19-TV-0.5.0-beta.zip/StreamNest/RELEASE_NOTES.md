StreamX 0.9.19 · StreamX TV 0.5.0 beta

• Trailer mode: one round through every card's trailer, screen kept on, turns itself off; animated notes.
• Brighter card trailers without YouTube's title bar; animated backdrop instead of black.
• Top cards: picks for you and new arrivals mixed in.
• New player engine (Media3 1.7) with FFmpeg audio + video decoders (NextLib).
• DNS status light in Network & DNS.
• X (AI): greets you every time, your chosen voice, spinning logo.

---

StreamX 0.9.18 · StreamX TV 0.4.9 beta

• Quick start + Upgrade to 4K: MovieBox starts at once, a sharper file is saved silently, one tap upgrades.
• Watch together: Share / Invite (link copied), remembered friends, 🔔 ring to call them in.
• Subtitle auto sync for online subtitles.
• Home source kept ready for instant starts.
• Addons: Configure button and pinning (Cinemeta and OpenSubtitles always on top).

---

StreamX 0.9.17 · StreamX TV 0.4.8 beta

• New Audio & Subtitles: bubble from its button, ticks and ⓘ details, subtitle stacks, online subtitles without reloading, timing and size sliders.
• MovieBox: all languages together and saved ahead; no-language files = original audio; .mpd playlists first.
• Wrong-title links skipped (Dune vs Dune: Prophecy); real quality from file names.
• Age guide and the real picture size when a video starts.
• Switching capsule with a progress ring; controls fixes.
• Memory-sized buffers; faster seeking.
• Update pop-up at app start; Hotstar-style card glide; card trailers fixed.

---

StreamX 0.9.16 · StreamX TV 0.4.7 beta

• Links race on real video; a backup link is saved quietly for instant switching.
• Servers ranked by your real plays: failing servers (FSL) go last; pixeldrain gets more time.
• One refusal = that server goes last for this play; no repeated tries; fewer VLC detours.
• MovieBox: Hindi → English → Original audio before quality; playlists count as seekable; one server for all dubs.
• Quality worked out for links that don't name it.
• Card trailers show the whole video (no zoom).
• Logs: which addons answered; server results from real plays.

---

StreamX 0.9.15 · StreamX TV 0.4.6 beta

• Fast start: Play opens the player at once; the best 3 links race; links already found are reused.
• Parallel download (IDM-style pieces) for faster starts and smoother 4K.
• Shared-server header fix (VA Player, MovieBox, pengu.uk); addon cookies kept.
• Green light = paused player really ready; broken paused player replaced; smarter stall switch; no VLC on refused links.
• Player: flat play/pause, tap-to-hide fixed, new button order with depth, Watch together icon, Sound in Audio & Subtitles.
• First-time visual tour; Plugins section; fingerprint for Developer's Corner; screen awake during Source Test.
• Card trailer placement reworked with an automatic black-screen fallback.

---

StreamX 0.9.14 · StreamX TV 0.4.5 beta

• User manual in Settings: every feature explained, searchable.
• Watch together: rooms with a 4-letter code, synced play/pause/seek, reactions.
• Downloads for offline viewing (title page › ⋯ › Download; My Space › Downloads).
• Home screen widget: Continue watching with Resume.
• GIF search for profile pictures (GIPHY key in Integrations).
• Search: moods and Surprise me.

---

StreamX 0.9.13 · StreamX TV 0.4.4 beta

• Faster green light: links checked as soon as fast addons answer; paused player ready after ~15 s saved.
• Dolby Vision plays on phones without a DV decoder (HDR base layer, like Nuvio).
• Browser-like cookies: MovieBox / VA Player links should now play.
• Stuck links switched after 8–10 s; refused links skip VLC and go to the next source.
• Tested sources only: failing groups and dead servers hidden. CNCVerse refreshed every 2 s.
• Profile lock with PIN + fingerprint unlock (Developer's Corner).
• Player: centre play/pause, controls stay while touched, rounded fading button row, sleep timer, audio boost, night mode, picture-in-picture, auto-skip intro, next-episode ring.
• Animated hanging-X logo, smoother card sliding, tablet-friendly card size, trailer black-screen fix.
• AI: logo syncs across phones, voice picker + speed, no emoji read aloud.

---

StreamX 0.9.12 · StreamX TV 0.4.3 beta

• Green light = a paused player is already waiting: Play starts in under a second.
• Play timing log in Developer's Corner (each step of every Play press, with times).
• CNCVerse is asked again every 5 s until a video plays.
• Source Test: VA Player headers fixed; can auto-arrange addons and Quick Start.
• Backup search skips failed links, follows the ranking, avoids REMUX/TrueHD; Dolby Vision-only files last on phones without DV.
• Home card trailers centred.
• Update pop-up on every start: Update now / Later / Skip this version.

---

StreamX 0.9.11 · StreamX TV 0.4.2 beta

• Status light on the Play button (green = instant, amber = normal, red = no stream; long-press for details).
• Dead links (web pages, not found, expired signed links) hidden from Sources.
• Faster starts: no second "file type" request when the server already said it.
• Source Test: popular titles only, 429 retried and not counted, results add up across runs.
• Phone: home card trailers bigger/centred, sound on by default.
• TV: no automatic trailers; keyboard opens only on OK.
• Animated profile pictures stay animated on other devices.

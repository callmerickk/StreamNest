package com.example.streamnest

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import coil.compose.AsyncImage
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** What the big Play button will do. */
private data class PlayTarget(val target: SourceTarget, val label: String, val resumeMs: Long, val frac: Float)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DetailScreen(vm: AppViewModel, meta0: Meta, onBack: () -> Unit, onOpen: (Meta) -> Unit = {}, sourcesFor: String? = null, onPlay: (Screen.Player) -> Unit) {
    var meta by remember { mutableStateOf(meta0) }
    LaunchedEffect(meta0.id) { vm.fullMeta(meta0)?.let { meta = it } }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val progress by vm.progress.collectAsStateWithLifecycle()
    val done by vm.doneKeys.collectAsStateWithLifecycle()
    val myList by vm.myList.collectAsStateWithLifecycle()
    val texts by vm.texts.collectAsStateWithLifecycle()
    val imdb = meta.id.substringBefore(":")

    var art by remember(imdb) { mutableStateOf<Art?>(null) }
    var tm by remember(imdb) { mutableStateOf<TmdbInfo?>(null) }
    LaunchedEffect(imdb) { tm = vm.tmdbInfo(imdb, meta.type) }
    var ratings by remember(imdb) { mutableStateOf<List<Rating>>(emptyList()) }
    var more by remember(imdb) { mutableStateOf<List<Meta>>(emptyList()) }
    var trailer by remember(imdb) { mutableStateOf<String?>(null) }
    LaunchedEffect(imdb) { art = vm.tmdbArt(imdb, meta.type) }
    LaunchedEffect(imdb) { ratings = vm.mdbRatings(imdb) }
    LaunchedEffect(imdb) { trailer = runCatching { vm.trailerId(meta) }.getOrNull() }
    LaunchedEffect(imdb, meta.genres) {
        val g = meta.genres.orEmpty().take(2)
        if (g.isNotEmpty() && isOn(texts["detailMore"] ?: "yes")) more = runCatching { vm.genreTitles(g, listOf(meta.type)) }.getOrDefault(emptyList()).filter { it.id != meta.id }.take(20)
    }

    var pick by remember { mutableStateOf<SourceTarget?>(null) }
    var actions by remember { mutableStateOf(false) }
    var openedSources by remember { mutableStateOf(false) }
    val subsJob = remember(pick?.videoId) { pick?.let { pk -> scope.async { runCatching { vm.subtitles(meta.type, pk.videoId) }.getOrDefault(emptyList()) } } }

    val episodes = remember(meta) { meta.videos.orEmpty().filter { it.season != null && it.episode != null }.sortedWith(compareBy({ it.season }, { it.episode })) }
    val seasons = remember(episodes) { episodes.mapNotNull { it.season }.distinct().sorted().let { s -> s.filter { it > 0 } + s.filter { it == 0 } } }

    val autoMode = t("autoPlayMode")
    val external = t("playerChoice") == "external"
    val quick = vm.qsActive()
    fun resumeFor(vid: String): Long = progress.firstOrNull { it.key == vid }
        ?.takeIf { it.durationMs <= 0 || it.positionMs < it.durationMs * 0.95 }?.positionMs ?: 0L
    fun target(ep: Video) = SourceTarget(ep.id, "${meta.name}  S${ep.season}E${ep.episode}", "S${ep.season} E${ep.episode}", ep.title ?: ep.name, ep.thumbnail)

    // The big button: resume where you left off, or the next episode / start.
    val playTarget = remember(meta, progress, done, episodes) {
        if (episodes.isEmpty()) {
            val p = progress.firstOrNull { it.key == meta.id }
            val r = resumeFor(meta.id)
            PlayTarget(SourceTarget(meta.id, meta.name, null, null, null), if (r > 0) "Resume ${fmtTime(r)}" else "Play", r,
                if (p != null && p.durationMs > 0) (p.positionMs.toFloat() / p.durationMs).coerceIn(0f, 1f) else 0f)
        } else {
            val mine = progress.filter { it.key.startsWith(meta.id + ":") }.maxByOrNull { it.updated }
            val ep = mine?.let { m -> episodes.firstOrNull { it.id == m.key } }
                ?: episodes.lastOrNull { it.id in done }?.let { last -> episodes.getOrNull(episodes.indexOf(last) + 1) }
                ?: episodes.firstOrNull { (it.season ?: 0) > 0 } ?: episodes.first()
            val r = resumeFor(ep.id)
            val p = progress.firstOrNull { it.key == ep.id }
            PlayTarget(target(ep), (if (r > 0) "Resume" else "Play") + " S${ep.season} E${ep.episode}", r,
                if (p != null && p.durationMs > 0) (p.positionMs.toFloat() / p.durationMs).coerceIn(0f, 1f) else 0f)
        }
    }
    var season by remember(seasons, playTarget.target.videoId) {
        mutableIntStateOf(episodes.firstOrNull { it.id == playTarget.target.videoId }?.season ?: seasons.firstOrNull() ?: 1)
    }
    val shown = remember(episodes, season) { episodes.filter { it.season == season }.distinctBy { it.id } }

    // Quick Start: look up the fast addons as soon as the page opens, and (optionally) prepare the video in the background.
    LaunchedEffect(playTarget.target.videoId, quick) {
        // Not using Quick Start: still fetch every addon's streams now, so Play starts without "Finding stream source".
        if (!quick) { runCatching { vm.allStreams(meta.type, playTarget.target.videoId) }; return@LaunchedEffect }
        val id = playTarget.target.videoId
        val list = runCatching { vm.quickStreams(meta.type, id) }.getOrDefault(emptyList())
        if (external || list.isEmpty() || Preloader.has(id) || (texts["playerEngine"] ?: "vlc") != "exo") return@LaunchedEffect
        val mode = texts["qsPreload"] ?: "wifi"
        if (!(mode == "always" || (mode == "wifi" && isOnWifi(ctx)))) return@LaunchedEffect
        val level = vm.playerPref("quality").ifEmpty { texts["qsQuality"] ?: "auto" }
        val s = vm.pickQuick(list, level) ?: vm.pickQuick(list, "auto") ?: return@LaunchedEffect
        val extra = withTimeoutOrNull(1500) { runCatching { vm.subtitles(meta.type, id) }.getOrDefault(emptyList()) }.orEmpty()
        val subs = s.stream.subtitles.orEmpty() + extra
        val player = buildPlayer(ctx, vm, isOn(texts["fastStart"] ?: "yes"))
        player.setMediaItem(MediaItem.Builder().setUri(s.stream.url!!).setSubtitleConfigurations(subtitleConfigs(subs)).build(), playTarget.resumeMs)
        player.playWhenReady = false
        player.prepare()
        Preloader.set(Preloaded(id, s.stream.url!!, subs, s.stream.name ?: s.addonName, s.addonName, list, player))
    }
    val preKey by rememberUpdatedState(playTarget.target.videoId)
    DisposableEffect(Unit) { onDispose { Preloader.release(preKey) } }

    /** Play button / episode tap: Quick Start or auto modes go straight to the player, manual opens the sources page. */
    fun start(t: SourceTarget, forceSources: Boolean = false, fromStart: Boolean = false) {
        if (fromStart) {
            // Start from the beginning: drop any video prepared at the resume point and play from 0.
            Preloader.release(t.videoId)
            if (!forceSources) {
                onPlay(Screen.Player(t.title, "", emptyList(), key = t.videoId, image = t.image ?: meta.background ?: meta.poster,
                    resumeMs = 0L, type = meta.type, meta = meta, find = true, quick = quick))
                return
            }
        }
        when {
            forceSources -> pick = t
            quick && !external -> onPlay(Screen.Player(t.title, "", emptyList(), key = t.videoId, image = t.image ?: meta.background ?: meta.poster,
                resumeMs = resumeFor(t.videoId), type = meta.type, meta = meta, find = true, quick = true))
            quick && external -> scope.launch {
                val list = runCatching { vm.quickStreams(meta.type, t.videoId) }.getOrDefault(emptyList())
                val s = vm.pickQuick(list, texts["qsQuality"] ?: "auto")
                if (s != null) openExternal(ctx, s.stream.url!!, t.title) else pick = t
            }
            !external && autoMode != "manual" -> onPlay(Screen.Player(t.title, "", emptyList(), key = t.videoId, image = t.image ?: meta.background ?: meta.poster,
                resumeMs = resumeFor(t.videoId), type = meta.type, meta = meta, find = true))
            else -> pick = t
        }
    }

    fun play(s: StreamItem, all: List<StreamItem>, resume: Long) {
        val tg = pick ?: return
        scope.launch {
            val extra = withTimeoutOrNull(1500) { subsJob?.await() }.orEmpty()
            val subs = s.stream.subtitles.orEmpty() + extra
            pick = null
            if (external) openExternal(ctx, s.stream.url!!, tg.title)
            else onPlay(Screen.Player(tg.title, s.stream.url!!, subs, key = tg.videoId, image = tg.image ?: meta.background ?: meta.poster,
                resumeMs = resume, type = meta.type, meta = meta, source = s.stream.name ?: s.addonName, addon = s.addonName,
                candidates = all.filter { it !== s }))
        }
    }

    // "Play manually" from Continue Watching: open the sources page for that video.
    LaunchedEffect(sourcesFor, episodes) {
        val id = sourcesFor ?: return@LaunchedEffect
        if (openedSources) return@LaunchedEffect
        if (id.contains(":") && episodes.isEmpty()) return@LaunchedEffect // wait for the episode list
        openedSources = true
        pick = episodes.firstOrNull { it.id == id }?.let { target(it) } ?: SourceTarget(id, meta.name, null, null, null)
    }

    val saved = myList.any { it.id == meta.id }
    var expanded by remember { mutableStateOf(false) }
    val backdrop = tm?.backdrop ?: art?.backdrop ?: backdropOf(meta)
    val logo = tm?.logo ?: art?.logo ?: logoOf(meta)
    val heroImage = tm?.poster ?: meta.poster ?: backdrop
    val listState = androidx.compose.foundation.lazy.rememberLazyListState()
    val pastHero by remember { derivedStateOf { listState.firstVisibleItemIndex > 0 } }
    var videoType by remember(imdb) { mutableStateOf<String?>(null) }
    var logoFailed by remember(logo) { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Bg)) {
        val screenH = androidx.compose.ui.platform.LocalConfiguration.current.screenHeightDp.dp
        LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(bottom = 40.dp)) {
            // ── Hero: tall artwork, title logo, genres ──
            item {
                Box(Modifier.fillMaxWidth().height(screenH * 0.6f)) {
                    AsyncImage(heroImage, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to Color(0x66000000), 0.22f to Color.Transparent, 0.6f to Color.Transparent, 0.85f to Bg.copy(alpha = 0.85f), 1f to Bg)))
                    // A touch of the accent colour rising from the bottom.
                    val glow = Accent.copy(alpha = 0.2f)
                    Box(Modifier.fillMaxSize().drawBehind {
                        val c = androidx.compose.ui.geometry.Offset(size.width / 2f, size.height)
                        drawCircle(Brush.radialGradient(listOf(glow, Color.Transparent), center = c, radius = size.width * 0.8f), radius = size.width * 0.8f, center = c)
                    })
                    Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        if (logo != null && !logoFailed) {
                            AsyncImage(logo, meta.name, Modifier.fillMaxWidth(0.8f).height(110.dp), contentScale = ContentScale.Fit, onError = { logoFailed = true })
                        } else Text(meta.name, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, lineHeight = 38.sp)
                        val g = (tm?.genres?.takeIf { it.isNotEmpty() } ?: meta.genres.orEmpty()).take(3)
                        if (g.isNotEmpty()) Text(g.joinToString(" • "), Modifier.padding(top = 10.dp), fontSize = 16.sp, color = Color(0xFFB6BDCC))
                    }
                }
            }
            // ── Play + round buttons ──
            item {
                Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.weight(1f).height(58.dp).clip(RoundedCornerShape(29.dp))
                            .background(Brush.horizontalGradient(listOf(Accent, Palette.accent2)))
                            .combinedClickable(onClick = { start(playTarget.target) }, onLongClick = { actions = true }),
                        Alignment.Center,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PlayArrow, null, Modifier.size(30.dp), tint = OnAccent)
                            Spacer(Modifier.width(6.dp))
                            Text(playTarget.label, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = OnAccent)
                        }
                        if (playTarget.frac > 0f) Box(Modifier.align(Alignment.BottomCenter).padding(horizontal = 26.dp, vertical = 8.dp).fillMaxWidth().height(3.dp)
                            .clip(RoundedCornerShape(2.dp)).background(OnAccent.copy(alpha = 0.3f))) {
                            Box(Modifier.fillMaxHeight().fillMaxWidth(playTarget.frac).background(OnAccent))
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    RoundButton(if (saved) Icons.Default.Check else Icons.Default.Add, if (saved) "In Watchlist" else "Add to Watchlist", accent = saved) { vm.toggleList(meta) }
                    Spacer(Modifier.width(12.dp))
                    RoundButton(Icons.Default.MoreHoriz, "More") { actions = true }
                }
            }
            // ── Year · runtime · certification, ratings, director / writer ──
            item {
                Column(Modifier.padding(horizontal = 18.dp, vertical = 16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        (tm?.release?.take(4) ?: meta.releaseInfo)?.let { Text(it, fontSize = 19.sp, fontWeight = FontWeight.Bold) }
                        (tm?.runtime ?: meta.runtime)?.let { Text(it, Modifier.padding(start = 16.dp), fontSize = 19.sp, fontWeight = FontWeight.Bold) }
                        tm?.certification?.let {
                            Text(it, Modifier.padding(start = 16.dp).border(1.5.dp, Color(0x80FFFFFF), RoundedCornerShape(6.dp)).padding(horizontal = 8.dp, vertical = 2.dp),
                                fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFDDE1EA))
                        }
                    }
                    if (isOn(texts["detailRatings"] ?: "yes")) {
                        val chips = buildList {
                            meta.imdbRating?.takeIf { it.isNotBlank() }?.let { if (ratings.none { r -> r.source == "IMDb" }) add(Rating("IMDb", it)) }
                            addAll(ratings)
                        }
                        if (chips.isNotEmpty()) LazyRow(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) { itemsIndexed(chips) { i, r -> RatingCard(r, i) } }
                    }
                    val directors = tm?.directors?.takeIf { it.isNotEmpty() } ?: meta.director.orEmpty()
                    val writers = tm?.writers?.takeIf { it.isNotEmpty() } ?: meta.writer.orEmpty()
                    if (directors.isNotEmpty()) CreditLine(if (meta.type == "series" && tm != null) "Created by" else "Director", directors.take(2).joinToString(", "))
                    if (writers.isNotEmpty()) CreditLine("Writer", writers.take(2).joinToString(", "))
                    (tm?.overview ?: meta.description)?.takeIf { it.isNotBlank() }?.let { d ->
                        Text(d, Modifier.padding(top = 14.dp).clickable { expanded = !expanded }, fontSize = 16.sp, lineHeight = 24.sp, color = Color(0xFFE2E5EC),
                            maxLines = if (expanded) Int.MAX_VALUE else 3, overflow = TextOverflow.Ellipsis)
                        Text(if (expanded) "Show Less ▴" else "Show More ▾", Modifier.padding(top = 4.dp).clickable { expanded = !expanded },
                            fontSize = 15.sp, color = Accent, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            // ── Episodes (series) ──
            if (seasons.isNotEmpty()) {
                item { DetailTitle("Episodes") }
                item {
                    LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(seasons) { sn ->
                            val on = sn == season
                            Text(if (sn == 0) "Specials" else "Season $sn",
                                Modifier.clip(RoundedCornerShape(20.dp)).background(if (on) Accent else Color(0xFF1C1F28)).clickable { season = sn }
                                    .padding(horizontal = 16.dp, vertical = 9.dp),
                                fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (on) OnAccent else Color.White)
                        }
                    }
                }
                items(shown, key = { it.id }) { ep ->
                    val p = progress.firstOrNull { it.key == ep.id }
                    val watched = ep.id in done
                    val frac = if (p != null && p.durationMs > 0) (p.positionMs.toFloat() / p.durationMs).coerceIn(0f, 1f) else 0f
                    EpisodeRow(ep, watched, frac, isNext = ep.id == playTarget.target.videoId,
                        onClick = { start(target(ep)) }, onLongClick = { start(target(ep), forceSources = true) })
                }
            }
            // ── Production ──
            tm?.companies?.takeIf { it.isNotEmpty() }?.let { cos ->
                item { DetailTitle("Production") }
                item {
                    LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(cos) { c ->
                            Box(Modifier.size(120.dp, 72.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFFE6E6E9)).padding(12.dp), Alignment.Center) {
                                if (c.logo != null) AsyncImage(c.logo, c.name, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                                else Text(c.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF111111), textAlign = TextAlign.Center, maxLines = 2)
                            }
                        }
                    }
                }
            }
            // ── Cast ──
            if (isOn(texts["detailCast"] ?: "yes")) {
                val cast = tm?.cast?.takeIf { it.isNotEmpty() }
                    ?: (meta.director.orEmpty().take(1).map { TmCast(it, "Director", null) } + meta.cast.orEmpty().take(14).map { TmCast(it, "", null) })
                if (cast.isNotEmpty()) {
                    item { DetailTitle("Cast") }
                    item {
                        LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            items(cast) { c ->
                                Column(Modifier.width(96.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(Modifier.size(92.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF2A2F3D), Color(0xFF1B1E28)))), Alignment.Center) {
                                        Text(c.name.split(" ").mapNotNull { it.firstOrNull()?.uppercase() }.take(2).joinToString(""), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color(0xFF8A94A8))
                                        if (c.photo != null) AsyncImage(c.photo, c.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                                    }
                                    Text(c.name, Modifier.padding(top = 8.dp), fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                                    if (c.role.isNotBlank()) Text(c.role, fontSize = 12.sp, color = Color(0xFF9AA3B5), maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
                                }
                            }
                        }
                    }
                }
            }
            // ── Trailers ──
            val vids = tm?.videos?.takeIf { it.isNotEmpty() }
                ?: meta.trailerStreams.orEmpty().mapNotNull { t -> t.ytId?.let { TmVideo(it, t.title ?: "Trailer", "Trailer", meta.releaseInfo?.take(4)) } }
            if (vids.isNotEmpty()) {
                val types = vids.map { it.type }.distinct()
                val sel = videoType?.takeIf { it in types } ?: types.first()
                item {
                    Row(Modifier.padding(start = 18.dp, end = 18.dp, top = 26.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Trailers", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        if (types.size > 1) LazyRow(Modifier.padding(start = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(types) { ty ->
                                val on = ty == sel
                                Text(ty, Modifier.clip(RoundedCornerShape(18.dp)).background(if (on) Accent.copy(alpha = 0.22f) else Color(0xFF1A1C24))
                                    .clickable { videoType = ty }.padding(horizontal = 14.dp, vertical = 7.dp),
                                    fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (on) Color.White else Color(0xFFB6BDCC))
                            }
                        }
                    }
                }
                item {
                    LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(vids.filter { it.type == sel }) { v ->
                            Column(Modifier.width(270.dp).clip(RoundedCornerShape(16.dp)).clickable {
                                runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=${v.key}"))) }
                            }) {
                                Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(16.dp)).background(Surface1)) {
                                    AsyncImage("https://img.youtube.com/vi/${v.key}/hqdefault.jpg", v.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                                    Box(Modifier.align(Alignment.Center).size(44.dp).clip(CircleShape).background(Color(0x99000000)), Alignment.Center) {
                                        Icon(Icons.Default.PlayArrow, null, Modifier.size(28.dp))
                                    }
                                }
                                Text(v.name, Modifier.padding(top = 8.dp), fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                v.year?.let { Text(it, fontSize = 13.sp, color = Color(0xFF9AA3B5)) }
                            }
                        }
                    }
                }
            }
            // ── Details table ──
            item {
                val rows = listOfNotNull(
                    tm?.status?.let { "Status" to it },
                    (tm?.release ?: meta.releaseInfo)?.let { "Release Info" to it },
                    (tm?.runtime ?: meta.runtime)?.let { "Runtime" to it },
                    tm?.certification?.let { "Certification" to it },
                    tm?.country?.let { "Origin Country" to it },
                    tm?.language?.let { "Original Language" to it },
                )
                if (rows.isNotEmpty()) Column(Modifier.padding(horizontal = 18.dp)) {
                    Text(if (meta.type == "series") "Series Details" else "Movie Details", Modifier.padding(top = 26.dp, bottom = 6.dp), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    rows.forEachIndexed { i, (k, v) ->
                        if (i > 0) HorizontalDivider(color = Color(0x14FFFFFF))
                        Row(Modifier.fillMaxWidth().padding(vertical = 16.dp)) {
                            Text(k, Modifier.weight(1f), fontSize = 16.sp, color = Color(0xFFB6BDCC))
                            Text(v, fontSize = 16.sp)
                        }
                    }
                }
            }
            // ── More like this ──
            if (isOn(texts["detailMore"] ?: "yes")) {
                val recs = tm?.recs.orEmpty()
                if (recs.isNotEmpty() || more.isNotEmpty()) {
                    item { DetailTitle("More Like This") }
                    item {
                        LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            if (recs.isNotEmpty()) items(recs, key = { it.kind + it.tmdbId }) { r ->
                                PosterTile(r.poster, r.title, r.year) {
                                    scope.launch { vm.tmdbToImdb(r)?.let { onOpen(Meta(id = it, type = if (r.kind == "tv") "series" else "movie", name = r.title, poster = r.poster)) } }
                                }
                            } else items(more, key = { it.id }) { m -> PosterTile(m.poster, m.name, m.releaseInfo?.take(4)) { onOpen(m) } }
                        }
                    }
                }
            }
            if (tm != null) item {
                Text("Powered by TMDB", Modifier.fillMaxWidth().padding(18.dp), fontSize = 13.sp, color = Color(0xFF8A94A8), textAlign = TextAlign.End)
            }
        }

        // Top bar: floating back button; after scrolling past the artwork, a solid bar with the title logo.
        val barAlpha by animateFloatAsState(if (pastHero) 1f else 0f, tween(250), label = "bar")
        Box(Modifier.fillMaxWidth().graphicsLayer { alpha = barAlpha }.background(Bg).statusBarsPadding().height(64.dp)) {
            if (logo != null && !logoFailed) AsyncImage(logo, meta.name, Modifier.align(Alignment.Center).height(44.dp).fillMaxWidth(0.55f), contentScale = ContentScale.Fit)
            else Text(meta.name, Modifier.align(Alignment.Center), fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            if (pastHero) Icon(if (saved) Icons.Default.Check else Icons.Default.Add, "Watchlist",
                Modifier.align(Alignment.CenterEnd).padding(end = 12.dp).size(44.dp).clip(CircleShape).clickable { vm.toggleList(meta) }.padding(8.dp))
        }
        Box(
            Modifier.statusBarsPadding().padding(10.dp).size(44.dp).clip(CircleShape).background(Color(0x88000000).copy(alpha = 0.53f * (1f - barAlpha))).clickable(onClick = onBack),
            Alignment.Center,
        ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", Modifier.size(24.dp)) }

        if (actions) TitleActionsSheet(
            meta.name, playTarget.target.epLabel ?: if (meta.type == "series") "Series" else "Movie",
            playTarget.target.image ?: backdrop, playTarget.frac, progress.firstOrNull { it.key == playTarget.target.videoId }?.let { timeLeft(it) },
            buildList {
                add(TitleAction("Play manually", Icons.Default.PlayArrow) { start(playTarget.target, forceSources = true) })
                if (playTarget.resumeMs > 0) add(TitleAction("Start from beginning", Icons.Default.Replay) { start(playTarget.target, fromStart = true) })
                add(TitleAction(if (saved) "Remove from Watchlist" else "Add to Watchlist", if (saved) Icons.Default.Check else Icons.Default.Add) { vm.toggleList(meta) })
                (tm?.videos?.firstOrNull()?.key ?: trailer)?.let { k ->
                    add(TitleAction("Watch trailer", Icons.Default.Movie) { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=$k"))) } })
                }
                add(TitleAction("Share", Icons.Default.Share) {
                    runCatching {
                        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                            .putExtra(Intent.EXTRA_TEXT, "${meta.name}${if (imdb.startsWith("tt")) " https://www.imdb.com/title/$imdb/" else ""}"), "Share"))
                    }
                })
            },
            onDismiss = { actions = false },
        )

        // Full-screen sources page slides up over the details.
        val tgt = pick
        AnimatedVisibility(
            tgt != null, Modifier.fillMaxSize(),
            enter = slideInVertically(spring(dampingRatio = 0.9f, stiffness = 380f)) { it / 3 } + fadeIn(tween(200)),
            exit = slideOutVertically(tween(220)) { it / 3 } + fadeOut(tween(180)),
        ) {
            var last by remember { mutableStateOf(tgt) }
            if (tgt != null) last = tgt
            last?.let { tg ->
                BackHandler { pick = null }
                SourcesScreen(vm, meta, tg, resumeFor(tg.videoId), onBack = { pick = null }) { s, all, resume -> play(s, all, resume) }
            }
        }
    }
}

@Composable
private fun DetailTitle(text: String) =
    Text(text, Modifier.padding(start = 16.dp, end = 16.dp, top = 26.dp, bottom = 12.dp), fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFE6E9F2))

private val ratingNumberRegex = Regex("""\d+(?:[.,]\d+)?""")

private fun ratingNumber(r: Rating): String? = ratingNumberRegex.find(r.value)?.value?.replace(',', '.')

private fun ratingFraction(r: Rating): Float {
    val n = ratingNumber(r)?.toFloatOrNull() ?: return 0f
    val f = when {
        r.value.trim().endsWith("%") -> n / 100f
        r.source == "Metacritic" || r.source == "Trakt" -> n / 100f
        r.source == "Letterboxd" -> n / 5f
        else -> n / 10f
    }
    return f.coerceIn(0f, 1f)
}

private fun ratingScoreColor(frac: Float): Color = when {
    frac >= 0.75f -> Color(0xFF2BD67B)
    frac >= 0.6f -> Color(0xFFFFC145)
    else -> Color(0xFFFF5A5F)
}

/** Brand badge: label, background, text colour. */
private fun ratingBrand(source: String): Triple<String, Color, Color> = when (source) {
    "IMDb" -> Triple("IMDb", Color(0xFFF5C518), Color.Black)
    "Rotten Tomatoes" -> Triple("RT", Color(0xFFFA320A), Color.Black)
    "Audience" -> Triple("Audience", Color(0xFFFFB400), Color.Black)
    "Metacritic" -> Triple("MC", Color(0xFF66CC33), Color.Black)
    "TMDB" -> Triple("TMDB", Color(0xFF01B4E4), Color.White)
    "Letterboxd" -> Triple("LB", Color(0xFF40BCF4), Color.Black)
    "Trakt" -> Triple("Trakt", Color(0xFFED1C24), Color.White)
    else -> Triple(source.take(6), Color(0xFFB6BDCC), Color.Black)
}

@Composable
private fun RatingCard(r: Rating, index: Int) {
    val frac = remember(r) { ratingFraction(r) }
    val label = remember(r) { ratingNumber(r) ?: r.value }
    val scoreColor = ratingScoreColor(frac)
    val (badgeText, badgeBg, badgeFg) = ratingBrand(r.source)
    val progress = remember(r) { Animatable(0f) }
    val enter = remember(r) { Animatable(0f) }
    LaunchedEffect(r) {
        delay(index * 90L)
        launch { enter.animateTo(1f, tween(durationMillis = 520, easing = FastOutSlowInEasing)) }
        progress.animateTo(frac, tween(durationMillis = 900, easing = FastOutSlowInEasing))
    }
    val shape = RoundedCornerShape(18.dp)
    Column(
        Modifier
            .width(88.dp)
            .graphicsLayer {
                val e = enter.value
                alpha = e
                scaleX = 0.9f + 0.1f * e
                scaleY = 0.9f + 0.1f * e
            }
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFF1C1F27), Color(0xFF121419))))
            .drawBehind {
                val glowCenter = Offset(size.width / 2f, 35.dp.toPx())
                val glowRadius = size.width * 0.75f
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(scoreColor.copy(alpha = 0.25f), Color.Transparent),
                        center = glowCenter,
                        radius = glowRadius
                    ),
                    radius = glowRadius,
                    center = glowCenter
                )
            }
            .border(1.dp, Brush.verticalGradient(listOf(Color(0x33FFFFFF), Color(0x08FFFFFF))), shape)
            .padding(top = 12.dp, bottom = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val sw = 4.5.dp.toPx()
                val tl = Offset(sw / 2f, sw / 2f)
                val arcSize = Size(size.width - sw, size.height - sw)
                drawArc(
                    color = Color(0x22FFFFFF),
                    startAngle = 0f,
                    sweepAngle = 360f,
                    useCenter = false,
                    topLeft = tl,
                    size = arcSize,
                    style = Stroke(width = sw)
                )
                val p = progress.value
                if (p > 0.001f) {
                    rotate(-90f) {
                        drawArc(
                            brush = Brush.sweepGradient(
                                colors = listOf(scoreColor.copy(alpha = 0.45f), scoreColor, scoreColor),
                                center = center
                            ),
                            startAngle = 0f,
                            sweepAngle = 360f * p,
                            useCenter = false,
                            topLeft = tl,
                            size = arcSize,
                            style = Stroke(width = sw, cap = StrokeCap.Round)
                        )
                    }
                }
            }
            Text(label, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1)
        }
        Text(
            badgeText,
            Modifier.padding(top = 10.dp).clip(RoundedCornerShape(5.dp)).background(badgeBg).padding(horizontal = 6.dp, vertical = 2.dp),
            fontSize = 10.sp, fontWeight = FontWeight.Black, color = badgeFg, maxLines = 1
        )
    }
}

@Composable
private fun ActionIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(Modifier.width(80.dp).clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, label, Modifier.size(24.dp))
        Text(label, Modifier.padding(top = 4.dp), fontSize = 12.sp, color = Color(0xFFB6BDCC), maxLines = 1)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun EpisodeRow(ep: Video, watched: Boolean, frac: Float, isNext: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    val alpha by animateFloatAsState(if (watched) 0.6f else 1f, label = "w")
    Row(
        Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLongClick).padding(horizontal = 16.dp, vertical = 8.dp)
            .graphicsLayer { this.alpha = alpha },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(150.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(10.dp)).background(Surface1)) {
            AsyncImage(ep.thumbnail, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            if (watched) Box(Modifier.align(Alignment.TopEnd).padding(6.dp).size(22.dp).clip(CircleShape).background(Color(0xCC000000)), Alignment.Center) {
                Icon(Icons.Default.Check, "Watched", Modifier.size(14.dp))
            } else Icon(Icons.Default.PlayCircle, null, Modifier.align(Alignment.Center).size(30.dp), tint = Color(0xD9FFFFFF))
            if (frac > 0f && !watched) Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(3.dp).background(Color(0x55FFFFFF))) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(frac).background(Accent))
            }
        }
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("E${ep.episode}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF9AA3B5))
                if (isNext) Text(if (frac > 0f) "CONTINUE" else "UP NEXT", Modifier.padding(start = 8.dp).clip(RoundedCornerShape(5.dp)).background(Accent.copy(alpha = 0.2f))
                    .padding(horizontal = 5.dp, vertical = 1.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Accent, letterSpacing = 0.5.sp)
            }
            Text(ep.title ?: ep.name ?: "Episode ${ep.episode}", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            (ep.overview ?: ep.description)?.takeIf { it.isNotBlank() }?.let {
                Text(it, fontSize = 12.sp, color = Color(0xFF9AA3B5), maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 16.sp)
            }
            ep.released?.take(10)?.let { r ->
                if (r > java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())) Text("Coming $r", fontSize = 11.sp, color = Accent)
            }
        }
    }
}

@Composable
private fun RoundButton(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, accent: Boolean = false, onClick: () -> Unit) =
    Box(
        Modifier.size(58.dp).clip(CircleShape).background(if (accent) Accent.copy(alpha = 0.25f) else Color(0xFF1E2029))
            .border(1.dp, if (accent) Accent.copy(alpha = 0.6f) else Color(0x14FFFFFF), CircleShape).clickable(onClick = onClick),
        Alignment.Center,
    ) { Icon(icon, desc, Modifier.size(26.dp)) }

@Composable
private fun CreditLine(label: String, value: String) = Row(Modifier.padding(top = 12.dp)) {
    Text("$label:", fontSize = 16.sp, color = Color(0xFF9AA3B5), fontWeight = FontWeight.SemiBold)
    Text(value, Modifier.padding(start = 8.dp), fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
}

@Composable
private fun PosterTile(poster: String?, title: String, year: String?, onClick: () -> Unit) =
    Column(Modifier.width(150.dp).clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick)) {
        AsyncImage(poster, title, Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(RoundedCornerShape(16.dp)).background(Surface1), contentScale = ContentScale.Crop)
        Text(title, Modifier.padding(top = 8.dp), fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        year?.let { Text(it, fontSize = 13.sp, color = Color(0xFF9AA3B5)) }
    }

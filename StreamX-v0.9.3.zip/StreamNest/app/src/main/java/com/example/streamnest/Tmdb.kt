package com.example.streamnest

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

/* Rich title info from TMDB (Help & Settings > Integrations > TMDB key). Everything is optional. */

data class TmCast(val name: String, val role: String, val photo: String?)
data class TmCompany(val name: String, val logo: String?)
data class TmVideo(val key: String, val name: String, val type: String, val year: String?)
data class TmRec(val tmdbId: String, val kind: String, val title: String, val year: String?, val poster: String?)
data class TmdbInfo(
    val tmdbId: String, val kind: String,
    val poster: String?, val backdrop: String?, val logo: String?,
    val certification: String?, val status: String?, val release: String?, val runtime: String?,
    val country: String?, val language: String?, val genres: List<String>, val overview: String?,
    val directors: List<String>, val writers: List<String>, val cast: List<TmCast>,
    val companies: List<TmCompany>, val videos: List<TmVideo>, val recs: List<TmRec>,
)

private val infoCache = HashMap<String, TmdbInfo>()
private const val IMG = "https://image.tmdb.org/t/p/"

private fun JsonObject.str(k: String) = (this[k] as? kotlinx.serialization.json.JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() }
private fun JsonObject.arr(k: String) = (this[k] as? JsonArray)?.mapNotNull { it as? JsonObject }.orEmpty()
private fun JsonObject.obj(k: String) = this[k] as? JsonObject

fun AppViewModel.tmdbKey(): String = (texts.value["tmdbKey"] ?: "").trim()

suspend fun AppViewModel.tmdbInfo(imdb: String, type: String): TmdbInfo? {
    val key = tmdbKey()
    if (key.isEmpty() || !imdb.startsWith("tt")) return null
    infoCache[imdb]?.let { return it }
    return runCatching {
        val find = Api.json.parseToJsonElement(Api.get("https://api.themoviedb.org/3/find/$imdb?api_key=$key&external_source=imdb_id")).jsonObject
        val tv = type == "series"
        val hit = find.arr(if (tv) "tv_results" else "movie_results").firstOrNull()
            ?: find.arr(if (tv) "movie_results" else "tv_results").firstOrNull() ?: return null
        val kind = if (find.arr("tv_results").firstOrNull() === hit) "tv" else "movie"
        val id = hit["id"]!!.jsonPrimitive.content
        val extra = if (kind == "tv") "credits,videos,content_ratings,recommendations,images" else "credits,videos,release_dates,recommendations,images"
        val d = Api.json.parseToJsonElement(Api.get("https://api.themoviedb.org/3/$kind/$id?api_key=$key&append_to_response=$extra&include_image_language=en,null")).jsonObject

        val imgs = d.obj("images")
        fun bestImg(field: String, lang: String?) = imgs?.arr(field)?.filter { lang == null || it.str("iso_639_1") == lang }
            ?.maxByOrNull { (it["vote_average"] as? kotlinx.serialization.json.JsonPrimitive)?.contentOrNull?.toDoubleOrNull() ?: 0.0 }?.str("file_path")
        val logo = bestImg("logos", "en") ?: bestImg("logos", null)

        val cert = if (kind == "movie") {
            val res = d.obj("release_dates")?.arr("results").orEmpty()
            listOf("IN", "US", "GB").firstNotNullOfOrNull { c -> res.firstOrNull { it.str("iso_3166_1") == c }?.arr("release_dates")?.firstNotNullOfOrNull { it.str("certification") } }
        } else {
            val res = d.obj("content_ratings")?.arr("results").orEmpty()
            listOf("IN", "US", "GB").firstNotNullOfOrNull { c -> res.firstOrNull { it.str("iso_3166_1") == c }?.str("rating") }
        }
        val runtimeMin = if (kind == "movie") d["runtime"]?.jsonPrimitive?.intOrNull
        else (d["episode_run_time"] as? JsonArray)?.firstOrNull()?.jsonPrimitive?.intOrNull
        val credits = d.obj("credits")
        val crew = credits?.arr("crew").orEmpty()
        val directors = if (kind == "tv") d.arr("created_by").mapNotNull { it.str("name") } else crew.filter { it.str("job") == "Director" }.mapNotNull { it.str("name") }
        val writers = crew.filter { it.str("department") == "Writing" }.mapNotNull { it.str("name") }.distinct().take(3)
        val cast = credits?.arr("cast").orEmpty().take(16).mapNotNull { c ->
            TmCast(c.str("name") ?: return@mapNotNull null, c.str("character") ?: "", c.str("profile_path")?.let { "${IMG}w185$it" })
        }
        val companies = (if (kind == "tv") d.arr("networks") + d.arr("production_companies") else d.arr("production_companies"))
            .mapNotNull { c -> TmCompany(c.str("name") ?: return@mapNotNull null, c.str("logo_path")?.let { "${IMG}w185$it" }) }.distinctBy { it.name }.take(6)
        val videos = d.obj("videos")?.arr("results").orEmpty().filter { it.str("site") == "YouTube" }.mapNotNull { v ->
            TmVideo(v.str("key") ?: return@mapNotNull null, v.str("name") ?: "Video", v.str("type") ?: "Video", v.str("published_at")?.take(4))
        }.sortedBy { listOf("Trailer", "Teaser", "Clip", "Featurette", "Behind the Scenes").indexOf(it.type).let { i -> if (i < 0) 9 else i } }
        val recs = d.obj("recommendations")?.arr("results").orEmpty().take(20).mapNotNull { r ->
            TmRec(r.str("id") ?: r["id"]?.jsonPrimitive?.content ?: return@mapNotNull null, r.str("media_type") ?: kind,
                r.str("title") ?: r.str("name") ?: return@mapNotNull null,
                (r.str("release_date") ?: r.str("first_air_date"))?.take(4), r.str("poster_path")?.let { "${IMG}w342$it" })
        }.distinctBy { it.kind + it.tmdbId }
        TmdbInfo(
            tmdbId = id, kind = kind,
            poster = d.str("poster_path")?.let { "${IMG}w780$it" },
            backdrop = d.str("backdrop_path")?.let { "${IMG}w1280$it" },
            logo = logo?.let { "${IMG}w500$it" },
            certification = cert, status = d.str("status"),
            release = (d.str("release_date") ?: d.str("first_air_date")),
            runtime = runtimeMin?.takeIf { it > 0 }?.let { if (it >= 60) "${it / 60}h ${it % 60}m" else "${it}m" },
            country = (d["origin_country"] as? JsonArray)?.firstOrNull()?.jsonPrimitive?.contentOrNull
                ?: d.arr("production_countries").firstOrNull()?.str("iso_3166_1"),
            language = d.str("original_language")?.uppercase(),
            genres = d.arr("genres").mapNotNull { it.str("name") },
            overview = d.str("overview"),
            directors = directors, writers = writers, cast = cast, companies = companies, videos = videos, recs = recs,
        ).also { infoCache[imdb] = it }
    }.getOrNull()
}

/** IMDb id for a TMDB recommendation, so it can open in StreamX. */
suspend fun AppViewModel.tmdbToImdb(r: TmRec): String? = runCatching {
    val o = Api.json.parseToJsonElement(Api.get("https://api.themoviedb.org/3/${r.kind}/${r.tmdbId}/external_ids?api_key=${tmdbKey()}")).jsonObject
    o.str("imdb_id")
}.getOrNull()

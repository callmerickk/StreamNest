StreamX 0.9.63

• Top-card trailers play inside the card, like Xstream: centred, filling the card, nothing showing behind the other cards.
• Titles inside collections (like the Avengers Collection) open properly, with their posters.

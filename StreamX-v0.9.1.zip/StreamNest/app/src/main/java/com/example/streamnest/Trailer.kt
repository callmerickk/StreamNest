package com.example.streamnest

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.PlayerConstants
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.options.IFramePlayerOptions
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView

/**
 * A muted, control-less YouTube trailer that fills (crops into) its box.
 * Uses YouTube's official embedded player. Some uploaders block embedding; then onError is called.
 */
@Composable
fun TrailerVideo(
    videoId: String,
    muted: Boolean,
    modifier: Modifier = Modifier,
    onPlaying: () -> Unit,
    onEnded: () -> Unit,
    onError: () -> Unit,
) {
    var yt by remember { mutableStateOf<YouTubePlayer?>(null) }
    var view by remember { mutableStateOf<YouTubePlayerView?>(null) }
    val playing by rememberUpdatedState(onPlaying)
    val ended by rememberUpdatedState(onEnded)
    val failed by rememberUpdatedState(onError)

    BoxWithConstraints(modifier) {
        // 16:9 video scaled to cover the card (the card itself is taller than 16:9).
        val h = maxHeight
        val w = maxOf(maxWidth, h * 16f / 9f)
        AndroidView(
            factory = { c ->
                YouTubePlayerView(c).apply {
                    enableAutomaticInitialization = false
                    val opts = IFramePlayerOptions.Builder().controls(0).rel(0).ivLoadPolicy(3).ccLoadPolicy(0).build()
                    initialize(object : AbstractYouTubePlayerListener() {
                        override fun onReady(youTubePlayer: YouTubePlayer) {
                            yt = youTubePlayer
                            youTubePlayer.mute()
                            youTubePlayer.loadVideo(videoId, 0f)
                        }
                        override fun onStateChange(youTubePlayer: YouTubePlayer, state: PlayerConstants.PlayerState) {
                            if (state == PlayerConstants.PlayerState.PLAYING) playing()
                            if (state == PlayerConstants.PlayerState.ENDED) ended()
                        }
                        override fun onError(youTubePlayer: YouTubePlayer, error: PlayerConstants.PlayerError) { failed() }
                    }, opts)
                    view = this
                }
            },
            modifier = Modifier.requiredSize(w, maxOf(h, w * 9f / 16f)).align(Alignment.Center),
        )
    }
    LaunchedEffect(muted, yt) { yt?.let { if (muted) it.mute() else it.unMute() } }
    DisposableEffect(Unit) { onDispose { runCatching { view?.release() } } }
}

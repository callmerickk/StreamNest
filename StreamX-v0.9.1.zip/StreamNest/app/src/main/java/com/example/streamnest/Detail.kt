package com.example.streamnest

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.MediaItem
import coil.compose.AsyncImage
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** What the big Play button will do. */
private data class PlayTarget(val target: SourceTarget, val label: String, val resumeMs: Long, val frac: Float)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DetailScreen(vm: AppViewModel, meta0: Meta, onBack: () -> Unit, onOpen: (Meta) -> Unit = {}, onPlay: (Screen.Player) -> Unit) {
    var meta by remember { mutableStateOf(meta0) }
    LaunchedEffect(meta0.id) { vm.fullMeta(meta0)?.let { meta = it } }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val progress by vm.progress.collectAsStateWithLifecycle()
    val done by vm.doneKeys.collectAsStateWithLifecycle()
    val myList by vm.myList.collectAsStateWithLifecycle()
    val texts by vm.texts.collectAsStateWithLifecycle()
    val imdb = meta.id.substringBefore(":")

    var art by remember(imdb) { mutableStateOf<Art?>(null) }
    var ratings by remember(imdb) { mutableStateOf<List<Rating>>(emptyList()) }
    var more by remember(imdb) { mutableStateOf<List<Meta>>(emptyList()) }
    var trailer by remember(imdb) { mutableStateOf<String?>(null) }
    LaunchedEffect(imdb) { art = vm.tmdbArt(imdb, meta.type) }
    LaunchedEffect(imdb) { ratings = vm.mdbRatings(imdb) }
    LaunchedEffect(imdb) { trailer = runCatching { vm.trailerId(meta) }.getOrNull() }
    LaunchedEffect(imdb, meta.genres) {
        val g = meta.genres.orEmpty().take(2)
        if (g.isNotEmpty() && isOn(texts["detailMore"] ?: "yes")) more = runCatching { vm.genreTitles(g, listOf(meta.type)) }.getOrDefault(emptyList()).filter { it.id != meta.id }.take(20)
    }

    var pick by remember { mutableStateOf<SourceTarget?>(null) }
    val subsJob = remember(pick?.videoId) { pick?.let { pk -> scope.async { runCatching { vm.subtitles(meta.type, pk.videoId) }.getOrDefault(emptyList()) } } }

    val episodes = remember(meta) { meta.videos.orEmpty().filter { it.season != null && it.episode != null }.sortedWith(compareBy({ it.season }, { it.episode })) }
    val seasons = remember(episodes) { episodes.mapNotNull { it.season }.distinct().sorted().let { s -> s.filter { it > 0 } + s.filter { it == 0 } } }

    val autoMode = t("autoPlayMode")
    val external = t("playerChoice") == "external"
    val quick = vm.qsActive()
    fun resumeFor(vid: String): Long = progress.firstOrNull { it.key == vid }
        ?.takeIf { it.durationMs <= 0 || it.positionMs < it.durationMs * 0.95 }?.positionMs ?: 0L
    fun target(ep: Video) = SourceTarget(ep.id, "${meta.name}  S${ep.season}E${ep.episode}", "S${ep.season} E${ep.episode}", ep.title ?: ep.name, ep.thumbnail)

    // The big button: resume where you left off, or the next episode / start.
    val playTarget = remember(meta, progress, done, episodes) {
        if (episodes.isEmpty()) {
            val p = progress.firstOrNull { it.key == meta.id }
            val r = resumeFor(meta.id)
            PlayTarget(SourceTarget(meta.id, meta.name, null, null, null), if (r > 0) "Resume ${fmtTime(r)}" else "Play", r,
                if (p != null && p.durationMs > 0) (p.positionMs.toFloat() / p.durationMs).coerceIn(0f, 1f) else 0f)
        } else {
            val mine = progress.filter { it.key.startsWith(meta.id + ":") }.maxByOrNull { it.updated }
            val ep = mine?.let { m -> episodes.firstOrNull { it.id == m.key } }
                ?: episodes.lastOrNull { it.id in done }?.let { last -> episodes.getOrNull(episodes.indexOf(last) + 1) }
                ?: episodes.firstOrNull { (it.season ?: 0) > 0 } ?: episodes.first()
            val r = resumeFor(ep.id)
            val p = progress.firstOrNull { it.key == ep.id }
            PlayTarget(target(ep), (if (r > 0) "Resume" else "Play") + " S${ep.season} E${ep.episode}", r,
                if (p != null && p.durationMs > 0) (p.positionMs.toFloat() / p.durationMs).coerceIn(0f, 1f) else 0f)
        }
    }
    var season by remember(seasons, playTarget.target.videoId) {
        mutableIntStateOf(episodes.firstOrNull { it.id == playTarget.target.videoId }?.season ?: seasons.firstOrNull() ?: 1)
    }
    val shown = remember(episodes, season) { episodes.filter { it.season == season } }

    // Quick Start: look up the fast addons as soon as the page opens, and (optionally) prepare the video in the background.
    LaunchedEffect(playTarget.target.videoId, quick) {
        if (!quick) return@LaunchedEffect
        val id = playTarget.target.videoId
        val list = runCatching { vm.quickStreams(meta.type, id) }.getOrDefault(emptyList())
        if (external || list.isEmpty() || Preloader.has(id) || texts["playerEngine"] == "vlc") return@LaunchedEffect
        val mode = texts["qsPreload"] ?: "wifi"
        if (!(mode == "always" || (mode == "wifi" && isOnWifi(ctx)))) return@LaunchedEffect
        val level = vm.playerPref("quality").ifEmpty { texts["qsQuality"] ?: "auto" }
        val s = vm.pickQuick(list, level) ?: vm.pickQuick(list, "auto") ?: return@LaunchedEffect
        val extra = withTimeoutOrNull(1500) { runCatching { vm.subtitles(meta.type, id) }.getOrDefault(emptyList()) }.orEmpty()
        val subs = s.stream.subtitles.orEmpty() + extra
        val player = buildPlayer(ctx, vm, isOn(texts["fastStart"] ?: "yes"))
        player.setMediaItem(MediaItem.Builder().setUri(s.stream.url!!).setSubtitleConfigurations(subtitleConfigs(subs)).build(), playTarget.resumeMs)
        player.playWhenReady = false
        player.prepare()
        Preloader.set(Preloaded(id, s.stream.url!!, subs, s.stream.name ?: s.addonName, s.addonName, list, player))
    }
    val preKey by rememberUpdatedState(playTarget.target.videoId)
    DisposableEffect(Unit) { onDispose { Preloader.release(preKey) } }

    /** Play button / episode tap: Quick Start or auto modes go straight to the player, manual opens the sources page. */
    fun start(t: SourceTarget, forceSources: Boolean = false) {
        when {
            forceSources -> pick = t
            quick && !external -> onPlay(Screen.Player(t.title, "", emptyList(), key = t.videoId, image = t.image ?: meta.background ?: meta.poster,
                resumeMs = resumeFor(t.videoId), type = meta.type, meta = meta, find = true, quick = true))
            quick && external -> scope.launch {
                val list = runCatching { vm.quickStreams(meta.type, t.videoId) }.getOrDefault(emptyList())
                val s = vm.pickQuick(list, texts["qsQuality"] ?: "auto")
                if (s != null) openExternal(ctx, s.stream.url!!, t.title) else pick = t
            }
            !external && autoMode != "manual" -> onPlay(Screen.Player(t.title, "", emptyList(), key = t.videoId, image = t.image ?: meta.background ?: meta.poster,
                resumeMs = resumeFor(t.videoId), type = meta.type, meta = meta, find = true))
            else -> pick = t
        }
    }

    fun play(s: StreamItem, all: List<StreamItem>, resume: Long) {
        val tg = pick ?: return
        scope.launch {
            val extra = withTimeoutOrNull(1500) { subsJob?.await() }.orEmpty()
            val subs = s.stream.subtitles.orEmpty() + extra
            pick = null
            if (external) openExternal(ctx, s.stream.url!!, tg.title)
            else onPlay(Screen.Player(tg.title, s.stream.url!!, subs, key = tg.videoId, image = tg.image ?: meta.background ?: meta.poster,
                resumeMs = resume, type = meta.type, meta = meta, source = s.stream.name ?: s.addonName, addon = s.addonName,
                candidates = all.filter { it !== s }))
        }
    }

    val saved = myList.any { it.id == meta.id }
    var expanded by remember { mutableStateOf(false) }
    val backdrop = art?.backdrop ?: backdropOf(meta)
    val logo = art?.logo ?: logoOf(meta)
    var logoFailed by remember(logo) { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Bg)) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 40.dp)) {
            // ── Hero ──
            item {
                Box(Modifier.fillMaxWidth().height(460.dp)) {
                    AsyncImage(backdrop, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to Color(0x80000000), 0.3f to Color.Transparent, 0.62f to Bg.copy(alpha = 0.55f), 1f to Bg)))
                    Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        if (logo != null && !logoFailed) {
                            AsyncImage(logo, meta.name, Modifier.fillMaxWidth(0.72f).height(96.dp), contentScale = ContentScale.Fit, onError = { logoFailed = true })
                        } else Text(meta.name, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center, lineHeight = 36.sp)
                        val line = listOfNotNull(meta.releaseInfo, meta.runtime, meta.genres?.take(3)?.joinToString(" · ")).filter { it.isNotBlank() }.joinToString("  •  ")
                        if (line.isNotBlank()) Text(line, Modifier.padding(top = 12.dp), fontSize = 13.sp, color = Color(0xFFC9CDD6), textAlign = TextAlign.Center)
                    }
                }
            }
            // ── Ratings ──
            if (isOn(texts["detailRatings"] ?: "yes")) item {
                val chips = buildList {
                    meta.imdbRating?.takeIf { it.isNotBlank() }?.let { if (ratings.none { r -> r.source == "IMDb" }) add(Rating("IMDb", it)) }
                    addAll(ratings)
                }
                if (chips.isNotEmpty()) LazyRow(Modifier.fillMaxWidth().padding(top = 14.dp), contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)) {
                    items(chips) { r -> RatingPill(r) }
                }
            }
            // ── Play / actions ──
            item {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 16.dp)) {
                    Box(
                        Modifier.fillMaxWidth().height(54.dp).clip(RoundedCornerShape(14.dp)).background(Accent)
                            .combinedClickable(onClick = { start(playTarget.target) }, onLongClick = { start(playTarget.target, forceSources = true) }),
                        Alignment.Center,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PlayArrow, null, Modifier.size(28.dp), tint = OnAccent)
                            Spacer(Modifier.width(6.dp))
                            Text(playTarget.label, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = OnAccent)
                        }
                        if (playTarget.frac > 0f) Box(Modifier.align(Alignment.BottomStart).fillMaxWidth(playTarget.frac).height(3.dp).background(OnAccent.copy(alpha = 0.7f)))
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                        ActionIcon(if (saved) Icons.Default.Check else Icons.Default.Add, if (saved) "In Watchlist" else "Watchlist") { vm.toggleList(meta) }
                        if (trailer != null) ActionIcon(Icons.Default.Movie, "Trailer") {
                            runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=$trailer"))) }
                        }
                        ActionIcon(Icons.Default.CloudQueue, "Sources") { start(playTarget.target, forceSources = true) }
                        ActionIcon(Icons.Default.Share, "Share") {
                            runCatching {
                                ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                                    .putExtra(Intent.EXTRA_TEXT, "${meta.name}${if (imdb.startsWith("tt")) " https://www.imdb.com/title/$imdb/" else ""}"), "Share"))
                            }
                        }
                    }
                }
            }
            // ── Story ──
            meta.description?.takeIf { it.isNotBlank() }?.let { d ->
                item {
                    Text(d, Modifier.padding(horizontal = 16.dp).clickable { expanded = !expanded }, fontSize = 14.sp, lineHeight = 21.sp, color = Color(0xFFD0D4DC),
                        maxLines = if (expanded) Int.MAX_VALUE else 3, overflow = TextOverflow.Ellipsis)
                }
            }
            // ── Cast & crew ──
            if (isOn(texts["detailCast"] ?: "yes") && (!meta.cast.isNullOrEmpty() || !meta.director.isNullOrEmpty())) {
                item { DetailTitle("Cast & crew") }
                item {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(meta.director.orEmpty().take(2).map { it to "Director" } + meta.cast.orEmpty().take(14).map { it to "Cast" }) { (n, role) ->
                            Column(Modifier.width(76.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.size(62.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF2A2F3D), Color(0xFF1B1E28)))), Alignment.Center) {
                                    Text(n.split(" ").mapNotNull { it.firstOrNull()?.uppercase() }.take(2).joinToString(""), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFFB6BDCC))
                                }
                                Text(n, Modifier.padding(top = 6.dp), fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, lineHeight = 15.sp)
                                Text(role, fontSize = 11.sp, color = Color(0xFF8A94A8))
                            }
                        }
                    }
                }
            }
            // ── Episodes ──
            if (seasons.isNotEmpty()) {
                item { DetailTitle("Episodes") }
                item {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(seasons) { sn ->
                            val on = sn == season
                            Text(if (sn == 0) "Specials" else "Season $sn",
                                Modifier.clip(RoundedCornerShape(20.dp)).background(if (on) Color.White else Color(0xFF1C1F28)).clickable { season = sn }
                                    .padding(horizontal = 16.dp, vertical = 9.dp),
                                fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (on) Color.Black else Color.White)
                        }
                    }
                }
                items(shown, key = { it.id }) { ep ->
                    val p = progress.firstOrNull { it.key == ep.id }
                    val watched = ep.id in done
                    val frac = if (p != null && p.durationMs > 0) (p.positionMs.toFloat() / p.durationMs).coerceIn(0f, 1f) else 0f
                    EpisodeRow(ep, watched, frac, isNext = ep.id == playTarget.target.videoId,
                        onClick = { start(target(ep)) }, onLongClick = { start(target(ep), forceSources = true) })
                }
            }
            // ── More like this ──
            if (more.isNotEmpty() && isOn(texts["detailMore"] ?: "yes")) {
                item { DetailTitle("More like this") }
                item {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(more, key = { it.id }) { m -> Poster(m, Modifier.width(112.dp)) { onOpen(it) } }
                    }
                }
            }
        }
        Box(
            Modifier.statusBarsPadding().padding(10.dp).size(44.dp).clip(CircleShape).background(Color(0x88000000)).clickable(onClick = onBack),
            Alignment.Center,
        ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", Modifier.size(24.dp)) }

        // Full-screen sources page slides up over the details.
        val tgt = pick
        AnimatedVisibility(
            tgt != null, Modifier.fillMaxSize(),
            enter = slideInVertically(spring(dampingRatio = 0.9f, stiffness = 380f)) { it / 3 } + fadeIn(tween(200)),
            exit = slideOutVertically(tween(220)) { it / 3 } + fadeOut(tween(180)),
        ) {
            var last by remember { mutableStateOf(tgt) }
            if (tgt != null) last = tgt
            last?.let { tg ->
                BackHandler { pick = null }
                SourcesScreen(vm, meta, tg, resumeFor(tg.videoId), onBack = { pick = null }) { s, all, resume -> play(s, all, resume) }
            }
        }
    }
}

@Composable
private fun DetailTitle(text: String) =
    Text(text, Modifier.padding(start = 16.dp, end = 16.dp, top = 26.dp, bottom = 12.dp), fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFE6E9F2))

@Composable
private fun RatingPill(r: Rating) {
    val c = when (r.source) {
        "IMDb" -> Color(0xFFF5C518); "Rotten Tomatoes" -> Color(0xFFFA320A); "Audience" -> Color(0xFFFFB400)
        "Metacritic" -> Color(0xFF66CC33); "TMDB" -> Color(0xFF01B4E4); "Letterboxd" -> Color(0xFF40BCF4); else -> Color(0xFFB6BDCC)
    }
    Row(Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFF16181F)).border(1.dp, Color(0x14FFFFFF), RoundedCornerShape(14.dp))
        .padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(when (r.source) { "Rotten Tomatoes" -> "RT"; "Metacritic" -> "MC"; else -> r.source }, Modifier.clip(RoundedCornerShape(4.dp)).background(c)
            .padding(horizontal = 4.dp, vertical = 1.dp), fontSize = 10.sp, fontWeight = FontWeight.Black, color = Color.Black)
        Spacer(Modifier.width(6.dp))
        Text(r.value, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ActionIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(Modifier.width(80.dp).clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, label, Modifier.size(24.dp))
        Text(label, Modifier.padding(top = 4.dp), fontSize = 12.sp, color = Color(0xFFB6BDCC), maxLines = 1)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun EpisodeRow(ep: Video, watched: Boolean, frac: Float, isNext: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    val alpha by animateFloatAsState(if (watched) 0.6f else 1f, label = "w")
    Row(
        Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLongClick).padding(horizontal = 16.dp, vertical = 8.dp)
            .graphicsLayer { this.alpha = alpha },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.width(150.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(10.dp)).background(Surface1)) {
            AsyncImage(ep.thumbnail, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            if (watched) Box(Modifier.align(Alignment.TopEnd).padding(6.dp).size(22.dp).clip(CircleShape).background(Color(0xCC000000)), Alignment.Center) {
                Icon(Icons.Default.Check, "Watched", Modifier.size(14.dp))
            } else Icon(Icons.Default.PlayCircle, null, Modifier.align(Alignment.Center).size(30.dp), tint = Color(0xD9FFFFFF))
            if (frac > 0f && !watched) Box(Modifier.align(Alignment.BottomStart).fillMaxWidth().height(3.dp).background(Color(0x55FFFFFF))) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(frac).background(Accent))
            }
        }
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("E${ep.episode}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF9AA3B5))
                if (isNext) Text(if (frac > 0f) "CONTINUE" else "UP NEXT", Modifier.padding(start = 8.dp).clip(RoundedCornerShape(5.dp)).background(Accent.copy(alpha = 0.2f))
                    .padding(horizontal = 5.dp, vertical = 1.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Accent, letterSpacing = 0.5.sp)
            }
            Text(ep.title ?: ep.name ?: "Episode ${ep.episode}", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            (ep.overview ?: ep.description)?.takeIf { it.isNotBlank() }?.let {
                Text(it, fontSize = 12.sp, color = Color(0xFF9AA3B5), maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 16.sp)
            }
            ep.released?.take(10)?.let { r ->
                if (r > java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())) Text("Coming $r", fontSize = 11.sp, color = Accent)
            }
        }
    }
}

package com.example.streamnest

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
private fun SimplePage(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) =
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).navigationBarsPadding().padding(bottom = 40.dp)) {
        PageHeader(title, onBack)
        content()
    }

@Composable
private fun Chips(options: List<Pair<String, String>>, selected: String, onPick: (String) -> Unit) {
    Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (id, label) ->
            val on = id == selected
            Text(label, Modifier.clip(RoundedCornerShape(16.dp)).background(if (on) Accent else Color(0xFF2A2A30)).clickable { onPick(id) }
                .padding(horizontal = 14.dp, vertical = 9.dp), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (on) OnAccent else Color.White)
        }
    }
}

// ───────────── Content & Discovery > Quick Start ─────────────

@Composable
internal fun QuickStartPage(vm: AppViewModel, onBack: () -> Unit) {
    val texts by vm.texts.collectAsStateWithLifecycle()
    val addons by vm.addons.collectAsStateWithLifecycle()
    fun v(k: String) = texts[k] ?: Defaults[k] ?: ""
    val chosen = v("qsAddons").split("|").filter { it.isNotBlank() }
    val langs = v("qsLangs").split(",").map { it.trim() }.filter { it.isNotEmpty() }
    val streamAddons = addons.filter { it.manifest.resources?.toString()?.contains("\"stream\"") == true }.map { it.manifest.name }.distinct()

    SimplePage("Quick Start", onBack) {
        Text(
            "Pick your fastest addons. Pressing Play starts straight from them with a quality selector (Auto / Full HD / Mid HD / Low) " +
                "and your preferred language. Every other addon stays under \"All sources\" in the player.",
            Modifier.padding(horizontal = 24.dp, vertical = 4.dp), fontSize = 14.sp, color = Muted,
        )
        SectionLabel("Quick Start")
        SettingsCard {
            ToggleRow("Use Quick Start", "Play from the addons below with the quality selector.", isOn(v("qsOn"))) { vm.setText("qsOn", if (it) "yes" else "no") }
        }

        SectionLabel("Quick Start addons (group 1)")
        SettingsCard {
            if (streamAddons.isEmpty()) Text("No stream addons installed yet. Add one in Addons.", Modifier.padding(20.dp), color = Muted)
            streamAddons.forEachIndexed { i, name ->
                if (i > 0) RowDivider(20.dp)
                val on = name in chosen
                Row(
                    Modifier.fillMaxWidth().clickable {
                        vm.setText("qsAddons", (if (on) chosen - name else chosen + name).joinToString("|"))
                    }.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Checkbox(on, null, colors = CheckboxDefaults.colors(checkedColor = Accent, checkmarkColor = OnAccent))
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(name, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                        Text(if (on) "Quick Start · plays first" else "All sources", fontSize = 12.sp, color = if (on) Accent else Muted)
                    }
                }
            }
        }

        SectionLabel("Preferred audio language")
        SettingsCard {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
                Text("Tried in this order. If the first isn't available, the next one plays.", fontSize = 13.sp, color = Muted)
                langs.forEachIndexed { i, l ->
                    Row(Modifier.padding(top = 10.dp).fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF222228)).padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Text("${i + 1}", Modifier.width(24.dp), fontWeight = FontWeight.Bold, color = Accent)
                        Text(l.replaceFirstChar { it.uppercase() }, Modifier.weight(1f), fontSize = 16.sp)
                        if (i > 0) Text("↑", Modifier.clip(RoundedCornerShape(8.dp)).clickable {
                            val m = langs.toMutableList(); m.add(i - 1, m.removeAt(i)); vm.setText("qsLangs", m.joinToString(","))
                        }.padding(horizontal = 10.dp, vertical = 2.dp), fontSize = 18.sp)
                        Icon(Icons.Default.Close, "Remove", Modifier.size(28.dp).clip(RoundedCornerShape(14.dp)).clickable {
                            vm.setText("qsLangs", (langs - l).joinToString(","))
                        }.padding(4.dp), tint = Muted)
                    }
                }
                val others = QsLanguages.keys.filter { it !in langs }
                if (others.isNotEmpty()) {
                    Text("Add", Modifier.padding(top = 14.dp), fontSize = 13.sp, color = Muted)
                    others.chunked(4).forEach { row ->
                        Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { l ->
                                Row(Modifier.clip(RoundedCornerShape(16.dp)).background(Color(0xFF2A2A30)).clickable { vm.setText("qsLangs", (langs + l).joinToString(",")) }
                                    .padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Add, null, Modifier.size(14.dp))
                                    Text(l.replaceFirstChar { it.uppercase() }, Modifier.padding(start = 4.dp), fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        SectionLabel("Quality")
        SettingsCard {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
                Text("Starting quality", fontSize = 18.sp, fontWeight = FontWeight.Medium)
                Text("Auto picks the best quality up to Full HD that starts fast. Changing it in the player is remembered.", fontSize = 13.sp, color = Muted)
                Chips(QualityLevels.map { it.id to it.label }, v("qsQuality")) { vm.setText("qsQuality", it); vm.setPlayerPref("quality", it) }
            }
            RowDivider(20.dp)
            ToggleRow("Hide duplicate qualities", "If two levels would play the same file, show only one.", isOn(v("qsHideDupes"))) { vm.setText("qsHideDupes", if (it) "yes" else "no") }
        }

        SectionLabel("Instant start")
        SettingsCard {
            Column(Modifier.padding(horizontal = 20.dp, vertical = 14.dp)) {
                Text("Prepare video on the title page", fontSize = 18.sp, fontWeight = FontWeight.Medium)
                Text("While you look at a title, the video gets ready in the background so Play starts almost instantly. Uses a little data.", fontSize = 13.sp, color = Muted)
                Chips(listOf("off" to "Off", "wifi" to "Wi-Fi only", "always" to "Always"), v("qsPreload")) { vm.setText("qsPreload", it) }
            }
        }
    }
}

// ───────────── Layout > Detail Page ─────────────

@Composable
internal fun DetailPageSettings(vm: AppViewModel, onBack: () -> Unit) {
    val texts by vm.texts.collectAsStateWithLifecycle()
    fun v(k: String) = texts[k] ?: Defaults[k] ?: ""
    fun yn(b: Boolean) = if (b) "yes" else "no"
    SimplePage("Detail Page", onBack) {
        SectionLabel("Sections")
        SettingsCard {
            ToggleRow("Ratings", "IMDb, plus Rotten Tomatoes, Metacritic and more with an MDBList key.", isOn(v("detailRatings"))) { vm.setText("detailRatings", yn(it)) }
            RowDivider(20.dp)
            ToggleRow("Cast & crew", "Director and cast row.", isOn(v("detailCast"))) { vm.setText("detailCast", yn(it)) }
            RowDivider(20.dp)
            ToggleRow("More like this", "Similar titles at the bottom.", isOn(v("detailMore"))) { vm.setText("detailMore", yn(it)) }
        }
        Text("Tip: long-press Play or any episode to choose a source yourself.", Modifier.padding(horizontal = 24.dp, vertical = 12.dp), fontSize = 13.sp, color = Muted)
    }
}

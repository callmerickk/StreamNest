# LibVLC calls back into its Java classes from native code (JNI); keep them intact in minified builds.
-keep class org.videolan.libvlc.** { *; }
-dontwarn org.videolan.libvlc.**

StreamX TV 0.8.3 (the phone app stays on 0.9.65)

• Plays start from the quickest streams and move to the best quality straight away.
• Better copies wait in Upgrade quality; Full HD 60fps has its own line.
• Skip Intro / Recap, Next Episode and Upgrade are selected as they appear: one OK. ▶ or ▼ sends them away.
• Any arrow shows the player options; ▼ again opens Watch Next, ▲ the quality and other options.
• Smoother loading screen, Home and search; picture and sound badges in the player.
• Frame-rate matching for films; trailers off by default (Settings › Layout).

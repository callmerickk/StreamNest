package com.example.streamnest

import android.content.Context
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody

/**
 * The app's look for everyone: in-app logo and the Home logo animation. Chosen in Developer's Corner and published to
 * the cloud (shared/appLook); every phone picks it up when the app opens. The launcher icon follows on the next fresh
 * start, unless the person picked their own icon in Settings.
 */
object AppLook {
    val ANIMS = listOf(
        "broadcast_living" to "Broadcast + Living signal",
        "broadcast" to "Broadcast",
        "tune" to "Tune in",
        "living" to "Living signal",
        "hanging" to "Hanging X",
        "none" to "No animation",
    )
    val logo = MutableStateFlow("signal")
    val anim = MutableStateFlow("broadcast_living")
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("look", Context.MODE_PRIVATE)

    fun init(ctx: Context) {
        logo.value = prefs(ctx).getString("logo", null) ?: "signal"
        anim.value = prefs(ctx).getString("anim", null) ?: "broadcast_living"
    }

    fun logoRes(id: String): Int = AppIcons.all.firstOrNull { it.id == id }?.res ?: R.drawable.logo_signal

    /** On this phone (Developer's Corner "Use on this phone", or what the cloud says). */
    fun set(ctx: Context, l: String, a: String) {
        logo.value = l; anim.value = a
        prefs(ctx).edit().putString("logo", l).putString("anim", a).apply()
        if (!AppIcons.picked(ctx) && AppIcons.all.any { it.id == l } && AppIcons.active(ctx) != l) AppIcons.setPending(ctx, l)
    }

    suspend fun fetch(ctx: Context) = withContext(Dispatchers.IO) {
        val txt = runCatching { Api.get("${CloudConfig.DB_URL}/shared/appLook.json") }.getOrNull() ?: return@withContext
        val o = runCatching { Api.json.parseToJsonElement(txt).jsonObject }.getOrNull() ?: return@withContext
        val l = o["logo"]?.jsonPrimitive?.contentOrNull?.takeIf { id -> AppIcons.all.any { it.id == id } } ?: return@withContext
        val a = o["anim"]?.jsonPrimitive?.contentOrNull?.takeIf { id -> ANIMS.any { it.first == id } } ?: anim.value
        withContext(Dispatchers.Main) { set(ctx, l, a) }
    }

    /** Developer's Corner: publish for everyone (only the owner's account may write). Null = done. */
    suspend fun publish(l: String, a: String): String? = withContext(Dispatchers.IO) {
        val t = Cloud.token() ?: return@withContext "Sign in first."
        val body = buildJsonObject { put("logo", l); put("anim", a); put("at", System.currentTimeMillis()) }
        runCatching {
            Api.http.newCall(Request.Builder().url("${CloudConfig.DB_URL}/shared/appLook.json?auth=$t")
                .put(body.toString().toRequestBody("application/json".toMediaType())).build()).execute().use { r ->
                if (r.isSuccessful) null else if (r.code == 401 || r.code == 403) "Not allowed: add the Firebase rule for shared/appLook, and use the owner's account." else "HTTP ${r.code}"
            }
        }.getOrElse { "Couldn't reach the cloud." }
    }
}

private object SignalOnce { var played = false }

/**
 * The Signal X mark (white X + three red waves on a dark tile), animated:
 * Broadcast — the X draws stroke by stroke, the waves ripple out once; Tune in — the waves flicker on like a signal
 * finding its connection, then the X pops; Living signal — a soft ripple every 6 s ([paused] while scrolling).
 * Plays once per app start.
 */
@Composable
fun SignalMark(size: Dp, anim: String, paused: Boolean = false, onIntroDone: () -> Unit = {}) {
    val intro = anim == "broadcast" || anim == "broadcast_living" || anim == "tune"
    val first = remember { !SignalOnce.played }
    val x1 = remember { Animatable(if (anim == "broadcast" || anim == "broadcast_living") (if (first) 0f else 1f) else 1f) }
    val x2 = remember { Animatable(x1.value) }
    val w = remember { List(3) { Animatable(if (intro && first) 0f else 1f) } }
    val pop = remember { Animatable(1f) }
    val pulse = remember { Animatable(0f) }
    val pausedNow by rememberUpdatedState(paused)
    LaunchedEffect(anim) {
        if (intro && first) {
            SignalOnce.played = true
            if (anim == "tune") {
                // Flicker: waves come and go, then lock; the X gives a small "connected" pop.
                val steps = listOf(0 to 1f, 1 to 0.7f, 2 to 0.4f, 1 to 0f, 2 to 0f, 1 to 0.7f, 2 to 0.4f)
                delay(200)
                for ((i, v) in steps) { w[i].snapTo(if (v == 0f) 0.15f else 1f); delay(180) }
                w[0].snapTo(1f)
                pop.animateTo(1.18f, tween(140)); pop.animateTo(1f, tween(200))
            } else {
                delay(150)
                x1.animateTo(1f, tween(350, easing = FastOutSlowInEasing))
                x2.animateTo(1f, tween(350, easing = FastOutSlowInEasing))
                coroutineScope {
                    w.forEachIndexed { i, a -> launch { delay(150L * i); a.animateTo(1f, tween(600, easing = FastOutSlowInEasing)) } }
                }
            }
            onIntroDone()
        } else onIntroDone()
        if (anim == "living" || anim == "broadcast_living") {
            while (true) {
                delay(6_000)
                if (pausedNow) continue
                pulse.animateTo(1f, tween(260)); pulse.animateTo(0f, tween(420))
            }
        }
    }
    val red = BrandRed
    Canvas(Modifier.size(size).graphicsLayer { scaleX = pop.value; scaleY = pop.value }) {
        val k = this.size.minDimension / 100f
        drawRoundRect(Color(0xFF121216), size = this.size, cornerRadius = CornerRadius(23f * k))
        val white = Color(0xFFF4F4F6)
        fun line(a: Offset, b: Offset, p: Float) { if (p > 0f) drawLine(white, a * k, (a + (b - a) * p) * k, 9f * k, StrokeCap.Round) }
        line(Offset(22f, 36f), Offset(46f, 64f), x1.value)
        line(Offset(22f, 64f), Offset(46f, 36f), x2.value)
        val radii = listOf(20f, 29f, 38f); val alphas = listOf(1f, 0.7f, 0.4f)
        for (i in 0..2) {
            val appear = w[i].value
            if (appear <= 0f) continue
            val sc = (0.6f + 0.4f * appear) * (1f + 0.12f * pulse.value)
            val al = (alphas[i] * appear + (1f - alphas[i]) * pulse.value * 0.6f).coerceIn(0f, 1f)
            scale(sc, pivot = Offset(34f * k, 50f * k)) {
                val r = radii[i] * k
                drawArc(red.copy(alpha = al), -40f, 80f, false, topLeft = Offset(40f * k - r, 50f * k - r), size = Size(r * 2, r * 2),
                    style = Stroke(6f * k, cap = StrokeCap.Round))
            }
        }
    }
}


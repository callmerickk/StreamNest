package com.example.streamnest

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import java.util.Locale

private enum class VState { Speaking, Listening, Thinking, Answer, Error }

/** The round glowing AI button that sits next to the TV / Movies capsule. */
@Composable
fun AiOrbButton(size: androidx.compose.ui.unit.Dp = 54.dp, onClick: () -> Unit) {
    val spin = rememberInfiniteTransition(label = "orb")
    val angle by spin.animateFloat(0f, 360f, infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "angle")
    Box(
        Modifier.size(size).clip(CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFF1F3B8A), Color(0xFF4A1E6E))))
            .border(1.dp, Color(0x40FFFFFF), CircleShape)
            .clickable(onClick = onClick),
        Alignment.Center,
    ) {
        Canvas(Modifier.size(size * 0.62f).graphicsLayer { rotationZ = angle }) {
            val r = this.size.minDimension / 2f
            val colors = listOf(Palette.accent, Palette.accent2, Color(0xFF6FB6FF), Palette.accent)
            drawCircle(Brush.sweepGradient(colors), radius = r * 0.92f, style = Stroke(width = r * 0.22f))
            drawCircle(Brush.radialGradient(listOf(Color.White, Color.White.copy(alpha = 0f)), radius = r * 0.55f), radius = r * 0.55f)
        }
    }
}

/**
 * Full-screen voice mode. Asks "What's your mood today?", listens, then shows matching titles.
 * Uses the phone's own speech recognition and text-to-speech (free, no account or key needed).
 */
@Composable
fun VoiceAssistant(vm: AppViewModel, onClose: () -> Unit, onOpen: (Meta) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val main = remember { Handler(Looper.getMainLooper()) }
    val profile by vm.current.collectAsState()

    var state by remember { mutableStateOf(VState.Speaking) }
    var caption by remember { mutableStateOf("") }
    var heard by remember { mutableStateOf("") }
    var level by remember { mutableFloatStateOf(0f) }
    var answer by remember { mutableStateOf<VoiceAnswer?>(null) }
    var firstTurn by remember { mutableStateOf(true) }

    // A brand-new recognizer is created for every question; reusing one is what crashed on some phones.
    val holder = remember { arrayOfNulls<SpeechRecognizer>(1) }
    val alive = remember { java.util.concurrent.atomic.AtomicBoolean(true) }
    var listener by remember { mutableStateOf<RecognitionListener?>(null) }
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsReady by remember { mutableStateOf(false) }

    fun dropRecognizer() {
        holder[0]?.let { r -> runCatching { r.cancel() }; runCatching { r.destroy() } }
        holder[0] = null
    }

    fun listen() {
        if (!alive.get()) return
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { state = VState.Error; caption = "Voice recognition isn't available on this phone."; return }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            state = VState.Error; caption = "Allow microphone access to talk to me."; return
        }
        dropRecognizer()
        heard = ""
        state = VState.Listening
        try {
            val r = SpeechRecognizer.createSpeechRecognizer(ctx)
            holder[0] = r
            listener?.let { r.setRecognitionListener(it) }
            r.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            )
        } catch (e: Exception) {
            state = VState.Error; caption = "The microphone is busy. Tap to try again."
        }
    }

    /** Speak a sentence, then optionally start listening when it finishes. */
    fun say(text: String, thenListen: Boolean) {
        caption = text
        val t = tts
        if (t == null || !ttsReady) { if (thenListen) listen(); return }
        val id = "sn_${System.nanoTime()}"
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { if (thenListen && utteranceId == id) main.post { if (alive.get()) listen() } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { if (thenListen && utteranceId == id) main.post { if (alive.get()) listen() } }
        })
        if (thenListen) state = VState.Speaking
        try { t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id) } catch (e: Exception) { if (thenListen) listen() }
    }

    fun handle(text: String) {
        heard = text
        state = VState.Thinking
        caption = "Got it…"
        scope.launch {
            val a = try { vm.interpret(text) } catch (e: Exception) { VoiceAnswer("Sorry, something went wrong. Please try again.", "", emptyList()) }
            if (!alive.get()) return@launch
            answer = a
            state = VState.Answer
            say(a.say, thenListen = false)
        }
    }

    fun greet() {
        val name = profile?.name?.takeIf { it.isNotBlank() && it != "Me" }
        val q = if (firstTurn) "Hi${if (name != null) " $name" else ""}! What's your mood today?" else "What would you like to watch?"
        firstTurn = false
        answer = null
        say(q, thenListen = true)
    }

    val askMic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) greet() else { state = VState.Error; caption = "Allow microphone access to talk to me." }
    }

    DisposableEffect(Unit) {
        listener = (object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { level = 0f }
            override fun onError(error: Int) {
                level = 0f
                if (state == VState.Listening) {
                    state = VState.Error
                    caption = if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
                        "I didn't catch that. Tap the mic and try again." else "Something went wrong with the microphone. Tap to try again."
                }
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) { state = VState.Error; caption = "I didn't catch that. Tap the mic and try again." } else handle(text)
            }
            override fun onPartialResults(partial: Bundle?) {
                partial?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { if (it.isNotBlank()) heard = it }
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val engine = TextToSpeech(ctx) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            main.post {
                if (!alive.get()) return@post
                if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) greet()
                else askMic.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
        runCatching { engine.language = Locale.getDefault() }
        tts = engine
        onDispose {
            alive.set(false)
            dropRecognizer()
            runCatching { engine.stop(); engine.shutdown() }
        }
    }

    BackHandler { onClose() }

    // ── UI ──
    val pulse = rememberInfiniteTransition(label = "pulse")
    val breathe by pulse.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b")
    val spin by pulse.animateFloat(0f, 360f, infiniteRepeatable(tween(if (state == VState.Thinking) 1200 else 5000, easing = LinearEasing)), label = "s")
    val orbScale = if (state == VState.Listening) 1f + level * 0.35f else breathe

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xF2050710), Color(0xF7140A1C), Color(0xFA050710))))
            .clickable(enabled = false) {},
    ) {
        Icon(
            Icons.Default.Close, "Close",
            Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(12.dp).size(44.dp).clip(CircleShape).clickable(onClick = onClose).padding(10.dp),
        )
        val shownAnswer = answer
        val showResults = state == VState.Answer && shownAnswer != null && shownAnswer.items.isNotEmpty()
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(top = 56.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // Orb
            Box(Modifier.padding(top = if (showResults) 0.dp else 90.dp).size(if (showResults) 110.dp else 200.dp), Alignment.Center) {
                Canvas(Modifier.fillMaxSize().graphicsLayer { scaleX = orbScale; scaleY = orbScale; rotationZ = spin }) {
                    val r = size.minDimension / 2f
                    drawCircle(Brush.radialGradient(listOf(Palette.accent.copy(alpha = 0.45f), Color.Transparent), radius = r), radius = r)
                    drawCircle(Brush.sweepGradient(listOf(Palette.accent, Palette.accent2, Color(0xFF6FB6FF), Color(0xFF9B5CFF), Palette.accent)), radius = r * 0.62f)
                    drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.95f), Color.White.copy(alpha = 0f)), radius = r * 0.5f), radius = r * 0.5f)
                }
                if (state == VState.Thinking) CircularProgressIndicator(Modifier.size(if (showResults) 120.dp else 214.dp), color = Color.White.copy(alpha = 0.6f), strokeWidth = 2.dp)
            }
            Spacer(Modifier.height(20.dp))
            Text(
                when (state) {
                    VState.Listening -> heard.ifBlank { "Listening…" }
                    VState.Thinking -> "“$heard”"
                    else -> caption
                },
                Modifier.padding(horizontal = 28.dp), fontSize = if (showResults) 18.sp else 22.sp, fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center, color = if (state == VState.Listening && heard.isBlank()) Color(0xFF9AA3B5) else Color.White,
            )
            if (state == VState.Speaking || (state == VState.Listening && heard.isBlank())) {
                Text("Try “I'm happy”, “something scary” or “play Marvel movies”", Modifier.padding(top = 10.dp, start = 28.dp, end = 28.dp),
                    fontSize = 14.sp, color = Color(0xFF8A94A8), textAlign = TextAlign.Center)
            }
            if (showResults) {
                Text(shownAnswer!!.title, Modifier.fillMaxWidth().padding(start = 16.dp, top = 18.dp, bottom = 8.dp), fontSize = 20.sp, fontWeight = FontWeight.Bold)
                LazyVerticalGrid(
                    GridCells.Adaptive(105.dp), Modifier.weight(1f), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 100.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp),
                ) { items(shownAnswer.items.distinctBy { it.type + it.id }, key = { it.type + it.id }) { m -> Poster(m, Modifier.fillMaxWidth()) { onOpen(it) } } }
            } else Spacer(Modifier.weight(1f))
        }
        // Mic button to talk again
        if (state == VState.Answer || state == VState.Error) {
            Box(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 24.dp).size(66.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Palette.accent, Palette.accent2))).clickable {
                        runCatching { tts?.stop() }
                        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) greet()
                        else askMic.launch(Manifest.permission.RECORD_AUDIO)
                    },
                Alignment.Center,
            ) { Icon(Icons.Default.Mic, "Talk again", Modifier.size(30.dp), tint = OnAccent) }
        }
    }
}

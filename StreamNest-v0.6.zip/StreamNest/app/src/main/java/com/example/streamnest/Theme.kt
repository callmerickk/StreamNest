package com.example.streamnest

import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

val Bg: Color get() = Palette.bg
val Accent: Color get() = Palette.accent
val Surface1 = Color(0xFF161B26)

// Rounded wordmark font used for the app name (Poppins, free Google font).
val BrandFont = FontFamily(
    Font(R.font.poppins_medium, FontWeight.Medium),
    Font(R.font.poppins_bold, FontWeight.Bold),
)

@Composable
fun StreamNestTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, onPrimary = OnAccent,
            background = Bg, surface = Bg, surfaceVariant = Surface1,
            onBackground = Color.White, onSurface = Color.White, onSurfaceVariant = Color(0xFFB6BDCC),
        ),
    ) {
        // Every Text/Icon defaults to white, so nothing renders black on the dark background.
        CompositionLocalProvider(LocalContentColor provides Color.White, content = content)
    }
}

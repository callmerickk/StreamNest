package com.example.streamnest

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import java.io.File
import androidx.compose.ui.graphics.Color
import kotlinx.serialization.json.JsonArray
import java.security.MessageDigest
import java.security.SecureRandom

const val CINEMETA = "https://v3-cinemeta.strem.io"

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context get() = getApplication<Application>()
    private val sp = app.getSharedPreferences("addons", Context.MODE_PRIVATE)
    // "library" holds app-wide settings (custom texts, playlist) and also the FIRST profile's watch data,
    // so everything saved by older versions carries over into profile 1 automatically.
    private val glob = app.getSharedPreferences("library", Context.MODE_PRIVATE)
    private val dev = app.getSharedPreferences("dev", Context.MODE_PRIVATE)

    val addons = MutableStateFlow<List<Addon>>(emptyList())
    val shelves = MutableStateFlow<List<Shelf>>(emptyList())
    val loading = MutableStateFlow(true)
    val searchResults = MutableStateFlow<List<Meta>>(emptyList())
    val addError = MutableStateFlow<String?>(null)
    private var searchJob: Job? = null

    val texts = MutableStateFlow(
        glob.getString("custom", null)?.let { runCatching { Api.json.decodeFromString<Map<String, String>>(it) }.getOrNull() } ?: emptyMap()
    )

    // bumped whenever the app logo changes, so screens reload it
    val imgVersion = MutableStateFlow(0)

    // ───────────── Profiles ─────────────
    val profiles = MutableStateFlow(loadProfiles())
    /** null until someone is picked on the "Who's watching?" screen */
    val current = MutableStateFlow<Profile?>(null)

    private var lib: SharedPreferences = glob
    val progress = MutableStateFlow<List<Progress>>(emptyList())
    val myList = MutableStateFlow<List<Meta>>(emptyList())
    val doneKeys = MutableStateFlow<Set<String>>(emptySet())
    val doneMs = MutableStateFlow(0L)

    private fun loadProfiles(): List<Profile> {
        val saved = glob.getString("profiles", null)?.let { runCatching { Api.json.decodeFromString<List<Profile>>(it) }.getOrNull() }
        if (!saved.isNullOrEmpty()) return saved
        // First run of this version: turn the existing user into profile 1 and add a Kids profile.
        val oldName = texts.value["profileName"]?.takeIf { it.isNotBlank() && it != "Guest" } ?: "Me"
        val oldAvatar = File(ctx.filesDir, "profile_avatar.img")
        val p1 = Profile("p1", oldName, avatar = if (oldAvatar.exists()) "img" else "")
        if (oldAvatar.exists()) oldAvatar.renameTo(avatarFile(p1))
        val list = listOf(p1, Profile("kids", "Kids", kids = true))
        glob.edit().putString("profiles", Api.json.encodeToString(list)).apply()
        return list
    }

    private fun saveProfiles(list: List<Profile>) {
        profiles.value = list
        glob.edit().putString("profiles", Api.json.encodeToString(list)).apply()
        current.value?.let { c -> current.value = list.firstOrNull { it.id == c.id } }
    }

    private fun prefsFor(p: Profile): SharedPreferences =
        if (p.id == "p1") glob else ctx.getSharedPreferences("library_${p.id}", Context.MODE_PRIVATE)

    fun selectProfile(p: Profile) {
        if (texts.value["lastProfile"] != p.id) setText("lastProfile", p.id)
        val wasKids = current.value?.kids
        current.value = p
        lib = prefsFor(p)
        progress.value = lib.getString("progress", null)?.let { runCatching { Api.json.decodeFromString<List<Progress>>(it) }.getOrNull() } ?: emptyList()
        myList.value = lib.getString("mylist", null)?.let { runCatching { Api.json.decodeFromString<List<Meta>>(it) }.getOrNull() } ?: emptyList()
        doneKeys.value = lib.getStringSet("done", emptySet())?.toSet() ?: emptySet()
        doneMs.value = lib.getLong("doneMs", 0L)
        if (wasKids != p.kids || shelves.value.isEmpty()) refresh()
    }

    /** Back to the "Who's watching?" screen. */
    fun leaveProfile() { current.value = null }

    fun addProfile(name: String, kids: Boolean): Profile {
        val p = Profile("p" + System.currentTimeMillis(), name.trim().ifEmpty { "Profile" }, kids)
        saveProfiles(profiles.value + p)
        return p
    }

    fun renameProfile(p: Profile, name: String, kids: Boolean) {
        val kidsChanged = p.kids != kids
        saveProfiles(profiles.value.map { if (it.id == p.id) it.copy(name = name.trim().ifEmpty { it.name }, kids = kids) else it })
        if (kidsChanged && current.value?.id == p.id) refresh()
    }

    fun deleteProfile(p: Profile) {
        if (profiles.value.size <= 1) return
        avatarFile(p).delete()
        if (p.id != "p1") ctx.deleteSharedPreferences("library_${p.id}")
        else glob.edit().remove("progress").remove("mylist").remove("done").remove("doneMs").apply()
        saveProfiles(profiles.value.filter { it.id != p.id })
        if (current.value?.id == p.id) current.value = null
    }

    fun avatarFile(p: Profile) = File(ctx.filesDir, "avatar_${p.id}")

    /** Copies the picked picture / GIF / video. Returns an error message, or null when it worked. */
    suspend fun setAvatar(p: Profile, uri: Uri): String? = withContext(Dispatchers.IO) {
        val type = ctx.contentResolver.getType(uri).orEmpty()
        val kind = when {
            type.startsWith("video/") -> "video"
            type == "image/gif" -> "gif"
            type.startsWith("image/") -> "img"
            else -> return@withContext "Pick a JPEG, PNG, GIF or a short video"
        }
        if (kind == "video") {
            val ms = runCatching {
                MediaMetadataRetriever().run {
                    setDataSource(ctx, uri)
                    val d = extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    release(); d
                }
            }.getOrDefault(0L)
            if (ms > 15_500) return@withContext "Video must be 15 seconds or shorter"
        }
        val size = runCatching { ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L }.getOrDefault(-1L)
        if (size > 25L * 1024 * 1024) return@withContext "File is too big (max 25 MB)"
        try {
            ctx.contentResolver.openInputStream(uri)!!.use { i -> avatarFile(p).outputStream().use { o -> i.copyTo(o) } }
        } catch (e: Exception) {
            return@withContext "Couldn't read that file"
        }
        withContext(Dispatchers.Main) {
            saveProfiles(profiles.value.map { if (it.id == p.id) it.copy(avatar = kind, ver = it.ver + 1) else it })
        }
        null
    }

    fun clearAvatar(p: Profile) {
        avatarFile(p).delete()
        saveProfiles(profiles.value.map { if (it.id == p.id) it.copy(avatar = "", ver = it.ver + 1) else it })
    }

    // ───────────── Custom texts & colors ─────────────
    init {
        applyPalette()
        Api.setDns(texts.value["dns"] ?: "system")
    }

    fun setDns(provider: String) {
        setText("dns", provider)
        Api.setDns(provider)
        refresh()
    }

    private fun applyPalette() {
        val m = Defaults + texts.value
        parseColor(m["accent"]!!)?.let { Palette.accent = it }
        parseColor(m["background"]!!)?.let { Palette.bg = it }
        parseColor(m["deckTint"]!!)?.let { Palette.tint = it }
        parseColor(m["accent2"]!!)?.let { Palette.accent2 = it }
        if (isOn(m["amoled"]!!)) Palette.bg = Color.Black
        m["cardCorner"]!!.trim().toIntOrNull()?.let { Palette.corner = it.coerceIn(0, 50) }
    }

    fun setText(key: String, value: String) {
        texts.value = texts.value + (key to value)
        glob.edit().putString("custom", Api.json.encodeToString(texts.value)).apply()
        applyPalette()
    }

    fun resetTexts() {
        texts.value = emptyMap()
        glob.edit().remove("custom").apply()
        applyPalette()
    }

    // ───────────── Watch data (per profile) ─────────────
    fun saveProgress(p: Progress) {
        if (p.positionMs < 10_000) return
        val others = progress.value.filter { it.key != p.key }
        val done = p.durationMs > 0 && p.positionMs > p.durationMs * 0.95
        progress.value = (if (done) others else listOf(p) + others).take(20)
        val ed = lib.edit().putString("progress", Api.json.encodeToString(progress.value))
        if (done && p.key !in doneKeys.value) {
            doneKeys.value = doneKeys.value + p.key
            doneMs.value = doneMs.value + p.durationMs
            ed.putStringSet("done", doneKeys.value).putLong("doneMs", doneMs.value)
        }
        ed.apply()
    }

    fun removeProgress(key: String) {
        progress.value = progress.value.filter { it.key != key }
        lib.edit().putString("progress", Api.json.encodeToString(progress.value)).apply()
    }

    fun clearHistory() {
        progress.value = emptyList()
        doneKeys.value = emptySet()
        doneMs.value = 0L
        lib.edit().remove("progress").remove("done").remove("doneMs").apply()
    }

    fun toggleList(m: Meta) {
        val cur = myList.value
        myList.value = if (cur.any { it.id == m.id }) cur.filter { it.id != m.id } else listOf(m) + cur
        lib.edit().putString("mylist", Api.json.encodeToString(myList.value)).apply()
    }

    // ───────────── Addons & catalogs ─────────────
    init {
        viewModelScope.launch {
            val saved = sp.getString("list", null)?.let {
                runCatching { Api.json.decodeFromString<List<Addon>>(it) }.getOrNull()
            }
            val list = saved ?: runCatching {
                listOf(Addon(CINEMETA, Api.fetch<Manifest>("$CINEMETA/manifest.json")))
            }.getOrDefault(emptyList())
            setAddons(list)
            if (current.value != null) refresh()
        }
    }

    /** Addons switched on in Help & Settings > Content & Discovery > Addons. */
    private val active: List<Addon> get() {
        val off = texts.value["addonsOff"].orEmpty().split("|").filter { it.isNotBlank() }.toSet()
        return addons.value.filter { it.baseUrl !in off }
    }

    fun isAddonOn(a: Addon) = a.baseUrl !in texts.value["addonsOff"].orEmpty().split("|")

    fun toggleAddon(a: Addon) {
        val off = texts.value["addonsOff"].orEmpty().split("|").filter { it.isNotBlank() }.toMutableSet()
        if (!off.add(a.baseUrl)) off.remove(a.baseUrl)
        setText("addonsOff", off.joinToString("|"))
        refresh()
    }

    fun moveAddon(a: Addon, by: Int) {
        val list = addons.value.toMutableList()
        val i = list.indexOf(a)
        val j = (i + by).coerceIn(0, list.lastIndex)
        if (i < 0 || i == j) return
        list.removeAt(i); list.add(j, a)
        setAddons(list)
        refresh()
    }

    fun reloadAddon(a: Addon) {
        viewModelScope.launch {
            runCatching { Api.fetch<Manifest>("${a.baseUrl}/manifest.json") }.onSuccess { m ->
                setAddons(addons.value.map { if (it.baseUrl == a.baseUrl) Addon(a.baseUrl, m) else it })
                refresh()
            }
        }
    }

    fun resourceCount(a: Addon) = (a.manifest.resources as? JsonArray)?.size ?: 0

    val appVersion: String get() = runCatching {
        val pi = ctx.packageManager.getPackageInfo(ctx.packageName, 0)
        "${pi.versionName} (${pi.versionCode})"
    }.getOrDefault("")

    private fun setAddons(list: List<Addon>) {
        addons.value = list
        if (list.isNotEmpty()) sp.edit().putString("list", Api.json.encodeToString(list)).apply()
    }

    private fun enc(id: String) = Uri.encode(id, ":")

    private fun typeLabel(type: String) = when (type) {
        "movie" -> "Movies"
        "series" -> "Series"
        else -> type.replaceFirstChar { it.uppercase() }
    }

    private var refreshJob: Job? = null

    fun refresh() {
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch {
            loading.value = true
            val result = if (current.value?.kids == true) kidsShelves() else coroutineScope {
                active.flatMap { a ->
                    a.manifest.catalogs
                        .filter { c -> c.extra.orEmpty().none { it.isRequired } }
                        .map { c ->
                            async {
                                runCatching {
                                    val items = Api.fetch<CatalogResponse>("${a.baseUrl}/catalog/${c.type}/${enc(c.id)}.json").metas
                                    Shelf("${c.name ?: c.id} ${typeLabel(c.type)}", items)
                                }.getOrNull()
                            }
                        }
                }.take(14).awaitAll()
            }
            shelves.value = result.filterNotNull().filter { it.items.isNotEmpty() }
            loading.value = false
        }
    }

    // Kids profile: only animation & family catalogs from Cinemeta.
    private suspend fun kidsShelves(): List<Shelf?> = coroutineScope {
        listOf(
            Triple("movie", "Animation", "Animated Movies"),
            Triple("series", "Animation", "Cartoons & Animated Series"),
            Triple("movie", "Family", "Family Movies"),
        ).map { (type, genre, title) ->
            async {
                runCatching {
                    Shelf(title, Api.fetch<CatalogResponse>("$CINEMETA/catalog/$type/top/genre=$genre.json").metas)
                }.getOrNull()
            }
        }.awaitAll()
    }

    fun addAddon(input: String) {
        viewModelScope.launch {
            addError.value = null
            val base = Api.normalize(input)
            if (addons.value.any { it.baseUrl == base }) { addError.value = "Already installed"; return@launch }
            try {
                val m = Api.fetch<Manifest>("$base/manifest.json")
                setAddons(addons.value + Addon(base, m))
                refresh()
            } catch (e: Exception) {
                addError.value = "Couldn't load addon: ${e.message}"
            }
        }
    }

    fun removeAddon(a: Addon) {
        setAddons(addons.value - a)
        if (addons.value.isEmpty()) sp.edit().remove("list").apply()
        refresh()
    }

    fun search(q: String) {
        searchJob?.cancel()
        if (q.length < 2) { searchResults.value = emptyList(); return }
        searchJob = viewModelScope.launch {
            delay(400)
            val res = coroutineScope {
                active.flatMap { a ->
                    a.manifest.catalogs.filter { c -> c.extra.orEmpty().any { it.name == "search" } }.map { c ->
                        async {
                            runCatching {
                                Api.fetch<CatalogResponse>("${a.baseUrl}/catalog/${c.type}/${enc(c.id)}/search=${Uri.encode(q)}.json").metas
                            }.getOrDefault(emptyList())
                        }
                    }
                }.awaitAll().flatten()
            }
            searchResults.value = res.distinctBy { it.type + it.id }
        }
    }

    suspend fun fullMeta(m: Meta): Meta? {
        for (a in active.filter { it.supports("meta", m.type, m.id) }) {
            val r = runCatching { Api.fetch<MetaResponse>("${a.baseUrl}/meta/${m.type}/${enc(m.id)}.json").meta }.getOrNull()
            if (r != null) return r
        }
        return null
    }

    suspend fun streams(type: String, id: String): List<StreamItem> = coroutineScope {
        active.filter { it.supports("stream", type, id) }.map { a ->
            async {
                runCatching {
                    Api.fetch<StreamResponse>("${a.baseUrl}/stream/$type/${enc(id)}.json").streams
                        .filter { !it.url.isNullOrBlank() }.map { StreamItem(a.manifest.name, it) }
                }.getOrDefault(emptyList())
            }
        }.awaitAll().flatten()
    }

    suspend fun subtitles(type: String, id: String): List<Subtitle> = coroutineScope {
        active.filter { it.supports("subtitles", type, id) }.map { a ->
            async {
                runCatching { Api.fetch<SubsResponse>("${a.baseUrl}/subtitles/$type/${enc(id)}.json").subtitles }
                    .getOrDefault(emptyList())
            }
        }.awaitAll().flatten()
    }

    // ───────────── App logo (Developer's Corner) ─────────────
    fun logoFile() = File(ctx.filesDir, "app_logo.img")

    fun setLogo(uri: Uri) {
        runCatching {
            ctx.contentResolver.openInputStream(uri)!!.use { i -> logoFile().outputStream().use { o -> i.copyTo(o) } }
        }
        imgVersion.value = imgVersion.value + 1
    }

    fun clearLogo() { logoFile().delete(); imgVersion.value = imgVersion.value + 1 }

    // ───────────── Developer's Corner password (salted hash, never stored as plain text) ─────────────
    private fun hashPw(salt: String, pw: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        var d = (salt + pw).toByteArray()
        repeat(5000) { d = md.digest(d) }
        return d.joinToString("") { "%02x".format(it) }
    }

    private fun newSalt() = ByteArray(16).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }

    private fun ensureDevPassword() {
        if (dev.contains("hash")) return
        val salt = newSalt()
        dev.edit().putString("salt", salt).putString("hash", hashPw(salt, "Anish@2007")).apply()
    }

    fun checkDevPassword(pw: String): Boolean {
        ensureDevPassword()
        return hashPw(dev.getString("salt", "") ?: "", pw) == dev.getString("hash", "")
    }

    fun changeDevPassword(old: String, new: String): Boolean {
        if (!checkDevPassword(old)) return false
        val salt = newSalt()
        dev.edit().putString("salt", salt).putString("hash", hashPw(salt, new)).apply()
        return true
    }

    // ───────────── Live TV (M3U playlist) ─────────────
    val channels = MutableStateFlow<List<Channel>>(emptyList())
    val tvUrl = MutableStateFlow(glob.getString("m3u", "") ?: "")
    val tvLoading = MutableStateFlow(false)
    val tvError = MutableStateFlow<String?>(null)

    fun loadChannels(url: String) {
        viewModelScope.launch {
            tvLoading.value = true
            tvError.value = null
            try {
                val list = parseM3u(Api.get(url.trim()))
                if (list.isEmpty()) {
                    tvError.value = "No channels found in that playlist"
                } else {
                    channels.value = list
                    tvUrl.value = url.trim()
                    glob.edit().putString("m3u", url.trim()).apply()
                }
            } catch (e: Exception) {
                tvError.value = "Couldn't load playlist: ${e.message}"
            }
            tvLoading.value = false
        }
    }

    fun clearChannels() {
        channels.value = emptyList()
        tvUrl.value = ""
        tvError.value = null
        glob.edit().remove("m3u").apply()
    }

    init { if (tvUrl.value.isNotBlank()) loadChannels(tvUrl.value) }

    // ───────────── Voice assistant brain (works offline, no API key) ─────────────
    suspend fun searchNow(q: String): List<Meta> = coroutineScope {
        active.flatMap { a ->
            a.manifest.catalogs.filter { c -> c.extra.orEmpty().any { it.name == "search" } }.map { c ->
                async {
                    runCatching {
                        Api.fetch<CatalogResponse>("${a.baseUrl}/catalog/${c.type}/${enc(c.id)}/search=${Uri.encode(q)}.json").metas
                    }.getOrDefault(emptyList())
                }
            }
        }.awaitAll().flatten().distinctBy { it.type + it.id }
    }

    suspend fun genreTitles(genres: List<String>, types: List<String>): List<Meta> = coroutineScope {
        val lists = genres.take(3).flatMap { g ->
            types.map { type ->
                async {
                    runCatching { Api.fetch<CatalogResponse>("$CINEMETA/catalog/$type/top/genre=${Uri.encode(g)}.json").metas }
                        .getOrDefault(emptyList())
                }
            }
        }.awaitAll()
        val out = ArrayList<Meta>()
        for (i in 0 until (lists.maxOfOrNull { it.size } ?: 0)) lists.forEach { l -> l.getOrNull(i)?.let { out.add(it) } }
        out.distinctBy { it.id }.take(40)
    }

    suspend fun interpret(heard: String): VoiceAnswer {
        val text = heard.lowercase().trim()
        val types = when {
            Regex("\\b(movie|movies|film|films)\\b").containsMatchIn(text) -> listOf("movie")
            Regex("\\b(series|tv shows?|shows|seasons?|episodes?)\\b").containsMatchIn(text) -> listOf("series")
            else -> listOf("movie", "series")
        }
        val command = Regex("^(please )?(play|show me|show|search for|search|find|look for|i want to watch|i wanna watch|put on|watch|open|start)\\s+(.*)$").find(text)
        val genre = Voice.genres.entries.firstOrNull { (k, _) -> Regex("\\b$k\\b").containsMatchIn(text) }?.value
        val mood = Voice.moods.firstOrNull { m -> m.words.any { Regex("\\b$it\\b").containsMatchIn(text) } }
        return when {
            genre != null && (command != null || text.split(" ").size <= 4) -> {
                val items = genreTitles(listOf(genre), types)
                VoiceAnswer("Here are some ${genre.lowercase()} picks.", "$genre ${Voice.typeWord(types)}", items)
            }
            mood != null && (command == null || Regex("\\b(something|anything|feel|feeling|mood)\\b").containsMatchIn(text)) -> {
                val items = genreTitles(mood.genres, types)
                VoiceAnswer(mood.reply, mood.title, items)
            }
            else -> {
                var q = (command?.groupValues?.get(3) ?: text)
                    .replace(Regex("\\b(the )?(movies|movie|films|film|series|shows|show|please|for me|some)\\b"), " ")
                    .replace(Regex("\\s+"), " ").trim()
                if (q.isBlank()) q = text
                val items = searchNow(q).let { r -> if (types.size == 1) r.filter { it.type == types[0] }.ifEmpty { r } else r }
                if (items.isEmpty()) VoiceAnswer("Sorry, I couldn't find anything for $q. Try saying it another way.", "No results for \"$q\"", emptyList())
                else VoiceAnswer("Here's what I found for $q.", "Results for \"$q\"", items)
            }
        }
    }

    // ───────────── Card trailers ─────────────
    private val trailerCache = HashMap<String, String?>()

    /** YouTube id of the title's trailer (from Cinemeta), or null. */
    suspend fun trailerId(m: Meta): String? {
        if (trailerCache.containsKey(m.id)) return trailerCache[m.id]
        val full = if (m.trailerStreams != null || m.trailers != null) m else fullMeta(m)
        val id = full?.trailerStreams?.firstOrNull { !it.ytId.isNullOrBlank() }?.ytId
            ?: full?.trailers?.firstOrNull { it.type.equals("Trailer", true) && !it.source.isNullOrBlank() }?.source
            ?: full?.trailers?.firstOrNull { !it.source.isNullOrBlank() }?.source
        trailerCache[m.id] = id
        return id
    }

    // ───────────── Player helpers ─────────────
    /** Intro / recap / outro times for a movie ("tt123") or episode ("tt123:1:2") from introdb.app. */
    suspend fun segments(key: String): Segments? {
        val parts = key.split(":")
        val imdb = parts[0]
        if (!imdb.startsWith("tt")) return null
        val url = if (parts.size >= 3) "https://api.introdb.app/segments?imdb_id=$imdb&season=${parts[1]}&episode=${parts[2]}"
        else "https://api.introdb.app/segments?imdb_id=$imdb"
        val r = runCatching { Api.fetch<Segments>(url) }.getOrNull() ?: return null
        // Only trust data for exactly this episode / movie.
        if (parts.size >= 3) {
            if (r.season != null && r.season != parts[1].toIntOrNull()) return null
            if (r.episode != null && r.episode != parts[2].toIntOrNull()) return null
        } else if (r.is_movie == false) return null
        // Drop doubtful or impossible ranges (too short, too long, low confidence).
        fun ok(sg: Seg?) = sg?.takeIf { it.end_ms - it.start_ms in 5_000..600_000 && it.start_ms >= 0 && it.confidence >= 0.5 }
        return Segments(ok(r.intro), ok(r.recap), r.outro?.takeIf { it.start_ms > 0 && it.confidence >= 0.5 }, r.is_movie, r.season, r.episode)
    }

    private val guideCache = HashMap<String, List<Pair<String, String>>>()

    /**
     * Content advisory (Violence, Profanity...) read from the title's public IMDb parental guide page.
     * Best effort: returns an empty list if the page can't be read or has no ratings.
     */
    suspend fun parentalGuide(imdbId: String): List<Pair<String, String>> {
        if (!imdbId.startsWith("tt")) return emptyList()
        guideCache[imdbId]?.let { return it }
        val html = runCatching {
            Api.getWith(
                "https://www.imdb.com/title/$imdbId/parentalguide",
                mapOf(
                    "User-Agent" to "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36",
                    "Accept-Language" to "en-US,en;q=0.9",
                ),
            )
        }.getOrNull() ?: return emptyList()
        val cats = listOf(
            "Violence" to listOf("Violence & Gore", "Violence &amp; Gore"),
            "Profanity" to listOf("Profanity"),
            "Frightening" to listOf("Frightening & Intense Scenes", "Frightening &amp; Intense Scenes"),
            "Nudity" to listOf("Sex & Nudity", "Sex &amp; Nudity"),
            "Alcohol/Drugs" to listOf("Alcohol, Drugs & Smoking", "Alcohol, Drugs &amp; Smoking"),
        )
        val sev = Regex("\\b(None|Mild|Moderate|Severe)\\b")
        val out = cats.mapNotNull { (label, heads) ->
            val at = heads.map { html.indexOf(it) }.filter { it >= 0 }.minOrNull() ?: return@mapNotNull null
            val level = sev.find(html.substring(at, minOf(html.length, at + 4000)))?.value ?: return@mapNotNull null
            if (level == "None") null else label to level
        }
        guideCache[imdbId] = out
        return out
    }

    /** Picks a stream automatically according to Help & Settings > Playback > Auto Stream Selection. */
    fun autoPick(list: List<StreamItem>, mode: String, pattern: String, preferAddon: String? = null): StreamItem? {
        if (list.isEmpty()) return null
        preferAddon?.let { a -> list.firstOrNull { it.addonName == a || it.stream.name == a }?.let { return it } }
        return when (mode) {
            "first" -> list.first()
            "regex" -> {
                val r = runCatching { Regex(pattern) }.getOrNull()
                if (r == null || pattern.isBlank()) list.first()
                else list.firstOrNull { s ->
                    r.containsMatchIn(listOfNotNull(s.stream.name, s.stream.title, s.stream.description, s.addonName, s.stream.url).joinToString(" "))
                } ?: list.first()
            }
            else -> null
        }
    }

    // Open the last profile straight away when "Remember last profile" is on.
    init {
        if (isOn(texts.value["rememberProfile"] ?: "no")) {
            profiles.value.firstOrNull { it.id == texts.value["lastProfile"] }?.let { selectProfile(it) }
        }
    }
}

private val logoRe = Regex("tvg-logo=\"([^\"]*)\"")
private val groupRe = Regex("group-title=\"([^\"]*)\"")

fun parseM3u(text: String): List<Channel> {
    val out = ArrayList<Channel>()
    var name: String? = null
    var logo: String? = null
    var group: String? = null
    for (raw in text.lineSequence()) {
        val line = raw.trim()
        if (line.startsWith("#EXTINF")) {
            name = line.substringAfterLast(",").trim()
            logo = logoRe.find(line)?.groupValues?.get(1)?.takeIf { it.isNotBlank() }
            group = groupRe.find(line)?.groupValues?.get(1)?.takeIf { it.isNotBlank() }
        } else if (line.isNotEmpty() && !line.startsWith("#") && name != null) {
            out.add(Channel(name.ifBlank { line }, logo, group, line))
            name = null
        }
    }
    return out
}

/** Cinemeta's own image host gives wide backdrops and title logos for any IMDb id. */
fun backdropOf(m: Meta): String? = m.background
    ?: if (m.id.startsWith("tt")) "https://images.metahub.space/background/medium/${m.id.substringBefore(':')}/img" else m.poster

fun logoOf(m: Meta): String? = m.logo
    ?: if (m.id.startsWith("tt")) "https://images.metahub.space/logo/medium/${m.id.substringBefore(':')}/img" else null

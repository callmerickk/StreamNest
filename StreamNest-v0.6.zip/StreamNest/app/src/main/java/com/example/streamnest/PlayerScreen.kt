package com.example.streamnest

import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Typeface
import android.net.Uri
import android.util.TypedValue
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.media3.ui.SubtitleView
import androidx.media3.common.text.Cue
import androidx.media3.common.text.CueGroup
import android.media.AudioManager
import android.view.View
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private fun subMime(url: String) = when {
    url.contains(".vtt", true) -> MimeTypes.TEXT_VTT
    url.contains(".ass", true) || url.contains(".ssa", true) -> MimeTypes.TEXT_SSA
    else -> MimeTypes.APPLICATION_SUBRIP
}

private fun fmt(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

/** Opens a stream in another installed player (VLC, MX Player…) through Android's app chooser. */
fun openExternal(ctx: android.content.Context, url: String, title: String) {
    try {
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(url), "video/*").putExtra("title", title)
        ctx.startActivity(Intent.createChooser(i, "Open with"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "No other video player found", Toast.LENGTH_SHORT).show()
    }
}

private data class TrackOpt(val label: String, val group: Tracks.Group, val index: Int, val selected: Boolean)

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    vm: AppViewModel,
    p: Screen.Player,
    onBack: () -> Unit,
    onReplace: (Screen.Player) -> Unit,
    onProgress: (Long, Long) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val texts by vm.texts.collectAsState()
    fun opt(k: String) = texts[k] ?: Defaults[k] ?: ""

    val type = p.type.ifBlank { if (p.key.contains(":")) "series" else "movie" }
    var meta by remember { mutableStateOf(p.meta) }
    var tracks by remember { mutableStateOf(Tracks.EMPTY) }
    var playing by remember { mutableStateOf(true) }
    var pos by remember { mutableLongStateOf(p.resumeMs) }
    var dur by remember { mutableLongStateOf(0L) }
    var buffered by remember { mutableLongStateOf(0L) }
    var loading by remember { mutableStateOf(true) }
    var controls by remember { mutableStateOf(true) }
    var poke by remember { mutableIntStateOf(0) }
    var locked by remember { mutableStateOf(false) }
    var more by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf<String?>(null) }
    var resize by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var speed by remember { mutableFloatStateOf(1f) }
    var advisory by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var showAdvisory by remember { mutableStateOf(false) }
    var segs by remember { mutableStateOf<Segments?>(null) }
    var showInfo by remember { mutableStateOf(false) }
    var seekHint by remember { mutableStateOf<String?>(null) }
    var nextLoading by remember { mutableStateOf(false) }
    var cues by remember { mutableStateOf<List<Cue>>(emptyList()) }
    var aspectIdx by remember { mutableIntStateOf(0) }
    var aspectLabel by remember { mutableStateOf<String?>(null) }
    var hud by remember { mutableStateOf<Pair<String, Float>?>(null) } // "brightness"/"volume" to level 0..1
    val audio = remember { ctx.getSystemService(android.content.Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var autoNextDone by remember { mutableStateOf(false) }

    val player = remember {
        // Streams go through the app's HTTP client, so the DNS chosen in Settings applies to video too.
        val dataSource = DefaultDataSource.Factory(ctx, OkHttpDataSource.Factory(Api.http))
        ExoPlayer.Builder(ctx).setMediaSourceFactory(DefaultMediaSourceFactory(dataSource)).build().apply {
            val subs = p.subs.filter { it.url.isNotBlank() }.map {
                MediaItem.SubtitleConfiguration.Builder(Uri.parse(it.url))
                    .setMimeType(subMime(it.url)).setLanguage(it.lang).setLabel(it.lang).build()
            }
            setMediaItem(MediaItem.Builder().setUri(p.url).setSubtitleConfigurations(subs).build(), p.resumeMs)
            addListener(object : Player.Listener {
                override fun onPlayerError(error: PlaybackException) {
                    Toast.makeText(ctx, "Playback error: ${error.errorCodeName}. Try another source.", Toast.LENGTH_LONG).show()
                }
                override fun onTracksChanged(t: Tracks) { tracks = t }
                override fun onCues(cueGroup: CueGroup) { cues = cueGroup.cues }
                override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
                override fun onPlaybackStateChanged(state: Int) { loading = state == Player.STATE_BUFFERING }
            })
            prepare(); playWhenReady = true
        }
    }

    // Episodes in order, for "Next episode".
    val episodes = remember(meta) {
        meta?.videos.orEmpty().filter { (it.season ?: 0) > 0 && it.episode != null }.sortedWith(compareBy({ it.season }, { it.episode }))
    }
    val nextEp = remember(episodes, p.key) { episodes.indexOfFirst { it.id == p.key }.let { i -> if (i >= 0) episodes.getOrNull(i + 1) else null } }

    // Load metadata, content advisory and skip-intro times in the background.
    LaunchedEffect(p.key) {
        if (meta == null || meta?.videos == null && type == "series") {
            vm.fullMeta(Meta(id = p.key.substringBefore(":"), type = type))?.let { meta = it }
        }
        if (isOn(opt("showAdvisory"))) {
            val g = vm.parentalGuide(p.key.substringBefore(":"))
            if (g.isNotEmpty()) { advisory = g; showAdvisory = true; delay(10_000); showAdvisory = false }
        }
    }
    LaunchedEffect(p.key) { if (isOn(opt("skipIntro"))) segs = vm.segments(p.key) }

    // Poll playback position.
    LaunchedEffect(player) {
        while (true) {
            pos = player.currentPosition
            dur = player.duration.coerceAtLeast(0L)
            buffered = player.bufferedPosition
            delay(500)
        }
    }
    // Auto-hide controls.
    LaunchedEffect(controls, poke, playing, panel) {
        if (controls && playing && panel == null) { delay(4000); controls = false; more = false }
    }
    // Info screen after being paused for a few seconds.
    LaunchedEffect(playing) {
        if (!playing && !loading && isOn(opt("pauseInfo"))) { delay(5000); if (!player.isPlaying) { showInfo = true; controls = false } }
        else showInfo = false
    }

    fun seekBy(ms: Long) { player.seekTo((player.currentPosition + ms).coerceIn(0L, maxOf(0L, player.duration))); poke++ }

    fun playNext() {
        val ep = nextEp ?: return
        val m = meta ?: return
        if (nextLoading) return
        nextLoading = true
        scope.launch {
            val list = vm.streams(type, ep.id)
            val pick = vm.autoPick(list, "first", "", preferAddon = p.source)
            if (pick == null) {
                Toast.makeText(ctx, "No stream found for the next episode", Toast.LENGTH_SHORT).show()
                nextLoading = false
                return@launch
            }
            val subs = pick.stream.subtitles.orEmpty() + vm.subtitles(type, ep.id)
            onReplace(
                Screen.Player(
                    "${m.name}  S${ep.season}E${ep.episode}", pick.stream.url!!, subs, key = ep.id,
                    image = ep.thumbnail ?: m.background ?: m.poster, type = type, meta = m, source = pick.stream.name ?: pick.addonName,
                )
            )
        }
    }

    // Auto-play next episode when the threshold is reached.
    val threshold = (opt("nextThreshold").toIntOrNull() ?: 95).coerceIn(50, 100) / 100f
    LaunchedEffect(pos, dur) {
        if (!autoNextDone && isOn(opt("autoNext")) && nextEp != null && dur > 60_000 && pos >= dur * threshold) {
            autoNextDone = true
            playNext()
        }
    }

    DisposableEffect(Unit) {
        val activity = ctx as Activity
        val ctrl = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        ctrl.hide(WindowInsetsCompat.Type.systemBars())
        ctrl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        onDispose {
            val d = player.duration
            onProgress(player.currentPosition, if (d > 0) d else 0L)
            player.release()
            // Give brightness back to the system when leaving the player.
            activity.window.attributes = activity.window.attributes.apply { screenBrightness = -1f }
            ctrl.show(WindowInsetsCompat.Type.systemBars())
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    BackHandler {
        when {
            panel != null -> panel = null
            showInfo -> showInfo = false
            locked -> { controls = true; poke++ }
            else -> onBack()
        }
    }

    // Subtitle look from Help & Settings > Playback.
    val subSize = opt("subSize").toFloatOrNull() ?: 20f
    val subStyle = CaptionStyleCompat(
        (parseColor(opt("subColor")) ?: Color.White).toArgb(),
        (parseColor(opt("subBg")) ?: Color.Transparent).toArgb(),
        Color.Transparent.toArgb(),
        if (isOn(opt("subOutline"))) CaptionStyleCompat.EDGE_TYPE_OUTLINE else CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW,
        (parseColor(opt("subOutlineColor")) ?: Color.Black).toArgb(),
        if (isOn(opt("subBold"))) Typeface.DEFAULT_BOLD else Typeface.DEFAULT,
    )

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { c ->
                PlayerView(c).apply {
                    useController = false
                    this.player = player
                    keepScreenOn = true
                }
            },
            update = { v ->
                v.resizeMode = resize
                v.subtitleView?.visibility = View.GONE
            },
            modifier = Modifier.fillMaxSize(),
        )
        // Subtitles live outside the video frame, so zoom / crop never moves or enlarges them.
        AndroidView(
            factory = { c -> SubtitleView(c).apply { setBottomPaddingFraction(0.07f) } },
            update = { sv ->
                sv.setApplyEmbeddedStyles(false)
                sv.setApplyEmbeddedFontSizes(false)
                sv.setStyle(subStyle)
                sv.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, subSize)
                sv.setCues(cues)
            },
            modifier = Modifier.fillMaxSize(),
        )

        // Tap to show/hide controls, double-tap left/right to skip 10 s,
        // swipe up/down on the left for brightness and on the right for volume.
        Box(
            Modifier.fillMaxSize().pointerInput(locked) {
                if (locked) return@pointerInput
                var left = true
                var level = 0f
                detectVerticalDragGestures(
                    onDragStart = { o ->
                        left = o.x < size.width / 2f
                        val act = ctx as Activity
                        level = if (left) act.window.attributes.screenBrightness.let { if (it < 0f) 0.5f else it }
                        else audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol
                    },
                    onDragEnd = { hud = null },
                    onDragCancel = { hud = null },
                ) { change, dy ->
                    change.consume()
                    level = (level - dy / (size.height * 0.8f)).coerceIn(0f, 1f)
                    if (left) {
                        val act = ctx as Activity
                        act.window.attributes = act.window.attributes.apply { screenBrightness = level.coerceAtLeast(0.01f) }
                        hud = "brightness" to level
                    } else {
                        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (level * maxVol).toInt(), 0)
                        hud = "volume" to level
                    }
                }
            }.pointerInput(locked) {
                detectTapGestures(
                    onTap = { if (showInfo) showInfo = false else { controls = !controls; poke++ } },
                    onDoubleTap = { o ->
                        if (!locked) {
                            if (o.x < size.width / 2f) { seekBy(-10_000); seekHint = "-10s" } else { seekBy(10_000); seekHint = "+10s" }
                        }
                    },
                )
            },
        )
        LaunchedEffect(seekHint) { if (seekHint != null) { delay(700); seekHint = null } }
        seekHint?.let {
            Text(it, Modifier.align(if (it.startsWith("-")) Alignment.CenterStart else Alignment.CenterEnd).padding(horizontal = 80.dp)
                .clip(RoundedCornerShape(30.dp)).background(Color(0x88000000)).padding(horizontal = 18.dp, vertical = 10.dp),
                fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        if (loading) CircularProgressIndicator(Modifier.align(Alignment.Center).size(48.dp), color = Color.White)
        hud?.let { (kind, lvl) ->
            Row(
                Modifier.align(Alignment.TopCenter).padding(top = 40.dp).clip(RoundedCornerShape(24.dp)).background(Color(0xB3000000))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(if (kind == "brightness") Icons.Default.LightMode else if (lvl == 0f) Icons.Default.VolumeOff else Icons.Default.VolumeUp, null, Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Box(Modifier.width(140.dp).height(5.dp).clip(RoundedCornerShape(3.dp)).background(Color(0x55FFFFFF))) {
                    Box(Modifier.fillMaxHeight().fillMaxWidth(lvl).background(Color.White))
                }
                Spacer(Modifier.width(10.dp))
                Text("${(lvl * 100).toInt()}%", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        LaunchedEffect(aspectLabel) { if (aspectLabel != null) { delay(1500); aspectLabel = null } }
        aspectLabel?.let {
            Text(it, Modifier.align(Alignment.Center).padding(top = 110.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xB3000000))
                .padding(horizontal = 16.dp, vertical = 8.dp), fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }

        // Content advisory, top-left (like the big OTT apps).
        AnimatedVisibility(showAdvisory && advisory.isNotEmpty(), Modifier.align(Alignment.TopStart).padding(start = 44.dp, top = 22.dp), enter = fadeIn(), exit = fadeOut()) {
            Row(Modifier.height(IntrinsicSize.Min)) {
                Box(Modifier.width(4.dp).fillMaxHeight().background(Color.White))
                Column(Modifier.padding(start = 14.dp)) {
                    advisory.forEach { (cat, level) ->
                        Row(Modifier.padding(vertical = 3.dp)) {
                            Text(cat, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text("  ·  $level", fontSize = 14.sp, color = Color(0xFFB6BDCC))
                        }
                    }
                }
            }
        }

        // Skip intro / recap, and Next episode near the end.
        val s = segs
        val inIntro = s?.intro?.let { pos >= it.start_ms && pos < it.end_ms - 1500 } == true
        val inRecap = s?.recap?.let { pos >= it.start_ms && pos < it.end_ms - 1500 } == true
        val nearEnd = nextEp != null && dur > 0 && (s?.outro?.let { pos >= it.start_ms } ?: (pos >= dur - 120_000))
        Column(Modifier.align(Alignment.BottomEnd).padding(end = 40.dp, bottom = if (controls) 110.dp else 32.dp), horizontalAlignment = Alignment.End) {
            if (inIntro || inRecap) PillButton(if (inIntro) "Skip Intro" else "Skip Recap", Icons.Default.FastForward) {
                val end = if (inIntro) s!!.intro!!.end_ms else s!!.recap!!.end_ms
                player.seekTo(end)
            }
            if (nearEnd && !locked) PillButton(if (nextLoading) "Loading…" else "Next Episode", Icons.Default.SkipNext) { playNext() }
        }

        // Main controls.
        AnimatedVisibility(controls && !locked && !showInfo, Modifier.fillMaxSize(), enter = fadeIn(), exit = fadeOut()) {
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to Color(0x99000000), 0.3f to Color(0x22000000), 0.65f to Color(0x33000000), 1f to Color(0xD9000000)))) {
                Row(Modifier.align(Alignment.TopEnd).padding(top = 16.dp, end = 36.dp), horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                    CtlIcon(Icons.Default.Lock, "Lock", 22) { locked = true; controls = true; poke++ }
                    CtlIcon(Icons.AutoMirrored.Filled.ArrowBack, "Back", 22) { onBack() }
                }
                Row(Modifier.align(Alignment.Center), horizontalArrangement = Arrangement.spacedBy(64.dp), verticalAlignment = Alignment.CenterVertically) {
                    CtlIcon(Icons.Default.Replay10, "Back 10 seconds", 30) { seekBy(-10_000) }
                    CtlIcon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "Pause" else "Play", 40) {
                        if (player.isPlaying) player.pause() else player.play(); poke++
                    }
                    CtlIcon(Icons.Default.Forward10, "Forward 10 seconds", 30) { seekBy(10_000) }
                }
                Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(start = 44.dp, end = 44.dp, bottom = 12.dp)) {
                    Text(meta?.name?.takeIf { type == "movie" } ?: p.title, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    p.source?.let { Text("Via $it", fontSize = 13.sp, color = Color(0xFFB6BDCC), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    Spacer(Modifier.height(6.dp))
                    SeekBar(pos, buffered, dur) { player.seekTo(it); poke++ }
                    Spacer(Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CtlIcon(Icons.Default.ClosedCaption, "Subtitles", 22) { panel = "subs" }
                        Spacer(Modifier.width(26.dp))
                        CtlIcon(Icons.Default.Audiotrack, "Audio", 21) { panel = "audio" }
                        Spacer(Modifier.width(26.dp))
                        CtlIcon(Icons.Default.Cloud, "Sources", 22) { panel = "sources" }
                        if (nextEp != null) { Spacer(Modifier.width(26.dp)); CtlIcon(Icons.Default.SkipNext, "Next episode", 22) { playNext() } }
                        Spacer(Modifier.width(26.dp))
                        CtlIcon(Icons.Default.Speed, "Speed", 22) { panel = "speed" }
                        Spacer(Modifier.width(26.dp))
                        if (more) {
                            CtlIcon(Icons.Default.AspectRatio, "Aspect ratio", 22) {
                                aspectIdx = (aspectIdx + 1) % AspectModes.size
                                resize = AspectModes[aspectIdx].second
                                aspectLabel = AspectModes[aspectIdx].first
                                poke++
                            }
                            Spacer(Modifier.width(26.dp))
                            CtlIcon(Icons.AutoMirrored.Filled.OpenInNew, "Open in another player", 21) { player.pause(); openExternal(ctx, p.url, p.title) }
                            Spacer(Modifier.width(26.dp))
                            CtlIcon(Icons.Default.Info, "Info", 22) { showInfo = true; controls = false }
                            Spacer(Modifier.width(26.dp))
                            CtlIcon(Icons.Default.ChevronLeft, "Less", 24) { more = false; poke++ }
                        } else CtlIcon(Icons.Default.ChevronRight, "More", 24) { more = true; poke++ }
                        Spacer(Modifier.weight(1f))
                        Text("${fmt(pos)} / ${fmt(dur)}", fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }

        // Locked: only an unlock button.
        if (locked && controls) {
            Box(Modifier.align(Alignment.TopEnd).padding(top = 16.dp, end = 36.dp).size(44.dp).clip(CircleShape).background(Color(0x99000000))
                .clickable { locked = false; poke++ }, Alignment.Center) { Icon(Icons.Default.LockOpen, "Unlock", Modifier.size(22.dp)) }
            LaunchedEffect(poke) { delay(2500); if (locked) controls = false }
        }

        // Info screen while paused (like Netflix / Prime).
        AnimatedVisibility(showInfo, Modifier.fillMaxSize(), enter = fadeIn(), exit = fadeOut()) {
            val m = meta
            Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0f to Color(0xF2000000), 0.6f to Color(0xAA000000), 1f to Color(0x22000000)))
                .clickable { showInfo = false }) {
                Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(0.55f).padding(start = 56.dp)) {
                    Text("You're watching", fontSize = 16.sp, color = Color(0xFFB6BDCC))
                    if (m != null && logoOf(m) != null) AsyncImage(logoOf(m), m.name, Modifier.padding(vertical = 10.dp).height(70.dp), contentScale = ContentScale.Fit, alignment = Alignment.CenterStart)
                    else Text(m?.name ?: p.title, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(vertical = 8.dp))
                    if (type == "series") Text(p.title.removePrefix(m?.name ?: "").trim(), fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    m?.let { mm ->
                        Text(listOfNotNull(mm.releaseInfo, mm.runtime, mm.imdbRating?.let { "IMDb $it" }).joinToString("  •  "), fontSize = 15.sp, color = Color(0xFFC9CEDB), modifier = Modifier.padding(top = 6.dp))
                        mm.genres?.takeIf { it.isNotEmpty() }?.let { Text(it.take(3).joinToString(" · "), fontSize = 15.sp, color = Accent, modifier = Modifier.padding(top = 4.dp)) }
                        val epDesc = mm.videos?.firstOrNull { it.id == p.key }?.let { it.title ?: it.name }
                        Text(mm.description ?: epDesc ?: "", fontSize = 16.sp, lineHeight = 22.sp, color = Color(0xFFE2E5EC), maxLines = 5, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 12.dp))
                    }
                    Text("Tap anywhere to continue", fontSize = 13.sp, color = Color(0xFF8A94A8), modifier = Modifier.padding(top = 16.dp))
                }
            }
        }

        // Side panels.
        panel?.let { which ->
            Box(Modifier.fillMaxSize().background(Color(0x66000000)).clickable { panel = null }) {
                Column(
                    Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(380.dp).background(Color(0xF2111319)).clickable(enabled = false) {}
                        .padding(horizontal = 20.dp, vertical = 20.dp),
                ) {
                    Text(
                        when (which) { "subs" -> "Subtitles"; "audio" -> "Audio"; "sources" -> "Sources"; "speed" -> "Playback speed"; else -> "Sources" },
                        fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp),
                    )
                    when (which) {
                        "subs" -> TrackList(tracks, C.TRACK_TYPE_TEXT, player, allowOff = true)
                        "audio" -> TrackList(tracks, C.TRACK_TYPE_AUDIO, player, allowOff = false)
                        "speed" -> OptionList(listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).map { "${it}x" to (speed == it) }) { i ->
                            speed = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)[i]; player.setPlaybackSpeed(speed); panel = null
                        }
                        else -> SourcesPanel(vm, type, p, player.currentPosition) { onReplace(it) }
                    }
                }
            }
        }
    }
}

@Composable
private fun CtlIcon(icon: ImageVector, desc: String, size: Int, onClick: () -> Unit) =
    Icon(icon, desc, Modifier.clip(CircleShape).clickable(onClick = onClick).padding(7.dp).size(size.dp), tint = Color.White)

@OptIn(UnstableApi::class)
private val AspectModes = listOf(
    "Fit" to AspectRatioFrameLayout.RESIZE_MODE_FIT,
    "Crop" to AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
    "Stretch" to AspectRatioFrameLayout.RESIZE_MODE_FILL,
)

@Composable
private fun PillButton(text: String, icon: ImageVector, onClick: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        Modifier.padding(top = 10.dp).clip(shape).background(Color(0xE6FFFFFF)).border(1.dp, Color(0x33000000), shape)
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, Modifier.size(18.dp), tint = Color.Black)
        Spacer(Modifier.width(6.dp))
        Text(text, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Black)
    }
}

/** Thick rounded seek bar: white = watched, grey = buffered. Tap or drag to seek. */
@Composable
private fun SeekBar(pos: Long, buffered: Long, dur: Long, onSeek: (Long) -> Unit) {
    var dragFrac by remember { mutableStateOf<Float?>(null) }
    val frac = dragFrac ?: if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
    val bFrac = if (dur > 0) (buffered.toFloat() / dur).coerceIn(0f, 1f) else 0f
    Canvas(
        Modifier.fillMaxWidth().height(22.dp)
            .pointerInput(dur) {
                detectTapGestures { o -> if (dur > 0) onSeek((o.x / size.width * dur).toLong()) }
            }
            .pointerInput(dur) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> dragFrac = (o.x / size.width).coerceIn(0f, 1f) },
                    onDragEnd = { dragFrac?.let { if (dur > 0) onSeek((it * dur).toLong()) }; dragFrac = null },
                    onDragCancel = { dragFrac = null },
                ) { change, _ -> dragFrac = (change.position.x / size.width).coerceIn(0f, 1f) }
            },
    ) {
        val h = 6.dp.toPx(); val y = (size.height - h) / 2f; val r = CornerRadius(h / 2f)
        drawRoundRect(Color(0x55FFFFFF), Offset(0f, y), Size(size.width, h), r)
        drawRoundRect(Color(0x88FFFFFF), Offset(0f, y), Size(size.width * bFrac, h), r)
        drawRoundRect(Color.White, Offset(0f, y), Size(size.width * frac, h), r)
        if (dragFrac != null) drawCircle(Color.White, 9.dp.toPx(), Offset(size.width * frac, size.height / 2f))
    }
}

@Composable
private fun OptionList(options: List<Pair<String, Boolean>>, onPick: (Int) -> Unit) {
    LazyColumn {
        items(options.size) { i ->
            val (label, on) = options[i]
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onPick(i) }.padding(vertical = 14.dp, horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text(label, Modifier.weight(1f), fontSize = 18.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
                if (on) Icon(Icons.Default.Check, null)
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun TrackList(tracks: Tracks, trackType: Int, player: ExoPlayer, allowOff: Boolean) {
    val opts = tracks.groups.filter { it.type == trackType }.flatMap { g ->
        (0 until g.length).filter { g.isTrackSupported(it) }.map { i ->
            val f = g.getTrackFormat(i)
            val name = listOfNotNull(f.label, f.language?.let { java.util.Locale(it).displayLanguage.takeIf { d -> d.isNotBlank() } ?: it })
                .distinct().joinToString(" · ").ifBlank { "Track ${i + 1}" }
            val extra = if (trackType == C.TRACK_TYPE_AUDIO && f.channelCount > 0) "  (${f.channelCount}ch)" else ""
            TrackOpt(name + extra, g, i, g.isTrackSelected(i))
        }
    }
    val off = player.trackSelectionParameters.disabledTrackTypes.contains(trackType)
    if (opts.isEmpty()) {
        Text(if (trackType == C.TRACK_TYPE_TEXT) "No subtitles in this stream. Install a subtitles addon to get more." else "Only one audio track.", color = Color(0xFF9AA3B5))
        return
    }
    val rows = (if (allowOff) listOf("Off" to off) else emptyList()) + opts.map { it.label to (it.selected && !off) }
    OptionList(rows) { i ->
        val params = player.trackSelectionParameters.buildUpon()
        if (allowOff && i == 0) params.setTrackTypeDisabled(trackType, true)
        else {
            val o = opts[if (allowOff) i - 1 else i]
            params.setTrackTypeDisabled(trackType, false).setOverrideForType(TrackSelectionOverride(o.group.mediaTrackGroup, o.index))
        }
        player.trackSelectionParameters = params.build()
    }
}

@Composable
private fun SourcesPanel(vm: AppViewModel, type: String, p: Screen.Player, posNow: Long, onSwitch: (Screen.Player) -> Unit) {
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf<List<StreamItem>?>(null) }
    LaunchedEffect(p.key) { list = vm.streams(type, p.key) }
    val l = list
    when {
        l == null -> Box(Modifier.fillMaxWidth().padding(30.dp), Alignment.Center) { CircularProgressIndicator(color = Color.White) }
        l.isEmpty() -> Text("No other sources found.", color = Color(0xFF9AA3B5))
        else -> LazyColumn {
            items(l) { s ->
                val current = s.stream.url == p.url
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(enabled = !current) {
                    scope.launch {
                        val subs = s.stream.subtitles.orEmpty() + vm.subtitles(type, p.key)
                        onSwitch(p.copy(url = s.stream.url!!, subs = subs, resumeMs = posNow, source = s.stream.name ?: s.addonName))
                    }
                }.padding(vertical = 10.dp, horizontal = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(s.stream.name ?: s.addonName, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, maxLines = 2)
                        if (current) Text("Playing", color = Accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(s.stream.title ?: s.stream.description ?: "", color = Color(0xFF9AA3B5), fontSize = 12.sp, maxLines = 3)
                    Text("via ${s.addonName}", color = Accent, fontSize = 12.sp)
                }
                HorizontalDivider(color = Color(0x22FFFFFF))
            }
        }
    }
}

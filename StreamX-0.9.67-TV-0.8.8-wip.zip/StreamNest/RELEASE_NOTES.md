StreamX TV 0.8.8 and StreamX 0.9.67

• TV: the sign-in QR code shows again; one OK opens the keyboard; voice works in the email box.
• Phone: Link a TV scanner opens upright; scanning the TV's QR and tapping Approve signs the TV in.

StreamX TV 0.8.7 and StreamX 0.9.66

TV 0.8.7
• Search asks one place only (TMDB): right order, whole film series together; Discover wall with posters of different sizes.
• Home like the phone: tall Trending posters, fresh shuffle, no cinema-only films (search still finds them).
• Films out at home play a web / Blu-ray copy, not a cinema recording (a cinema copy only as the last resort, with a note).
• Each source asked only for what it carries; 4K HDHUB starts ahead; less memory while a film starts.
• Bin reachable with ▲; rating pop-up keeps the remote inside; highlights match each button; notice once per TV and account.

Phone 0.9.66
• Settings › Account › Link a TV: scan the TV's QR code (or type the code) and approve.

StreamX TV 0.8.6 (the phone app stays on 0.9.65)

• Sign in with your phone: scan the QR code or type the 6-digit code in StreamX on your phone (Settings › Account › Link a TV) and approve. Email sign-in is still there.
• Sound formats (Dolby, DTS, TrueHD…) now use StreamX's own FFmpeg audio build.

StreamX TV 0.8.5 (the phone app stays on 0.9.65)

• Better quality is always reachable from the player bar (▲); its countdown waits while it is selected.
• Waits up to a minute for VegaMovies / RogMovies HD, then other sources; 4K TVs get "Upgrade to 4K".
• Seeking with the menu hidden: just the bar and a preview, 10 s steps that speed up when held, one jump on release.
• Quality list like the phone: Auto, 4K, 1080p 60fps, 1080p, 720p, 480p, Other streams.
• Search uses the TV's own keyboard and voice, plus a mic button; phone-style posters.
• Home like the phone: Pick up where you left off, numbered Trending, AIDEN picked for you; faster pictures and profiles.
• NOW PLAYING on Continue Watching when a title plays on another device; progress syncs within seconds.
• Audio & Subtitles: wider, every option reachable with the remote.
• A new row starts at its first card; hold OK on a card for its options.
• The bin next to Pick up where you left off: mark titles, Delete removes them and their cache.
• Turbo + Elite on from the start; Exit asks and can clear the cache.

StreamX TV 0.8.4 (the phone app stays on 0.9.65)

• Opens faster and lighter on Fire TV sticks.
• Smooth loading screen; streaming playlists climb to their best quality without pausing.
• Continue Watching works after an update (a fresh link from the same source, no error screen).
• Next Episode shows the episode's picture with the countdown.
• 1 GB sticks: fewer pictures in memory, no 60fps copies, no trailers.

package com.example.streamnest

/** The QR scanner, held upright (the library's own scanner opens sideways). */
class PortraitScanActivity : com.journeyapps.barcodescanner.CaptureActivity()

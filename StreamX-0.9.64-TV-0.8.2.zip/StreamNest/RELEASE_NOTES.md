StreamX 0.9.64

• vivo phones: the player no longer closes itself a moment after pressing Play.
• The quality upgrade stops retrying a source after two failed tries.
• Trailers on Home cards and title pages are paused for now (the ▶ Trailer button still works).

StreamX 0.9.73

• VR headset mode in the player (tap ‹ next to the clock).
• AIDEN: "play", "open", "search" and "my list" work at once.
• Downloads now show in your gallery (Movies/StreamX).
• A nudge to update after a problem on an older version.

---

StreamX TV 0.9.15 

• Back on Home no longer freezes or closes the app.
• The first open after an update stays open.
• Posters load once at start (no more reloading).
• Home appears at once and refreshes quietly.

StreamX 0.9.69

• Once a video is playing, a broken link never brings back the loading screen — the picture stays while it reconnects.
• Faster start when a link fails; late links become backups.
• Fake / placeholder videos are skipped.
• Continue watching resumes on the same source.
• Watch next gets ready in the corner more reliably.

---

StreamX TV 0.9.15 

• Back on Home no longer freezes or closes the app.
• The first open after an update stays open.
• Posters load once at start (no more reloading).
• Home appears at once and refreshes quietly.

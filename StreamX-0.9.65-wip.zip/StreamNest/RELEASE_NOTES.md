StreamX 0.9.65

• VegaMovies plays again.
• vivo phones: the player opens straight away with the stream that was ready.
• "Hey Aiden" is switched off for now.
• Updates are always offered when the app opens.

StreamX 0.9.62

• Trailers on the top cards are centred and fill the card again, and no longer show behind the other cards.

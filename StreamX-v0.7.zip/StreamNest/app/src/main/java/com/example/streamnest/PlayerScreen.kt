package com.example.streamnest

import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Typeface
import android.media.AudioManager
import android.net.Uri
import android.util.TypedValue
import android.view.View
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack

import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.text.Cue
import androidx.media3.common.text.CueGroup
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.media3.ui.SubtitleView
import coil.compose.AsyncImage
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** Inter: the clean geometric sans used by the player (bundled, SIL Open Font License). */
val InterFont = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold),
)

private fun subMime(url: String) = when {
    url.contains(".vtt", true) -> MimeTypes.TEXT_VTT
    url.contains(".ass", true) || url.contains(".ssa", true) -> MimeTypes.TEXT_SSA
    else -> MimeTypes.APPLICATION_SUBRIP
}

/** Opens a stream in another installed player (VLC, MX Player…) through Android's app chooser. */
fun openExternal(ctx: android.content.Context, url: String, title: String) {
    try {
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(url), "video/*").putExtra("title", title)
        ctx.startActivity(Intent.createChooser(i, "Open with"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "No other video player found", Toast.LENGTH_SHORT).show()
    }
}

private data class TrackOpt(val label: String, val group: Tracks.Group, val index: Int, val selected: Boolean)

/** What is actually playing (the link can change: finding, fallbacks, switching source). */
private data class Now(val url: String, val subs: List<Subtitle>, val source: String?, val addon: String?)

private val noRipple = MutableInteractionSource()

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    vm: AppViewModel,
    p: Screen.Player,
    onBack: () -> Unit,
    onReplace: (Screen.Player) -> Unit,
    onProgress: (pos: Long, dur: Long, url: String, subs: List<Subtitle>) -> Unit,
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val texts by vm.texts.collectAsStateWithLifecycle()
    fun opt(k: String) = texts[k] ?: Defaults[k] ?: ""

    val type = p.type.ifBlank { if (p.key.contains(":")) "series" else "movie" }
    var meta by remember { mutableStateOf(p.meta) }
    var now by remember { mutableStateOf(if (p.url.isNotBlank()) Now(p.url, p.subs, p.source, p.addon) else null) }
    var candidates by remember { mutableStateOf(p.candidates) }
    var tracks by remember { mutableStateOf(Tracks.EMPTY) }
    var playing by remember { mutableStateOf(true) }
    var pos by remember { mutableLongStateOf(p.resumeMs) }
    var dur by remember { mutableLongStateOf(0L) }
    var buffered by remember { mutableLongStateOf(0L) }
    var buffering by remember { mutableStateOf(true) }
    var firstFrame by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf(if (p.url.isBlank()) "Finding stream source" else "Buffering…") }
    var failure by remember { mutableStateOf<String?>(null) }
    var findRequest by remember { mutableIntStateOf(if (p.url.isBlank()) 1 else 0) }
    var controls by remember { mutableStateOf(false) }
    var poke by remember { mutableIntStateOf(0) }
    var locked by remember { mutableStateOf(false) }
    var more by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf<String?>(null) }
    var lastPanel by remember { mutableStateOf("sources") }
    var resize by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var speed by remember { mutableFloatStateOf(1f) }
    var advisory by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var showAdvisory by remember { mutableStateOf(false) }
    var segs by remember { mutableStateOf<Segments?>(null) }
    var showInfo by remember { mutableStateOf(false) }
    var seekHint by remember { mutableStateOf<String?>(null) }
    var cues by remember { mutableStateOf<List<Cue>>(emptyList()) }
    var aspectIdx by remember { mutableIntStateOf(0) }
    var aspectLabel by remember { mutableStateOf<String?>(null) }
    var hud by remember { mutableStateOf<Pair<String, Float>?>(null) }
    val audio = remember { ctx.getSystemService(android.content.Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var autoNextDone by remember { mutableStateOf(false) }
    var linkSaved by remember { mutableStateOf(false) }

    // Faster start: begin playing after ~1 s of video instead of the default 2.5 s (Playback > Fast start).
    val player = remember {
        val fast = isOn(texts["fastStart"] ?: Defaults["fastStart"] ?: "yes")
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 50_000, if (fast) 1_000 else 2_500, if (fast) 2_000 else 5_000)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()
        // Streams go through the app's HTTP client, so the DNS chosen in Settings applies to video too.
        val dataSource = DefaultDataSource.Factory(ctx, OkHttpDataSource.Factory(Api.http))
        ExoPlayer.Builder(ctx).setLoadControl(load).setMediaSourceFactory(DefaultMediaSourceFactory(dataSource)).build()
    }

    fun load(n: Now, startMs: Long) {
        val subs = n.subs.filter { it.url.isNotBlank() }.map {
            MediaItem.SubtitleConfiguration.Builder(Uri.parse(it.url)).setMimeType(subMime(it.url)).setLanguage(it.lang).setLabel(it.lang).build()
        }
        firstFrame = false; failure = null; status = "Buffering…"; linkSaved = false
        player.setMediaItem(MediaItem.Builder().setUri(n.url).setSubtitleConfigurations(subs).build(), startMs)
        player.prepare(); player.playWhenReady = true
        now = n
    }

    // Start straight away when a link was given; the player is preparing while the loading screen shows.
    LaunchedEffect(player) { now?.let { load(it, p.resumeMs) } }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val n = now
                if (n != null && vm.lastLink(p.key)?.url == n.url) vm.forgetLink(p.key)
                val next = candidates.firstOrNull()
                if (!firstFrame && next != null) {
                    // Fallback: this link didn't start, quietly try the next source.
                    candidates = candidates.drop(1)
                    Toast.makeText(ctx, "Source didn't load, trying the next one…", Toast.LENGTH_SHORT).show()
                    scope.launch {
                        load(Now(next.stream.url!!, next.stream.subtitles.orEmpty() + (n?.subs.orEmpty().filter { s -> next.stream.subtitles.orEmpty().none { it.url == s.url } }),
                            next.stream.name ?: next.addonName, next.addonName), if (pos > 0) pos else p.resumeMs)
                    }
                } else failure = "This source couldn't be played (${error.errorCodeName})."
            }
            override fun onTracksChanged(t: Tracks) { tracks = t }
            override fun onCues(cueGroup: CueGroup) { cues = cueGroup.cues }
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onRenderedFirstFrame() { firstFrame = true }
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                if (state == Player.STATE_READY && !linkSaved) {
                    linkSaved = true
                    now?.let { n -> if (n.url.startsWith("http")) vm.rememberLink(p.key, n.url, n.source, n.addon) }
                    // Audio-only or no video track: there is no "first frame", so don't wait for it.
                    if (player.videoSize.width == 0) scope.launch { delay(800); firstFrame = true }
                }
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l) }
    }

    // "Finding stream source": Auto Stream Selection inside the player (and for the next episode).
    LaunchedEffect(findRequest) {
        if (findRequest == 0) return@LaunchedEffect
        failure = null; firstFrame = false; status = "Finding stream source"
        val subsJob = async { runCatching { vm.subtitles(type, p.key) }.getOrDefault(emptyList()) }
        val forced = findRequest > 1 // asked again after a failure: never reuse the old link
        val last = if (!forced && isOn(opt("reuseLastLink"))) vm.lastLink(p.key) else null
        if (last != null) {
            load(Now(last.url, withTimeoutOrNull(1200) { subsJob.await() }.orEmpty(), last.source, last.addon), p.resumeMs)
            // Also look up other sources in the background, in case the saved link has expired.
            scope.launch { vm.streamsFlow(type, p.key).first { it.second }.let { (l, _) -> candidates = vm.filtered(l).list.filter { it.stream.url != last.url } } }
            return@LaunchedEffect
        }
        val mode = opt("autoPlayMode").let { if (it == "manual") "first" else it }
        val patterns = regexList(opt("autoRegex"))
        val prefer = p.source
        var picked: StreamItem? = null
        var pool: List<StreamItem> = emptyList()
        var hiddenAll = false
        vm.streamsFlow(type, p.key).first { (l, done) ->
            val f = vm.filtered(l)
            pool = f.list
            hiddenAll = f.forcedEmpty
            picked = when {
                pool.isEmpty() -> null
                prefer != null && !done -> pool.firstOrNull { it.stream.name == prefer } // same source as the last episode
                mode == "regex" && patterns.isNotEmpty() -> matchChain(pool, patterns.take(1))?.first ?: if (done) vm.autoPick(pool, "regex", opt("autoRegex")) else null
                else -> if (done || prefer == null) vm.autoPick(pool, "first", "", prefer) else null
            }
            picked != null || done
        }
        val s = picked ?: (if (pool.isNotEmpty()) vm.autoPick(pool, mode, opt("autoRegex"), prefer) else null)
        if (s == null) {
            failure = if (hiddenAll) "No streams match your forced stream filters." else "No stream found for this title."
            return@LaunchedEffect
        }
        candidates = pool.filter { it !== s }
        val extra = withTimeoutOrNull(1500) { subsJob.await() }.orEmpty()
        load(Now(s.stream.url!!, s.stream.subtitles.orEmpty() + extra, s.stream.name ?: s.addonName, s.addonName), p.resumeMs)
    }
    LaunchedEffect(firstFrame, buffering) { if (!firstFrame && now != null && failure == null) status = "Buffering…" }

    // Episodes in order, for "Next episode".
    val episodes = remember(meta) {
        meta?.videos.orEmpty().filter { (it.season ?: 0) > 0 && it.episode != null }.sortedWith(compareBy({ it.season }, { it.episode }))
    }
    val nextEp = remember(episodes, p.key) { episodes.indexOfFirst { it.id == p.key }.let { i -> if (i >= 0) episodes.getOrNull(i + 1) else null } }

    LaunchedEffect(p.key) {
        if (meta == null || meta?.videos == null && type == "series") {
            vm.fullMeta(Meta(id = p.key.substringBefore(":"), type = type))?.let { meta = it }
        }
    }
    // Content advisory once the video is on screen.
    LaunchedEffect(p.key, firstFrame) {
        if (firstFrame && advisory.isEmpty() && isOn(opt("showAdvisory")) && p.key.startsWith("tt")) {
            val g = vm.parentalGuide(p.key.substringBefore(":"))
            if (g.isNotEmpty()) { advisory = g; showAdvisory = true; delay(9_000); showAdvisory = false }
        }
    }
    LaunchedEffect(p.key) { if (isOn(opt("skipIntro"))) segs = vm.segments(p.key) }

    LaunchedEffect(player) {
        while (true) {
            pos = player.currentPosition
            dur = player.duration.coerceAtLeast(0L)
            buffered = player.bufferedPosition
            delay(500)
        }
    }
    LaunchedEffect(controls, poke, playing, panel) {
        if (controls && playing && panel == null) { delay(4000); controls = false; more = false }
    }
    LaunchedEffect(playing, firstFrame) {
        if (firstFrame && !playing && !buffering && isOn(opt("pauseInfo"))) { delay(5000); if (!player.isPlaying) { showInfo = true; controls = false } }
        else showInfo = false
    }

    fun seekBy(ms: Long) { player.seekTo((player.currentPosition + ms).coerceIn(0L, maxOf(0L, player.duration))); poke++ }

    fun playNext() {
        val ep = nextEp ?: return
        val m = meta ?: return
        onReplace(
            Screen.Player(
                "${m.name}  S${ep.season}E${ep.episode}", "", emptyList(), key = ep.id,
                image = ep.thumbnail ?: m.background ?: m.poster, type = type, meta = m,
                source = now?.source, addon = now?.addon, find = true,
            )
        )
    }

    val threshold = (opt("nextThreshold").toIntOrNull() ?: 95).coerceIn(50, 100) / 100f
    LaunchedEffect(pos, dur) {
        if (!autoNextDone && isOn(opt("autoNext")) && nextEp != null && dur > 60_000 && pos >= dur * threshold) {
            autoNextDone = true
            playNext()
        }
    }

    DisposableEffect(Unit) {
        val activity = ctx as Activity
        val ctrl = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        ctrl.hide(WindowInsetsCompat.Type.systemBars())
        ctrl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        onDispose {
            val d = player.duration
            now?.let { n -> if (firstFrame) onProgress(player.currentPosition, if (d > 0) d else 0L, n.url, n.subs) }
            player.release()
            activity.window.attributes = activity.window.attributes.apply { screenBrightness = -1f }
            ctrl.show(WindowInsetsCompat.Type.systemBars())
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    BackHandler {
        when {
            panel != null -> panel = null
            showInfo -> showInfo = false
            locked && firstFrame -> { controls = true; poke++ }
            else -> onBack()
        }
    }

    val subSize = opt("subSize").toFloatOrNull() ?: 20f
    val subStyle = CaptionStyleCompat(
        (parseColor(opt("subColor")) ?: Color.White).toArgb(),
        (parseColor(opt("subBg")) ?: Color.Transparent).toArgb(),
        Color.Transparent.toArgb(),
        if (isOn(opt("subOutline"))) CaptionStyleCompat.EDGE_TYPE_OUTLINE else CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW,
        (parseColor(opt("subOutlineColor")) ?: Color.Black).toArgb(),
        if (isOn(opt("subBold"))) Typeface.DEFAULT_BOLD else Typeface.DEFAULT,
    )

    // Loading screen fades out, then the video fades in from black.
    val loadingAlpha by animateFloatAsState(if (firstFrame && failure == null) 0f else 1f, tween(420), label = "loading")
    val videoAlpha by animateFloatAsState(if (firstFrame) 1f else 0f, tween(650, delayMillis = 180), label = "video")

    ProvideTextStyle(TextStyle(fontFamily = InterFont, color = Color.White)) {
        BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
            // Measured from the reference player: wide side margins, scaled to this screen.
            val side = (maxWidth * 0.11f).coerceIn(28.dp, 110.dp)
            val topEnd = (maxWidth * 0.12f).coerceIn(28.dp, 120.dp)
            val topY = (maxHeight * 0.12f).coerceIn(16.dp, 64.dp)
            val bottomY = (maxHeight * 0.06f).coerceIn(12.dp, 36.dp)

            Box(Modifier.fillMaxSize()) {
                AndroidView(
                    factory = { c -> PlayerView(c).apply { useController = false; this.player = player; keepScreenOn = true } },
                    update = { v -> v.resizeMode = resize; v.subtitleView?.visibility = View.GONE },
                    modifier = Modifier.fillMaxSize(),
                )
                // Subtitles live outside the video frame, so zoom / crop never moves or enlarges them.
                AndroidView(
                    factory = { c -> SubtitleView(c).apply { setBottomPaddingFraction(0.07f) } },
                    update = { sv ->
                        sv.setApplyEmbeddedStyles(false); sv.setApplyEmbeddedFontSizes(false)
                        sv.setStyle(subStyle); sv.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, subSize); sv.setCues(cues)
                    },
                    modifier = Modifier.fillMaxSize(),
                )
                // The video surface can't fade itself, so a black layer on top fades away instead.
                Box(Modifier.fillMaxSize().graphicsLayer { alpha = 1f - videoAlpha }.background(Color.Black))
            }

            // Gestures: tap = controls, double-tap = ±10 s, swipe left side = brightness, right side = volume.
            Box(
                Modifier.fillMaxSize().pointerInput(locked, firstFrame) {
                    if (locked || !firstFrame) return@pointerInput
                    var left = true
                    var level = 0f
                    detectVerticalDragGestures(
                        onDragStart = { o ->
                            left = o.x < size.width / 2f
                            val act = ctx as Activity
                            level = if (left) act.window.attributes.screenBrightness.let { if (it < 0f) 0.5f else it }
                            else audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVol
                        },
                        onDragEnd = { hud = null },
                        onDragCancel = { hud = null },
                    ) { change, dy ->
                        change.consume()
                        level = (level - dy / (size.height * 0.8f)).coerceIn(0f, 1f)
                        if (left) {
                            val act = ctx as Activity
                            act.window.attributes = act.window.attributes.apply { screenBrightness = level.coerceAtLeast(0.01f) }
                            hud = "brightness" to level
                        } else {
                            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (level * maxVol).toInt(), 0)
                            hud = "volume" to level
                        }
                    }
                }.pointerInput(locked, firstFrame) {
                    detectTapGestures(
                        onTap = { if (firstFrame) { if (showInfo) showInfo = false else { controls = !controls; poke++ } } },
                        onDoubleTap = { o ->
                            if (!locked && firstFrame) {
                                if (o.x < size.width / 2f) { seekBy(-10_000); seekHint = "-10s" } else { seekBy(10_000); seekHint = "+10s" }
                            }
                        },
                    )
                },
            )

            LaunchedEffect(seekHint) { if (seekHint != null) { delay(700); seekHint = null } }
            seekHint?.let {
                Text(it, Modifier.align(if (it.startsWith("-")) Alignment.CenterStart else Alignment.CenterEnd).padding(horizontal = side)
                    .clip(RoundedCornerShape(30.dp)).background(Color(0x88000000)).padding(horizontal = 18.dp, vertical = 10.dp),
                    fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            }
            // Mid-playback buffering: a thin spinner only.
            if (firstFrame && buffering && failure == null) CircularProgressIndicator(Modifier.align(Alignment.Center).size(40.dp), color = Color.White, strokeWidth = 3.dp)
            hud?.let { (kind, lvl) ->
                Row(
                    Modifier.align(Alignment.TopCenter).padding(top = 32.dp).clip(RoundedCornerShape(24.dp)).background(Color(0xB3000000))
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(if (kind == "brightness") Icons.Default.LightMode else if (lvl == 0f) Icons.Default.VolumeOff else Icons.Default.VolumeUp, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Box(Modifier.width(140.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0x55FFFFFF))) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth(lvl).background(Color.White))
                    }
                    Spacer(Modifier.width(10.dp))
                    Text("${(lvl * 100).toInt()}%", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            LaunchedEffect(aspectLabel) { if (aspectLabel != null) { delay(1500); aspectLabel = null } }
            aspectLabel?.let {
                Text(it, Modifier.align(Alignment.Center).padding(top = 110.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xB3000000))
                    .padding(horizontal = 16.dp, vertical = 8.dp), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }

            // Content advisory, top-left: white bar + "Category · Level" lines, 12sp.
            AnimatedVisibility(showAdvisory && advisory.isNotEmpty() && !controls, Modifier.align(Alignment.TopStart).padding(start = side, top = 20.dp),
                enter = fadeIn(tween(500)), exit = fadeOut(tween(500))) {
                Row(Modifier.height(IntrinsicSize.Min)) {
                    Box(Modifier.width(3.dp).fillMaxHeight().background(Color.White))
                    Column(Modifier.padding(start = 12.dp)) {
                        advisory.forEach { (cat, level) ->
                            Row(Modifier.padding(vertical = 4.dp)) {
                                Text(cat, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text("  ·  $level", fontSize = 12.sp, color = Color(0xFFB6BDCC))
                            }
                        }
                    }
                }
            }

            // Skip intro / recap, and Next episode near the end.
            val s = segs
            val inIntro = s?.intro?.let { pos >= it.start_ms && pos < it.end_ms - 1500 } == true
            val inRecap = s?.recap?.let { pos >= it.start_ms && pos < it.end_ms - 1500 } == true
            val nearEnd = nextEp != null && dur > 0 && (s?.outro?.let { pos >= it.start_ms } ?: (pos >= dur - 120_000))
            if (firstFrame) Column(Modifier.align(Alignment.BottomEnd).padding(end = side, bottom = if (controls) 128.dp else 32.dp), horizontalAlignment = Alignment.End) {
                if (inIntro || inRecap) PillButton(if (inIntro) "Skip Intro" else "Skip Recap", Icons.Default.FastForward) {
                    player.seekTo(if (inIntro) s!!.intro!!.end_ms else s!!.recap!!.end_ms)
                }
                if (nearEnd && !locked) PillButton("Next Episode", Icons.Default.SkipNext) { playNext() }
            }

            // ───── Controls (fade in / out) ─────
            AnimatedVisibility(controls && !locked && !showInfo && firstFrame, Modifier.fillMaxSize(), enter = fadeIn(tween(220)), exit = fadeOut(tween(260))) {
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to Color(0x8C000000), 0.28f to Color(0x26000000), 0.6f to Color(0x33000000), 1f to Color(0xD9000000)))) {
                    Row(Modifier.align(Alignment.TopEnd).padding(top = topY, end = topEnd), horizontalArrangement = Arrangement.spacedBy(33.dp), verticalAlignment = Alignment.CenterVertically) {
                        CtlIcon(Icons.Default.LockOpen, "Lock", 22) { locked = true; controls = true; poke++ }
                        CtlIcon(Icons.AutoMirrored.Filled.ArrowBack, "Back", 22) { onBack() }
                    }
                    // Centre: replay 10 · play/pause · forward 10, 160dp apart (centre to centre).
                    Box(Modifier.align(Alignment.Center).width(380.dp).height(72.dp)) {
                        CtlIcon(Icons.Default.Replay10, "Back 10 seconds", 30, Modifier.align(Alignment.Center).offset(x = (-160).dp)) { seekBy(-10_000) }
                        CtlIcon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "Pause" else "Play", 40, Modifier.align(Alignment.Center)) {
                            if (player.isPlaying) player.pause() else player.play(); poke++
                        }
                        CtlIcon(Icons.Default.Forward10, "Forward 10 seconds", 30, Modifier.align(Alignment.Center).offset(x = 160.dp)) { seekBy(10_000) }
                    }
                    Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(start = side, end = side, bottom = bottomY)) {
                        Text(meta?.name?.takeIf { type == "movie" } ?: p.title, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        now?.source?.let { Text("Via ${it.replace("\n", " | ")}", Modifier.padding(top = 2.dp), fontSize = 13.sp, color = Color(0xFFA9AFBC), fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                        Spacer(Modifier.height(10.dp))
                        SeekBar(pos, buffered, dur) { player.seekTo(it); poke++ }
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(29.dp)) {
                            CtlIcon(Icons.Default.ClosedCaption, "Subtitles", 26, pad = 0) { panel = "subs" }
                            CtlIcon(Icons.Default.Audiotrack, "Audio", 24, pad = 0) { panel = "audio" }
                            CtlIcon(Icons.Default.CloudQueue, "Sources", 26, pad = 0) { panel = "sources" }
                            if (nextEp != null) CtlIcon(Icons.Default.SkipNext, "Next episode", 26, pad = 0) { playNext() }
                            CtlIcon(Icons.Default.Speed, "Speed", 26, pad = 0) { panel = "speed" }
                            if (more) {
                                CtlIcon(Icons.Default.AspectRatio, "Aspect ratio", 26, pad = 0) {
                                    aspectIdx = (aspectIdx + 1) % AspectModes.size
                                    resize = AspectModes[aspectIdx].second
                                    aspectLabel = AspectModes[aspectIdx].first
                                    poke++
                                }
                                CtlIcon(Icons.Default.OpenInNew, "Open in another player", 24, pad = 0) { player.pause(); now?.let { openExternal(ctx, it.url, p.title) } }
                                CtlIcon(Icons.Outlined.Info, "Info", 25, pad = 0) { showInfo = true; controls = false }
                            }
                            Box(Modifier.size(30.dp).clip(CircleShape).background(Color(0x40FFFFFF)).clickable { more = !more; poke++ }, Alignment.Center) {
                                Icon(if (more) Icons.Default.ChevronLeft else Icons.Default.ChevronRight, if (more) "Less" else "More", Modifier.size(20.dp))
                            }
                            Spacer(Modifier.weight(1f))
                            Text("${fmtTime(pos)} / ${fmtTime(dur)}", fontSize = 15.sp)
                        }
                    }
                }
            }

            if (locked && controls) {
                Box(Modifier.align(Alignment.TopEnd).padding(top = topY, end = topEnd).size(44.dp).clip(CircleShape).background(Color(0x99000000))
                    .clickable { locked = false; poke++ }, Alignment.Center) { Icon(Icons.Default.Lock, "Unlock", Modifier.size(22.dp)) }
                LaunchedEffect(poke) { delay(2500); if (locked) controls = false }
            }

            // Info screen while paused.
            AnimatedVisibility(showInfo, Modifier.fillMaxSize(), enter = fadeIn(tween(400)), exit = fadeOut(tween(300))) {
                val m = meta
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0f to Color(0xF2000000), 0.6f to Color(0xAA000000), 1f to Color(0x22000000)))
                    .clickable { showInfo = false }) {
                    Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(0.55f).padding(start = side)) {
                        Text("You're watching", fontSize = 15.sp, color = Color(0xFFB6BDCC))
                        if (m != null && logoOf(m) != null) AsyncImage(logoOf(m), m.name, Modifier.padding(vertical = 10.dp).height(70.dp), contentScale = ContentScale.Fit, alignment = Alignment.CenterStart)
                        else Text(m?.name ?: p.title, fontSize = 30.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 8.dp))
                        if (type == "series") Text(p.title.removePrefix(m?.name ?: "").trim(), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                        m?.let { mm ->
                            Text(listOfNotNull(mm.releaseInfo, mm.runtime, mm.imdbRating?.let { "IMDb $it" }).joinToString("  •  "), fontSize = 14.sp, color = Color(0xFFC9CEDB), modifier = Modifier.padding(top = 6.dp))
                            mm.genres?.takeIf { it.isNotEmpty() }?.let { Text(it.take(3).joinToString(" · "), fontSize = 14.sp, color = Accent, modifier = Modifier.padding(top = 4.dp)) }
                            val epDesc = mm.videos?.firstOrNull { it.id == p.key }?.let { it.title ?: it.name }
                            Text(mm.description ?: epDesc ?: "", fontSize = 15.sp, lineHeight = 22.sp, color = Color(0xFFE2E5EC), maxLines = 5, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 12.dp))
                        }
                        Text("Tap anywhere to continue", fontSize = 13.sp, color = Color(0xFF8A94A8), modifier = Modifier.padding(top = 16.dp))
                    }
                }
            }

            // ───── Loading screen: dimmed artwork, "Finding stream source" → "Buffering…" ─────
            if (loadingAlpha > 0.01f) {
                Box(Modifier.fillMaxSize().graphicsLayer { alpha = loadingAlpha }.clickable(interactionSource = noRipple, indication = null) {}) {
                    AsyncImage(p.image ?: meta?.background ?: meta?.poster, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Color(0xA6000000)))
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0f to Color(0x66000000), 0.5f to Color.Transparent, 1f to Color(0x99000000))))
                    val f = failure
                    if (f == null) {
                        Crossfade(status, Modifier.align(Alignment.Center), animationSpec = tween(350), label = "status") { st ->
                            Text(st, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFD5D8DF), letterSpacing = 0.4.sp)
                        }
                    } else {
                        Column(Modifier.align(Alignment.Center).padding(horizontal = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(f, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                            Row(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                LoadBtn("Find another source", true) { findRequest = if (findRequest < 1) 2 else findRequest + 1 }
                                LoadBtn("Choose source", false) { failure = null; panel = "sources"; status = "Buffering…" }
                            }
                        }
                    }
                    Box(
                        Modifier.align(Alignment.TopEnd).padding(top = 20.dp, end = topEnd - 14.dp).size(50.dp).clip(CircleShape).background(Color(0x80000000)).clickable { onBack() },
                        Alignment.Center,
                    ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", Modifier.size(22.dp)) }
                    Box(
                        Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp).size(34.dp).clip(CircleShape).background(Color(0x40FFFFFF)).clickable { panel = "sources" },
                        Alignment.Center,
                    ) { Icon(Icons.Default.KeyboardArrowUp, "Sources", Modifier.size(22.dp)) }
                }
            }

            // ───── Side panels slide in from the right ─────
            LaunchedEffect(panel) { panel?.let { lastPanel = it } }
            AnimatedVisibility(panel != null, Modifier.fillMaxSize(), enter = fadeIn(tween(200)), exit = fadeOut(tween(200))) {
                Box(Modifier.fillMaxSize().background(Color(0x66000000)).clickable(interactionSource = noRipple, indication = null) { panel = null })
            }
            AnimatedVisibility(
                panel != null, Modifier.align(Alignment.CenterEnd).fillMaxHeight(),
                enter = slideInHorizontally(spring(dampingRatio = 0.86f, stiffness = 420f)) { it } + fadeIn(tween(160)),
                exit = slideOutHorizontally(tween(220)) { it } + fadeOut(tween(200)),
            ) {
                val which = panel ?: lastPanel
                Column(
                    Modifier.fillMaxHeight().width(400.dp).clip(RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp))
                        .background(Color(0xF5111216)).border(1.dp, Color(0x14FFFFFF), RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp))
                        .clickable(interactionSource = noRipple, indication = null) {}
                        .padding(horizontal = 20.dp, vertical = 20.dp),
                ) {
                    Text(
                        when (which) { "subs" -> "Subtitles"; "audio" -> "Audio"; "speed" -> "Playback speed"; else -> "Sources" },
                        fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp),
                    )
                    when (which) {
                        "subs" -> TrackList(tracks, C.TRACK_TYPE_TEXT, player, allowOff = true)
                        "audio" -> TrackList(tracks, C.TRACK_TYPE_AUDIO, player, allowOff = false)
                        "speed" -> OptionList(listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).map { "${it}x" to (speed == it) }) { i ->
                            speed = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)[i]; player.setPlaybackSpeed(speed); panel = null
                        }
                        else -> SourcesPanel(vm, type, p.key, now?.url) { st, all ->
                            panel = null
                            candidates = all.filter { it !== st }
                            val keep = if (firstFrame) player.currentPosition else p.resumeMs
                            scope.launch {
                                val extra = withTimeoutOrNull(1500) { runCatching { vm.subtitles(type, p.key) }.getOrDefault(emptyList()) }.orEmpty()
                                load(Now(st.stream.url!!, st.stream.subtitles.orEmpty() + extra, st.stream.name ?: st.addonName, st.addonName), keep)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CtlIcon(icon: ImageVector, desc: String, size: Int, modifier: Modifier = Modifier, pad: Int = 8, onClick: () -> Unit) =
    Icon(icon, desc, modifier.clip(CircleShape).clickable(onClick = onClick).padding(pad.dp).size(size.dp), tint = Color.White)

@Composable
private fun LoadBtn(text: String, primary: Boolean, onClick: () -> Unit) =
    Text(text, Modifier.clip(RoundedCornerShape(22.dp)).background(if (primary) Color.White else Color(0x33FFFFFF)).clickable(onClick = onClick)
        .padding(horizontal = 18.dp, vertical = 10.dp), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (primary) Color.Black else Color.White)

@OptIn(UnstableApi::class)
private val AspectModes = listOf(
    "Fit" to AspectRatioFrameLayout.RESIZE_MODE_FIT,
    "Crop" to AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
    "Stretch" to AspectRatioFrameLayout.RESIZE_MODE_FILL,
)

@Composable
private fun PillButton(text: String, icon: ImageVector, onClick: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Row(
        Modifier.padding(top = 10.dp).clip(shape).background(Color(0xE6FFFFFF)).border(1.dp, Color(0x33000000), shape)
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, Modifier.size(18.dp), tint = Color.Black)
        Spacer(Modifier.width(6.dp))
        Text(text, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Black)
    }
}

/** 6dp rounded seek bar: white = watched, grey = buffered. Tap or drag to seek. */
@Composable
private fun SeekBar(pos: Long, buffered: Long, dur: Long, onSeek: (Long) -> Unit) {
    var dragFrac by remember { mutableStateOf<Float?>(null) }
    val frac = dragFrac ?: if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
    val bFrac = if (dur > 0) (buffered.toFloat() / dur).coerceIn(0f, 1f) else 0f
    Canvas(
        Modifier.fillMaxWidth().height(22.dp)
            .pointerInput(dur) { detectTapGestures { o -> if (dur > 0) onSeek((o.x / size.width * dur).toLong()) } }
            .pointerInput(dur) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> dragFrac = (o.x / size.width).coerceIn(0f, 1f) },
                    onDragEnd = { dragFrac?.let { if (dur > 0) onSeek((it * dur).toLong()) }; dragFrac = null },
                    onDragCancel = { dragFrac = null },
                ) { change, _ -> dragFrac = (change.position.x / size.width).coerceIn(0f, 1f) }
            },
    ) {
        val h = 6.dp.toPx(); val y = (size.height - h) / 2f; val r = CornerRadius(h / 2f)
        drawRoundRect(Color(0x4DFFFFFF), Offset(0f, y), Size(size.width, h), r)
        drawRoundRect(Color(0x80FFFFFF), Offset(0f, y), Size(size.width * bFrac, h), r)
        drawRoundRect(Color.White, Offset(0f, y), Size(size.width * frac, h), r)
        if (dragFrac != null) drawCircle(Color.White, 8.dp.toPx(), Offset(size.width * frac, size.height / 2f))
    }
}

@Composable
private fun OptionList(options: List<Pair<String, Boolean>>, onPick: (Int) -> Unit) {
    LazyColumn {
        items(options.size) { i ->
            val (label, on) = options[i]
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onPick(i) }.padding(vertical = 13.dp, horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text(label, Modifier.weight(1f), fontSize = 16.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal)
                if (on) Icon(Icons.Default.Check, null, tint = Accent)
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun TrackList(tracks: Tracks, trackType: Int, player: ExoPlayer, allowOff: Boolean) {
    val opts = tracks.groups.filter { it.type == trackType }.flatMap { g ->
        (0 until g.length).filter { g.isTrackSupported(it) }.map { i ->
            val f = g.getTrackFormat(i)
            val name = listOfNotNull(f.label, f.language?.let { java.util.Locale(it).displayLanguage.takeIf { d -> d.isNotBlank() } ?: it })
                .distinct().joinToString(" · ").ifBlank { "Track ${i + 1}" }
            val extra = if (trackType == C.TRACK_TYPE_AUDIO && f.channelCount > 0) "  (${f.channelCount}ch)" else ""
            TrackOpt(name + extra, g, i, g.isTrackSelected(i))
        }
    }
    val off = player.trackSelectionParameters.disabledTrackTypes.contains(trackType)
    if (opts.isEmpty()) {
        Text(if (trackType == C.TRACK_TYPE_TEXT) "No subtitles in this stream. Install a subtitles addon to get more." else "Only one audio track.", color = Color(0xFF9AA3B5))
        return
    }
    val rows = (if (allowOff) listOf("Off" to off) else emptyList()) + opts.map { it.label to (it.selected && !off) }
    OptionList(rows) { i ->
        val params = player.trackSelectionParameters.buildUpon()
        if (allowOff && i == 0) params.setTrackTypeDisabled(trackType, true)
        else {
            val o = opts[if (allowOff) i - 1 else i]
            params.setTrackTypeDisabled(trackType, false).setOverrideForType(TrackSelectionOverride(o.group.mediaTrackGroup, o.index))
        }
        player.trackSelectionParameters = params.build()
    }
}

/** Sources inside the player: same filtered list and badges as the sources page. */
@Composable
private fun SourcesPanel(vm: AppViewModel, type: String, key: String, playingUrl: String?, onSwitch: (StreamItem, List<StreamItem>) -> Unit) {
    val texts by vm.texts.collectAsStateWithLifecycle()
    val pack by vm.badgePack.collectAsStateWithLifecycle()
    var all by remember { mutableStateOf<List<StreamItem>>(emptyList()) }
    var done by remember { mutableStateOf(false) }
    var showAll by remember { mutableStateOf(false) }
    LaunchedEffect(key) { vm.streamsFlow(type, key).collect { (l, d) -> all = l; done = d } }
    val f = remember(all, texts["tagRules"], showAll) { if (showAll) Filtered(all, 0, false, emptyList()) else vm.filtered(all) }
    val fusion = isOn(texts["fusionBadges"] ?: Defaults["fusionBadges"] ?: "yes")
    val showAddon = isOn(texts["showAddonName"] ?: "yes")
    when {
        f.forcedEmpty -> Column {
            Text("No ${f.forcedLabels.joinToString(" / ")} streams for this title.", color = Color(0xFF9AA3B5))
            LoadBtn("Show all streams", true) { showAll = true }
        }
        f.list.isEmpty() && done -> Text("No sources found.", color = Color(0xFF9AA3B5))
        f.list.isEmpty() -> Box(Modifier.fillMaxWidth().padding(30.dp), Alignment.Center) { CircularProgressIndicator(color = Color.White, strokeWidth = 3.dp) }
        else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(f.list) { s ->
                StreamCard(s, fusion, showAddon, pack, playing = s.stream.url == playingUrl, compact = true) { onSwitch(s, f.list) }
            }
            if (!done) item { Box(Modifier.fillMaxWidth().padding(12.dp), Alignment.Center) { CircularProgressIndicator(Modifier.size(24.dp), color = Color.White, strokeWidth = 2.dp) } }
        }
    }
}

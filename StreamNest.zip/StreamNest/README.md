# StreamNest
Disney+/Hotstar-inspired Android app (Kotlin, Compose, Media3 ExoPlayer).

- Customize: Profile tab -> Customize (edit every text, colors, roundness). Defaults in Config.kt; home-screen app name in res/values/strings.xml
- Metadata: Cinemeta (built-in, default addon)
- Addons: Stremio addon protocol (catalog / meta / stream / subtitles)
- Player: Media3 ExoPlayer (Apache-2.0), CC button for subtitle tracks
- Only direct-URL streams (HTTP/HLS/DASH) play. Torrent/infoHash streams are not supported.

## Build
1. Open this folder in Android Studio (Koala or newer). It generates the Gradle wrapper.
2. Sync, then Run on a device/emulator (minSdk 24).

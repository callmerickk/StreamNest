package com.example.streamnest

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString

const val CINEMETA = "https://v3-cinemeta.strem.io"

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val sp = app.getSharedPreferences("addons", Context.MODE_PRIVATE)

    val addons = MutableStateFlow<List<Addon>>(emptyList())
    val shelves = MutableStateFlow<List<Shelf>>(emptyList())
    val loading = MutableStateFlow(true)
    val searchResults = MutableStateFlow<List<Meta>>(emptyList())
    val addError = MutableStateFlow<String?>(null)
    private var searchJob: Job? = null

    private val lib = app.getSharedPreferences("library", Context.MODE_PRIVATE)
    val progress = MutableStateFlow(
        lib.getString("progress", null)?.let { runCatching { Api.json.decodeFromString<List<Progress>>(it) }.getOrNull() } ?: emptyList()
    )
    val myList = MutableStateFlow(
        lib.getString("mylist", null)?.let { runCatching { Api.json.decodeFromString<List<Meta>>(it) }.getOrNull() } ?: emptyList()
    )

    val texts = MutableStateFlow(
        lib.getString("custom", null)?.let { runCatching { Api.json.decodeFromString<Map<String, String>>(it) }.getOrNull() } ?: emptyMap()
    )

    init { applyPalette() }

    private fun applyPalette() {
        val m = Defaults + texts.value
        parseColor(m["accent"]!!)?.let { Palette.accent = it }
        parseColor(m["background"]!!)?.let { Palette.bg = it }
        parseColor(m["deckTint"]!!)?.let { Palette.tint = it }
        m["cardCorner"]!!.trim().toIntOrNull()?.let { Palette.corner = it.coerceIn(0, 50) }
    }

    fun setText(key: String, value: String) {
        texts.value = texts.value + (key to value)
        lib.edit().putString("custom", Api.json.encodeToString(texts.value)).apply()
        applyPalette()
    }

    fun resetTexts() {
        texts.value = emptyMap()
        lib.edit().remove("custom").apply()
        applyPalette()
    }

    fun saveProgress(p: Progress) {
        if (p.positionMs < 10_000) return
        val others = progress.value.filter { it.key != p.key }
        val done = p.durationMs > 0 && p.positionMs > p.durationMs * 0.95
        progress.value = (if (done) others else listOf(p) + others).take(20)
        lib.edit().putString("progress", Api.json.encodeToString(progress.value)).apply()
    }

    fun toggleList(m: Meta) {
        val cur = myList.value
        myList.value = if (cur.any { it.id == m.id }) cur.filter { it.id != m.id } else listOf(m) + cur
        lib.edit().putString("mylist", Api.json.encodeToString(myList.value)).apply()
    }

    init {
        viewModelScope.launch {
            val saved = sp.getString("list", null)?.let {
                runCatching { Api.json.decodeFromString<List<Addon>>(it) }.getOrNull()
            }
            val list = saved ?: runCatching {
                listOf(Addon(CINEMETA, Api.fetch<Manifest>("$CINEMETA/manifest.json")))
            }.getOrDefault(emptyList())
            setAddons(list)
            refresh()
        }
    }

    private fun setAddons(list: List<Addon>) {
        addons.value = list
        if (list.isNotEmpty()) sp.edit().putString("list", Api.json.encodeToString(list)).apply()
    }

    private fun enc(id: String) = Uri.encode(id, ":")

    fun refresh() = viewModelScope.launch {
        loading.value = true
        val result = coroutineScope {
            addons.value.flatMap { a ->
                a.manifest.catalogs
                    .filter { c -> c.extra.orEmpty().none { it.isRequired } }
                    .map { c ->
                        async {
                            runCatching {
                                val items = Api.fetch<CatalogResponse>("${a.baseUrl}/catalog/${c.type}/${enc(c.id)}.json").metas
                                Shelf("${c.name ?: c.id} ${c.type.replaceFirstChar { it.uppercase() }}", items)
                            }.getOrNull()
                        }
                    }
            }.take(14).awaitAll()
        }
        shelves.value = result.filterNotNull().filter { it.items.isNotEmpty() }
        loading.value = false
    }

    fun addAddon(input: String) {
        viewModelScope.launch {
            addError.value = null
            val base = Api.normalize(input)
            if (addons.value.any { it.baseUrl == base }) { addError.value = "Already installed"; return@launch }
            try {
                val m = Api.fetch<Manifest>("$base/manifest.json")
                setAddons(addons.value + Addon(base, m))
                refresh()
            } catch (e: Exception) {
                addError.value = "Couldn't load addon: ${e.message}"
            }
        }
    }

    fun removeAddon(a: Addon) {
        setAddons(addons.value - a)
        if (addons.value.isEmpty()) sp.edit().remove("list").apply()
        refresh()
    }

    fun search(q: String) {
        searchJob?.cancel()
        if (q.length < 2) { searchResults.value = emptyList(); return }
        searchJob = viewModelScope.launch {
            delay(400)
            val res = coroutineScope {
                addons.value.flatMap { a ->
                    a.manifest.catalogs.filter { c -> c.extra.orEmpty().any { it.name == "search" } }.map { c ->
                        async {
                            runCatching {
                                Api.fetch<CatalogResponse>("${a.baseUrl}/catalog/${c.type}/${enc(c.id)}/search=${Uri.encode(q)}.json").metas
                            }.getOrDefault(emptyList())
                        }
                    }
                }.awaitAll().flatten()
            }
            searchResults.value = res.distinctBy { it.type + it.id }
        }
    }

    suspend fun fullMeta(m: Meta): Meta? {
        for (a in addons.value.filter { it.supports("meta", m.type, m.id) }) {
            val r = runCatching { Api.fetch<MetaResponse>("${a.baseUrl}/meta/${m.type}/${enc(m.id)}.json").meta }.getOrNull()
            if (r != null) return r
        }
        return null
    }

    suspend fun streams(type: String, id: String): List<StreamItem> = coroutineScope {
        addons.value.filter { it.supports("stream", type, id) }.map { a ->
            async {
                runCatching {
                    Api.fetch<StreamResponse>("${a.baseUrl}/stream/$type/${enc(id)}.json").streams
                        .filter { !it.url.isNullOrBlank() }.map { StreamItem(a.manifest.name, it) }
                }.getOrDefault(emptyList())
            }
        }.awaitAll().flatten()
    }

    suspend fun subtitles(type: String, id: String): List<Subtitle> = coroutineScope {
        addons.value.filter { it.supports("subtitles", type, id) }.map { a ->
            async {
                runCatching { Api.fetch<SubsResponse>("${a.baseUrl}/subtitles/$type/${enc(id)}.json").subtitles }
                    .getOrDefault(emptyList())
            }
        }.awaitAll().flatten()
    }
}

package com.example.streamnest

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom

const val CINEMETA = "https://v3-cinemeta.strem.io"

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context get() = getApplication<Application>()
    private val sp = app.getSharedPreferences("addons", Context.MODE_PRIVATE)
    // "library" holds app-wide settings (custom texts, playlist) and also the FIRST profile's watch data,
    // so everything saved by older versions carries over into profile 1 automatically.
    private val glob = app.getSharedPreferences("library", Context.MODE_PRIVATE)
    private val dev = app.getSharedPreferences("dev", Context.MODE_PRIVATE)

    val addons = MutableStateFlow<List<Addon>>(emptyList())
    val shelves = MutableStateFlow<List<Shelf>>(emptyList())
    val loading = MutableStateFlow(true)
    val searchResults = MutableStateFlow<List<Meta>>(emptyList())
    val addError = MutableStateFlow<String?>(null)
    private var searchJob: Job? = null

    val texts = MutableStateFlow(
        glob.getString("custom", null)?.let { runCatching { Api.json.decodeFromString<Map<String, String>>(it) }.getOrNull() } ?: emptyMap()
    )

    // bumped whenever the app logo changes, so screens reload it
    val imgVersion = MutableStateFlow(0)

    // ───────────── Profiles ─────────────
    val profiles = MutableStateFlow(loadProfiles())
    /** null until someone is picked on the "Who's watching?" screen */
    val current = MutableStateFlow<Profile?>(null)

    private var lib: SharedPreferences = glob
    val progress = MutableStateFlow<List<Progress>>(emptyList())
    val myList = MutableStateFlow<List<Meta>>(emptyList())
    val doneKeys = MutableStateFlow<Set<String>>(emptySet())
    val doneMs = MutableStateFlow(0L)

    private fun loadProfiles(): List<Profile> {
        val saved = glob.getString("profiles", null)?.let { runCatching { Api.json.decodeFromString<List<Profile>>(it) }.getOrNull() }
        if (!saved.isNullOrEmpty()) return saved
        // First run of this version: turn the existing user into profile 1 and add a Kids profile.
        val oldName = texts.value["profileName"]?.takeIf { it.isNotBlank() && it != "Guest" } ?: "Me"
        val oldAvatar = File(ctx.filesDir, "profile_avatar.img")
        val p1 = Profile("p1", oldName, avatar = if (oldAvatar.exists()) "img" else "")
        if (oldAvatar.exists()) oldAvatar.renameTo(avatarFile(p1))
        val list = listOf(p1, Profile("kids", "Kids", kids = true))
        glob.edit().putString("profiles", Api.json.encodeToString(list)).apply()
        return list
    }

    private fun saveProfiles(list: List<Profile>) {
        profiles.value = list
        glob.edit().putString("profiles", Api.json.encodeToString(list)).apply()
        current.value?.let { c -> current.value = list.firstOrNull { it.id == c.id } }
    }

    private fun prefsFor(p: Profile): SharedPreferences =
        if (p.id == "p1") glob else ctx.getSharedPreferences("library_${p.id}", Context.MODE_PRIVATE)

    fun selectProfile(p: Profile) {
        val wasKids = current.value?.kids
        current.value = p
        lib = prefsFor(p)
        progress.value = lib.getString("progress", null)?.let { runCatching { Api.json.decodeFromString<List<Progress>>(it) }.getOrNull() } ?: emptyList()
        myList.value = lib.getString("mylist", null)?.let { runCatching { Api.json.decodeFromString<List<Meta>>(it) }.getOrNull() } ?: emptyList()
        doneKeys.value = lib.getStringSet("done", emptySet())?.toSet() ?: emptySet()
        doneMs.value = lib.getLong("doneMs", 0L)
        if (wasKids != p.kids || shelves.value.isEmpty()) refresh()
    }

    /** Back to the "Who's watching?" screen. */
    fun leaveProfile() { current.value = null }

    fun addProfile(name: String, kids: Boolean): Profile {
        val p = Profile("p" + System.currentTimeMillis(), name.trim().ifEmpty { "Profile" }, kids)
        saveProfiles(profiles.value + p)
        return p
    }

    fun renameProfile(p: Profile, name: String, kids: Boolean) {
        val kidsChanged = p.kids != kids
        saveProfiles(profiles.value.map { if (it.id == p.id) it.copy(name = name.trim().ifEmpty { it.name }, kids = kids) else it })
        if (kidsChanged && current.value?.id == p.id) refresh()
    }

    fun deleteProfile(p: Profile) {
        if (profiles.value.size <= 1) return
        avatarFile(p).delete()
        if (p.id != "p1") ctx.deleteSharedPreferences("library_${p.id}")
        else glob.edit().remove("progress").remove("mylist").remove("done").remove("doneMs").apply()
        saveProfiles(profiles.value.filter { it.id != p.id })
        if (current.value?.id == p.id) current.value = null
    }

    fun avatarFile(p: Profile) = File(ctx.filesDir, "avatar_${p.id}")

    /** Copies the picked picture / GIF / video. Returns an error message, or null when it worked. */
    suspend fun setAvatar(p: Profile, uri: Uri): String? = withContext(Dispatchers.IO) {
        val type = ctx.contentResolver.getType(uri).orEmpty()
        val kind = when {
            type.startsWith("video/") -> "video"
            type == "image/gif" -> "gif"
            type.startsWith("image/") -> "img"
            else -> return@withContext "Pick a JPEG, PNG, GIF or a short video"
        }
        if (kind == "video") {
            val ms = runCatching {
                MediaMetadataRetriever().run {
                    setDataSource(ctx, uri)
                    val d = extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    release(); d
                }
            }.getOrDefault(0L)
            if (ms > 15_500) return@withContext "Video must be 15 seconds or shorter"
        }
        val size = runCatching { ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L }.getOrDefault(-1L)
        if (size > 25L * 1024 * 1024) return@withContext "File is too big (max 25 MB)"
        try {
            ctx.contentResolver.openInputStream(uri)!!.use { i -> avatarFile(p).outputStream().use { o -> i.copyTo(o) } }
        } catch (e: Exception) {
            return@withContext "Couldn't read that file"
        }
        withContext(Dispatchers.Main) {
            saveProfiles(profiles.value.map { if (it.id == p.id) it.copy(avatar = kind, ver = it.ver + 1) else it })
        }
        null
    }

    fun clearAvatar(p: Profile) {
        avatarFile(p).delete()
        saveProfiles(profiles.value.map { if (it.id == p.id) it.copy(avatar = "", ver = it.ver + 1) else it })
    }

    // ───────────── Custom texts & colors ─────────────
    init { applyPalette() }

    private fun applyPalette() {
        val m = Defaults + texts.value
        parseColor(m["accent"]!!)?.let { Palette.accent = it }
        parseColor(m["background"]!!)?.let { Palette.bg = it }
        parseColor(m["deckTint"]!!)?.let { Palette.tint = it }
        m["cardCorner"]!!.trim().toIntOrNull()?.let { Palette.corner = it.coerceIn(0, 50) }
    }

    fun setText(key: String, value: String) {
        texts.value = texts.value + (key to value)
        glob.edit().putString("custom", Api.json.encodeToString(texts.value)).apply()
        applyPalette()
    }

    fun resetTexts() {
        texts.value = emptyMap()
        glob.edit().remove("custom").apply()
        applyPalette()
    }

    // ───────────── Watch data (per profile) ─────────────
    fun saveProgress(p: Progress) {
        if (p.positionMs < 10_000) return
        val others = progress.value.filter { it.key != p.key }
        val done = p.durationMs > 0 && p.positionMs > p.durationMs * 0.95
        progress.value = (if (done) others else listOf(p) + others).take(20)
        val ed = lib.edit().putString("progress", Api.json.encodeToString(progress.value))
        if (done && p.key !in doneKeys.value) {
            doneKeys.value = doneKeys.value + p.key
            doneMs.value = doneMs.value + p.durationMs
            ed.putStringSet("done", doneKeys.value).putLong("doneMs", doneMs.value)
        }
        ed.apply()
    }

    fun removeProgress(key: String) {
        progress.value = progress.value.filter { it.key != key }
        lib.edit().putString("progress", Api.json.encodeToString(progress.value)).apply()
    }

    fun clearHistory() {
        progress.value = emptyList()
        doneKeys.value = emptySet()
        doneMs.value = 0L
        lib.edit().remove("progress").remove("done").remove("doneMs").apply()
    }

    fun toggleList(m: Meta) {
        val cur = myList.value
        myList.value = if (cur.any { it.id == m.id }) cur.filter { it.id != m.id } else listOf(m) + cur
        lib.edit().putString("mylist", Api.json.encodeToString(myList.value)).apply()
    }

    // ───────────── Addons & catalogs ─────────────
    init {
        viewModelScope.launch {
            val saved = sp.getString("list", null)?.let {
                runCatching { Api.json.decodeFromString<List<Addon>>(it) }.getOrNull()
            }
            val list = saved ?: runCatching {
                listOf(Addon(CINEMETA, Api.fetch<Manifest>("$CINEMETA/manifest.json")))
            }.getOrDefault(emptyList())
            setAddons(list)
            if (current.value != null) refresh()
        }
    }

    private fun setAddons(list: List<Addon>) {
        addons.value = list
        if (list.isNotEmpty()) sp.edit().putString("list", Api.json.encodeToString(list)).apply()
    }

    private fun enc(id: String) = Uri.encode(id, ":")

    private fun typeLabel(type: String) = when (type) {
        "movie" -> "Movies"
        "series" -> "Series"
        else -> type.replaceFirstChar { it.uppercase() }
    }

    private var refreshJob: Job? = null

    fun refresh() {
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch {
            loading.value = true
            val result = if (current.value?.kids == true) kidsShelves() else coroutineScope {
                addons.value.flatMap { a ->
                    a.manifest.catalogs
                        .filter { c -> c.extra.orEmpty().none { it.isRequired } }
                        .map { c ->
                            async {
                                runCatching {
                                    val items = Api.fetch<CatalogResponse>("${a.baseUrl}/catalog/${c.type}/${enc(c.id)}.json").metas
                                    Shelf("${c.name ?: c.id} ${typeLabel(c.type)}", items)
                                }.getOrNull()
                            }
                        }
                }.take(14).awaitAll()
            }
            shelves.value = result.filterNotNull().filter { it.items.isNotEmpty() }
            loading.value = false
        }
    }

    // Kids profile: only animation & family catalogs from Cinemeta.
    private suspend fun kidsShelves(): List<Shelf?> = coroutineScope {
        listOf(
            Triple("movie", "Animation", "Animated Movies"),
            Triple("series", "Animation", "Cartoons & Animated Series"),
            Triple("movie", "Family", "Family Movies"),
        ).map { (type, genre, title) ->
            async {
                runCatching {
                    Shelf(title, Api.fetch<CatalogResponse>("$CINEMETA/catalog/$type/top/genre=$genre.json").metas)
                }.getOrNull()
            }
        }.awaitAll()
    }

    fun addAddon(input: String) {
        viewModelScope.launch {
            addError.value = null
            val base = Api.normalize(input)
            if (addons.value.any { it.baseUrl == base }) { addError.value = "Already installed"; return@launch }
            try {
                val m = Api.fetch<Manifest>("$base/manifest.json")
                setAddons(addons.value + Addon(base, m))
                refresh()
            } catch (e: Exception) {
                addError.value = "Couldn't load addon: ${e.message}"
            }
        }
    }

    fun removeAddon(a: Addon) {
        setAddons(addons.value - a)
        if (addons.value.isEmpty()) sp.edit().remove("list").apply()
        refresh()
    }

    fun search(q: String) {
        searchJob?.cancel()
        if (q.length < 2) { searchResults.value = emptyList(); return }
        searchJob = viewModelScope.launch {
            delay(400)
            val res = coroutineScope {
                addons.value.flatMap { a ->
                    a.manifest.catalogs.filter { c -> c.extra.orEmpty().any { it.name == "search" } }.map { c ->
                        async {
                            runCatching {
                                Api.fetch<CatalogResponse>("${a.baseUrl}/catalog/${c.type}/${enc(c.id)}/search=${Uri.encode(q)}.json").metas
                            }.getOrDefault(emptyList())
                        }
                    }
                }.awaitAll().flatten()
            }
            searchResults.value = res.distinctBy { it.type + it.id }
        }
    }

    suspend fun fullMeta(m: Meta): Meta? {
        for (a in addons.value.filter { it.supports("meta", m.type, m.id) }) {
            val r = runCatching { Api.fetch<MetaResponse>("${a.baseUrl}/meta/${m.type}/${enc(m.id)}.json").meta }.getOrNull()
            if (r != null) return r
        }
        return null
    }

    suspend fun streams(type: String, id: String): List<StreamItem> = coroutineScope {
        addons.value.filter { it.supports("stream", type, id) }.map { a ->
            async {
                runCatching {
                    Api.fetch<StreamResponse>("${a.baseUrl}/stream/$type/${enc(id)}.json").streams
                        .filter { !it.url.isNullOrBlank() }.map { StreamItem(a.manifest.name, it) }
                }.getOrDefault(emptyList())
            }
        }.awaitAll().flatten()
    }

    suspend fun subtitles(type: String, id: String): List<Subtitle> = coroutineScope {
        addons.value.filter { it.supports("subtitles", type, id) }.map { a ->
            async {
                runCatching { Api.fetch<SubsResponse>("${a.baseUrl}/subtitles/$type/${enc(id)}.json").subtitles }
                    .getOrDefault(emptyList())
            }
        }.awaitAll().flatten()
    }

    // ───────────── App logo (Developer's Corner) ─────────────
    fun logoFile() = File(ctx.filesDir, "app_logo.img")

    fun setLogo(uri: Uri) {
        runCatching {
            ctx.contentResolver.openInputStream(uri)!!.use { i -> logoFile().outputStream().use { o -> i.copyTo(o) } }
        }
        imgVersion.value = imgVersion.value + 1
    }

    fun clearLogo() { logoFile().delete(); imgVersion.value = imgVersion.value + 1 }

    // ───────────── Developer's Corner password (salted hash, never stored as plain text) ─────────────
    private fun hashPw(salt: String, pw: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        var d = (salt + pw).toByteArray()
        repeat(5000) { d = md.digest(d) }
        return d.joinToString("") { "%02x".format(it) }
    }

    private fun newSalt() = ByteArray(16).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }

    private fun ensureDevPassword() {
        if (dev.contains("hash")) return
        val salt = newSalt()
        dev.edit().putString("salt", salt).putString("hash", hashPw(salt, "Anish@2007")).apply()
    }

    fun checkDevPassword(pw: String): Boolean {
        ensureDevPassword()
        return hashPw(dev.getString("salt", "") ?: "", pw) == dev.getString("hash", "")
    }

    fun changeDevPassword(old: String, new: String): Boolean {
        if (!checkDevPassword(old)) return false
        val salt = newSalt()
        dev.edit().putString("salt", salt).putString("hash", hashPw(salt, new)).apply()
        return true
    }

    // ───────────── Live TV (M3U playlist) ─────────────
    val channels = MutableStateFlow<List<Channel>>(emptyList())
    val tvUrl = MutableStateFlow(glob.getString("m3u", "") ?: "")
    val tvLoading = MutableStateFlow(false)
    val tvError = MutableStateFlow<String?>(null)

    fun loadChannels(url: String) {
        viewModelScope.launch {
            tvLoading.value = true
            tvError.value = null
            try {
                val list = parseM3u(Api.get(url.trim()))
                if (list.isEmpty()) {
                    tvError.value = "No channels found in that playlist"
                } else {
                    channels.value = list
                    tvUrl.value = url.trim()
                    glob.edit().putString("m3u", url.trim()).apply()
                }
            } catch (e: Exception) {
                tvError.value = "Couldn't load playlist: ${e.message}"
            }
            tvLoading.value = false
        }
    }

    fun clearChannels() {
        channels.value = emptyList()
        tvUrl.value = ""
        tvError.value = null
        glob.edit().remove("m3u").apply()
    }

    init { if (tvUrl.value.isNotBlank()) loadChannels(tvUrl.value) }
}

private val logoRe = Regex("tvg-logo=\"([^\"]*)\"")
private val groupRe = Regex("group-title=\"([^\"]*)\"")

fun parseM3u(text: String): List<Channel> {
    val out = ArrayList<Channel>()
    var name: String? = null
    var logo: String? = null
    var group: String? = null
    for (raw in text.lineSequence()) {
        val line = raw.trim()
        if (line.startsWith("#EXTINF")) {
            name = line.substringAfterLast(",").trim()
            logo = logoRe.find(line)?.groupValues?.get(1)?.takeIf { it.isNotBlank() }
            group = groupRe.find(line)?.groupValues?.get(1)?.takeIf { it.isNotBlank() }
        } else if (line.isNotEmpty() && !line.startsWith("#") && name != null) {
            out.add(Channel(name.ifBlank { line }, logo, group, line))
            name = null
        }
    }
    return out
}

/** Cinemeta's own image host gives wide backdrops and title logos for any IMDb id. */
fun backdropOf(m: Meta): String? = m.background
    ?: if (m.id.startsWith("tt")) "https://images.metahub.space/background/medium/${m.id.substringBefore(':')}/img" else m.poster

fun logoOf(m: Meta): String? = m.logo
    ?: if (m.id.startsWith("tt")) "https://images.metahub.space/logo/medium/${m.id.substringBefore(':')}/img" else null

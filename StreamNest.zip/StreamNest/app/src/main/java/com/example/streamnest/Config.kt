package com.example.streamnest

import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color

/*
 * EDIT TEXTS HERE (defaults) or inside the app: Profile tab -> Customize.
 * Values changed inside the app are saved on the phone and override these defaults.
 */
val Defaults: Map<String, String> = linkedMapOf(
    "appName" to "StreamNest",
    "showBrand" to "yes",
    "forYou" to "For You",
    "badge" to "#{rank} in Popular",
    "watchNow" to "Watch Now",
    "continueWatching" to "Continue Watching",
    "myList" to "My List",
    "pillLeft" to "TV",
    "pillRight" to "Movies",
    "navHome" to "Home",
    "searchHint" to "Search movies & series",
    "playBtn" to "Play",
    "chooseSource" to "Choose source",
    "noStreams" to "No playable (direct URL) streams found. Install an addon that provides streams.",
    "emptyMsg" to "Nothing to show. Check your connection or add an addon.",
    "addonsTitle" to "Addons",
    "addonsHint" to "Paste an addon link (https:// or stremio://). Addons provide catalogs, streams and subtitles.",
    "addonUrlHint" to "Addon URL",
    "installBtn" to "Install",
    "accent" to "#1F80E0",
    "background" to "#0B0F1A",
    "deckTint" to "#2B1A47",
    "cardCorner" to "34",
)

data class Field(val key: String, val label: String)

val TextFields = listOf(
    Field("appName", "App name"),
    Field("showBrand", "Show app name on Home (yes / no)"),
    Field("forYou", "Home title"),
    Field("badge", "Badge text ({rank} = number, empty = hide)"),
    Field("watchNow", "Watch button"),
    Field("continueWatching", "Continue row title"),
    Field("myList", "My List title"),
    Field("pillLeft", "Pill tab 1 (shows series)"),
    Field("pillRight", "Pill tab 2 (shows movies)"),
    Field("navHome", "Bottom bar: Home label"),
    Field("searchHint", "Search placeholder"),
    Field("playBtn", "Play button"),
    Field("chooseSource", "Source dialog title"),
    Field("noStreams", "No streams message"),
    Field("emptyMsg", "Empty home message"),
    Field("addonsTitle", "Addons page title"),
    Field("addonsHint", "Addons page hint"),
    Field("addonUrlHint", "Addon URL placeholder"),
    Field("installBtn", "Install button"),
)

val StyleFields = listOf(
    Field("accent", "Accent color (hex, e.g. #1F80E0)"),
    Field("background", "Background color (hex)"),
    Field("deckTint", "Home top glow color (hex)"),
    Field("cardCorner", "Card roundness (0 to 50)"),
)

object Palette {
    var accent by mutableStateOf(Color(0xFF1F80E0))
    var bg by mutableStateOf(Color(0xFF0B0F1A))
    var tint by mutableStateOf(Color(0xFF2B1A47))
    var corner by mutableIntStateOf(34)
}

fun parseColor(s: String): Color? = runCatching {
    Color(android.graphics.Color.parseColor(if (s.trim().startsWith("#")) s.trim() else "#${s.trim()}"))
}.getOrNull()

val LocalTexts = compositionLocalOf<Map<String, String>> { emptyMap() }

@Composable
fun t(key: String): String = LocalTexts.current[key] ?: Defaults[key] ?: key

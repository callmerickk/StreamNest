package com.example.streamnest

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg: Color get() = Palette.bg
val Accent: Color get() = Palette.accent
val Surface1 = Color(0xFF151C2E)

@Composable
fun StreamNestTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, background = Bg, surface = Bg,
            surfaceVariant = Surface1, onBackground = Color.White, onSurface = Color.White,
        ),
        content = content,
    )
}

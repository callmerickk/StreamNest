package com.example.streamnest

import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlin.math.abs

@Composable
private fun SectionTitle(text: String) =
    Text(text, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFE6E9F2),
        modifier = Modifier.padding(start = 16.dp, top = 28.dp, bottom = 12.dp))

@Composable
fun HomeScreen(
    vm: AppViewModel,
    homeTap: Int,
    onOpen: (Meta) -> Unit,
    onPlay: (Screen.Player) -> Unit,
    onVoice: (String) -> Unit,
) {
    val allShelves by vm.shelves.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val myList by vm.myList.collectAsStateWithLifecycle()
    val ver by vm.imgVersion.collectAsStateWithLifecycle()
    var filter by remember { mutableStateOf<String?>(null) }
    var pillOpen by rememberSaveable { mutableStateOf(true) }
    val listState = rememberLazyListState()
    val ctx = LocalContext.current

    val hasSports = remember(allShelves) { allShelves.any { it.title.contains("sport", ignoreCase = true) } }
    val shelves = remember(allShelves, filter) {
        allShelves.filter { s ->
            when (filter) {
                null -> true
                "sports" -> s.title.contains("sport", ignoreCase = true)
                else -> s.items.firstOrNull()?.type == filter
            }
        }
    }

    val autoSlide = t("autoSlide").trim().lowercase() != "no"
    val slideSecs = t("slideSeconds").trim().toIntOrNull()?.coerceIn(2, 20) ?: 5
    val showBrand = t("showBrand").trim().lowercase() == "yes"
    val brandName = t("appName")
    val continueTitle = t("continueWatching").replace("{name}", t("profileName"))
    val labelLeft = t("pillLeft")
    val labelRight = t("pillRight")
    val labelSports = t("pillSports")
    val logo = remember(ver) { vm.logoFile().takeIf { it.exists() } }

    LaunchedEffect(homeTap) { if (homeTap > 0) listState.animateScrollToItem(0) }

    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val q = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!q.isNullOrBlank()) onVoice(q)
    }
    val startVoice = {
        try {
            voice.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            )
        } catch (e: Exception) {
            Toast.makeText(ctx, "Voice search isn't available on this phone", Toast.LENGTH_SHORT).show()
        }
    }

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxWidth().height(560.dp).background(Brush.verticalGradient(listOf(Palette.tint, Bg))))

        if (shelves.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                if (loading) CircularProgressIndicator()
                else Text(t("emptyMsg"), Modifier.padding(32.dp))
            }
        } else {
            val deck = remember(shelves) { shelves.first().items.filter { it.poster != null || it.background != null }.take(8) }
            LazyColumn(Modifier.fillMaxSize(), state = listState) {
                item {
                    Column {
                        Row(
                            Modifier.statusBarsPadding().padding(start = 16.dp, top = 10.dp, bottom = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            if (logo != null) {
                                AsyncImage(logo, null, Modifier.size(34.dp).clip(RoundedCornerShape(9.dp)), contentScale = ContentScale.Crop)
                                Spacer(Modifier.width(10.dp))
                            }
                            if (showBrand) Text(brandName, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEDEFF7))
                            if (logo == null && !showBrand) Spacer(Modifier.height(34.dp))
                        }
                        Deck(deck, myList, autoSlide, slideSecs, onOpen) { vm.toggleList(it) }
                    }
                }
                if (progress.isNotEmpty()) {
                    item { SectionTitle(continueTitle) }
                    item {
                        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(progress, key = { it.key }) { p ->
                                ContinueCard(
                                    p,
                                    onClick = { onPlay(Screen.Player(p.title, p.url, p.subs, p.key, p.image, p.positionMs)) },
                                    onRemove = { vm.removeProgress(p.key) },
                                )
                            }
                        }
                    }
                }
                if (myList.isNotEmpty()) {
                    item { SectionTitle(t("myList")) }
                    item { PosterRow(myList, onOpen) }
                }
                items(shelves) { shelf ->
                    SectionTitle(shelf.title)
                    PosterRow(shelf.items, onOpen)
                }
                item { Spacer(Modifier.height(190.dp)) }
            }
        }

        FloatingFilters(
            filter = filter,
            expanded = pillOpen,
            labels = buildList {
                add(labelLeft to "series")
                add(labelRight to "movie")
                if (hasSports) add(labelSports to "sports")
            },
            onToggle = { pillOpen = !pillOpen },
            onFilter = { filter = if (filter == it) null else it },
            onMic = { startVoice() },
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 100.dp),
        )
    }
}

@Composable
private fun PosterRow(items: List<Meta>, onOpen: (Meta) -> Unit) =
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(items, key = { it.type + it.id }) { m -> Poster(m, Modifier.width(124.dp), onOpen) }
    }

@Composable
private fun Deck(
    items: List<Meta>,
    myList: List<Meta>,
    auto: Boolean,
    secs: Int,
    onOpen: (Meta) -> Unit,
    onToggle: (Meta) -> Unit,
) {
    if (items.isEmpty()) return
    val cardW = (LocalConfiguration.current.screenWidthDp * 0.83f).dp
    val pager = rememberPagerState { items.size }
    val dragged by pager.interactionSource.collectIsDraggedAsState()

    // Auto-slide: advance every few seconds; pauses while the finger is on the cards.
    LaunchedEffect(auto, secs, dragged, items.size) {
        if (!auto || dragged || items.size < 2) return@LaunchedEffect
        while (true) {
            delay(secs * 1000L)
            pager.animateScrollToPage((pager.currentPage + 1) % items.size, animationSpec = tween(700))
        }
    }

    HorizontalPager(
        state = pager,
        pageSize = PageSize.Fixed(cardW),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp),
        beyondViewportPageCount = 3,
        modifier = Modifier.fillMaxWidth(),
    ) { page ->
        val m = items[page]
        DeckCard(
            m, rank = page + 1, saved = myList.any { it.id == m.id },
            onOpen = { onOpen(m) }, onToggle = { onToggle(m) },
            modifier = Modifier
                .zIndex(-abs(page - pager.currentPage).toFloat())
                .graphicsLayer {
                    val r = page - pager.currentPage - pager.currentPageOffsetFraction
                    val s = 1f - 0.06f * minOf(abs(r), 2.5f)
                    scaleX = s; scaleY = s
                    if (r > 0f) translationX = -minOf(r, 3f) * size.width * 0.88f
                    alpha = if (r > 2.6f) 0f else 1f - 0.18f * minOf(abs(r), 2f)
                },
        )
    }
}

@Composable
private fun DeckCard(m: Meta, rank: Int, saved: Boolean, onOpen: () -> Unit, onToggle: () -> Unit, modifier: Modifier) {
    val shape = RoundedCornerShape(Palette.corner.dp)
    val badgeText = t("badge").replace("{rank}", rank.toString())
    Box(modifier.fillMaxWidth().aspectRatio(0.79f).clip(shape).background(Color(0xFF05070C)).clickable(onClick = onOpen)) {
        AsyncImage(m.poster ?: m.background, m.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.45f to Color.Transparent, 0.9f to Color(0xEE000000), 1f to Color.Black)))

        if (badgeText.isNotBlank()) Row(
            Modifier.padding(16.dp).clip(RoundedCornerShape(14.dp)).background(Color(0x77000000))
                .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(14.dp)).padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Default.EmojiEvents, null, Modifier.size(20.dp), tint = Color(0xFFFFC043))
            Spacer(Modifier.width(8.dp))
            Text(badgeText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }

        Column(Modifier.align(Alignment.BottomStart).padding(horizontal = 16.dp, vertical = 16.dp)) {
            if (m.logo != null) {
                AsyncImage(m.logo, m.name, Modifier.fillMaxWidth(0.8f).height(72.dp), contentScale = ContentScale.Fit, alignment = Alignment.CenterStart)
            } else {
                Text(m.name, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(8.dp))
            Text(
                (listOfNotNull(m.releaseInfo) + m.genres.orEmpty().take(2)).joinToString("  •  "),
                fontSize = 14.sp, color = Color(0xFFC9CEDB),
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassButton(Modifier.weight(1f).height(50.dp), onOpen) {
                    Icon(Icons.Default.PlayArrow, null, Modifier.size(26.dp)); Spacer(Modifier.width(6.dp))
                    Text(t("watchNow"), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                }
                GlassButton(Modifier.size(50.dp), onToggle) {
                    Icon(if (saved) Icons.Default.Check else Icons.Default.Add, if (saved) "In My List" else "Add to My List")
                }
            }
        }
    }
}

@Composable
private fun GlassButton(modifier: Modifier, onClick: () -> Unit, content: @Composable RowScope.() -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(modifier.clip(shape).background(Color(0x40FFFFFF)).border(1.dp, Color(0x26FFFFFF), shape).clickable(onClick = onClick),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically, content = content)
}

@Composable
private fun ContinueCard(p: Progress, onClick: () -> Unit, onRemove: () -> Unit) {
    val frac = if (p.durationMs > 0) (p.positionMs.toFloat() / p.durationMs).coerceIn(0f, 1f) else 0f
    val leftMin = if (p.durationMs > 0) ((p.durationMs - p.positionMs) / 60000).toInt() else 0
    val left = if (p.durationMs <= 0) "Resume" else if (leftMin >= 60) "${leftMin / 60}h ${leftMin % 60}m left" else "${maxOf(leftMin, 1)}m left"
    var menu by remember { mutableStateOf(false) }
    Column(Modifier.width(220.dp)) {
        Column(Modifier.clickable(onClick = onClick)) {
            Box(Modifier.fillMaxWidth().aspectRatio(1.78f).clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp)).background(Surface1)) {
                AsyncImage(p.image, p.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Icon(Icons.Default.PlayArrow, null, Modifier.align(Alignment.BottomStart).padding(8.dp).size(30.dp))
            }
            Box(Modifier.fillMaxWidth().height(3.dp).background(Color(0x33FFFFFF))) {
                Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(Accent))
            }
        }
        Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(p.title, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(left, fontSize = 12.sp, color = Color(0xFF8A94A8))
            }
            Box {
                Icon(Icons.Default.MoreVert, "More", Modifier.clickable { menu = true }.padding(2.dp).size(22.dp), tint = Color(0xFFB6BDCC))
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Remove from Continue Watching") }, onClick = { menu = false; onRemove() })
                }
            }
        }
    }
}

@Composable
private fun FloatingFilters(
    filter: String?,
    expanded: Boolean,
    labels: List<Pair<String, String>>,
    onToggle: () -> Unit,
    onFilter: (String) -> Unit,
    onMic: () -> Unit,
    modifier: Modifier,
) {
    val pill = RoundedCornerShape(50)
    Row(modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Row(
            Modifier.clip(pill).background(Brush.horizontalGradient(listOf(Color(0xF02A3590), Color(0xF0512C86))))
                .border(1.dp, Color(0x33FFFFFF), pill).animateContentSize().padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AnimatedVisibility(
                visible = expanded,
                enter = expandHorizontally() + fadeIn(),
                exit = shrinkHorizontally() + fadeOut(),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    labels.forEach { (label, type) ->
                        Text(label, Modifier.clickable { onFilter(type) }.padding(horizontal = 20.dp, vertical = 16.dp),
                            fontSize = 18.sp, fontWeight = FontWeight.Medium, maxLines = 1,
                            color = if (filter == type) Color.White else Color(0xB3FFFFFF))
                        Box(Modifier.width(1.dp).height(22.dp).background(Color(0x44FFFFFF)))
                    }
                }
            }
            Icon(
                if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.FilterList,
                if (expanded) "Collapse" else "Expand",
                Modifier.clickable(onClick = onToggle).padding(horizontal = 14.dp, vertical = 14.dp).size(28.dp),
            )
        }
        Box(
            Modifier.size(58.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF1F4FA8), Color(0xFF5A2A8A))))
                .border(1.dp, Color(0x33FFFFFF), CircleShape).clickable(onClick = onMic),
            Alignment.Center,
        ) { Icon(Icons.Default.Mic, "Voice search", Modifier.size(26.dp)) }
    }
}

package com.example.streamnest

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object Api {
    val json = Json { ignoreUnknownKeys = true; isLenient = true; coerceInputValues = true }
    val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS).build()

    suspend fun get(url: String): String = withContext(Dispatchers.IO) {
        http.newCall(Request.Builder().url(url).build()).execute().use {
            require(it.isSuccessful) { "HTTP ${it.code}" }
            it.body!!.string()
        }
    }

    suspend inline fun <reified T> fetch(url: String): T = json.decodeFromString<T>(get(url))

    fun normalize(input: String): String =
        input.trim().replace("stremio://", "https://").removeSuffix("/manifest.json").trimEnd('/')
}

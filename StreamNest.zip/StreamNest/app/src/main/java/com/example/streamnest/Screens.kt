package com.example.streamnest

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import androidx.compose.ui.graphics.vector.ImageVector
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

sealed interface Screen {
    data class Detail(val meta: Meta) : Screen
    data class Player(val title: String, val url: String, val subs: List<Subtitle>, val key: String = "", val image: String? = null, val resumeMs: Long = 0L) : Screen
}

@Composable
fun App(vm: AppViewModel = viewModel()) {
    val stack = remember { mutableStateListOf<Screen>() }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var homeTap by rememberSaveable { mutableIntStateOf(0) }
    var voiceQuery by rememberSaveable { mutableStateOf("") }
    val pop = { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex); Unit }
    BackHandler(stack.isNotEmpty()) { pop() }

    val texts by vm.texts.collectAsStateWithLifecycle()
    CompositionLocalProvider(LocalTexts provides texts) {
    when (val top = stack.lastOrNull()) {
        is Screen.Player -> PlayerScreen(top, onBack = pop, onProgress = { pos, dur ->
            if (top.key.isNotEmpty()) vm.saveProgress(Progress(top.key, top.title, top.image, top.url, top.subs, pos, dur, System.currentTimeMillis()))
        })
        is Screen.Detail -> DetailScreen(vm, top.meta, onBack = pop, onPlay = { stack.add(it) })
        null -> Box(Modifier.fillMaxSize().background(Bg)) {
            val open: (Meta) -> Unit = { stack.add(Screen.Detail(it)) }
            when (tab) {
                0 -> HomeScreen(vm, homeTap, open, { stack.add(it) }, onVoice = { voiceQuery = it; vm.search(it); tab = 1 })
                1 -> SearchScreen(vm, voiceQuery, open)
                2 -> LiveTvScreen(vm) { stack.add(it) }
                3 -> LibraryScreen(vm, open)
                else -> SettingsHost(vm)
            }
            FloatingNav(
                tab, vm,
                onTab = { if (it == 0 && tab == 0) { homeTap++; vm.refresh() } else tab = it },
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 12.dp),
            )
        }
    }
    }
}

@Composable
fun FloatingNav(tab: Int, vm: AppViewModel, onTab: (Int) -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(36.dp)
    Row(
        modifier.fillMaxWidth().padding(horizontal = 18.dp).clip(shape).background(Color(0xEE141926))
            .border(1.dp, Color(0x22FFFFFF), shape).padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically,
    ) {
        NavItem(Icons.Default.Home, t("navHome"), tab == 0, Modifier.weight(1f)) { onTab(0) }
        NavItem(Icons.Default.Search, t("navSearch"), tab == 1, Modifier.weight(1f)) { onTab(1) }
        NavItem(Icons.Default.LiveTv, t("navLive"), tab == 2, Modifier.weight(1f)) { onTab(2) }
        NavItem(Icons.Default.VideoLibrary, t("navLibrary"), tab == 3, Modifier.weight(1f)) { onTab(3) }
        Column(
            Modifier.weight(1f).clip(RoundedCornerShape(28.dp))
                .background(if (tab == 4) Accent.copy(alpha = 0.22f) else Color.Transparent)
                .clickable { onTab(4) }.padding(vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Avatar(vm, 30.dp, Modifier.then(if (tab == 4) Modifier.border(2.dp, Accent, CircleShape) else Modifier))
            if (tab == 4) Text(t("navProfile"), fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Accent, maxLines = 1)
        }
    }
}

@Composable
private fun NavItem(icon: ImageVector, label: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(28.dp))
            .background(if (selected) Accent.copy(alpha = 0.22f) else Color.Transparent)
            .clickable(onClick = onClick).padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, label, Modifier.size(28.dp), tint = if (selected) Accent else Color(0xFF8A94A8))
        if (selected) Text(label, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Accent, maxLines = 1)
    }
}

@Composable
fun Poster(m: Meta, modifier: Modifier = Modifier, onClick: (Meta) -> Unit) {
    AsyncImage(
        model = m.poster, contentDescription = m.name, contentScale = ContentScale.Crop,
        modifier = modifier.aspectRatio(2f / 3f).clip(RoundedCornerShape(8.dp)).background(Surface1).clickable { onClick(m) },
    )
}

// ───────────── Search ─────────────
@Composable
fun SearchScreen(vm: AppViewModel, initial: String, onOpen: (Meta) -> Unit) {
    var q by rememberSaveable(initial) { mutableStateOf(initial) }
    val res by vm.searchResults.collectAsStateWithLifecycle()
    Column(Modifier.statusBarsPadding().padding(16.dp)) {
        OutlinedTextField(
            q, { q = it; vm.search(it) }, Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text(t("searchHint")) }, leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(12.dp),
        )
        LazyVerticalGrid(
            GridCells.Adaptive(105.dp), contentPadding = PaddingValues(top = 16.dp, bottom = 120.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp),
        ) { items(res, key = { it.type + it.id }) { m -> Poster(m, Modifier.fillMaxWidth(), onOpen) } }
    }
}

// ───────────── Detail ─────────────
@Composable
fun DetailScreen(vm: AppViewModel, meta0: Meta, onBack: () -> Unit, onPlay: (Screen.Player) -> Unit) {
    var meta by remember { mutableStateOf(meta0) }
    LaunchedEffect(meta0.id) { vm.fullMeta(meta0)?.let { meta = it } }
    val scope = rememberCoroutineScope()
    var pick by remember { mutableStateOf<Pair<String, String>?>(null) } // videoId to title
    var streams by remember { mutableStateOf<List<StreamItem>?>(null) }
    LaunchedEffect(pick) { streams = null; pick?.let { streams = vm.streams(meta.type, it.first) } }

    val episodes = remember(meta) { meta.videos.orEmpty().filter { it.season != null && it.episode != null } }
    val seasons = remember(episodes) { episodes.mapNotNull { it.season }.distinct().sorted() }
    var season by remember(seasons) { mutableIntStateOf(seasons.firstOrNull { it > 0 } ?: seasons.firstOrNull() ?: 1) }
    val shown = remember(episodes, season) { episodes.filter { it.season == season }.sortedBy { it.episode } }

    Box(Modifier.fillMaxSize().background(Bg)) {
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Box(Modifier.fillMaxWidth().height(340.dp)) {
                    AsyncImage(meta.background ?: meta.poster, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x66000000), Color.Transparent, Bg))))
                }
            }
            item {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    Text(meta.name, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    val line = listOfNotNull(meta.releaseInfo, meta.runtime, meta.imdbRating?.let { "★ $it" }).joinToString("  •  ")
                    Text(line, color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                    meta.genres?.takeIf { it.isNotEmpty() }?.let { Text(it.joinToString(" • "), color = Accent, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)) }
                    if (episodes.isEmpty()) {
                        Button({ pick = meta.id to meta.name }, Modifier.fillMaxWidth().padding(top = 14.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent), shape = RoundedCornerShape(8.dp)) {
                            Icon(Icons.Default.PlayArrow, null); Text(t("playBtn"), fontWeight = FontWeight.Bold)
                        }
                    }
                    meta.description?.let { Text(it, color = Color(0xFFD0D4DC), fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 14.dp)) }
                    if (seasons.isNotEmpty()) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 14.dp)) {
                            items(seasons) { s -> FilterChip(season == s, { season = s }, { Text(if (s == 0) "Specials" else "Season $s") }) }
                        }
                    }
                }
            }
            items(shown, key = { it.id }) { ep ->
                Row(
                    Modifier.fillMaxWidth().clickable { pick = ep.id to "${meta.name}  S${ep.season}E${ep.episode}" }.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    AsyncImage(ep.thumbnail, null, Modifier.width(120.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(6.dp)).background(Surface1), contentScale = ContentScale.Crop)
                    Spacer(Modifier.width(12.dp))
                    Text("${ep.episode}. ${ep.title ?: ep.name ?: "Episode ${ep.episode}"}", maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.PlayCircle, null, tint = Accent)
                }
            }
            item { Spacer(Modifier.height(32.dp)) }
        }
        IconButton(onBack, Modifier.statusBarsPadding().padding(8.dp).background(Color(0x88000000), CircleShape)) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
    }

    pick?.let { (vid, title) ->
        AlertDialog(
            onDismissRequest = { pick = null },
            containerColor = Surface1,
            title = { Text(t("chooseSource")) },
            text = {
                val list = streams
                when {
                    list == null -> Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) { CircularProgressIndicator() }
                    list.isEmpty() -> Text(t("noStreams"))
                    else -> LazyColumn(Modifier.heightIn(max = 380.dp)) {
                        items(list) { s ->
                            Column(Modifier.fillMaxWidth().clickable {
                                scope.launch {
                                    val subs = s.stream.subtitles.orEmpty() + vm.subtitles(meta.type, vid)
                                    pick = null
                                    onPlay(Screen.Player(title, s.stream.url!!, subs, key = vid, image = meta.background ?: meta.poster))
                                }
                            }.padding(vertical = 10.dp)) {
                                Text(s.stream.name ?: s.addonName, fontWeight = FontWeight.SemiBold)
                                Text(s.stream.title ?: s.stream.description ?: "", color = Color.Gray, fontSize = 12.sp, maxLines = 3)
                            }
                            HorizontalDivider(color = Color(0x22FFFFFF))
                        }
                    }
                }
            },
            confirmButton = { TextButton({ pick = null }) { Text("Cancel") } },
        )
    }
}

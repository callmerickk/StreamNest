package com.example.streamnest

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

sealed interface Screen {
    data class Detail(val meta: Meta) : Screen
    data class Player(val title: String, val url: String, val subs: List<Subtitle>, val key: String = "", val image: String? = null, val resumeMs: Long = 0L) : Screen
}

@Composable
fun App(vm: AppViewModel = viewModel()) {
    val stack = remember { mutableStateListOf<Screen>() }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val pop = { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex); Unit }
    BackHandler(stack.isNotEmpty()) { pop() }

    val texts by vm.texts.collectAsStateWithLifecycle()
    CompositionLocalProvider(LocalTexts provides texts) {
    when (val top = stack.lastOrNull()) {
        is Screen.Player -> PlayerScreen(top, onBack = pop, onProgress = { pos, dur ->
            if (top.key.isNotEmpty()) vm.saveProgress(Progress(top.key, top.title, top.image, top.url, top.subs, pos, dur, System.currentTimeMillis()))
        })
        is Screen.Detail -> DetailScreen(vm, top.meta, onBack = pop, onPlay = { stack.add(it) })
        null -> Scaffold(
            containerColor = Bg,
            contentWindowInsets = WindowInsets(0),
            bottomBar = { BottomBar(tab) { tab = it } },
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                val open: (Meta) -> Unit = { stack.add(Screen.Detail(it)) }
                when (tab) {
                    0 -> HomeScreen(vm, open) { stack.add(it) }
                    1 -> SearchScreen(vm, open)
                    else -> AddonsScreen(vm)
                }
            }
        }
    }
    }
}

@Composable
fun BottomBar(tab: Int, onTab: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF0D121D)).navigationBarsPadding()) {
        Box(Modifier.fillMaxWidth().height(2.dp).background(Brush.horizontalGradient(listOf(Color.Transparent, Accent, Color.Transparent))))
        Row(Modifier.fillMaxWidth().height(68.dp), horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically) {
            val off = Color(0xFF8A94A8)
            Column(Modifier.clickable { onTab(0) }.padding(horizontal = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.AutoAwesome, "Home", Modifier.size(30.dp), tint = if (tab == 0) Color.White else off)
                if (tab == 0) Text(t("navHome"), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
            Icon(Icons.Default.Search, "Search", Modifier.clickable { onTab(1) }.padding(horizontal = 24.dp).size(54.dp).padding(12.dp), tint = if (tab == 1) Color.White else off)
            Box(
                Modifier.size(36.dp).clip(CircleShape).background(Surface1).clickable { onTab(2) }
                    .then(if (tab == 2) Modifier.border(2.dp, Accent, CircleShape) else Modifier),
                Alignment.Center,
            ) { Icon(Icons.Default.Person, "Profile and addons", tint = Color.White) }
        }
    }
}

@Composable
fun Poster(m: Meta, modifier: Modifier = Modifier, onClick: (Meta) -> Unit) {
    AsyncImage(
        model = m.poster, contentDescription = m.name, contentScale = ContentScale.Crop,
        modifier = modifier.aspectRatio(2f / 3f).clip(RoundedCornerShape(8.dp)).background(Surface1).clickable { onClick(m) },
    )
}

// ───────────── Search ─────────────
@Composable
fun SearchScreen(vm: AppViewModel, onOpen: (Meta) -> Unit) {
    var q by rememberSaveable { mutableStateOf("") }
    val res by vm.searchResults.collectAsStateWithLifecycle()
    Column(Modifier.statusBarsPadding().padding(16.dp)) {
        OutlinedTextField(
            q, { q = it; vm.search(it) }, Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text(t("searchHint")) }, leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(12.dp),
        )
        LazyVerticalGrid(
            GridCells.Adaptive(105.dp), contentPadding = PaddingValues(top = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp),
        ) { items(res, key = { it.type + it.id }) { m -> Poster(m, Modifier.fillMaxWidth(), onOpen) } }
    }
}

// ───────────── Addons ─────────────
@Composable
fun AddonsScreen(vm: AppViewModel) {
    val addons by vm.addons.collectAsStateWithLifecycle()
    val error by vm.addError.collectAsStateWithLifecycle()
    val texts by vm.texts.collectAsStateWithLifecycle()
    var resetN by remember { mutableIntStateOf(0) }
    var url by rememberSaveable { mutableStateOf("") }
    LazyColumn(Modifier.statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text(t("addonsTitle"), fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text(t("addonsHint"), color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp))
            OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text(t("addonUrlHint")) }, shape = RoundedCornerShape(12.dp))
            Spacer(Modifier.height(8.dp))
            Button({ vm.addAddon(url); url = "" }, enabled = url.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Icon(Icons.Default.Add, null); Text(t("installBtn")) }
            error?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp) }
        }
        items(addons, key = { it.baseUrl }) { a ->
            Card(colors = CardDefaults.cardColors(containerColor = Surface1)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${a.manifest.name}  v${a.manifest.version}", fontWeight = FontWeight.SemiBold)
                        a.manifest.description?.let { Text(it, color = Color.Gray, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis) }
                    }
                    if (a.baseUrl != CINEMETA) IconButton({ vm.removeAddon(a) }) { Icon(Icons.Default.Delete, "Remove") }
                }
            }
        }
        item {
            Spacer(Modifier.height(16.dp))
            Text("Customize", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Edit any text, color or roundness. Changes apply instantly and are saved. The name under the app icon is set in res/values/strings.xml.", color = Color.Gray, fontSize = 13.sp, modifier = Modifier.padding(vertical = 6.dp))
        }
        items(TextFields + StyleFields, key = { "f_" + it.key }) { f ->
            key(resetN) {
                var v by remember { mutableStateOf(Defaults.let { _ -> texts[f.key] ?: Defaults[f.key] ?: "" }) }
                OutlinedTextField(v, { v = it; vm.setText(f.key, it) }, Modifier.fillMaxWidth(), label = { Text(f.label) }, shape = RoundedCornerShape(12.dp))
            }
        }
        item {
            OutlinedButton({ vm.resetTexts(); resetN++ }) { Text("Reset to defaults") }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ───────────── Detail ─────────────
@Composable
fun DetailScreen(vm: AppViewModel, meta0: Meta, onBack: () -> Unit, onPlay: (Screen.Player) -> Unit) {
    var meta by remember { mutableStateOf(meta0) }
    LaunchedEffect(meta0.id) { vm.fullMeta(meta0)?.let { meta = it } }
    val scope = rememberCoroutineScope()
    var pick by remember { mutableStateOf<Pair<String, String>?>(null) } // videoId to title
    var streams by remember { mutableStateOf<List<StreamItem>?>(null) }
    LaunchedEffect(pick) { streams = null; pick?.let { streams = vm.streams(meta.type, it.first) } }

    val episodes = remember(meta) { meta.videos.orEmpty().filter { it.season != null && it.episode != null } }
    val seasons = remember(episodes) { episodes.mapNotNull { it.season }.distinct().sorted() }
    var season by remember(seasons) { mutableIntStateOf(seasons.firstOrNull { it > 0 } ?: seasons.firstOrNull() ?: 1) }
    val shown = remember(episodes, season) { episodes.filter { it.season == season }.sortedBy { it.episode } }

    Box(Modifier.fillMaxSize().background(Bg)) {
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Box(Modifier.fillMaxWidth().height(340.dp)) {
                    AsyncImage(meta.background ?: meta.poster, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x66000000), Color.Transparent, Bg))))
                }
            }
            item {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    Text(meta.name, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    val line = listOfNotNull(meta.releaseInfo, meta.runtime, meta.imdbRating?.let { "★ $it" }).joinToString("  •  ")
                    Text(line, color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                    meta.genres?.takeIf { it.isNotEmpty() }?.let { Text(it.joinToString(" • "), color = Accent, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)) }
                    if (episodes.isEmpty()) {
                        Button({ pick = meta.id to meta.name }, Modifier.fillMaxWidth().padding(top = 14.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent), shape = RoundedCornerShape(8.dp)) {
                            Icon(Icons.Default.PlayArrow, null); Text(t("playBtn"), fontWeight = FontWeight.Bold)
                        }
                    }
                    meta.description?.let { Text(it, color = Color(0xFFD0D4DC), fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 14.dp)) }
                    if (seasons.isNotEmpty()) {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 14.dp)) {
                            items(seasons) { s -> FilterChip(season == s, { season = s }, { Text(if (s == 0) "Specials" else "Season $s") }) }
                        }
                    }
                }
            }
            items(shown, key = { it.id }) { ep ->
                Row(
                    Modifier.fillMaxWidth().clickable { pick = ep.id to "${meta.name}  S${ep.season}E${ep.episode}" }.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    AsyncImage(ep.thumbnail, null, Modifier.width(120.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(6.dp)).background(Surface1), contentScale = ContentScale.Crop)
                    Spacer(Modifier.width(12.dp))
                    Text("${ep.episode}. ${ep.title ?: ep.name ?: "Episode ${ep.episode}"}", maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    Icon(Icons.Default.PlayCircle, null, tint = Accent)
                }
            }
            item { Spacer(Modifier.height(32.dp)) }
        }
        IconButton(onBack, Modifier.statusBarsPadding().padding(8.dp).background(Color(0x88000000), CircleShape)) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
    }

    pick?.let { (vid, title) ->
        AlertDialog(
            onDismissRequest = { pick = null },
            containerColor = Surface1,
            title = { Text(t("chooseSource")) },
            text = {
                val list = streams
                when {
                    list == null -> Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) { CircularProgressIndicator() }
                    list.isEmpty() -> Text(t("noStreams"))
                    else -> LazyColumn(Modifier.heightIn(max = 380.dp)) {
                        items(list) { s ->
                            Column(Modifier.fillMaxWidth().clickable {
                                scope.launch {
                                    val subs = s.stream.subtitles.orEmpty() + vm.subtitles(meta.type, vid)
                                    pick = null
                                    onPlay(Screen.Player(title, s.stream.url!!, subs, key = vid, image = meta.background ?: meta.poster))
                                }
                            }.padding(vertical = 10.dp)) {
                                Text(s.stream.name ?: s.addonName, fontWeight = FontWeight.SemiBold)
                                Text(s.stream.title ?: s.stream.description ?: "", color = Color.Gray, fontSize = 12.sp, maxLines = 3)
                            }
                            HorizontalDivider(color = Color(0x22FFFFFF))
                        }
                    }
                }
            },
            confirmButton = { TextButton({ pick = null }) { Text("Cancel") } },
        )
    }
}

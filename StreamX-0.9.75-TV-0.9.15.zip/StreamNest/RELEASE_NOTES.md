StreamX 0.9.74

• New profile page: your Continue watching above the profiles, no more jumping profile.
• Green light only for a real copy (fake short videos are skipped before Play).
• Home style is now first in Settings › Layout, with previews.
• AI opens only when you tap it.

---

StreamX TV 0.9.15 

• Back on Home no longer freezes or closes the app.
• The first open after an update stays open.
• Posters load once at start (no more reloading).
• Home appears at once and refreshes quietly.

StreamX 0.9.75

• Settings › Layout like Xstream: Home style, Bottom bar and Theme with previews, plus Quick looks.
• New Glass theme. Everyone starts on All Live (change it any time).
• Top 10 and Home rows load faster.
• Just a ring when continuing — no text pill.
• Weak internet: quality steps down inside the stream instead of loading.

---

StreamX TV 0.9.15 

• Back on Home no longer freezes or closes the app.
• The first open after an update stays open.
• Posters load once at start (no more reloading).
• Home appears at once and refreshes quietly.

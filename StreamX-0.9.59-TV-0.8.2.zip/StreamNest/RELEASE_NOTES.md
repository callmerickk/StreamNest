StreamX 0.9.59

• MovieBox streams start at once and no longer freeze for 20+ seconds.
• Next episode: no loading screen. It gets ready in the corner while the current one plays, then takes over.
• Auto play next is off: the next episode starts only when you pick it, or when the current one has ended.
• Each title plays in the language you last used for it.
• 18+ is off by default (Settings › Layout to switch it on).
• Trailers on the top cards fill the card.
• Continue Watching opens straight away after the app was closed.

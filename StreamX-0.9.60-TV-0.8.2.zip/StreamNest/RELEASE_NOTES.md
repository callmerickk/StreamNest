StreamX 0.9.60

• Series like Game of Thrones and New Girl are found on Hotstar again.
• Still strict: a different show with the same name is never picked.
• Includes everything from 0.9.59: faster MovieBox, next episode in the corner, your language kept per title, 18+ off by default, trailers fill the cards.

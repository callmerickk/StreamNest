package com.example.streamnest

/** TV 0.8.6: FFmpeg audio decoders from our own LGPL build of Media3's FFmpeg extension (loaded by DefaultRenderersFactory
 * when extension renderers are on). No GPL code. */
open class FfRenderers(ctx: android.content.Context) : androidx.media3.exoplayer.DefaultRenderersFactory(ctx)

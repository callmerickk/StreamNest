package com.example.streamnest

/** Phone: NextLib FFmpeg decoders (until the phone build moves to the LGPL audio build too). */
open class FfRenderers(ctx: android.content.Context) : io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory(ctx)

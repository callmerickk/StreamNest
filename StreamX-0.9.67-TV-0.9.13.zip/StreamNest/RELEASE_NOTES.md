StreamX TV 0.9.13 (the phone app stays on 0.9.67)

• Lighter and smoother: pictures load at the size shown, Home fills faster.
• Background jobs wait until Home has settled and you stop scrolling.
• Opens and scrolls more smoothly (main screens pre-compiled).

StreamX 0.9.76

• Fewer crashes: only your subtitle languages are loaded, smarter memory use.
• Watch together: calls connect on mobile networks, call status shown, camera errors explained.
• New HDR switch (quality menu) — off by default.
• Glass theme on every page. Choose your look once (Glass is NEW).

---

StreamX TV 0.9.15 

• Back on Home no longer freezes or closes the app.
• The first open after an update stays open.
• Posters load once at start (no more reloading).
• Home appears at once and refreshes quietly.

StreamX TV 0.8.5 (the phone app stays on 0.9.65)

• Better quality is always reachable from the player bar (▲); its countdown waits while it is selected.
• Waits up to a minute for VegaMovies / RogMovies HD, then other sources; 4K TVs get "Upgrade to 4K".
• Seeking with the menu hidden: just the bar and a preview, 10 s steps that speed up when held, one jump on release.
• Quality list like the phone: Auto, 4K, 1080p 60fps, 1080p, 720p, 480p, Other streams.
• Search uses the TV's own keyboard and voice, plus a mic button; phone-style posters.
• Home like the phone: Pick up where you left off, numbered Trending, AIDEN picked for you; faster pictures and profiles.
• NOW PLAYING on Continue Watching when a title plays on another device; progress syncs within seconds.
• Turbo + Elite on from the start; Exit asks and can clear the cache.

StreamX TV 0.8.4 (the phone app stays on 0.9.65)

• Opens faster and lighter on Fire TV sticks.
• Smooth loading screen; streaming playlists climb to their best quality without pausing.
• Continue Watching works after an update (a fresh link from the same source, no error screen).
• Next Episode shows the episode's picture with the countdown.
• 1 GB sticks: fewer pictures in memory, no 60fps copies, no trailers.

package com.example.streamnest

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import okhttp3.Request
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipInputStream

/*
 * "Hey Aiden": wakes the AI card while Xstream is open (also during a movie).
 * An offline listener (Vosk, Apache 2.0) that only knows a handful of words, so it is light and nothing you say
 * leaves the phone until a name is heard. Its small voice model (~36 MB) downloads once, the first time.
 * It pauses while an assistant is talking with you, during Watch together calls, and when the app is in the background.
 */
object WakeWord {
    private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-in-0.4.zip"
    private const val MODEL_DIR = "vosk-model-small-en-in-0.4"
    val status = MutableStateFlow("off")   // off · downloading · ready · listening · error
    private val running = AtomicBoolean(false)
    private val downloading = AtomicBoolean(false)
    @Volatile private var thread: Thread? = null
    @Volatile internal var lastHit = 0L  // 0.9.6: internal (WakeWordSr)
    @Volatile private var gen = 0
    var onName: () -> Unit = {}
    /** Something is playing: only the full "Hey Aiden", said clearly. */
    @Volatile var strict = false
    /** No wake-ups until then (e.g. right after a chat closes). */
    @Volatile var quietUntil = 0L

    // 0.9.6: internal, shared with WakeWordSr (the on-device recogniser of the slim build).
    internal val names = setOf("aiden", "aidan", "eden", "aidin")
    internal val heys = setOf("hey", "hi", "okay", "ok")

    /** Reads one final Vosk result: true when "Hey Aiden" (or just "Aiden" when nothing plays) was said clearly. */
    private fun pick(json: String, rms: Double): Boolean {
        val o = runCatching { Api.json.parseToJsonElement(json) as kotlinx.serialization.json.JsonObject }.getOrNull() ?: return false
        val words = (o["result"] as? kotlinx.serialization.json.JsonArray)?.mapNotNull { e ->
            val w = e as? kotlinx.serialization.json.JsonObject ?: return@mapNotNull null
            val word = (w["word"] as? kotlinx.serialization.json.JsonPrimitive)?.content ?: return@mapNotNull null
            val conf = (w["conf"] as? kotlinx.serialization.json.JsonPrimitive)?.content?.toDoubleOrNull() ?: 0.0
            word to conf
        }.orEmpty()
        if (words.isEmpty() || words.any { it.first == "[unk]" }) return false
        // The whole utterance must be the phrase ("hey aiden" / "aiden"), never a name inside other talk.
        val hasHey = words.size == 2 && words[0].first in heys && words[1].first in names
        val bare = words.size == 1 && words[0].first in names
        if (!hasHey && !bare) return false
        if (strict && !hasHey) return false
        // Quiet mumbles that only look like the name are ignored.
        if (rms < 0.004) return false
        val need = if (strict) 0.90 else 0.80
        if (words.any { it.second < need }) return false
        ActLog.add("AI", "wake heard: ${words.joinToString(" ") { it.first + "(" + "%.2f".format(it.second) + ")" }}")
        return true
    }

    private fun modelDir(ctx: Context) = File(ctx.filesDir, "vosk/$MODEL_DIR")
    fun hasModel(ctx: Context) = Feature.noVosk || File(modelDir(ctx), "am").exists() || File(modelDir(ctx), "conf").exists()
    /** 0.9.6: false = hide the "Hey Aiden" option (slim build on a phone without an on-device recogniser). */
    fun supported(ctx: Context): Boolean = !Feature.noVosk || WakeWordSr.available(ctx)

    /** Start listening (downloads the model first if needed). Safe to call repeatedly. */
    fun start(ctx: Context) {
        val app = ctx.applicationContext
        if (Feature.noVosk) { WakeWordSr.start(app); return }   // 0.9.6: Android's on-device recogniser, no Vosk
        if (ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { status.value = "off"; return }
        if (!hasModel(app)) { download(app); return }
        if (running.getAndSet(true)) return
        val g = ++gen
        val t = Thread({ loop(app, g) }, "wake-word").apply { isDaemon = true; priority = Thread.MIN_PRIORITY + 1 }
        thread = t
        t.start()
    }

    fun stop() {
        if (Feature.noVosk) WakeWordSr.stop()   // 0.9.6 (the lines below then do nothing harmful)
        running.set(false)
        gen++
        thread = null
        if (status.value == "listening") status.value = "ready"
    }

    private fun download(ctx: Context) {
        if (Feature.noVosk) return   // 0.9.6: never fetch the Vosk model in the slim build
        // The voice model (36 MB) downloads on Wi-Fi only, never on mobile data.
        val unmetered = runCatching {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            cm.getNetworkCapabilities(cm.activeNetwork)?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_NOT_METERED) == true
        }.getOrDefault(false)
        if (!unmetered) { status.value = "off"; return }
        if (downloading.getAndSet(true)) return
        status.value = "downloading"
        Thread({
            try {
                val tmp = File(ctx.cacheDir, "vosk.zip")
                Api.http.newCall(Request.Builder().url(MODEL_URL).build()).execute().use { r ->
                    if (!r.isSuccessful) error("HTTP ${r.code}")
                    r.body!!.byteStream().use { inp -> tmp.outputStream().use { inp.copyTo(it) } }
                }
                val root = File(ctx.filesDir, "vosk").apply { mkdirs() }
                ZipInputStream(tmp.inputStream().buffered()).use { z ->
                    while (true) {
                        val e = z.nextEntry ?: break
                        val out = File(root, e.name)
                        if (!out.canonicalPath.startsWith(root.canonicalPath)) continue
                        if (e.isDirectory) out.mkdirs() else { out.parentFile?.mkdirs(); out.outputStream().use { z.copyTo(it) } }
                    }
                }
                tmp.delete()
                ActLog.add("AI", "wake word model ready")
                status.value = "ready"
                downloading.set(false)
                start(ctx)
            } catch (e: Exception) {
                ActLog.add("AI", "wake word model download failed: ${e.message}")
                status.value = "error"
                downloading.set(false)
            }
        }, "wake-dl").start()
    }

    @SuppressLint("MissingPermission")
    private fun loop(ctx: Context, g: Int) {
        var model: org.vosk.Model? = null
        var rec: org.vosk.Recognizer? = null
        var ar: AudioRecord? = null
        try {
            model = org.vosk.Model(modelDir(ctx).absolutePath)
            // A few short phrases plus "unknown" (everything else lands there, so ordinary talk never wakes it).
            // Whole results only, with per-word confidence: "Hey Aiden" always works; the bare name only when nothing plays.
            val words = "[\"hey aiden\", \"hi aiden\", \"okay aiden\", \"ok aiden\", \"aiden\", \"hey aidan\", \"aidan\", \"hey eden\", \"hey aidin\", \"[unk]\"]"
            rec = org.vosk.Recognizer(model, 16000f, words)
            runCatching { rec.setWords(true) }
            val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            ar = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, 16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min * 2, 8192))
            if (ar.state != AudioRecord.STATE_INITIALIZED) error("mic busy")
            ar.startRecording()
            status.value = "listening"
            val buf = ShortArray(1600)
            var peak = 0.0
            while (running.get() && g == gen) {
                val n = ar.read(buf, 0, buf.size)
                if (n <= 0) continue
                var sum = 0.0
                for (k in 0 until n) { val v = buf[k] / 32768.0; sum += v * v }
                val rms = kotlin.math.sqrt(sum / n)
                if (rms > peak) peak = rms
                if (!rec.acceptWaveForm(buf, n)) continue
                if (!pick(rec.result, peak)) { peak = 0.0; continue }
                peak = 0.0
                if (System.currentTimeMillis() - lastHit > 4000 && System.currentTimeMillis() > quietUntil) {
                    lastHit = System.currentTimeMillis()
                    rec.reset()
                    ActLog.add("AI", "wake word: hey aiden")
                    android.os.Handler(android.os.Looper.getMainLooper()).post { onName() }
                }
            }
        } catch (e: Throwable) {
            ActLog.add("AI", "wake word stopped: ${e.message}")
            status.value = "error"
        } finally {
            runCatching { ar?.stop() }; runCatching { ar?.release() }
            runCatching { rec?.close() }; runCatching { model?.close() }
            if (g == gen) running.set(false)
            if (status.value == "listening") status.value = "ready"
        }
    }
}


/** Something else needs the microphone (voice search): the wake word stops while n > 0. */
object MicHold { val n = kotlinx.coroutines.flow.MutableStateFlow(0) }

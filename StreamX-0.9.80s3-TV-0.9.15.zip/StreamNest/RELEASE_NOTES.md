StreamX 0.9.80

• Glass theme stays glass: no more plain black page.
• Smoother player and smoother scrolling.
• New Continue Watching page with picture cards.
• Updates download in the background with a small progress pill.
• "Saved video" is now called "cached video".
• Crash reports help fix problems (no email or name is sent).

---

StreamX TV 0.9.15 

• Back on Home no longer freezes or closes the app.
• The first open after an update stays open.
• Posters load once at start (no more reloading).
• Home appears at once and refreshes quietly.

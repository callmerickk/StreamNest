package com.example.streamnest

import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

@Composable
private fun SectionTitle(text: String) =
    Text(text, fontSize = 21.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFE6E9F2),
        maxLines = 1, overflow = TextOverflow.Ellipsis,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 26.dp, bottom = 12.dp))

/** The app's logo: the uploaded one from Developer's Corner, or the built-in red mark. */
@Composable
fun AppLogo(vm: AppViewModel, size: Dp, modifier: Modifier = Modifier) {
    val ver by vm.imgVersion.collectAsStateWithLifecycle()
    val custom = remember(ver) { vm.logoFile().takeIf { it.exists() } }
    if (custom != null) AsyncImage(custom, null, modifier.size(size).clip(RoundedCornerShape(size * 0.22f)), contentScale = ContentScale.Crop)
    else Image(painterResource(R.drawable.logo_mark), null, modifier.size(size))
}

private data class DeckItem(val meta: Meta, val catalog: String)

/** LazyColumn key of the top cards (also used to find them in the list's layout info). */
private const val DeckKey = "deck"

/**
 * A soft drop shadow drawn as a few stacked translucent rounded rects behind the content.
 * Much cheaper than Modifier.shadow on weak GPUs (Fire TV): no elevation/RenderNode shadow work, it is recorded once
 * per size, and it costs nothing extra while the element moves or fades. [corner] is clamped to a pill at most.
 */
internal fun Modifier.softHalo(corner: Dp, spread: Dp = 10.dp, strength: Float = 0.45f, dy: Dp = 3.dp): Modifier = drawWithCache {
    val steps = 4
    val s = spread.toPx()
    val off = dy.toPx()
    val r = minOf(corner.toPx(), size.minDimension / 2f)
    val c = Color.Black.copy(alpha = strength / steps)
    onDrawBehind {
        for (i in 1..steps) {
            val g = s * i / steps
            drawRoundRect(
                color = c,
                topLeft = Offset(-g, -g + off),
                size = Size(size.width + 2 * g, size.height + 2 * g),
                cornerRadius = CornerRadius(r + g),
            )
        }
    }
}

private val CapsuleBrush = Brush.horizontalGradient(listOf(Color(0xF2263070), Color(0xF24A2468)))

@Composable
fun HomeScreen(
    vm: AppViewModel,
    listState: LazyListState,
    capsuleHide: State<Float>,
    onOpen: (Meta) -> Unit,
    onPlay: (Screen.Player) -> Unit,
    onLive: () -> Unit,
    onAi: () -> Unit,
    onManual: (Meta, String) -> Unit = { _, _ -> },
) {
    val allShelves by vm.shelves.collectAsStateWithLifecycle()
    val loading by vm.loading.collectAsStateWithLifecycle()
    val progress by vm.progress.collectAsStateWithLifecycle()
    val myList by vm.myList.collectAsStateWithLifecycle()
    val profile by vm.current.collectAsStateWithLifecycle()
    val recs by vm.recommended.collectAsStateWithLifecycle()
    var actionsFor by remember { mutableStateOf<Progress?>(null) }
    val showRecs = isOn(t("showRecs"))
    val recTitle = t("recommendedFor").replace("{name}", profile?.name ?: "you")
    var filter by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current

    val hasSports = remember(allShelves) { allShelves.any { it.title.contains("sport", ignoreCase = true) } }
    val rowsOrder = t("rowsOrder")
    val rowsHidden = t("rowsHidden")
    val arranged = remember(allShelves, rowsOrder, rowsHidden) {
        val hidden = rowsHidden.split("|").toSet()
        arrangeShelves(allShelves, rowsOrder).filter { it.title !in hidden }
    }
    val shelves = remember(arranged, filter) {
        arranged.filter { s ->
            when (filter) {
                null -> true
                "sports" -> s.title.contains("sport", ignoreCase = true)
                else -> s.items.firstOrNull()?.type == filter
            }
        }
    }
    // Top cards: mix the first two rows (e.g. popular movies + popular series).
    val deck = remember(shelves) {
        val a = shelves.getOrNull(0)?.let { s -> s.items.map { DeckItem(it, s.title) } }.orEmpty()
        val b = shelves.getOrNull(1)?.let { s -> s.items.map { DeckItem(it, s.title) } }.orEmpty()
        (0 until maxOf(a.size, b.size)).flatMap { listOfNotNull(a.getOrNull(it), b.getOrNull(it)) }
            .filter { it.meta.poster != null }.distinctBy { it.meta.id }.take(10)
    }

    val autoSlide = t("autoSlide").trim().lowercase() != "no"
    val slideSecs = t("slideSeconds").trim().toIntOrNull()?.coerceIn(2, 20) ?: 5
    val showBrand = t("showBrand").trim().lowercase() == "yes"
    val appName = t("appName")
    val cwStyle = t("cwStyle")
    val showHero = isOn(t("showHero"))
    val cardTrailers = isOn(t("cardTrailers"))
    val cwShow = isOn(t("cwShow"))
    val continueTitle = t("continueWatching").replace("{name}", profile?.name ?: "")
    val newOn = t("newOn").replace("{app}", appName)
    val pillLeft = t("pillLeft"); val pillRight = t("pillRight"); val pillSports = t("pillSports"); val pillLive = t("pillLive")
    // Remembered so FloatingFilters gets the same list instance and can skip recomposition.
    val pillLabels = remember(pillLeft, pillRight, pillSports, pillLive, hasSports) {
        buildList {
            add(pillLeft to "series")
            add(pillRight to "movie")
            if (hasSports) add(pillSports to "sports")
            add(pillLive to "live")
        }
    }
    // The top cards keep their position when you scroll away and come back (state lives outside the lazy item).
    val deckPager = rememberPagerState { deck.size }
    // True while at least half of the top cards are on screen. Recomputed on scroll, but only notifies readers
    // when the answer flips, so it costs nothing per frame. Trailers / auto-slide stop when the deck scrolls away.
    val deckOnScreen = remember(listState) {
        derivedStateOf {
            val info = listState.layoutInfo
            val d = info.visibleItemsInfo.firstOrNull { it.key == DeckKey }
            d != null && d.offset + d.size / 2 > info.viewportStartOffset
        }
    }
    val tint = Palette.tint
    val bg = Bg
    val topBrush = remember(tint, bg) { Brush.verticalGradient(listOf(tint, bg)) }
    val accent = Accent
    val brandRim = remember(accent) { Brush.horizontalGradient(listOf(accent, accent.copy(alpha = 0.25f))) }
    val onFilter: (String) -> Unit = remember(onLive) {
        { type: String -> if (type == "live") onLive() else { filter = if (filter == type) null else type }; Unit }
    }
    val onTop: () -> Unit = remember(listState, scope) { { scope.launch { listState.animateScrollToItem(0) }; Unit } }

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxWidth().height(600.dp).background(topBrush))

        LazyColumn(Modifier.fillMaxSize(), state = listState) {
            item(key = "header", contentType = "header") {
                Row(Modifier.statusBarsPadding().padding(start = 16.dp, end = 16.dp, top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    val pill = RoundedCornerShape(50)
                    Row(
                        Modifier.clip(pill).background(Color(0x99101420))
                            .border(1.dp, brandRim, pill)
                            .padding(start = 6.dp, end = if (showBrand) 16.dp else 6.dp, top = 6.dp, bottom = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        AppLogo(vm, 28.dp)
                        if (showBrand) {
                            Spacer(Modifier.width(8.dp))
                            Wordmark(appName)
                        }
                    }
                }
            }
            item(key = "forYou", contentType = "forYou") {
                Text(t("forYou"), fontSize = 26.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFFEDEFF7),
                    modifier = Modifier.padding(start = 16.dp, top = 18.dp, bottom = 16.dp))
            }
            if (shelves.isEmpty()) {
                item(key = "empty", contentType = "empty") {
                    Box(Modifier.fillMaxWidth().height(420.dp), Alignment.Center) {
                        if (loading) CircularProgressIndicator(color = Accent) else Text(t("emptyMsg"), Modifier.padding(32.dp))
                    }
                }
            } else {
                if (showHero) item(key = DeckKey, contentType = DeckKey) {
                    Deck(vm, deck, deckPager, deckOnScreen, myList, autoSlide, slideSecs, cardTrailers, onOpen) { vm.toggleList(it) }
                }
            }
            if (progress.isNotEmpty() && filter == null && cwShow) {
                item(key = "cwTitle", contentType = "title") { SectionTitle(continueTitle) }
                item(key = "cwRow", contentType = "cwRow") {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(progress, key = { it.key }, contentType = { "cw" }) { p ->
                            ContinueCard(p, cwStyle, onClick = { onPlay(Screen.Player(p.title, p.url, p.subs, p.key, p.image, p.positionMs)) }, onRemove = { vm.removeProgress(p.key) },
                                onLongClick = { actionsFor = p })
                        }
                    }
                }
            }
            if (recs.isNotEmpty() && filter == null && showRecs) {
                item(key = "recTitle", contentType = "title") { SectionTitle(recTitle) }
                item(key = "recRow", contentType = "row") { ShelfRow(recs, onOpen) }
            }
            // Keys include the index so two catalogs with the same name can never collide (duplicate keys crash).
            itemsIndexed(shelves, key = { i, s -> "shelf:$i:${s.title}" }, contentType = { _, _ -> "shelf" }) { _, shelf ->
                SectionTitle(if (shelf.title.startsWith("New")) "$newOn · ${shelf.title.removePrefix("New ").trim()}" else shelf.title)
                ShelfRow(shelf.items, onOpen)
            }
            item(key = "bottomSpace", contentType = "spacer") { Spacer(Modifier.navigationBarsPadding().height(180.dp)) }
        }

        Box(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 70.dp)) {
            FloatingFilters(
                vm = vm, hide = capsuleHide,
                filter = filter,
                labels = pillLabels,
                onFilter = onFilter,
                onTop = onTop,
                onAi = onAi,
            )
        }
    }
    actionsFor?.let { p ->
        ContinueActions(
            p,
            onDetails = { onOpen(p.toMeta()) },
            onManual = { onManual(p.toMeta(), p.key) },
            onStartOver = { onPlay(Screen.Player(p.title, p.url, p.subs, p.key, p.image, 0L)) },
            onRemove = { vm.removeProgress(p.key) },
            onDismiss = { actionsFor = null },
        )
    }
}

// Poster Card Style (Help & Settings > Layout > Poster Card Style)
val PosterWidths = linkedMapOf("Compact" to 100, "Dense" to 112, "Standard" to 120, "Balanced" to 126, "Comfort" to 140, "Large" to 156)
val PosterCorners = linkedMapOf("Sharp" to 0, "Subtle" to 4, "Classic" to 8, "Rounded" to 12, "Pill" to 22)

@Composable fun posterWidth(): Dp = (PosterWidths[t("posterWidth")] ?: 126).dp
@Composable fun posterCorner(): Dp = (PosterCorners[t("posterCorner")] ?: 12).dp

/** Applies the row order chosen in Home Layout; rows not in the list keep their original order at the end. */
fun arrangeShelves(all: List<Shelf>, order: String): List<Shelf> {
    val wanted = order.split("|").filter { it.isNotBlank() }
    return all.withIndex().sortedBy { (i, s) -> wanted.indexOf(s.title).let { if (it < 0) 10_000 + i else it } }.map { it.value }
}

/**
 * A home row. When the catalog addon designs its own posters (wide "Top 10" artwork with rank, rating and provider,
 * square art…), they are shown whole, in their own shape, exactly as the addon made them. Otherwise: wide landscape
 * cards (Hotstar style) or tall posters, depending on settings.
 */
@Composable
fun ShelfRow(items: List<Meta>, onOpen: (Meta) -> Unit) {
    val landscape = isOn(t("landscapePosters"))
    val addonDesign = isOn(t("addonPosters"))
    val w = posterWidth()
    // Shape the addon declares (posterShape), or the real shape of its first poster once it has loaded.
    val declared = items.firstNotNullOfOrNull { it.posterShape?.lowercase()?.takeIf { s -> s == "landscape" || s == "square" } }
    var detected by remember(items.firstOrNull()?.id) { mutableStateOf<Float?>(null) }
    val ratio: Float? = if (!addonDesign) null else when (declared) {
        "landscape" -> detected?.takeIf { it > 1.2f } ?: (16f / 9f)
        "square" -> 1f
        else -> detected?.takeIf { it > 1.2f || it in 0.9f..1.1f }
    }
    val corner = posterCorner()
    val posterShape = remember(corner) { RoundedCornerShape(corner) }
    // Coil sizes each request from the (fixed) layout constraints, so posters are decoded at card size, not full size.
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(if (ratio != null) 14.dp else 10.dp)) {
        itemsIndexed(items, key = { _, m -> m.type + m.id }, contentType = { _, _ -> "card" }) { i, m ->
            val onRatio: (Float) -> Unit = { r -> if (i == 0 && detected == null) detected = r }
            when {
                ratio != null -> AddonPosterCard(m, ratio, onRatio) { onOpen(m) }
                landscape -> LandscapeCard(m, w * 1.87f) { onOpen(m) }
                else -> AsyncImage(
                    m.poster, m.name,
                    Modifier.width(w).aspectRatio(2f / 3f).clip(posterShape).background(Surface1).clickable { onOpen(m) },
                    contentScale = ContentScale.Crop,
                    onSuccess = { st -> val sz = st.painter.intrinsicSize; if (addonDesign && sz.width > 0f && sz.height > 0f) onRatio(sz.width / sz.height) },
                )
            }
        }
    }
}

/** The addon's own poster, shown whole (no cropping, nothing drawn on top), with the title and year under it. */
@Composable
fun AddonPosterCard(m: Meta, ratio: Float, onRatio: (Float) -> Unit = {}, onClick: () -> Unit) {
    val width = when { ratio > 1.2f -> 262.dp; ratio >= 0.9f -> 170.dp; else -> posterWidth() }
    val corner = posterCorner().coerceAtLeast(12.dp)
    val shape = remember(corner) { RoundedCornerShape(corner) }
    Column(Modifier.width(width).clickable(onClick = onClick)) {
        // softHalo instead of Modifier.shadow: elevation shadows on every card are re-rendered while rows scroll.
        Box(Modifier.fillMaxWidth().aspectRatio(ratio).softHalo(corner, spread = 8.dp, strength = 0.55f, dy = 4.dp).clip(shape).background(Surface1)) {
            AsyncImage(
                m.poster ?: backdropOf(m), m.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop,
                onSuccess = { st -> val sz = st.painter.intrinsicSize; if (sz.width > 0f && sz.height > 0f) onRatio(sz.width / sz.height) },
            )
            Box(Modifier.fillMaxSize().border(1.dp, Brush.verticalGradient(listOf(Color(0x1FFFFFFF), Color(0x05FFFFFF))), shape))
        }
        Text(m.name, Modifier.padding(top = 10.dp, start = 2.dp), fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Color(0xFFEDEFF5),
            maxLines = 1, overflow = TextOverflow.Ellipsis)
        m.releaseInfo?.takeIf { it.isNotBlank() }?.let { Text(it.take(4), Modifier.padding(start = 2.dp, top = 2.dp), fontSize = 13.sp, color = Color(0xFF9AA3B5)) }
    }
}

@Composable
fun LandscapeRow(items: List<Meta>, onOpen: (Meta) -> Unit) =
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        items(items, key = { it.type + it.id }) { m -> LandscapeCard(m) { onOpen(m) } }
    }

/** Wide 16:9 card: backdrop artwork with the title logo on top (Hotstar style). */
@Composable
fun LandscapeCard(m: Meta, width: Dp = 236.dp, onClick: () -> Unit) {
    var logoFailed by remember(m.id) { mutableStateOf(false) }
    val hideLabels = isOn(t("hideLabels"))
    Box(Modifier.width(width).aspectRatio(16f / 9f).clip(RoundedCornerShape(posterCorner())).background(Surface1).clickable(onClick = onClick)) {
        AsyncImage(backdropOf(m), m.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0f to Color(0xCC000000), 0.65f to Color.Transparent)))
        val logo = logoOf(m)
        if (!hideLabels) Box(Modifier.align(Alignment.BottomStart).padding(10.dp).fillMaxWidth(0.55f)) {
            if (logo != null && !logoFailed) {
                AsyncImage(logo, m.name, Modifier.fillMaxWidth().height(42.dp), contentScale = ContentScale.Fit,
                    alignment = Alignment.BottomStart, onError = { logoFailed = true })
            } else {
                Text(m.name, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun Deck(
    vm: AppViewModel, items: List<DeckItem>, pager: PagerState, onScreen: State<Boolean>, myList: List<Meta>,
    auto: Boolean, secs: Int, trailers: Boolean,
    onOpen: (Meta) -> Unit, onToggle: (Meta) -> Unit,
) {
    if (items.isEmpty()) return
    val cardW = (LocalConfiguration.current.screenWidthDp * 0.83f).dp
    // Only flips when the deck crosses half-visible, so this read recomposes Deck rarely (never per scroll frame).
    val visible = onScreen.value
    val dragged by pager.interactionSource.collectIsDraggedAsState()
    // Once you swipe the cards yourself, auto-slide stops and the card you land on plays its trailer (muted).
    var userTook by remember { mutableStateOf(false) }
    var trailerId by remember { mutableStateOf<String?>(null) }
    var muted by remember { mutableStateOf(true) }
    LaunchedEffect(dragged) { if (dragged) { userTook = true; trailerId = null } }
    var holdTick by remember { mutableIntStateOf(0) }
    LaunchedEffect(pager.settledPage, userTook, trailers, holdTick, visible) {
        trailerId = null
        // No trailer (WebView) while the cards are mostly scrolled out of view.
        if (!trailers || !userTook || !visible) return@LaunchedEffect
        // Starts right after the cards stop sliding (or straight away when you hold a card).
        delay(if (holdTick > 0) 150 else 300)
        trailerId = items.getOrNull(pager.settledPage)?.let { vm.trailerId(it.meta) }
    }

    // Holding a card starts looking up its streams too, so Play is ready sooner.
    LaunchedEffect(holdTick) {
        if (holdTick == 0) return@LaunchedEffect
        val m = items.getOrNull(pager.settledPage)?.meta ?: return@LaunchedEffect
        if (m.type == "movie") runCatching { if (vm.qsActive()) vm.quickStreams("movie", m.id) else vm.allStreams("movie", m.id) }
    }

    // Auto-slide every few seconds until you take over.
    LaunchedEffect(auto, secs, dragged, userTook, items.size, visible) {
        // Auto-slide pauses while the cards are scrolled away (no pager animation competing with list scrolling).
        if (!auto || dragged || userTook || !visible || items.size < 2) return@LaunchedEffect
        while (true) {
            delay(secs * 1000L)
            pager.animateScrollToPage((pager.currentPage + 1) % items.size, animationSpec = tween(700))
        }
    }

    HorizontalPager(
        state = pager,
        pageSize = PageSize.Fixed(cardW),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp),
        // 2 is enough for the stacked look (cards 3+ behind are fully transparent) and composes fewer heavy cards.
        beyondViewportPageCount = 2,
        key = { items.getOrNull(it)?.meta?.id ?: "p$it" },
        modifier = Modifier.fillMaxWidth(),
    ) { page ->
        val d = items[page]
        DeckCard(
            d.meta, rank = page + 1, catalog = d.catalog, saved = myList.any { it.id == d.meta.id },
            trailer = if (page == pager.settledPage) trailerId else null, muted = muted,
            onMute = { muted = !muted },
            onTrailerDone = { trailerId = null; userTook = false },
            onOpen = { onOpen(d.meta) }, onToggle = { onToggle(d.meta) },
            onHold = { if (trailers) { userTook = true; holdTick++ } },
            modifier = Modifier
                .zIndex(-abs(page - pager.currentPage).toFloat())
                .graphicsLayer {
                    val r = page - pager.currentPage - pager.currentPageOffsetFraction
                    val s = 1f - 0.06f * minOf(abs(r), 2.5f)
                    scaleX = s; scaleY = s
                    if (r > 0f) translationX = -minOf(r, 3f) * size.width * 0.88f
                    // Only 0 or 1: a partial alpha on these big, busy cards made the GPU render each stacked card
                    // into an offscreen buffer on every frame (also while the page itself scrolls).
                    alpha = if (r > 2.6f) 0f else 1f
                }
                // The cards behind are dimmed with a cheap translucent overlay instead (same look on the dark page).
                .drawWithContent {
                    drawContent()
                    val r = page - pager.currentPage - pager.currentPageOffsetFraction
                    val dim = 0.18f * minOf(abs(r), 2f)
                    if (dim > 0.005f) {
                        val cr = Palette.corner.dp.toPx()
                        drawRoundRect(Color.Black, alpha = dim, cornerRadius = CornerRadius(cr, cr))
                    }
                },
        )
    }
}

@Composable
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
private fun DeckCard(
    m: Meta, rank: Int, catalog: String, saved: Boolean,
    trailer: String?, muted: Boolean, onMute: () -> Unit, onTrailerDone: () -> Unit,
    onOpen: () -> Unit, onToggle: () -> Unit, modifier: Modifier, onHold: () -> Unit = {},
) {
    val shape = RoundedCornerShape(Palette.corner.dp)
    val rating = m.imdbRating?.toDoubleOrNull()
    val rankText = t("badge").replace("{rank}", rank.toString()).replace("{catalog}", catalog)
    var logoFailed by remember(m.id) { mutableStateOf(false) }
    var videoOn by remember(trailer) { mutableStateOf(false) }
    val posterAlpha by animateFloatAsState(if (videoOn) 0f else 1f, tween(600), label = "poster")
    Box(modifier.fillMaxWidth().aspectRatio(0.76f).clip(shape).background(Color(0xFF05070C)).combinedClickable(onClick = onOpen, onLongClick = onHold)) {
        if (trailer != null) {
            TrailerVideo(trailer, muted, Modifier.fillMaxSize(), onPlaying = { videoOn = true }, onEnded = onTrailerDone, onError = onTrailerDone)
            // Keeps touches for the card (swipe / tap) instead of the video.
            Box(Modifier.fillMaxSize().pointerInput(Unit) { awaitPointerEventScope { while (true) awaitPointerEvent() } })
        }
        val art = if (m.posterShape.equals("landscape", true) || m.posterShape.equals("square", true)) backdropOf(m) ?: m.poster else m.poster ?: backdropOf(m)
        AsyncImage(art, m.name, Modifier.fillMaxSize().graphicsLayer { alpha = posterAlpha }, contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.42f to Color.Transparent, 0.82f to Color(0xEE000000), 1f to Color.Black)))

        // Badge: IMDb score for highly rated titles, otherwise the rank in its row.
        val badgeShape = RoundedCornerShape(14.dp)
        if (rating != null && rating >= 7.5) {
            Row(Modifier.padding(16.dp).clip(badgeShape).background(Color(0x99000000)).border(1.dp, Color(0x33FFFFFF), badgeShape)
                .padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clip(RoundedCornerShape(4.dp)).background(Color(0xFFF5C518)).padding(horizontal = 5.dp, vertical = 2.dp)) {
                    Icon(Icons.Default.Star, null, Modifier.size(14.dp), tint = Color.Black)
                }
                Spacer(Modifier.width(8.dp))
                Text("IMDb ${m.imdbRating}", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            }
        } else if (rankText.isNotBlank()) {
            Row(Modifier.padding(16.dp).clip(badgeShape).background(Color(0x99000000)).border(1.dp, Color(0x33FFFFFF), badgeShape)
                .padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.WorkspacePremium, null, Modifier.size(20.dp), tint = Color(0xFFFFB13B))
                Spacer(Modifier.width(8.dp))
                Text(rankText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        if (trailer != null && videoOn) {
            Box(
                Modifier.align(Alignment.TopEnd).padding(14.dp).size(40.dp).clip(CircleShape).background(Color(0x88000000))
                    .border(1.dp, Color(0x33FFFFFF), CircleShape).clickable(onClick = onMute),
                Alignment.Center,
            ) { Icon(if (muted) Icons.Default.VolumeOff else Icons.Default.VolumeUp, if (muted) "Unmute" else "Mute", Modifier.size(20.dp)) }
        }
        Column(Modifier.align(Alignment.BottomStart).padding(16.dp)) {
            val logo = logoOf(m)
            if (logo != null && !logoFailed) {
                AsyncImage(logo, m.name, Modifier.fillMaxWidth(0.85f).height(84.dp), contentScale = ContentScale.Fit,
                    alignment = Alignment.BottomStart, onError = { logoFailed = true })
            } else {
                Text(m.name, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(10.dp))
            Text(
                (listOfNotNull(m.releaseInfo?.take(4)) + m.genres.orEmpty().take(2)).joinToString("  •  "),
                fontSize = 15.sp, color = Color(0xFFC9CEDB), maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassButton(Modifier.weight(1f).height(52.dp), onOpen) {
                    Icon(Icons.Default.PlayArrow, null, Modifier.size(28.dp)); Spacer(Modifier.width(6.dp))
                    Text(t("watchNow"), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                }
                GlassButton(Modifier.size(52.dp), onToggle) {
                    Icon(if (saved) Icons.Default.Check else Icons.Default.Add, if (saved) "In Watchlist" else "Add to Watchlist")
                }
            }
        }
    }
}

@Composable
private fun GlassButton(modifier: Modifier, onClick: () -> Unit, content: @Composable RowScope.() -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(modifier.clip(shape).background(Color(0x3DFFFFFF)).border(1.dp, Color(0x26FFFFFF), shape).clickable(onClick = onClick),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically, content = content)
}

/** Continue Watching card. style: "card" (TV-style), "wide" (info on the artwork) or "poster" (tall). */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun ContinueCard(p: Progress, style: String = "card", onClick: () -> Unit, onRemove: () -> Unit, onLongClick: (() -> Unit)? = null) {
    val long = onLongClick ?: onRemove
    val tap = Modifier.combinedClickable(onClick = onClick, onLongClick = long)
    val frac = if (p.durationMs > 0) (p.positionMs.toFloat() / p.durationMs).coerceIn(0f, 1f) else 0f
    val leftMin = if (p.durationMs > 0) ((p.durationMs - p.positionMs) / 60000).toInt() else 0
    val left = if (p.durationMs <= 0) "Resume" else if (leftMin >= 60) "${leftMin / 60}h ${leftMin % 60}m left" else "${maxOf(leftMin, 1)}m left"
    var menu by remember { mutableStateOf(false) }
    val corner = posterCorner()
    val more: @Composable () -> Unit = {
        Box {
            Icon(Icons.Default.MoreVert, "More", Modifier.clip(CircleShape).clickable { if (onLongClick != null) onLongClick() else menu = true }.padding(2.dp).size(22.dp), tint = Color(0xFFB6BDCC))
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Remove from Continue Watching") }, onClick = { menu = false; onRemove() })
            }
        }
    }
    val bar: @Composable () -> Unit = {
        Box(Modifier.fillMaxWidth().height(3.dp).background(Color(0x33FFFFFF))) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(Accent))
        }
    }
    when (style) {
        "wide" -> Box(Modifier.width(300.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(corner)).background(Surface1).then(tap)) {
            AsyncImage(p.image, p.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.35f to Color.Transparent, 1f to Color(0xE6000000))))
            Row(Modifier.align(Alignment.BottomStart).padding(start = 12.dp, end = 6.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PlayCircle, null, Modifier.size(34.dp))
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(p.title, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(left, fontSize = 12.sp, color = Color(0xFFC9CEDB))
                }
                more()
            }
            Box(Modifier.align(Alignment.BottomCenter)) { bar() }
        }
        "poster" -> Column(Modifier.width(posterWidth())) {
            Box(Modifier.fillMaxWidth().aspectRatio(2f / 3f).clip(RoundedCornerShape(corner)).background(Surface1).then(tap)) {
                AsyncImage(p.image, p.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Icon(Icons.Default.PlayCircle, null, Modifier.align(Alignment.Center).size(40.dp))
                Box(Modifier.align(Alignment.BottomCenter)) { bar() }
            }
            Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(left, Modifier.weight(1f), fontSize = 12.sp, color = Color(0xFF8A94A8), maxLines = 1)
                more()
            }
        }
        else -> Column(Modifier.width(236.dp)) {
            Column(Modifier.clip(RoundedCornerShape(corner)).then(tap)) {
                Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Surface1)) {
                    AsyncImage(p.image, p.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.6f to Color.Transparent, 1f to Color(0x99000000))))
                    Icon(Icons.Default.PlayArrow, null, Modifier.align(Alignment.BottomStart).padding(8.dp).size(30.dp))
                }
                bar()
            }
            Row(Modifier.padding(top = 8.dp, start = 4.dp), verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text(p.title, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(left, fontSize = 13.sp, color = Color(0xFF8A94A8))
                }
                more()
            }
        }
    }
}

/** Hotstar-style capsule (centred) with the AI voice button on the right. */
@Composable
private fun FloatingFilters(
    vm: AppViewModel,
    hide: State<Float>,
    filter: String?,
    labels: List<Pair<String, String>>,
    onFilter: (String) -> Unit,
    onTop: () -> Unit,
    onAi: () -> Unit,
) {
    val pill = RoundedCornerShape(50)
    val maxCapsule = (LocalConfiguration.current.screenWidthDp - 2 * (12 + 52 + 8)).dp
    Box(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
        Row(
            Modifier.align(Alignment.Center).widthIn(max = maxCapsule)
                // Scrolling down slides the capsule away (behind the bottom bar); the AI button stays as a small mic.
                // Before: alpha + Modifier.shadow on this layer forced an offscreen buffer and shadow re-render every
                // frame. Now the fade uses ModulateAlpha (alpha applied per draw, no offscreen buffer) and is fully
                // skipped (alpha 0) once hidden. Everything here is read in the draw phase: no recomposition.
                .graphicsLayer {
                    val v = hide.value
                    translationY = v * 150.dp.toPx()
                    alpha = if (v >= 0.999f) 0f else 1f - v
                    compositingStrategy = CompositingStrategy.ModulateAlpha
                }
                // Static, pre-recorded halo instead of Modifier.shadow (elevation shadows re-render as the pill moves).
                .softHalo(100.dp, spread = 12.dp, strength = 0.5f, dy = 4.dp)
                .clip(pill)
                .background(CapsuleBrush)
                .border(1.dp, Color(0x33FFFFFF), pill).padding(horizontal = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            labels.forEach { (label, type) ->
                Text(label, Modifier.clip(pill).clickable { onFilter(type) }.padding(horizontal = 11.dp, vertical = 12.dp),
                    fontSize = 15.sp, fontWeight = if (filter == type) FontWeight.Bold else FontWeight.Medium, maxLines = 1,
                    color = if (filter == type) Color.White else Color(0xC8FFFFFF))
                Box(Modifier.width(1.dp).height(18.dp).background(Color(0x44FFFFFF)))
            }
            Icon(Icons.Default.KeyboardArrowUp, "Back to top", Modifier.clip(CircleShape).clickable(onClick = onTop).padding(horizontal = 8.dp, vertical = 10.dp).size(24.dp))
        }
        Box(Modifier.align(Alignment.CenterEnd)) { AiOrbButton(vm, 52.dp, hide, onAi) }
    }
}


// ───────────── "Top 10" ranked rows ─────────────

/** Rows named like "Top 10…", "Top X…", "Trending Top…" get big rank numbers (Netflix / Nuvio style). */
fun isRankedRow(title: String) = Regex("\\btop\\b|\\btrending\\b", RegexOption.IGNORE_CASE).containsMatchIn(title)

private val CountryFlags = linkedMapOf(
    "india" to "🇮🇳", "usa" to "🇺🇸", "united states" to "🇺🇸", "us" to "🇺🇸", "uk" to "🇬🇧", "united kingdom" to "🇬🇧", "korea" to "🇰🇷",
    "japan" to "🇯🇵", "spain" to "🇪🇸", "france" to "🇫🇷", "germany" to "🇩🇪", "canada" to "🇨🇦", "australia" to "🇦🇺", "brazil" to "🇧🇷", "mexico" to "🇲🇽",
)
private val ServiceTags = linkedMapOf(
    "netflix" to ("NETFLIX" to Color(0xFFE50914)), "prime" to ("PRIME" to Color(0xFF00A8E1)), "amazon" to ("PRIME" to Color(0xFF00A8E1)),
    "disney" to ("DISNEY+" to Color(0xFF3A8DFF)), "hotstar" to ("HOTSTAR" to Color(0xFF3A8DFF)), "hbo" to ("HBO" to Color(0xFF9B5CFF)),
    "apple" to ("APPLE TV+" to Color(0xFFDDDDDD)), "zee5" to ("ZEE5" to Color(0xFF8E44FF)), "sony" to ("SONYLIV" to Color(0xFFF5A20A)),
    "jio" to ("JIO" to Color(0xFFE5197A)), "hulu" to ("HULU" to Color(0xFF1CE783)), "paramount" to ("PARAMOUNT+" to Color(0xFF0064FF)),
)

@Composable
fun RankedRow(title: String, items: List<Meta>, onOpen: (Meta) -> Unit) {
    val lower = title.lowercase()
    fun has(word: String) = Regex("\\b${Regex.escape(word)}\\b").containsMatchIn(lower)
    val service = ServiceTags.entries.firstOrNull { lower.contains(it.key) }?.value
    val flag = if (service == null) CountryFlags.entries.firstOrNull { has(it.key) }?.value else null
    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        itemsIndexed(items, key = { _, m -> m.type + m.id }) { i, m -> RankedCard(i + 1, m, flag, service) { onOpen(m) } }
    }
}

@OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)
@Composable
private fun RankedCard(rank: Int, m: Meta, flag: String?, service: Pair<String, Color>?, onClick: () -> Unit) {
    val shape = RoundedCornerShape(posterCorner().coerceAtLeast(14.dp))
    Column(Modifier.width(262.dp).clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick)) {
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(shape).background(Surface1)) {
            AsyncImage(backdropOf(m), m.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            // Dark fade on the left so the number and info stay readable.
            Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0f to Color(0xF0000000), 0.32f to Color(0x99000000), 0.55f to Color.Transparent)))
            if (rank <= 10) Column(Modifier.align(Alignment.CenterStart).padding(start = 10.dp).width(78.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "$rank",
                    fontSize = if (rank >= 10) 68.sp else 92.sp, fontWeight = FontWeight.Black, lineHeight = 92.sp,
                    style = androidx.compose.ui.text.TextStyle(
                        brush = Brush.verticalGradient(listOf(Color(0xFFFFFFFF).copy(alpha = 0.85f), Accent.copy(alpha = 0.35f), Color(0x22FFFFFF))),
                        shadow = androidx.compose.ui.graphics.Shadow(Color(0x99000000), androidx.compose.ui.geometry.Offset(0f, 4f), 12f),
                    ),
                )
                m.genres?.firstOrNull()?.let {
                    Text(it.uppercase(), fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp, color = Color(0xFFDDE1EA), maxLines = 1)
                }
                m.imdbRating?.takeIf { it.isNotBlank() }?.let {
                    Text("★ $it", Modifier.padding(top = 2.dp), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                when {
                    service != null -> Text(service.first, Modifier.padding(top = 4.dp), fontSize = 9.sp, fontWeight = FontWeight.Black, color = service.second, letterSpacing = 0.6.sp, maxLines = 1)
                    flag != null -> Text(flag, Modifier.padding(top = 2.dp), fontSize = 16.sp)
                }
            }
        }
        Text(m.name, Modifier.padding(top = 10.dp, start = 2.dp), fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        m.releaseInfo?.takeIf { it.isNotBlank() }?.let { Text(it.take(4), Modifier.padding(start = 2.dp, top = 2.dp), fontSize = 13.sp, color = Color(0xFF9AA3B5)) }
    }
}

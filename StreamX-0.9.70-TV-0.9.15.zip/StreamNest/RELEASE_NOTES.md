StreamX 0.9.70

• New quality menu: what you chose and what really plays, at a glance.
• A red dot on the progress bar; dragging hides everything else.
• ±10 s jumps land exactly.
• "Scene after the credits" note, Pilot / Finale tags.
• Films only in cinemas: Remind me or play the cinema copy.

---

StreamX TV 0.9.15 

• Back on Home no longer freezes or closes the app.
• The first open after an update stays open.
• Posters load once at start (no more reloading).
• Home appears at once and refreshes quietly.

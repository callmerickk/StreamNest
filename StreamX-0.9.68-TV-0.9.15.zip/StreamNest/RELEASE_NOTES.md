StreamX 0.9.68

• No more endless switching when an episode's length differs from its info.
• Expired or wrong links are never retried.
• Faster, lighter start (old logs no longer downloaded).
• Updates install on the first try.
• The app tour can always be skipped (Back skips it too).

---

StreamX TV 0.9.15 

• Back on Home no longer freezes or closes the app.
• The first open after an update stays open.
• Posters load once at start (no more reloading).
• Home appears at once and refreshes quietly.

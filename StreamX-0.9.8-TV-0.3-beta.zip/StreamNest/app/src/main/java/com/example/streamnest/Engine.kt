package com.example.streamnest

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.ResolvingDataSource
import kotlinx.serialization.encodeToString
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.interfaces.IMedia
import org.videolan.libvlc.util.VLCVideoLayout
import java.util.concurrent.ConcurrentHashMap

/*
 * Some addons (e.g. MovieBox) only serve video when the player sends the request headers they give
 * with each stream (behaviorHints.proxyHeaders.request: Referer, User-Agent, Origin…). We remember them
 * by link and by server, and add them to every video request, in both engines.
 */
object StreamHeaders {
    private val byUrl = ConcurrentHashMap<String, Map<String, String>>()
    private val byHost = ConcurrentHashMap<String, Map<String, String>>()
    @Volatile var active: Map<String, String> = emptyMap()
    private var prefs: android.content.SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs != null) return
        prefs = ctx.getSharedPreferences("stream_headers", Context.MODE_PRIVATE)
        runCatching {
            prefs?.getString("all", null)?.let { Api.json.decodeFromString<Map<String, Map<String, String>>>(it) }?.forEach { (u, h) ->
                byUrl[u] = h; Uri.parse(u).host?.let { byHost[it] = h }
            }
        }
    }

    fun remember(s: StreamItem) {
        val url = s.stream.url ?: return
        val h = s.stream.behaviorHints?.proxyHeaders?.request?.filterKeys { it.isNotBlank() }.orEmpty()
        if (h.isEmpty()) return
        byUrl[url] = h
        Uri.parse(url).host?.let { byHost[it] = h }
        // Keep the newest 200 links so Continue Watching still works after a restart.
        val keep = byUrl.entries.toList().takeLast(200).associate { it.key to it.value }
        runCatching { prefs?.edit()?.putString("all", Api.json.encodeToString(keep))?.apply() }
    }

    fun forUrl(url: String): Map<String, String> = byUrl[url] ?: Uri.parse(url).host?.let { byHost[it] }.orEmpty()

    /** Headers for any request while a video plays (segments may live on other hosts). */
    fun forRequest(uri: Uri): Map<String, String> = byUrl[uri.toString()] ?: uri.host?.let { byHost[it] } ?: active
}

/** Wraps the HTTP source so every request carries the stream's headers. */
@OptIn(UnstableApi::class)
fun withStreamHeaders(upstream: DataSource.Factory): DataSource.Factory =
    ResolvingDataSource.Factory(upstream) { spec ->
        val h = StreamHeaders.forRequest(spec.uri)
        if (h.isEmpty()) spec else spec.withAdditionalHeaders(h)
    }

// ───────────── VLC engine (Playback > Player engine) ─────────────

/** Events from VLC, turned into the same states the player UI already uses. */
interface VlcListener {
    fun onPlaying(playing: Boolean)
    fun onBuffering(buffering: Boolean)
    fun onFirstFrame()
    fun onError()
    fun onEnded()
}

class VlcEngine(ctx: Context, private val listener: VlcListener) {
    private val lib = LibVLC(ctx.applicationContext, arrayListOf(
        "--network-caching=1000", "--http-reconnect", "--audio-time-stretch", "--avcodec-skiploopfilter=1", "--sub-autodetect-file",
    ))
    val mp = MediaPlayer(lib)
    private var pendingSeek = 0L
    /** Preferred audio languages in order (e.g. hindi, original); applied once when a file starts. */
    var preferAudio: List<String> = emptyList()
    private var audioChosen = false
    private var vout = false
    private var pendingPlay = false
    private var attached: VLCVideoLayout? = null

    init {
        mp.setEventListener(MediaPlayer.EventListener { e ->
            when (e.type) {
                MediaPlayer.Event.Playing -> {
                    listener.onPlaying(true); listener.onBuffering(false)
                    if (!audioChosen) { audioChosen = true; pickAudio() }
                }
                MediaPlayer.Event.Paused, MediaPlayer.Event.Stopped -> listener.onPlaying(false)
                MediaPlayer.Event.Buffering -> listener.onBuffering(e.buffering < 100f)
                MediaPlayer.Event.Vout -> if (e.voutCount > 0 && !vout) {
                    vout = true
                    // The start position is given to VLC up front (:start-time); if a server ignored it, seek now.
                    val want = pendingSeek
                    pendingSeek = 0
                    if (want > 5_000 && runCatching { mp.time }.getOrDefault(0L) < want - 5_000) runCatching { mp.setTime(want) }
                    listener.onFirstFrame()
                }
                MediaPlayer.Event.EncounteredError -> listener.onError()
                MediaPlayer.Event.EndReached -> listener.onEnded()
            }
        })
    }

    fun attach(layout: VLCVideoLayout) {
        if (attached === layout) return
        runCatching { mp.detachViews() }
        mp.attachViews(layout, null, true, false)
        attached = layout
        if (pendingPlay) { pendingPlay = false; mp.play() }
    }

    private fun pickAudio() {
        val tracks = audioTracks()
        if (tracks.size < 2) return
        for (lang in preferAudio) {
            val words = (QsLanguages[lang] ?: listOf(lang)).filter { it.length >= 3 }
            tracks.firstOrNull { (_, name) -> val n = name.lowercase(); words.any { n.contains(it) } }?.let { selectAudio(it.first); return }
        }
    }

    /** [hw] = false plays with software decoding (slower, but handles codecs the phone's chip can't). */
    /**
     * [hw] = false plays with software decoding (slower, but handles codecs the phone's chip can't).
     * [cachingMs] = how much video VLC keeps ready ahead; bigger for large / 4K files so they don't stutter.
     */
    fun load(url: String, headers: Map<String, String>, subs: List<Subtitle>, startMs: Long, hw: Boolean = true, cachingMs: Int = 1000) {
        vout = false
        audioChosen = false
        val m = Media(lib, Uri.parse(url))
        m.setHWDecoderEnabled(hw, false)
        if (!hw) m.addOption(":avcodec-threads=0")
        m.addOption(":network-caching=${cachingMs.coerceIn(300, 8000)}")
        // Big files: keep up by dropping a late frame instead of freezing.
        if (cachingMs > 1500) { m.addOption(":drop-late-frames"); m.addOption(":skip-frames") }
        // Start exactly where you were (switching source / audio, resuming).
        if (startMs > 1_000) m.addOption(":start-time=${"%.3f".format(java.util.Locale.US, startMs / 1000.0)}")
        headers.entries.firstOrNull { it.key.equals("User-Agent", true) }?.let { m.addOption(":http-user-agent=${it.value}") }
        headers.entries.firstOrNull { it.key.equals("Referer", true) }?.let { m.addOption(":http-referrer=${it.value}") }
        mp.setMedia(m)
        m.release()
        subs.filter { it.url.isNotBlank() }.forEach { runCatching { mp.addSlave(IMedia.Slave.Type.Subtitle, Uri.parse(it.url), false) } }
        pendingSeek = startMs
        listener.onBuffering(true)
        // VLC needs its video views attached before playback starts, or it plays without a picture.
        if (attached != null) mp.play() else pendingPlay = true
    }

    val time: Long get() = runCatching { mp.time }.getOrDefault(0L).coerceAtLeast(0L)
    val length: Long get() = runCatching { mp.length }.getOrDefault(0L).coerceAtLeast(0L)
    val isPlaying: Boolean get() = runCatching { mp.isPlaying }.getOrDefault(false)
    fun play() = mp.play()
    fun pause() = mp.pause()
    fun seek(ms: Long) { mp.setTime(ms.coerceAtLeast(0L)) }
    var rate: Float
        get() = runCatching { mp.rate }.getOrDefault(1f)
        set(v) { mp.setRate(v) }

    /** 0 = Fit, 1 = Crop (fill screen), 2 = Stretch — same order as the ExoPlayer aspect modes. */
    fun setAspect(i: Int) {
        mp.setVideoScale(when (i) { 1 -> MediaPlayer.ScaleType.SURFACE_FIT_SCREEN; 2 -> MediaPlayer.ScaleType.SURFACE_FILL; else -> MediaPlayer.ScaleType.SURFACE_BEST_FIT })
    }

    fun audioTracks(): List<Pair<Int, String>> = mp.audioTracks?.filter { it.id >= 0 }?.map { it.id to it.name } ?: emptyList()
    fun subTracks(): List<Pair<Int, String>> = mp.spuTracks?.filter { it.id >= 0 }?.map { it.id to it.name } ?: emptyList()
    val audioTrack: Int get() = mp.audioTrack
    val subTrack: Int get() = mp.spuTrack
    fun selectAudio(id: Int) { mp.setAudioTrack(id) }
    fun selectSub(id: Int) { mp.setSpuTrack(id) }

    /** Called when switching back to ExoPlayer: the VLC video view goes away, so let go of it too. */
    fun stop() = runCatching {
        pendingPlay = false
        mp.stop()
        mp.detachViews(); attached = null
    }

    fun release() {
        runCatching { mp.setEventListener(null as MediaPlayer.EventListener?) }
        runCatching { mp.stop() }
        runCatching { mp.detachViews() }
        runCatching { mp.release() }
        runCatching { lib.release() }
    }
}

// ───────────── Playback log (Developer's Corner) ─────────────

/** Why links failed, newest first, so stubborn files can be fixed. */
object PlaybackLog {
    private const val KEY = "lines"
    fun add(ctx: Context, line: String) {
        val p = ctx.getSharedPreferences("playback_log", Context.MODE_PRIVATE)
        val stamp = java.text.SimpleDateFormat("dd MMM HH:mm", java.util.Locale.US).format(java.util.Date())
        val all = listOf("$stamp  $line") + all(ctx)
        p.edit().putString(KEY, all.take(60).joinToString("\n")).apply()
    }
    fun all(ctx: Context): List<String> =
        ctx.getSharedPreferences("playback_log", Context.MODE_PRIVATE).getString(KEY, "")!!.split("\n").filter { it.isNotBlank() }
    fun clear(ctx: Context) { ctx.getSharedPreferences("playback_log", Context.MODE_PRIVATE).edit().clear().apply() }

    /** Asks the server for the first bytes, to learn why a link failed (e.g. HTTP 403). */
    suspend fun probe(url: String): String = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        runCatching {
            val b = okhttp3.Request.Builder().url(url).header("Range", "bytes=0-1")
            StreamHeaders.forUrl(url).forEach { (k, v) -> runCatching { b.header(k, v) } }
            Api.http.newCall(b.build()).execute().use { r -> "HTTP ${r.code}" + (r.header("Content-Type")?.let { " · $it" } ?: "") }
        }.getOrElse { "network: ${it.javaClass.simpleName}" }
    }
}

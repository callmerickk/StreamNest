StreamX 0.9.44

• Better quality pops up sooner: StreamX asks for HD links in short, quick rounds and picks the fastest servers first.
• Servers that only show ad pages are skipped.
• Subtitles move up above the controls while they're on screen, so you can keep reading.
• Developer's Corner › Auto-play logic: undo the last change or bring back any earlier logic, plus a switch for the previous behaviour.
• Developer's Corner › Refresh Lab: measures when HD links appear and play.

---

StreamX TV 0.7.0 beta

• Every part works with the remote: the "How was it?" card, Audio & Subtitles sliders, Watch together, Edit profile.
• Quality is now simple: Instant, 4K, Full HD, Mid HD. Every link with its picture tags is in Sources.
• Better quality pops up by itself when a sharper source is ready; OK switches at the same moment.
• Next and Episodes buttons in the player; Watch Next posters open up with details.
• New loading screen: a heartbeat monitor with the real percentage loaded.
• Home's card deck fans out to the right; Continue Watching cards show the story, ratings and the next episode.
• My Space is your profile dashboard; Library has your watchlist, a calendar of new episodes, notifications and Clear all.
• Faster start, quicker profile opening, new Fire TV icon, and your TV's Continue Watching now reaches your phone.

---

StreamX TV 0.6.0 beta

• A new player made for the remote: ◀ ▶ jump 30 s, ▲ shows the timeline (10 s steps), ▼ opens Watch Next, Back clears everything.
• Quality and Audio & Subtitles at the top; Watch Next and ❯ More at the bottom, each opening a small StreamX bubble.
• Home's card deck slides, with the next cards stacked under it.
• New focus box: dark glass with a soft white edge.
• The search box works with the Fire TV keyboard and Alexa voice typing again.

---

StreamX 0.9.43 · StreamX TV 0.5.24 beta

• Chat in Watch together, with new messages popping up on the video.
• When the person who made the room leaves, the watch party ends for everyone.
• Your mic and camera stay off until you switch them on.
• Tap a ring or a WhatsApp invite link to join: pick your profile and you're in the room.
• Smoother start animation.

---

StreamX 0.9.42 · StreamX TV 0.5.23 beta

• VPN in Network & DNS: watch through another country, for StreamX only.
• Smart mode: only sources that don't work in India go through the VPN.
• Connect your own VPN (Proton VPN and others) by signing in once on its website.
• Speed test picks the fastest country; slow ones are skipped.
• StreamX was born on 10 October 2026 — now at the end of the Update Log.

---

StreamX 0.9.41 · StreamX TV 0.5.22 beta

• Talk and see each other in Watch together: friends appear in round bubbles you can move, resize and frame.
• Play and pause now happen for everyone at the same moment, and stay in sync while you watch.
• If someone's video is loading, everyone waits for them.
• All Watch together options in one place: the Watch together button on the player.
• StreamX asks once for notifications, microphone and camera (they stay off until you turn them on).

---

StreamX 0.9.40 · StreamX TV 0.5.21 beta

• Signing in on a new phone brings back everything from your account: addons, Quick Start, AI logo and settings.
• X's voice is saved with your account.
• Only one StreamX icon on the home screen.

---

StreamX 0.9.39 · StreamX TV 0.5.20 beta

• The new StreamX logo everywhere: app icon, start animation, sign-in, widget and notifications.
• Sharper posters in Picked for you.
• The AI logo and X's voice are now the same for everyone.

---

StreamX 0.9.38 · StreamX TV 0.5.19 beta

• New StreamX logo with a new opening animation, and six new app icons to choose from.
• Upgrade to HD works on mobile data again.
• Smoother playback when you pick a source yourself.
• Quality menu: the Instant section folds away so you can pick another quality faster.
• Addons with the same name stay separate, and each can have its own name.

---

StreamX 0.9.37 · StreamX TV 0.5.18 beta

• Videos start faster when the quick server is busy, and you get a clear message when a title isn't available yet.
• The Upgrade to HD shows up sooner and stays instant even after you jump in the video.
• Titles you watched in HD start in HD next time, and the next episode is made ready in HD near the end.
• Quality menu in three columns — 4K, 1080p, 720p — grouped by picture type, plus a Picture preference setting.
• Continue Watching: long-press a card for a smooth menu.
• Rename any addon.

---

StreamX 0.9.36 · StreamX TV 0.5.17 beta

• Connect PenguPlay with StreamX: sign in once and your own account joins the quick server, so videos start instantly even at busy times.
• Choosing a stream now has three parts: Quick play, Backup play (the best file plays automatically) and your own addons.
• Built-in servers are set up and kept up to date automatically.

---

StreamX 0.9.35 · StreamX TV 0.5.16 beta

• Videos start faster when the quick server is busy.
• A cleaner look: streams show quality, language and picture details, nothing technical.
• Share your setup with family, and choose whether your quick server account goes along.

---

StreamX 0.9.34 · StreamX TV 0.5.15 beta

• Quick play slow? After 6 s of silence on the title page, CNCVerse is asked again and HdHub's links are used too — the best file gets its first minute saved so Play is still instant. If MovieBox answers before Play, it takes over.
• In the player: after 5 s of silence, the other addons' links race at once instead of waiting 15–25 s.
• Instant plays are unchanged.

---

StreamX 0.9.33 · StreamX TV 0.5.14 beta

• Audio & Subtitles: source and provider names hidden in the audio details too.
• Fixed: the app closed in the background during Watch together (the host's player was read from the wrong thread every 3 s).

---

StreamX 0.9.32 · StreamX TV 0.5.13 beta

• Addons › Backup & move: Export (save a file to your phone, or send to the cloud and get a code — with a Copy button) and Import (from a file or a code), with Replace or Merge.
• Quick play with PenguPlay + AIOStreams: AIOStreams' MovieBox links count for quick play; its other servers stay in All sources.
• The StreamX formatter's new fields (quality type, visual tags, audio, channels) are read exactly — for Sources tags and the cam filter.
• Fixed: leaving the title page could cancel the player's own addon request ("no answer… cancelled").

---

StreamX 0.9.31 · StreamX TV 0.5.12 beta

• Fewer requests to the addons' servers: the title page, player, upgrade search and Sources now share one request per title — the main reason MovieBox started refusing us.
• MovieBox answers nothing or "busy" → asked once more after a moment.
• No MovieBox link → the title page prepares the best HD file instead (first minute saved), so Play still starts at once.
• Cam / TS / DVDScr copies are hidden when a proper WEB or BluRay release exists.
• Play timing now shows what each addon answered and how fast.

---

StreamX 0.9.30 · StreamX TV 0.5.11 beta

• Quick play is MovieBox-first again: its streaming playlist starts in a fraction of a second, ahead of HdHub / CNCVerse files (they take 3–8 s) — then Upgrade quality brings the HD file.
• The Source Test only puts addons that start within 2 s into Quick Start.

---

StreamX 0.9.29 · StreamX TV 0.5.10 beta

• Quick play is instant again: 0.9.28 changed the subtitle choice while the video was still opening, which made it start over (5–6 s of buffering).
• Upgrade quality is back, with a real jump test: an HD file is offered only if a piece from its middle comes back.
• Subtitles: "In this video" now lists only the subtitles really inside the file; the ones loaded with the link or from subtitle addons are under Online (no more "0 online").

---

StreamX 0.9.28 · StreamX TV 0.5.9 beta

• Upgrade quality only offers files you can jump inside (no streaming playlists that can't seek).
• Subtitles: Hindi audio → off by default (pick one if you want); English or any other language → English subtitles on.
• Subtitles inside the video show just the language and kind (English, English – SDH, Forced) — no provider names.

---

StreamX 0.9.27 · StreamX TV 0.5.8 beta

• Updates: the pop-up always shows the newest build (it could show the one before for up to 10 minutes), and installs exactly the version it shows.

---

StreamX 0.9.26 · StreamX TV 0.5.7 beta

• Sources by visual tag: Dolby Vision, HDR10+, HDR10, SDR… Inside, each file shows only quality, picture tags, sound (e.g. DD+ 5.1) and size — no server or provider names.
• The first file of the top 3 tag groups is saved ahead (⚡ Ready) and starts at once.
• Dev sources (› menu) for accounts chosen in Developer's Corner: every source with its server, as before.
• Subtitles in focus: a header card showing what's on and what auto sync is doing.

---

StreamX 0.9.25 · StreamX TV 0.5.6 beta

• HD while quick play runs: 2 Full HD files and 1 4K file (best working servers) get their start and index saved in the background — they open in about a second.
• Quality menu: Quick (with its real quality) · 4K · Full HD · Mid HD, each with its quality; a red tick = ready.
• CNCVerse is asked from the title page on, and once more ~20 s after the start, so Vegamovies links are there for the upgrade.
• Audio: switching back to a language (Hindi → Original → Hindi) plays that same Hindi stream again, at once.
• Quick play shows just the "Serving it fresh" scene (it starts in a moment); all-addon plays keep both scenes.
• Subtitles: five online subtitles downloaded at once; auto sync keeps the one that fits the talking best and lines it up every 30 s until it fits.

---

StreamX 0.9.24 · StreamX TV 0.5.5 beta

• Upgrade quality / Upgrade to 4K rebuilt: as soon as MovieBox starts, HD links are gathered (HdHub, AIOStreams, CNCVerse asked every 2 s), the best working server is checked and its start, index and the next seconds are saved — then the offer shows, and one tap switches instantly.
• Sources during a quick play: only servers that play, in ranking order (dead and web-page servers left out).

---

StreamX 0.9.23 · StreamX TV 0.5.4 beta

• Audio & Subtitles: the three columns (Audio · Subtitles · Style & timing) are now equal, with the same gap between them, and centred.

---

StreamX 0.9.22 · StreamX TV 0.5.3 beta

• Audio & Subtitles back to the clean rows: language name, a small ⓘ with the details (codec, channels, quality), a red tick on the one playing — in three sections (Audio · Subtitles · Style & timing).
• Subtitles inside the video are picked automatically; online ones (English by default) only when the video has none, downloaded right after play starts.
• Adjust timing: − and + buttons (0.1 s per tap, hold to keep going), an Auto sync switch and a Sync now button right there; auto sync checks sooner and tells you what it did.
• Upgrade offer fixed: it no longer needs a second picture decoder to check the HD file, waits less for slow addons, and accepts dual-audio files. Its steps show in Play timing.

---

StreamX 0.9.21 · StreamX TV 0.5.2 beta

• Source Test fixed: its hidden player no longer jams the phone's video decoder (most links were failing for that); MovieBox playlists now count as the fast, seekable links they are.
• Audio & Subtitles: every audio track and subtitle at once, grouped by language; your chosen audio language is remembered per title (also in Continue Watching).
• Quality menu opens instantly; › sits under the end of the progress bar.
• Upgrade offer shows as soon as a better HD file is ready (30 s countdown), and again 5 s after any jump.
• Title page prepares much faster (it no longer waits for subtitles).
• Faster search (exact title first) with a 🎤 voice search button, and a faster ready light.
• X (AI): the voice you pick is really used.
• Double-tap jumps 10 s (no more 30 s bubble).
• Info in the player works again; the 50 % starting volume only applies to earphones / Bluetooth.

---

StreamX 0.9.20 · StreamX TV 0.5.1 beta

• Every player pop-up grows out of its own button (Watch Next, Episodes, Watch together, › More…).
• › opens a small bubble with the extra options.
• Audio list fixed (was empty after a ready start).
• Quality menu: exact levels (720p in HD 720p), 4K only when playing / chosen.
• Share / Invite fixed; glass back buttons in Settings.

---

StreamX 0.9.19 · StreamX TV 0.5.0 beta

• Trailer mode: one round through every card's trailer, screen kept on, turns itself off; animated notes.
• Brighter card trailers with an animated backdrop instead of black.
• Top cards: picks for you and new arrivals mixed in.
• New player engine (Media3 1.7) with FFmpeg audio + video decoders (NextLib).
• DNS status light in Network & DNS.
• X (AI): greets you every time, your chosen voice, spinning logo.

---

StreamX 0.9.18 · StreamX TV 0.4.9 beta

• Quick start + Upgrade to 4K: MovieBox starts at once, a sharper file is saved silently, one tap upgrades.
• Watch together: Share / Invite (link copied), remembered friends, 🔔 ring to call them in.
• Subtitle auto sync for online subtitles.
• Home source kept ready for instant starts.
• Addons: Configure button and pinning (Cinemeta and OpenSubtitles always on top).

---

StreamX 0.9.17 · StreamX TV 0.4.8 beta

• New Audio & Subtitles: bubble from its button, ticks and ⓘ details, subtitle stacks, online subtitles without reloading, timing and size sliders.
• MovieBox: all languages together and saved ahead; no-language files = original audio; .mpd playlists first.
• Wrong-title links skipped (Dune vs Dune: Prophecy); real quality from file names.
• Age guide and the real picture size when a video starts.
• Switching capsule with a progress ring; controls fixes.
• Memory-sized buffers; faster seeking.
• Update pop-up at app start; Hotstar-style card glide; card trailers fixed.

---

StreamX 0.9.16 · StreamX TV 0.4.7 beta

• Links race on real video; a backup link is saved quietly for instant switching.
• Servers ranked by your real plays: failing servers (FSL) go last; pixeldrain gets more time.
• One refusal = that server goes last for this play; no repeated tries; fewer VLC detours.
• MovieBox: Hindi → English → Original audio before quality; playlists count as seekable; one server for all dubs.
• Quality worked out for links that don't name it.
• Card trailers show the whole video (no zoom).
• Logs: which addons answered; server results from real plays.

---

StreamX 0.9.15 · StreamX TV 0.4.6 beta

• Fast start: Play opens the player at once; the best 3 links race; links already found are reused.
• Parallel download (IDM-style pieces) for faster starts and smoother 4K.
• Shared-server header fix (VA Player, MovieBox, pengu.uk); addon cookies kept.
• Green light = paused player really ready; broken paused player replaced; smarter stall switch; no VLC on refused links.
• Player: flat play/pause, tap-to-hide fixed, new button order with depth, Watch together icon, Sound in Audio & Subtitles.
• First-time visual tour; Plugins section; fingerprint for Developer's Corner; screen awake during Source Test.
• Card trailer placement reworked with an automatic black-screen fallback.

---

StreamX 0.9.14 · StreamX TV 0.4.5 beta

• User manual in Settings: every feature explained, searchable.
• Watch together: rooms with a 4-letter code, synced play/pause/seek, reactions.
• Downloads for offline viewing (title page › ⋯ › Download; My Space › Downloads).
• Home screen widget: Continue watching with Resume.
• GIF search for profile pictures (GIPHY key in Integrations).
• Search: moods and Surprise me.

---

StreamX 0.9.13 · StreamX TV 0.4.4 beta

• Faster green light: links checked as soon as fast addons answer; paused player ready after ~15 s saved.
• Dolby Vision plays on phones without a DV decoder (HDR base layer, like Nuvio).
• Browser-like cookies: MovieBox / VA Player links should now play.
• Stuck links switched after 8–10 s; refused links skip VLC and go to the next source.
• Tested sources only: failing groups and dead servers hidden. CNCVerse refreshed every 2 s.
• Profile lock with PIN + fingerprint unlock (Developer's Corner).
• Player: centre play/pause, controls stay while touched, rounded fading button row, sleep timer, audio boost, night mode, picture-in-picture, auto-skip intro, next-episode ring.
• Animated hanging-X logo, smoother card sliding, tablet-friendly card size, trailer black-screen fix.
• AI: logo syncs across phones, voice picker + speed, no emoji read aloud.

---

StreamX 0.9.12 · StreamX TV 0.4.3 beta

• Green light = a paused player is already waiting: Play starts in under a second.
• Play timing log in Developer's Corner (each step of every Play press, with times).
• CNCVerse is asked again every 5 s until a video plays.
• Source Test: VA Player headers fixed; can auto-arrange addons and Quick Start.
• Backup search skips failed links, follows the ranking, avoids REMUX/TrueHD; Dolby Vision-only files last on phones without DV.
• Home card trailers centred.
• Update pop-up on every start: Update now / Later / Skip this version.

---

StreamX 0.9.11 · StreamX TV 0.4.2 beta

• Status light on the Play button (green = instant, amber = normal, red = no stream; long-press for details).
• Dead links (web pages, not found, expired signed links) hidden from Sources.
• Faster starts: no second "file type" request when the server already said it.
• Source Test: popular titles only, 429 retried and not counted, results add up across runs.
• Phone: home card trailers bigger/centred, sound on by default.
• TV: no automatic trailers; keyboard opens only on OK.
• Animated profile pictures stay animated on other devices.

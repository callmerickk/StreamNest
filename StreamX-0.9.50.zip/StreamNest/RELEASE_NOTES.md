StreamX 0.9.50

• Updates keep downloading when you minimise StreamX (with a notification), plus a Download in background button.
• New bottom bar: Home, Search, Library and Profile — hold Profile and slide up to switch profiles.
• A bell at the top of Home for notifications; the TV / Movies / Live switch is gone.
• Hold any poster for its trailer and ratings.
• Turbo is the default way to watch (recommended): streams start almost instantly; Classic is one tap away.
• Settings › Sources & Extensions, Extensions and Filters with your own rules.
• Netflix-style subtitles, smarter auto sync and Follow the speaker (beta).
• Faster seek previews; Continue Watching and episodes start faster.
• Fixes: plugin settings no longer close the app, Proton VPN sign-in, GIF search.

---

StreamX TV 0.7.5 beta

• Trailers on the home screen are switched off for now, so moving around is smooth again.
• Loading screen: a calm dark background, with the moment playing inside the card and the progress around its edge.

---

StreamX TV 0.7.4 beta

• Search waits for you: type, then press Search. It no longer crashes the Fire TV Stick.
• New loading screen: a large card with the progress around its edge and the heartbeat line under it, over a blurred picture.
• The loading screen goes away as soon as the video plays.
• The Next episode pop-up shows near the end of every episode.
• Trailers are back in the big Home card, playing as real video.

---

StreamX 0.9.47 · StreamX TV 0.7.3 beta

Phone
• Watch together is a full page: watch friends, introductions (everyone decides who can see them), shared lists with plans, chats and privacy.
• Watchlist calendar: new episodes, release days and your plans; everyone in a plan is reminded at the same time and can join the room.
• Chats: one-to-one with view-once photos (screenshots blocked) and a 24 h – 7 day keep time; groups are text only and clear after 24 hours.
• My Space: your own dashboard, Library and Watch together, Watchlist, Notifications, Clear Continue Watching.
• Upgrade quality pops up again when a sharper file is ready.
• GIF profile pictures without any key, or paste any GIF link.

TV
• Upgrade quality ring fits and the pill goes away when its time ends; movies keep Next inside More.
• Lighter loading screen; Choose manually, pop-ups, Settings and Search work properly with the remote; bigger search keys and Fire TV voice typing.

---

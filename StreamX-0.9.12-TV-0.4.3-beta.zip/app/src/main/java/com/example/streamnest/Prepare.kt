package com.example.streamnest

import android.content.Context
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/** What the title page has prepared for instant play. */
data class Prepared(
    val key: String,
    /** Short status shown under the Play button. */
    val status: String,
    val progress: Float = 0f,
    /** Saved enough: Play starts straight from storage. */
    val ready: Boolean = false,
    /** Nothing could be prepared: Play uses the normal search. */
    val failed: Boolean = false,
    val item: StreamItem? = null,
    val list: List<StreamItem> = emptyList(),
    val subs: List<Subtitle> = emptyList(),
    /** Bytes saved so far and the target. */
    val saved: Long = 0, val target: Long = 0,
)

/**
 * Instant play: as soon as a title page opens, the streams are found, the best link (your quality group → language →
 * Source Test ranking) is checked, and its first minute — or the minute from your resume point — is saved to storage.
 * Play then starts from storage like a file on a hard disk. If a link refuses, the next one is tried.
 */
object Prepare {
    val state = MutableStateFlow<Prepared?>(null)
    private var job: Job? = null
    private var saveJob: Job? = null
    private var lastResume = 0L
    private var preparedAt = 0L

    /** Links of each title that failed while preparing: the player's own search never tries them again. */
    private val failed = java.util.concurrent.ConcurrentHashMap<String, MutableSet<String>>()
    fun failedFor(id: String): Set<String> = failed[id]?.toSet().orEmpty()

    fun start(vm: AppViewModel, ctx: Context, type: String, id: String, resumeMs: Long, durMs: Long?, quick: Boolean, level: String) {
        val cur = state.value
        // Same title, same resume point (within 30 s), prepared or still preparing: keep it.
        val sameSpot = kotlin.math.abs(resumeMs - lastResume) < 30_000 && System.currentTimeMillis() - preparedAt < 15 * 60_000L
        if (cur != null && cur.key == id && sameSpot && !cur.failed && (job?.isActive == true || cur.ready)) return
        cancel()
        lastResume = resumeMs
        preparedAt = System.currentTimeMillis()
        state.value = Prepared(id, "Finding streams…")
        job = vm.viewModelScope.launch {
            var list = runCatching { if (quick) vm.quickStreams(type, id) else vm.allStreams(type, id) }.getOrDefault(emptyList())
            val subs = withTimeoutOrNull(2500) { runCatching { vm.subtitles(type, id) }.getOrDefault(emptyList()) }.orEmpty()
            val tried = HashSet<String>()
            val bad = failed.getOrPut(id) { java.util.concurrent.ConcurrentHashMap.newKeySet() }
            var lastWhy = ""

            /** Checks one link and saves its start. true = ready. */
            suspend fun attempt(s: StreamItem, i: Int, n: Int): Boolean {
                val url = s.stream.url ?: return false
                val label = "${Ranker.labelOf(Ranker.groupKey(s)).substringAfter(" · ", "")} · ${qualityName(s.resolution())}"
                state.value = Prepared(id, "Checking ${i + 1}/$n · $label", list = list, subs = subs)
                StreamCache.register(s)
                val pr = StreamCache.probe(url)
                if (!pr.ok) {
                    lastWhy = pr.error ?: "HTTP ${pr.status}"
                    bad += url
                    // Dead (web page / not found / bad request): never again. Busy (429) or expired (403): just the next one.
                    if (Ranker.isDeadReason(pr.status, pr.type)) { Ranker.markDeadUrl(url); Ranker.recordFail(s, "prepare: $lastWhy") }
                    return false
                }
                // Playlists (HLS / DASH) stream in small pieces: nothing to save, they start fast.
                val mime = StreamType.mimeFor(url, s.stream.behaviorHints?.filename)
                if (mime != null) {
                    state.value = Prepared(id, "Ready · streaming playlist · $label", 1f, ready = true, item = s, list = list, subs = subs)
                    readyPlayer(vm, ctx, id, s, url, mime, subs, list, resumeMs)
                    return true
                }
                if (!pr.seekable) { lastWhy = "file can't be jumped inside (not seekable)"; bad += url; return false }
                // One minute from the start (or from your resume point); very big files: ~15 seconds.
                val perMin = minuteBytes(s, pr.size, durMs)
                val big = perMin > 150L * 1024 * 1024
                val want = if (big) perMin / 4 else perMin
                val startByte = if (resumeMs > 5_000 && pr.size > 0 && durMs != null && durMs > 0)
                    ((pr.size.toDouble() * resumeMs / durMs).toLong() - 2L * 1024 * 1024).coerceAtLeast(0L) / (1024 * 1024) * (1024 * 1024)
                else 0L
                val len = if (pr.size > 0) minOf(want, pr.size - startByte) else want
                val minStart = if (big) want else want / 4 // enough to start without waiting
                state.value = Prepared(id, "Saving ${if (big) "15 s" else "1:00"} · $label", 0f, item = s, list = list, subs = subs, target = len)
                // Many files keep their index at the end (MP4 "moov", MKV "cues" for jumping to your resume point):
                // save the end too, so the player never has to fetch it before starting.
                if (pr.size > 40L * 1024 * 1024) {
                    val mp4 = url.contains(".mp4", true) || s.stream.behaviorHints?.filename?.endsWith(".mp4", true) == true
                    val tail = if (mp4) minOf(24L * 1024 * 1024, pr.size / 60) else minOf(8L * 1024 * 1024, pr.size / 200)
                    StreamCache.save(ctx, url, pr.size - tail, tail) { }
                }
                val err = StreamCache.save(ctx, url, startByte, len) { f ->
                    val done = (len * f).toLong()
                    state.value = Prepared(id, if (done >= minStart) "Ready · saving more ${(f * 100).toInt()}% · $label" else "Saving ${(f * 100).toInt()}% · $label",
                        f, ready = done >= minStart, item = s, list = list, subs = subs, saved = done, target = len)
                }
                if (err == null) {
                    state.value = Prepared(id, "⚡ Ready to play instantly · ${if (big) "15 s" else "1:00"} saved · $label", 1f, ready = true,
                        item = s, list = list, subs = subs, saved = len, target = len)
                    readyPlayer(vm, ctx, id, s, url, null, subs, list, resumeMs)
                    return true
                }
                // Saving failed half-way: still fine to play if enough is saved.
                val now = state.value
                if (now != null && now.ready) { state.value = now.copy(status = "Ready · ${(now.progress * 100).toInt()}% saved · $label"); return true }
                lastWhy = err
                return false
            }

            while (true) {
                val cands = vm.rankedCandidates(list, level, quickOnly = quick).filter { it.stream.url !in tried }.take(5)
                for ((i, s) in cands.withIndex()) {
                    s.stream.url?.let { tried += it }
                    if (attempt(s, i, cands.size)) return@launch
                }
                // Nothing worked (yet). A slow addon (CNCVerse) may still bring links: wait for them.
                if (!SlowAddons.watching(id)) break
                state.value = Prepared(id, "Waiting for more links (CNCVerse is still collecting)…", list = list, subs = subs)
                val known = list.mapNotNull { it.stream.url }.toSet() + tried
                val m = withTimeoutOrNull(90_000) {
                    SlowAddons.links.first { mm -> mm[id].orEmpty().any { it.stream.url != null && it.stream.url !in known } }
                }
                val more = m?.get(id)?.filter { it.stream.url != null && it.stream.url !in known } ?: break
                list = vm.filtered((list + more).distinctBy { it.stream.url }).list
            }
            state.value = Prepared(id, "Couldn't prepare (${lastWhy.ifBlank { "no link answered" }}) — Play will search again",
                failed = true, list = list, subs = subs)
        }
    }

    /**
     * Phones: once the start is saved, a player opens it in the background and waits, paused, so Play shows the video
     * in a fraction of a second (the player is handed over). Not on TV (memory).
     */
    private fun readyPlayer(vm: AppViewModel, ctx: Context, id: String, s: StreamItem, url: String, mime: String?, subs: List<Subtitle>, list: List<StreamItem>, resumeMs: Long) {
        if (BuildConfig.IS_TV || Preloader.has(id)) return
        runCatching {
            val p = buildPlayer(ctx, vm, true)
            p.setMediaItem(androidx.media3.common.MediaItem.Builder().setUri(url).apply { if (mime != null) setMimeType(mime) }
                .setSubtitleConfigurations(subtitleConfigs(subs)).build(), resumeMs)
            p.playWhenReady = false
            p.prepare()
            Preloader.set(Preloaded(id, url, subs, s.stream.name ?: s.addonName, s.addonName, list, p))
        }
    }

    /** Stop downloading (Play was pressed — the player takes over; what was saved stays saved). */
    fun stopSaving() { job?.cancel(); job = null }

    fun cancel() { job?.cancel(); job = null; saveJob?.cancel(); saveJob = null }

    fun qualityName(res: Int): String = when { res >= 1440 -> "4K"; res >= 1080 -> "1080p"; res >= 720 -> "720p"; res > 0 -> "${res}p"; else -> "SD" }

    /**
     * While a video plays: save one minute (from the current point) of the top-ranked links in the other quality groups,
     * so switching quality starts almost at once. Runs one link at a time.
     */
    fun saveOthers(vm: AppViewModel, ctx: Context, list: List<StreamItem>, playingUrl: String, posMs: Long, durMs: Long) {
        saveJob?.cancel()
        saveJob = vm.viewModelScope.launch {
            val playing = list.firstOrNull { it.stream.url == playingUrl }
            val levels = listOf("4k", "fhd", "mhd").filter { lv -> playing == null || Ranker.tier(playing.resolution()) != Ranker.tier(AllQualityLevels.first { it.id == lv }.res) }
            for (lv in levels) {
                val s = vm.rankedCandidates(list, lv, quickOnly = true).firstOrNull { it.stream.url != playingUrl &&
                    Ranker.tier(it.resolution()) == Ranker.tier(AllQualityLevels.first { q -> q.id == lv }.res) } ?: continue
                val url = s.stream.url ?: continue
                if (isPlaylistLink(s, url)) continue
                StreamCache.register(s)
                val pr = StreamCache.probe(url)
                if (!pr.ok || !pr.seekable || pr.size <= 0) continue
                val perMin = minuteBytes(s, pr.size, durMs)
                val start = ((pr.size.toDouble() * posMs / durMs.coerceAtLeast(1)).toLong() - 1024 * 1024).coerceAtLeast(0L) / (1024 * 1024) * (1024 * 1024)
                StreamCache.save(ctx, url, start, minOf(perMin, pr.size - start)) { }
            }
        }
    }

    fun stopOthers() { saveJob?.cancel(); saveJob = null }
}

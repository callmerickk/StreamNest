StreamX 0.9.12 · StreamX TV 0.4.3 beta

• Green light = a paused player is already waiting: Play starts in under a second.
• Play timing log in Developer's Corner (each step of every Play press, with times).
• CNCVerse is asked again every 5 s until a video plays.
• Source Test: VA Player headers fixed; can auto-arrange addons and Quick Start.
• Backup search skips failed links, follows the ranking, avoids REMUX/TrueHD; Dolby Vision-only files last on phones without DV.
• Home card trailers centred.
• Update pop-up on every start: Update now / Later / Skip this version.

---

StreamX 0.9.11 · StreamX TV 0.4.2 beta

• Status light on the Play button (green = instant, amber = normal, red = no stream; long-press for details).
• Dead links (web pages, not found, expired signed links) hidden from Sources.
• Faster starts: no second "file type" request when the server already said it.
• Source Test: popular titles only, 429 retried and not counted, results add up across runs.
• Phone: home card trailers bigger/centred, sound on by default.
• TV: no automatic trailers; keyboard opens only on OK.
• Animated profile pictures stay animated on other devices.
